# Authentication Features Documentation

This document describes the advanced authentication features added to the auth service: Google OAuth, Multi-Factor Authentication (MFA), and Email/SMS Verification.

## Features Overview

### 1. Google OAuth / "Sign in with Google"
- OAuth 2.0 integration with Google
- Automatic user creation or account linking
- JWT token generation after OAuth flow

### 2. Multi-Factor Authentication (MFA)
- TOTP-based MFA using authenticator apps (Google Authenticator, Authy, etc.)
- QR code generation for easy setup
- Backup codes for account recovery
- Optional MFA requirement during login

### 3. Email/SMS Verification
- Email verification codes (6-digit)
- SMS verification codes (via Twilio)
- Code expiration (15 minutes)
- One-time use codes

## Database Schema

### New Tables
- `auth.oauth_providers` - Stores OAuth provider accounts linked to users
- `auth.mfa_settings` - Stores TOTP secrets and backup codes
- `auth.verification_codes` - Stores email/SMS verification codes

### Extended Users Table
- `phone` - Phone number for SMS verification
- `email_verified` - Email verification status
- `phone_verified` - Phone verification status
- `mfa_enabled` - MFA enabled flag
- `updated_at` - Last update timestamp

## API Endpoints

### OAuth
- `GET /auth/google` - Initiate Google OAuth flow
- `GET /auth/google/callback` - Handle Google OAuth callback

### MFA
- `POST /mfa/setup` - Setup MFA (returns secret, QR code, backup codes)
- `POST /mfa/verify` - Verify MFA code and enable MFA
- `POST /mfa/disable` - Disable MFA (requires code verification)
- `POST /mfa/verify-login` - Verify MFA code during login

### Verification
- `POST /verify/email/send` - Send email verification code
- `POST /verify/email/verify` - Verify email code
- `POST /verify/phone/send` - Send SMS verification code
- `POST /verify/phone/verify` - Verify phone code

### Updated Endpoints
- `POST /login` - Now supports MFA (returns `requiresMFA: true` if MFA enabled)
- `POST /register` - Optionally sends verification email
- `GET /me` - Returns verification and MFA status

## Environment Variables

### Google OAuth
```bash
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GOOGLE_CALLBACK_URL=http://localhost:4001/auth/google/callback
FRONTEND_URL=http://localhost:3001
```

### Email (SMTP)
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
SMTP_FROM=noreply@record-platform.com
```

### SMS (Twilio)
```bash
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_FROM_NUMBER=+1234567890
```

## Setup Instructions

### Quick Setup (Automated) ✅ Recommended

Run the setup script from the repository root:
```bash
./scripts/setup-auth-service.sh
```

This will:
1. ✅ Check prerequisites (psql, pnpm)
2. ✅ Run the database migration
3. ✅ Install dependencies
4. ✅ Generate Prisma client
5. ✅ Check environment variables
6. ✅ Show Google OAuth setup instructions

**Custom database connection:**
```bash
DB_HOST=localhost DB_PORT=5437 DB_USER=postgres DB_NAME=records DB_PASSWORD=postgres ./scripts/setup-auth-service.sh
```

### Manual Setup

#### 1. Database Migration
Run the extended schema migration:
```bash
psql -h localhost -p 5437 -U postgres -d records -f infra/db/07-auth-schema-extended.sql
```

**Note**: The migration is idempotent - safe to run multiple times. It will only add columns/tables that don't exist.

#### 2. Install Dependencies
```bash
cd services/auth-service
pnpm install
```

#### 3. Generate Prisma Client
```bash
pnpm prisma generate
```

#### 4. Configure Environment Variables

**For Kubernetes Deployment:**
Update `infra/k8s/base/config/app-secrets.yaml` with your credentials:
```yaml
stringData:
  GOOGLE_CLIENT_ID: "your_client_id"
  GOOGLE_CLIENT_SECRET: "your_client_secret"
  SMTP_HOST: "smtp.gmail.com"
  SMTP_USER: "your_email@gmail.com"
  SMTP_PASSWORD: "your_app_password"
  TWILIO_ACCOUNT_SID: "your_account_sid"
  TWILIO_AUTH_TOKEN: "your_auth_token"
  TWILIO_FROM_NUMBER: "+1234567890"
```

**For Local Development:**
Create a `.env` file in `services/auth-service/` or export variables:
```bash
export GOOGLE_CLIENT_ID="your_client_id"
export GOOGLE_CLIENT_SECRET="your_client_secret"
export SMTP_HOST="smtp.gmail.com"
export SMTP_USER="your_email@gmail.com"
export SMTP_PASSWORD="your_app_password"
export TWILIO_ACCOUNT_SID="your_account_sid"
export TWILIO_AUTH_TOKEN="your_auth_token"
export TWILIO_FROM_NUMBER="+1234567890"
```

### 5. Google OAuth Setup
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable Google+ API
4. Create OAuth 2.0 credentials
5. Add authorized redirect URI: `http://localhost:4001/auth/google/callback`
6. Set `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`

### 6. Email Setup (Gmail Example)
1. Enable 2-Step Verification
2. Generate App Password
3. Set `SMTP_USER` and `SMTP_PASSWORD`

### 7. SMS Setup (Twilio)
1. Sign up for [Twilio](https://www.twilio.com/)
2. Get Account SID and Auth Token
3. Purchase a phone number
4. Set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM_NUMBER`

## Usage Examples

### Google OAuth Flow
1. User clicks "Sign in with Google"
2. Redirects to `/auth/google`
3. User authorizes on Google
4. Callback to `/auth/google/callback`
5. Redirects to frontend with JWT token

### MFA Setup Flow
1. User calls `POST /mfa/setup` (authenticated)
2. Receives secret, QR code, and backup codes
3. User scans QR code with authenticator app
4. User calls `POST /mfa/verify` with code from app
5. MFA is enabled

### Login with MFA
1. User calls `POST /login` with email/password
2. If MFA enabled, returns `{ requiresMFA: true, userId: "..." }`
3. User calls `POST /mfa/verify-login` with userId and code
4. User receives JWT token

### Email Verification Flow
1. User calls `POST /verify/email/send` with email
2. Receives 6-digit code via email
3. User calls `POST /verify/email/verify` with email and code
4. Email is verified

## Security Considerations

- **Verification codes**: Hashed before storage, expire after 15 minutes
- **Backup codes**: Hashed before storage, removed after use
- **TOTP secrets**: Stored securely, never exposed to frontend
- **OAuth tokens**: Not stored, only profile data cached
- **Rate limiting**: Consider adding rate limiting for verification endpoints

## Frontend Integration

### Google OAuth Button
```tsx
<a href="http://localhost:4001/auth/google">Sign in with Google</a>
```

### MFA Setup
```typescript
// Setup MFA
const response = await fetch('/mfa/setup', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` }
});
const { qrCode, backupCodes } = await response.json();

// Display QR code
<img src={qrCode} alt="MFA QR Code" />

// Verify and enable
await fetch('/mfa/verify', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` },
  body: JSON.stringify({ code: userEnteredCode })
});
```

### Login with MFA
```typescript
// Step 1: Login
const loginRes = await fetch('/login', {
  method: 'POST',
  body: JSON.stringify({ email, password })
});
const loginData = await loginRes.json();

if (loginData.requiresMFA) {
  // Step 2: Get MFA code from user
  const mfaCode = prompt('Enter MFA code:');
  
  // Step 3: Verify MFA
  const verifyRes = await fetch('/mfa/verify-login', {
    method: 'POST',
    body: JSON.stringify({ userId: loginData.userId, code: mfaCode })
  });
  
  if (verifyRes.ok) {
    // Step 4: Complete login (get token from original login)
    // Note: You may need to adjust the flow based on your implementation
  }
}
```

## Testing

### Test OAuth (without Google setup)
- OAuth routes will log warnings but won't crash
- Test with mock Google credentials in development

### Test MFA
```bash
# Setup MFA
curl -X POST http://localhost:4001/mfa/setup \
  -H "Authorization: Bearer YOUR_TOKEN"

# Verify MFA
curl -X POST http://localhost:4001/mfa/verify \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"code": "123456"}'
```

### Test Email Verification
```bash
# Send code
curl -X POST http://localhost:4001/verify/email/send \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com"}'

# Verify code
curl -X POST http://localhost:4001/verify/email/verify \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com", "code": "123456"}'
```

## Future Enhancements

- [ ] Additional OAuth providers (GitHub, Microsoft, etc.)
- [ ] WebAuthn/FIDO2 support
- [ ] SMS fallback for MFA
- [ ] Rate limiting for verification endpoints
- [ ] Admin dashboard for MFA management
- [ ] Audit logging for security events

