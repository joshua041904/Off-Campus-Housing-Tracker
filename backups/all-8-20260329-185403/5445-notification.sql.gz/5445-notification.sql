--
-- PostgreSQL database dump
--

\restrict DqByhcB7UQsndViqzgOVzbuQboR7evPDCYhGDccvNmxzjyoDlfMzPpSzPrU2hft

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notification; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA notification;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: notification_channel; Type: TYPE; Schema: notification; Owner: -
--

CREATE TYPE notification.notification_channel AS ENUM (
    'email',
    'sms',
    'push'
);


--
-- Name: notification_status; Type: TYPE; Schema: notification; Owner: -
--

CREATE TYPE notification.notification_status AS ENUM (
    'pending',
    'sent',
    'failed',
    'retrying'
);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: notification; Owner: -
--

CREATE FUNCTION notification.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: notifications; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type text NOT NULL,
    channel notification.notification_channel NOT NULL,
    status notification.notification_status DEFAULT 'pending'::notification.notification_status NOT NULL,
    payload jsonb NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE notifications; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.notifications IS 'Every notification attempt. Update status after delivery/retry; optional notification.sent event for analytics.';


--
-- Name: outbox_events; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.outbox_events IS 'Transactional outbox for optional NotificationSentV1 emit; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON COLUMN notification.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON COLUMN notification.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.processed_events IS 'Idempotent consumer: check event_id before processing; insert after successful handle; then commit offset.';


--
-- Name: user_preferences; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.user_preferences (
    user_id uuid NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    booking_alerts boolean DEFAULT true NOT NULL,
    message_alerts boolean DEFAULT true NOT NULL,
    moderation_alerts boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_preferences; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.user_preferences IS 'Per-user notification preferences. Check before sending; never block domain flows.';


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.notifications (id, user_id, event_type, channel, status, payload, attempt_count, last_attempt_at, created_at) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.processed_events (event_id, processed_at) FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.user_preferences (user_id, email_enabled, sms_enabled, push_enabled, booking_alerts, message_alerts, moderation_alerts, updated_at) FROM stdin;
79c8c1ff-df19-4702-987e-0b60f0ee3fb4	t	f	t	t	t	t	2026-03-29 05:11:32.416199+00
ae456eb6-60fa-4b43-9fdb-aaefc61472fd	t	f	t	t	t	t	2026-03-29 05:15:02.927335+00
3f0abec3-950a-45af-a8b9-27a70b9b9792	t	f	t	t	t	t	2026-03-29 05:45:56.131204+00
f99aaced-de3d-47dd-8349-defe2545da34	t	f	t	t	t	t	2026-03-29 05:53:26.548842+00
\.


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: idx_notification_outbox_unpublished; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notification_outbox_unpublished ON notification.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_notifications_pending_retrying; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_pending_retrying ON notification.notifications USING btree (status) WHERE (status = ANY (ARRAY['pending'::notification.notification_status, 'retrying'::notification.notification_status]));


--
-- Name: idx_notifications_status; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_status ON notification.notifications USING btree (status);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_user ON notification.notifications USING btree (user_id, created_at DESC);


--
-- Name: user_preferences tr_user_preferences_updated; Type: TRIGGER; Schema: notification; Owner: -
--

CREATE TRIGGER tr_user_preferences_updated BEFORE UPDATE ON notification.user_preferences FOR EACH ROW EXECUTE FUNCTION notification.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict DqByhcB7UQsndViqzgOVzbuQboR7evPDCYhGDccvNmxzjyoDlfMzPpSzPrU2hft

