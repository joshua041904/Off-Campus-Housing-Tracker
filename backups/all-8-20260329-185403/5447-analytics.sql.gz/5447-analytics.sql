--
-- PostgreSQL database dump
--

\restrict BLrkfaQbTUJGDsxRKHIb2Si8EsQ6wit5ymdPiMHE48KxrZT1ltHniGhWnSZfSnq

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: analytics; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA analytics;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: analytics; Owner: -
--

CREATE FUNCTION analytics.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_metrics; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.daily_metrics (
    date date NOT NULL,
    new_users integer DEFAULT 0 NOT NULL,
    new_listings integer DEFAULT 0 NOT NULL,
    new_bookings integer DEFAULT 0 NOT NULL,
    completed_bookings integer DEFAULT 0 NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    listings_flagged integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE daily_metrics; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.daily_metrics IS 'Precomputed daily aggregates. Updated when consuming domain events.';


--
-- Name: events; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type text NOT NULL,
    event_version integer DEFAULT 1 NOT NULL,
    payload jsonb NOT NULL,
    source_service text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    event_id uuid NOT NULL
);


--
-- Name: TABLE events; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.events IS 'Immutable event log. Ground truth for analytics. Project into aggregates; do not normalize event schema.';


--
-- Name: COLUMN events.event_id; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON COLUMN analytics.events.event_id IS 'Unique event id from envelope; used for idempotent consumption and replay.';


--
-- Name: listing_feel_cache; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.listing_feel_cache (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content_hash text NOT NULL,
    audience text DEFAULT 'renter'::text NOT NULL,
    model text NOT NULL,
    analysis_text text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE listing_feel_cache; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.listing_feel_cache IS 'Short-lived cache for Ollama listing “feel” analysis (thundering herd mitigation).';


--
-- Name: processed_events; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.processed_events IS 'Idempotent consumer: only process if event_id not present; then insert and commit offset.';


--
-- Name: projection_state; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.projection_state (
    projection_name text NOT NULL,
    last_processed_event_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE projection_state; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.projection_state IS 'Per-projection cursor; enables reset and replay from last_processed_event_id or from beginning.';


--
-- Name: projection_versions; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.projection_versions (
    name text NOT NULL,
    version integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE projection_versions; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.projection_versions IS 'Projection schema version; increment on logic change, then replay from beginning and update version.';


--
-- Name: recommendation_experiments; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.recommendation_experiments (
    id integer NOT NULL,
    name text NOT NULL,
    model_id integer NOT NULL,
    traffic_percentage integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE recommendation_experiments; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.recommendation_experiments IS 'Traffic-split experiments for recommendation models. Deterministic user bucketing (hash(user_id) % 100) selects experiment vs baseline.';


--
-- Name: recommendation_experiments_id_seq; Type: SEQUENCE; Schema: analytics; Owner: -
--

CREATE SEQUENCE analytics.recommendation_experiments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recommendation_experiments_id_seq; Type: SEQUENCE OWNED BY; Schema: analytics; Owner: -
--

ALTER SEQUENCE analytics.recommendation_experiments_id_seq OWNED BY analytics.recommendation_experiments.id;


--
-- Name: recommendation_models; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.recommendation_models (
    id integer NOT NULL,
    name text NOT NULL,
    version text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE recommendation_models; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.recommendation_models IS 'Versioned recommendation models (e.g. baseline-ranking v1, geo-boost v2). Only one baseline active at a time.';


--
-- Name: recommendation_models_id_seq; Type: SEQUENCE; Schema: analytics; Owner: -
--

CREATE SEQUENCE analytics.recommendation_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recommendation_models_id_seq; Type: SEQUENCE OWNED BY; Schema: analytics; Owner: -
--

ALTER SEQUENCE analytics.recommendation_models_id_seq OWNED BY analytics.recommendation_models.id;


--
-- Name: recommendation_weights; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.recommendation_weights (
    model_id integer NOT NULL,
    distance numeric NOT NULL,
    price numeric NOT NULL,
    popularity numeric NOT NULL,
    trust numeric NOT NULL,
    recency numeric NOT NULL
);


--
-- Name: TABLE recommendation_weights; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.recommendation_weights IS 'Per-model weights for hybrid recommendation scoring (distance, price, popularity, trust, recency).';


--
-- Name: user_activity; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.user_activity (
    user_id uuid NOT NULL,
    listings_created integer DEFAULT 0 NOT NULL,
    bookings_made integer DEFAULT 0 NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_activity; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.user_activity IS 'Per-user activity counters. Updated on event consumption.';


--
-- Name: user_listing_engagement; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.user_listing_engagement (
    user_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    messages_sent integer DEFAULT 0 NOT NULL,
    bookings integer DEFAULT 0 NOT NULL,
    last_interaction_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_listing_engagement; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.user_listing_engagement IS 'Conversation/listing messaging counts for renter–landlord analytics (consumer stub).';


--
-- Name: user_watchlist_daily; Type: TABLE; Schema: analytics; Owner: -
--

CREATE TABLE analytics.user_watchlist_daily (
    user_id uuid NOT NULL,
    day date NOT NULL,
    adds integer DEFAULT 0 NOT NULL,
    removes integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_watchlist_daily; Type: COMMENT; Schema: analytics; Owner: -
--

COMMENT ON TABLE analytics.user_watchlist_daily IS 'Projected watchlist adds/removes per user per day (from booking/listing domain events).';


--
-- Name: recommendation_experiments id; Type: DEFAULT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_experiments ALTER COLUMN id SET DEFAULT nextval('analytics.recommendation_experiments_id_seq'::regclass);


--
-- Name: recommendation_models id; Type: DEFAULT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_models ALTER COLUMN id SET DEFAULT nextval('analytics.recommendation_models_id_seq'::regclass);


--
-- Data for Name: daily_metrics; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.daily_metrics (date, new_users, new_listings, new_bookings, completed_bookings, messages_sent, listings_flagged, updated_at) FROM stdin;
2026-03-29	0	14	0	0	0	0	2026-03-29 19:04:01.314607+00
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.events (id, event_type, event_version, payload, source_service, created_at, event_id) FROM stdin;
\.


--
-- Data for Name: listing_feel_cache; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.listing_feel_cache (id, content_hash, audience, model, analysis_text, created_at) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.processed_events (event_id, processed_at) FROM stdin;
3ad4a30f-49c7-4bbd-9bf7-484a2dd38a70	2026-03-29 05:11:14.958528+00
97534cf5-89e1-42cc-bc52-273c646d60df	2026-03-29 05:14:02.983409+00
db623c83-92b0-49fd-8c8d-c7e36e97ac10	2026-03-29 05:14:17.446474+00
130a5b46-cd35-4958-bb34-b2909fa934bb	2026-03-29 05:14:30.135818+00
62b2914b-af7c-47a8-9261-8849852b6c47	2026-03-29 05:14:59.78602+00
e3ba4367-31e7-4b82-9886-1ed5b1919e97	2026-03-29 05:45:21.325425+00
c5fe8bd0-9c4f-4ce2-a3a3-30ab72815be5	2026-03-29 05:45:26.110517+00
32efca4f-3b8d-4836-abbc-020ab579e6a9	2026-03-29 05:45:35.665619+00
751ca440-e1d8-490b-b9d3-b50964108848	2026-03-29 05:45:53.384253+00
2b12a1bb-1033-46e6-b41e-f44cf4f644b6	2026-03-29 05:52:37.612531+00
d6a20ef7-c974-4ec2-a881-5c0974ffe6ed	2026-03-29 05:52:43.608494+00
2176fe47-0cf4-4fc0-8dda-fcdcf8bcb2f8	2026-03-29 05:53:03.050665+00
2b73cdcc-4ccc-4058-b85c-693edcc420b5	2026-03-29 05:53:24.42461+00
f6bab218-bf34-416c-b9be-66c08dae7d5a	2026-03-29 19:04:00.94291+00
\.


--
-- Data for Name: projection_state; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.projection_state (projection_name, last_processed_event_id, updated_at) FROM stdin;
\.


--
-- Data for Name: projection_versions; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.projection_versions (name, version, updated_at) FROM stdin;
\.


--
-- Data for Name: recommendation_experiments; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.recommendation_experiments (id, name, model_id, traffic_percentage, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: recommendation_models; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.recommendation_models (id, name, version, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: recommendation_weights; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.recommendation_weights (model_id, distance, price, popularity, trust, recency) FROM stdin;
\.


--
-- Data for Name: user_activity; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.user_activity (user_id, listings_created, bookings_made, messages_sent, updated_at) FROM stdin;
\.


--
-- Data for Name: user_listing_engagement; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.user_listing_engagement (user_id, listing_id, messages_sent, bookings, last_interaction_at) FROM stdin;
\.


--
-- Data for Name: user_watchlist_daily; Type: TABLE DATA; Schema: analytics; Owner: -
--

COPY analytics.user_watchlist_daily (user_id, day, adds, removes, updated_at) FROM stdin;
\.


--
-- Name: recommendation_experiments_id_seq; Type: SEQUENCE SET; Schema: analytics; Owner: -
--

SELECT pg_catalog.setval('analytics.recommendation_experiments_id_seq', 1, false);


--
-- Name: recommendation_models_id_seq; Type: SEQUENCE SET; Schema: analytics; Owner: -
--

SELECT pg_catalog.setval('analytics.recommendation_models_id_seq', 1, false);


--
-- Name: daily_metrics daily_metrics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.daily_metrics
    ADD CONSTRAINT daily_metrics_pkey PRIMARY KEY (date);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: listing_feel_cache listing_feel_cache_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.listing_feel_cache
    ADD CONSTRAINT listing_feel_cache_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: projection_state projection_state_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.projection_state
    ADD CONSTRAINT projection_state_pkey PRIMARY KEY (projection_name);


--
-- Name: projection_versions projection_versions_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.projection_versions
    ADD CONSTRAINT projection_versions_pkey PRIMARY KEY (name);


--
-- Name: recommendation_experiments recommendation_experiments_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_experiments
    ADD CONSTRAINT recommendation_experiments_pkey PRIMARY KEY (id);


--
-- Name: recommendation_models recommendation_models_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_models
    ADD CONSTRAINT recommendation_models_pkey PRIMARY KEY (id);


--
-- Name: recommendation_weights recommendation_weights_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_weights
    ADD CONSTRAINT recommendation_weights_pkey PRIMARY KEY (model_id);


--
-- Name: user_activity user_activity_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.user_activity
    ADD CONSTRAINT user_activity_pkey PRIMARY KEY (user_id);


--
-- Name: user_listing_engagement user_listing_engagement_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.user_listing_engagement
    ADD CONSTRAINT user_listing_engagement_pkey PRIMARY KEY (user_id, listing_id);


--
-- Name: user_watchlist_daily user_watchlist_daily_pkey; Type: CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.user_watchlist_daily
    ADD CONSTRAINT user_watchlist_daily_pkey PRIMARY KEY (user_id, day);


--
-- Name: idx_analytics_events_created; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX idx_analytics_events_created ON analytics.events USING btree (created_at);


--
-- Name: idx_analytics_events_event_id; Type: INDEX; Schema: analytics; Owner: -
--

CREATE UNIQUE INDEX idx_analytics_events_event_id ON analytics.events USING btree (event_id);


--
-- Name: idx_analytics_events_type; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX idx_analytics_events_type ON analytics.events USING btree (event_type);


--
-- Name: idx_listing_feel_cache_hash_audience; Type: INDEX; Schema: analytics; Owner: -
--

CREATE UNIQUE INDEX idx_listing_feel_cache_hash_audience ON analytics.listing_feel_cache USING btree (content_hash, audience);


--
-- Name: idx_rec_models_name_version; Type: INDEX; Schema: analytics; Owner: -
--

CREATE UNIQUE INDEX idx_rec_models_name_version ON analytics.recommendation_models USING btree (name, version);


--
-- Name: idx_user_listing_engagement_listing; Type: INDEX; Schema: analytics; Owner: -
--

CREATE INDEX idx_user_listing_engagement_listing ON analytics.user_listing_engagement USING btree (listing_id);


--
-- Name: daily_metrics tr_daily_metrics_updated; Type: TRIGGER; Schema: analytics; Owner: -
--

CREATE TRIGGER tr_daily_metrics_updated BEFORE UPDATE ON analytics.daily_metrics FOR EACH ROW EXECUTE FUNCTION analytics.set_updated_at();


--
-- Name: user_activity tr_user_activity_updated; Type: TRIGGER; Schema: analytics; Owner: -
--

CREATE TRIGGER tr_user_activity_updated BEFORE UPDATE ON analytics.user_activity FOR EACH ROW EXECUTE FUNCTION analytics.set_updated_at();


--
-- Name: recommendation_experiments recommendation_experiments_model_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_experiments
    ADD CONSTRAINT recommendation_experiments_model_id_fkey FOREIGN KEY (model_id) REFERENCES analytics.recommendation_models(id) ON DELETE CASCADE;


--
-- Name: recommendation_weights recommendation_weights_model_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: -
--

ALTER TABLE ONLY analytics.recommendation_weights
    ADD CONSTRAINT recommendation_weights_model_id_fkey FOREIGN KEY (model_id) REFERENCES analytics.recommendation_models(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict BLrkfaQbTUJGDsxRKHIb2Si8EsQ6wit5ymdPiMHE48KxrZT1ltHniGhWnSZfSnq

