--
-- PostgreSQL database dump
--

\restrict i02m31kbyBhuEaD3jfOpoFR9R9QdSZcC2YAbpCV6dRBGJf8dyNFBeNFXgp1lgOG

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notification; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA notification;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: notification_channel; Type: TYPE; Schema: notification; Owner: -
--

CREATE TYPE notification.notification_channel AS ENUM (
    'email',
    'sms',
    'push'
);


--
-- Name: notification_status; Type: TYPE; Schema: notification; Owner: -
--

CREATE TYPE notification.notification_status AS ENUM (
    'pending',
    'sent',
    'failed',
    'retrying'
);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: notification; Owner: -
--

CREATE FUNCTION notification.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: notifications; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type text NOT NULL,
    channel notification.notification_channel NOT NULL,
    status notification.notification_status DEFAULT 'pending'::notification.notification_status NOT NULL,
    payload jsonb NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE notifications; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.notifications IS 'Every notification attempt. Update status after delivery/retry; optional notification.sent event for analytics.';


--
-- Name: outbox_events; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.outbox_events IS 'Transactional outbox for optional NotificationSentV1 emit; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON COLUMN notification.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON COLUMN notification.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.processed_events IS 'Idempotent consumer: check event_id before processing; insert after successful handle; then commit offset.';


--
-- Name: user_preferences; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.user_preferences (
    user_id uuid NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    booking_alerts boolean DEFAULT true NOT NULL,
    message_alerts boolean DEFAULT true NOT NULL,
    moderation_alerts boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_preferences; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.user_preferences IS 'Per-user notification preferences. Check before sending; never block domain flows.';


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.notifications (id, user_id, event_type, channel, status, payload, attempt_count, last_attempt_at, created_at) FROM stdin;
e96e1622-ac99-49b9-8e2f-dc92a56cbff6	7234bc99-006e-4f5c-9a83-47d6d67fdb43	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"77ad49ce-7ec4-439c-a003-d8034f989e79\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:16:14.399Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"user_id\\":\\"7234bc99-006e-4f5c-9a83-47d6d67fdb43\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:16:14.084Z\\"}"}	0	\N	2026-04-02 16:16:15.172204+00
55908fba-18cb-4ce3-9707-d7c9cbe0043c	7234bc99-006e-4f5c-9a83-47d6d67fdb43	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c05fa408-abba-4706-814d-151114fbbed6\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"5268cde9-5de0-4bd5-9b36-80dc9b9c9938\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:16:16.919Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"5268cde9-5de0-4bd5-9b36-80dc9b9c9938\\",\\"user_id\\":\\"7234bc99-006e-4f5c-9a83-47d6d67fdb43\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:16:16.910Z\\"}"}	0	\N	2026-04-02 16:16:17.027629+00
eab8b50c-4eff-4f3b-96d7-0d894fd41a52	5c5cf9bf-b32e-4c82-99a6-4261cf4442b2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"f89ae113-820a-451f-8871-b582f63c4d36\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"2298648c-53ab-4b65-b8cc-ec9bf8560b26\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T16:16:18.828Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"2298648c-53ab-4b65-b8cc-ec9bf8560b26\\",\\"post_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"user_id\\":\\"5c5cf9bf-b32e-4c82-99a6-4261cf4442b2\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-02T16:16:18.789Z\\"}"}	0	\N	2026-04-02 16:16:18.861345+00
4d9ee792-9bb6-4d61-be04-1f78add86d3b	7234bc99-006e-4f5c-9a83-47d6d67fdb43	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"16094db1-94a5-48eb-8da7-2dd58cff3166\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"aad3eef7-4ffb-4a31-9d6f-12bddbd9e86e\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:16:25.432Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"aad3eef7-4ffb-4a31-9d6f-12bddbd9e86e\\",\\"user_id\\":\\"7234bc99-006e-4f5c-9a83-47d6d67fdb43\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:16:25.428Z\\"}"}	0	\N	2026-04-02 16:16:25.461145+00
cff2e941-0d07-47ed-8245-f7b9a1a35177	5c5cf9bf-b32e-4c82-99a6-4261cf4442b2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"04fd8ae9-d0b5-438f-9e2f-7a6c2fff4a62\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"e9d45dbe-c909-4de7-aec6-59a77684f5ce\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T16:16:26.828Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"e9d45dbe-c909-4de7-aec6-59a77684f5ce\\",\\"post_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"user_id\\":\\"5c5cf9bf-b32e-4c82-99a6-4261cf4442b2\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-02T16:16:26.821Z\\"}"}	0	\N	2026-04-02 16:16:26.924038+00
a9044e3c-d05b-42fe-9c29-bc6084d124b4	c0808d18-707c-46b1-867f-bdd3084f1cb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"5d0f9028-e4f9-4e7f-bcf6-75ee9e36d92e\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"fa63cdbf-5614-4cab-86f2-8bf14c0e3b71\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:17:26.611Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"fa63cdbf-5614-4cab-86f2-8bf14c0e3b71\\",\\"user_id\\":\\"c0808d18-707c-46b1-867f-bdd3084f1cb5\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:17:26.604Z\\"}"}	0	\N	2026-04-02 16:17:26.681922+00
06b0a1dc-b19c-4a82-a3bb-bc994e24a5de	c0808d18-707c-46b1-867f-bdd3084f1cb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"3704e34d-a81b-423e-afcf-148f6b64b9cb\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"bcbe72d8-f26b-4e38-a482-df9e020e02c8\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T16:17:26.922Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"bcbe72d8-f26b-4e38-a482-df9e020e02c8\\",\\"post_id\\":\\"fa63cdbf-5614-4cab-86f2-8bf14c0e3b71\\",\\"user_id\\":\\"c0808d18-707c-46b1-867f-bdd3084f1cb5\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-02T16:17:26.917Z\\"}"}	0	\N	2026-04-02 16:17:26.951697+00
711aa652-d106-4a03-8af0-4239034a1d89	c0808d18-707c-46b1-867f-bdd3084f1cb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"f5d24bb3-5e71-47e7-9900-4046634acaaf\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"3ca7d813-43ed-4ab6-94f0-b9101f3524a2\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-02T16:17:27.963Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"3ca7d813-43ed-4ab6-94f0-b9101f3524a2\\",\\"user_id\\":\\"c0808d18-707c-46b1-867f-bdd3084f1cb5\\",\\"read_at\\":\\"2026-04-02T16:17:27.963Z\\"}"}	0	\N	2026-04-02 16:17:27.982935+00
a2769cf6-9fa0-453d-8cf4-5bea81c14870	8e571065-a208-49df-a748-0b30dc7109b2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"32c7ae82-f53f-4b39-833a-bc222bd4144b\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"cb3c69fc-5472-471a-b1a1-adce749dc602\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:50:25.324Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"cb3c69fc-5472-471a-b1a1-adce749dc602\\",\\"user_id\\":\\"8e571065-a208-49df-a748-0b30dc7109b2\\",\\"title\\":\\"Map test 1775148624961\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:50:28.112175+00
e0334a80-81fe-4f74-a6be-232aeb00527e	a738ea17-952d-4b04-b945-1cf62cd5d870	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c5c9159f-4ecd-4866-ba84-f40743a77e6e\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"571ea9a8-d6b8-4585-998c-6943b2253c7b\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:50:24.610Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"571ea9a8-d6b8-4585-998c-6943b2253c7b\\",\\"user_id\\":\\"a738ea17-952d-4b04-b945-1cf62cd5d870\\",\\"title\\":\\"Quiet studio e2e-1775148616063\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:50:28.524995+00
3dd17471-4334-433d-bfca-9f1bef3cd1cf	3d5426a3-26a7-455d-ab4e-e850cb2e2ea3	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"012d9593-e387-4799-8d50-05d537c8a1cf\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"8b5575eb-c9b7-4518-9523-336b5a096d43\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:50:41.971Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"8b5575eb-c9b7-4518-9523-336b5a096d43\\",\\"user_id\\":\\"3d5426a3-26a7-455d-ab4e-e850cb2e2ea3\\",\\"title\\":\\"Pet e2e 1775148639915\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:50:43.422709+00
d6f5febf-adaf-4797-a4ea-15903ed957e8	05b56e24-98c9-42d2-8a38-daa48bc96f45	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1fe19c75-7633-4098-8597-5377db90256a\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"aa9cbaba-87aa-4613-b428-e0b10f2443dd\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:51:01.133Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"aa9cbaba-87aa-4613-b428-e0b10f2443dd\\",\\"user_id\\":\\"05b56e24-98c9-42d2-8a38-daa48bc96f45\\",\\"title\\":\\"Integrity suite sysint-1775148656980\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:51:01.464955+00
8d0b8220-4625-43fe-abd7-8e53a8f1eabb	1aff089b-4f63-4f41-bed2-20f9a76d79c1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"80d38ebc-2e24-49e8-b2ef-9945f40c2cde\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:15:47.817Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"user_id\\":\\"1aff089b-4f63-4f41-bed2-20f9a76d79c1\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:15:47.735Z\\"}"}	0	\N	2026-04-02 19:15:48.768132+00
da60ea13-a3b3-4215-a3f0-af337e27b1b2	1aff089b-4f63-4f41-bed2-20f9a76d79c1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"f92ffafb-e4e7-43a0-84fe-fb5ca9a109b3\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"973baa40-f132-4c8a-9359-c7842709da47\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:15:50.443Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"973baa40-f132-4c8a-9359-c7842709da47\\",\\"user_id\\":\\"1aff089b-4f63-4f41-bed2-20f9a76d79c1\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:15:50.433Z\\"}"}	0	\N	2026-04-02 19:15:50.59729+00
c98cc2e5-1612-424f-8196-2e5a981def49	20ee7a8d-1d81-4c42-9b4b-2963329a4756	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"6829d687-24f6-4917-8c04-40cf51e89d56\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"946794d5-e445-4baa-86ab-89951c36da94\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T19:15:52.321Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"946794d5-e445-4baa-86ab-89951c36da94\\",\\"post_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"user_id\\":\\"20ee7a8d-1d81-4c42-9b4b-2963329a4756\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-02T19:15:52.295Z\\"}"}	0	\N	2026-04-02 19:15:52.378087+00
1246946f-7cfa-4f03-a3ae-676268548683	1aff089b-4f63-4f41-bed2-20f9a76d79c1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"ba257aea-04fb-4084-8a63-10aeddc76d3f\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"b97890b6-aaf6-489d-84ee-69f9481745a1\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:16:00.150Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"b97890b6-aaf6-489d-84ee-69f9481745a1\\",\\"user_id\\":\\"1aff089b-4f63-4f41-bed2-20f9a76d79c1\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:16:00.128Z\\"}"}	0	\N	2026-04-02 19:16:00.31162+00
e29643f4-cb91-429b-8ae1-f8251f68cd3f	20ee7a8d-1d81-4c42-9b4b-2963329a4756	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"120072a5-ac8e-4550-86d3-2a917f79a8df\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"841f1700-53fa-403e-bd06-039b161ef407\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T19:16:01.637Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"841f1700-53fa-403e-bd06-039b161ef407\\",\\"post_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"user_id\\":\\"20ee7a8d-1d81-4c42-9b4b-2963329a4756\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-02T19:16:01.624Z\\"}"}	0	\N	2026-04-02 19:16:01.734442+00
92b1191e-2fd9-4d3a-aed2-f14db82ed253	a9341364-d6e8-4040-87c3-4cf400a832aa	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"d238ba83-ef57-43d5-9fb4-10f37f351278\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"21856eb1-a9bb-4df4-a5e2-bdd2368c39e2\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:17:35.361Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"21856eb1-a9bb-4df4-a5e2-bdd2368c39e2\\",\\"user_id\\":\\"a9341364-d6e8-4040-87c3-4cf400a832aa\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:17:35.357Z\\"}"}	0	\N	2026-04-02 19:17:35.444479+00
e8f682cd-cf40-4aa2-806e-45c093789a6a	a9341364-d6e8-4040-87c3-4cf400a832aa	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c6cd0861-5e85-4409-9635-9af61f87e173\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"6de41213-57bd-4919-86e6-b65b49920bb7\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T19:17:35.795Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"6de41213-57bd-4919-86e6-b65b49920bb7\\",\\"post_id\\":\\"21856eb1-a9bb-4df4-a5e2-bdd2368c39e2\\",\\"user_id\\":\\"a9341364-d6e8-4040-87c3-4cf400a832aa\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-02T19:17:35.784Z\\"}"}	0	\N	2026-04-02 19:17:35.989529+00
c602cd26-418d-4595-a6a5-8e14bc7d6c0b	a9341364-d6e8-4040-87c3-4cf400a832aa	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"6f4c7007-1ba6-4517-bc27-4589901124c9\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"00215cc1-2d02-4ac9-aef0-88335b9658e7\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-02T19:17:37.091Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"00215cc1-2d02-4ac9-aef0-88335b9658e7\\",\\"user_id\\":\\"a9341364-d6e8-4040-87c3-4cf400a832aa\\",\\"read_at\\":\\"2026-04-02T19:17:37.091Z\\"}"}	0	\N	2026-04-02 19:17:37.137258+00
fd736f8c-d97d-4e95-94db-596f0b0e44e1	e501fce8-ac79-407c-914b-d298ef4994d8	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"633db336-2a1a-4609-913d-697573712772\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"6d09d27a-68e9-490a-a504-e233f40d787a\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:02.339Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"6d09d27a-68e9-490a-a504-e233f40d787a\\",\\"user_id\\":\\"e501fce8-ac79-407c-914b-d298ef4994d8\\",\\"title\\":\\"Map test 1775159341375\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:03.70491+00
52c84e20-d3b5-4028-a099-3eec33290d13	c727f598-56e9-46b8-8e11-05c44b7e2d3c	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"8a0a1eae-06c7-4a53-9194-548d41303522\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"0ea3f922-057e-43f2-bb22-d8214af91e27\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:00.886Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"0ea3f922-057e-43f2-bb22-d8214af91e27\\",\\"user_id\\":\\"c727f598-56e9-46b8-8e11-05c44b7e2d3c\\",\\"title\\":\\"Quiet studio e2e-1775159336341\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:04.115451+00
a1805e26-0e38-441c-9080-af953b9ab8c9	07b3f0c5-2878-4cf8-a23b-e523bf1a7f04	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"31632df7-7f85-4398-8133-2868daaf4ef1\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"bff25836-d0dd-4504-8437-1295aac5e21f\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:12.758Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"bff25836-d0dd-4504-8437-1295aac5e21f\\",\\"user_id\\":\\"07b3f0c5-2878-4cf8-a23b-e523bf1a7f04\\",\\"title\\":\\"Pet e2e 1775159351837\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:12.947569+00
e8ef7b4e-ab02-4a65-b619-e2684ce53317	8c008efc-755f-4122-a81e-039ffc40cccf	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"09e1a36a-4495-442c-a070-7c6793b35f6e\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"31a82671-d478-4942-8f52-e020cb3217b8\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:21.735Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"31a82671-d478-4942-8f52-e020cb3217b8\\",\\"user_id\\":\\"8c008efc-755f-4122-a81e-039ffc40cccf\\",\\"title\\":\\"Integrity suite sysint-1775159360870\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:21.935337+00
e2a3a430-a9ec-431d-b79d-8f872d260bd9	5b201134-d66a-496a-acb9-36da330a7321	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"73981f61-4aa3-4c9c-bb80-7871c3afd338\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"b0d1c2af-41ec-479f-ae85-6d89b2f95ef5\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T17:03:26.412Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"b0d1c2af-41ec-479f-ae85-6d89b2f95ef5\\",\\"user_id\\":\\"5b201134-d66a-496a-acb9-36da330a7321\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T17:03:26.366Z\\"}"}	0	\N	2026-04-03 17:03:27.270327+00
f60e802f-7da0-4613-9399-5ac529b34777	5b201134-d66a-496a-acb9-36da330a7321	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"cdb500d8-4a85-42f6-9fd4-167122d26921\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"79598673-d410-4d62-bf89-c453fdfe9e95\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T17:03:28.530Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"79598673-d410-4d62-bf89-c453fdfe9e95\\",\\"user_id\\":\\"5b201134-d66a-496a-acb9-36da330a7321\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T17:03:28.521Z\\"}"}	0	\N	2026-04-03 17:03:28.693249+00
bf3a5d0b-ac5b-45bc-a566-00bd11a00e81	2d92335c-9f36-4bd8-aaa3-44b932bb3a4a	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1cc3de31-e2b5-4447-91fb-2b31b53b79bd\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"1b56cd33-127b-4eb0-8510-703b42790f1a\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-03T17:03:30.029Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"1b56cd33-127b-4eb0-8510-703b42790f1a\\",\\"post_id\\":\\"b0d1c2af-41ec-479f-ae85-6d89b2f95ef5\\",\\"user_id\\":\\"2d92335c-9f36-4bd8-aaa3-44b932bb3a4a\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-03T17:03:30.005Z\\"}"}	0	\N	2026-04-03 17:03:30.049732+00
1aa6db91-fcbe-4053-8168-5e81f1f4538c	5b201134-d66a-496a-acb9-36da330a7321	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"2665e030-cf29-4e24-b6cb-c3da5e56c311\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"496415c1-8eb7-4007-ab21-d17a1ca3bdf0\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T17:03:40.789Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"496415c1-8eb7-4007-ab21-d17a1ca3bdf0\\",\\"user_id\\":\\"5b201134-d66a-496a-acb9-36da330a7321\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T17:03:40.785Z\\"}"}	0	\N	2026-04-03 17:03:41.017892+00
792595f4-54ff-4f0b-8e95-8e16cc597035	2d92335c-9f36-4bd8-aaa3-44b932bb3a4a	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"0c1f5db0-b5a1-4155-941a-8b75f68a4b41\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"4c3bd9a1-5411-4d0a-a2b2-e31e05679987\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-03T17:03:42.192Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"4c3bd9a1-5411-4d0a-a2b2-e31e05679987\\",\\"post_id\\":\\"b0d1c2af-41ec-479f-ae85-6d89b2f95ef5\\",\\"user_id\\":\\"2d92335c-9f36-4bd8-aaa3-44b932bb3a4a\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-03T17:03:42.188Z\\"}"}	0	\N	2026-04-03 17:03:42.205037+00
0dc7de27-24ed-4ed7-b68b-9ca96d81b6b7	5a541579-cac6-4498-ae0b-94253c62938d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"9cc37eb2-3b84-4738-81bc-ca34bae79643\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"e0091404-d0da-4289-81f8-c0d3650c2ba4\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T17:04:51.005Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"e0091404-d0da-4289-81f8-c0d3650c2ba4\\",\\"user_id\\":\\"5a541579-cac6-4498-ae0b-94253c62938d\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T17:04:50.814Z\\"}"}	0	\N	2026-04-03 17:04:51.331902+00
42899686-fd5f-4636-b5d2-e7566daf74fb	5a541579-cac6-4498-ae0b-94253c62938d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"9e2d0e0c-501e-4274-ab27-37e3ffe9a231\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"9c4710c3-ee9c-4653-8d43-05f2482d9aee\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-03T17:04:52.118Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"9c4710c3-ee9c-4653-8d43-05f2482d9aee\\",\\"post_id\\":\\"e0091404-d0da-4289-81f8-c0d3650c2ba4\\",\\"user_id\\":\\"5a541579-cac6-4498-ae0b-94253c62938d\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-03T17:04:52.108Z\\"}"}	0	\N	2026-04-03 17:04:52.17307+00
a8c31a50-822c-40c7-995c-a16fc28ea0c6	5a541579-cac6-4498-ae0b-94253c62938d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"bb66f7d6-ca93-4970-b2a3-7349a8ff0f9e\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"cc629307-2d86-47af-a5ba-79d23f43e5b5\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-03T17:04:52.910Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"cc629307-2d86-47af-a5ba-79d23f43e5b5\\",\\"user_id\\":\\"5a541579-cac6-4498-ae0b-94253c62938d\\",\\"read_at\\":\\"2026-04-03T17:04:52.910Z\\"}"}	0	\N	2026-04-03 17:04:52.938988+00
fb2cc33b-96ce-4dda-802f-a289a9f289ee	e0ac579c-d748-4241-bddb-3688da4bf353	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"0ea4f064-4d52-496b-9d4a-e99e696764f3\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"744cfff8-d3a4-43e1-b169-07fd8ba89cc2\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T17:36:02.270Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"744cfff8-d3a4-43e1-b169-07fd8ba89cc2\\",\\"user_id\\":\\"e0ac579c-d748-4241-bddb-3688da4bf353\\",\\"title\\":\\"Map test 1775237760613\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 17:36:03.266707+00
7f5a5911-bae2-4b5b-818a-c2245bc57edc	3307a410-7a66-42a1-9972-911e91151bd1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"bd9a777e-2ee2-48a5-934b-029e446c2d58\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"fc03fc06-34f0-4087-9c35-dcd515629c06\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T17:36:02.267Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"fc03fc06-34f0-4087-9c35-dcd515629c06\\",\\"user_id\\":\\"3307a410-7a66-42a1-9972-911e91151bd1\\",\\"title\\":\\"Quiet studio e2e-1775237757354\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 17:36:03.5423+00
32f59d70-b081-4d50-843a-d7140c725415	74040b02-8359-4193-ba8a-85a79b84a1bf	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"5a7fcc50-0d41-41e7-bd5d-472689513097\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"729bc88b-6fcd-492d-8568-bfab8efd75e2\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T17:36:12.308Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"729bc88b-6fcd-492d-8568-bfab8efd75e2\\",\\"user_id\\":\\"74040b02-8359-4193-ba8a-85a79b84a1bf\\",\\"title\\":\\"Pet e2e 1775237771743\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 17:36:12.818024+00
9575db34-65f2-4867-9d8d-897c5a7ff394	dae02d42-2558-4bbe-87d4-04b9dc8e7d08	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1264ec1e-474f-458d-87c7-c59866446785\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"519866a7-d966-4cbf-bf12-05e0277954c6\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T17:36:23.255Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"519866a7-d966-4cbf-bf12-05e0277954c6\\",\\"user_id\\":\\"dae02d42-2558-4bbe-87d4-04b9dc8e7d08\\",\\"title\\":\\"Integrity suite sysint-1775237781982\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 17:36:23.515862+00
c35a186f-b596-4359-b832-1ea1a405eed1	47b9bd59-1687-427a-afbc-87fe6082e826	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4a4c97a7-12d8-489b-86a8-11b1c7a99ba4\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"95d08c9d-059f-4136-adc6-7edd078132d9\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T20:21:40.264Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"95d08c9d-059f-4136-adc6-7edd078132d9\\",\\"user_id\\":\\"47b9bd59-1687-427a-afbc-87fe6082e826\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T20:21:39.418Z\\"}"}	0	\N	2026-04-03 20:21:41.061439+00
4707f8fa-80c5-4962-9eeb-e59527977253	47b9bd59-1687-427a-afbc-87fe6082e826	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"ecceba77-a6aa-46cf-9e4f-bbf3f3ee5200\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"004205aa-3077-406c-b9d5-5a64193e00a0\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T20:21:42.579Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"004205aa-3077-406c-b9d5-5a64193e00a0\\",\\"user_id\\":\\"47b9bd59-1687-427a-afbc-87fe6082e826\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T20:21:42.566Z\\"}"}	0	\N	2026-04-03 20:21:42.978917+00
10f5aca2-7e6e-426b-88f4-9be624631f57	6cd98c8c-6c7a-45e0-a0ef-abc6157d4e85	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"7cd6b552-83b1-4d94-bfb4-54e6f60010de\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"69f92330-4b3f-4071-8197-b6c7a9da5da4\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-03T20:21:44.807Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"69f92330-4b3f-4071-8197-b6c7a9da5da4\\",\\"post_id\\":\\"95d08c9d-059f-4136-adc6-7edd078132d9\\",\\"user_id\\":\\"6cd98c8c-6c7a-45e0-a0ef-abc6157d4e85\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-03T20:21:44.773Z\\"}"}	0	\N	2026-04-03 20:21:44.875764+00
dd61dbc5-9882-4a61-94f1-40346d09884b	47b9bd59-1687-427a-afbc-87fe6082e826	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"e7fb6751-38e4-4ccd-b90c-e32336653531\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"819ab76f-74f8-4e62-afda-c64878709ab8\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T20:21:55.046Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"819ab76f-74f8-4e62-afda-c64878709ab8\\",\\"user_id\\":\\"47b9bd59-1687-427a-afbc-87fe6082e826\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T20:21:55.037Z\\"}"}	0	\N	2026-04-03 20:21:55.070495+00
ed67542c-313f-4df0-badc-932fbbf4b3c5	6cd98c8c-6c7a-45e0-a0ef-abc6157d4e85	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"528c35ec-77c4-4cd3-b8ca-ba608fa4c86b\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"3c2dee25-8886-47ef-aa9d-2b49aadd8652\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-03T20:21:56.728Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"3c2dee25-8886-47ef-aa9d-2b49aadd8652\\",\\"post_id\\":\\"95d08c9d-059f-4136-adc6-7edd078132d9\\",\\"user_id\\":\\"6cd98c8c-6c7a-45e0-a0ef-abc6157d4e85\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-03T20:21:56.709Z\\"}"}	0	\N	2026-04-03 20:21:56.791055+00
c6bf1298-1adf-4a55-913a-64e3c4525841	3ba07474-e5dc-42c2-9109-6e34b64d6459	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"75595e61-4a8f-4352-bf54-e8b89c9371a9\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"d4c7154d-cc1f-48c5-85e6-90bcc479e68a\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-03T20:23:10.857Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"d4c7154d-cc1f-48c5-85e6-90bcc479e68a\\",\\"user_id\\":\\"3ba07474-e5dc-42c2-9109-6e34b64d6459\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-03T20:23:10.846Z\\"}"}	0	\N	2026-04-03 20:23:10.949691+00
d8f69290-79a4-4ea8-9bee-84aa500a4f54	3ba07474-e5dc-42c2-9109-6e34b64d6459	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"a976e5b6-669a-45aa-aeb5-c9dc8e37ccfc\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"0f8d57b8-0312-465d-8676-542966356d40\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-03T20:23:11.264Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"0f8d57b8-0312-465d-8676-542966356d40\\",\\"post_id\\":\\"d4c7154d-cc1f-48c5-85e6-90bcc479e68a\\",\\"user_id\\":\\"3ba07474-e5dc-42c2-9109-6e34b64d6459\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-03T20:23:11.259Z\\"}"}	0	\N	2026-04-03 20:23:11.290944+00
09d5fe4c-b233-4d4d-b8a8-987c40faf6da	3ba07474-e5dc-42c2-9109-6e34b64d6459	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"fd90cbe1-e277-4b8d-bb7e-53cbc5480161\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"7919c3f5-74a6-440b-93bb-65c60afb9246\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-03T20:23:11.923Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"7919c3f5-74a6-440b-93bb-65c60afb9246\\",\\"user_id\\":\\"3ba07474-e5dc-42c2-9109-6e34b64d6459\\",\\"read_at\\":\\"2026-04-03T20:23:11.923Z\\"}"}	0	\N	2026-04-03 20:23:11.942762+00
f8061d69-ab15-4b71-8e46-0df1c06776c7	1de5af4c-890f-4795-a7cb-2b5381e98012	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"341480cd-813d-4751-8611-d51e2ada0a4f\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"f44bcd05-c442-4486-8a58-359f2551f203\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T20:55:40.846Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"f44bcd05-c442-4486-8a58-359f2551f203\\",\\"user_id\\":\\"1de5af4c-890f-4795-a7cb-2b5381e98012\\",\\"title\\":\\"Quiet studio e2e-1775249733595\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 20:55:44.746893+00
bc905da2-0cf1-4e66-aa41-177d238f1b52	6e29a3f8-9d8d-4bd8-99b5-1203d02ad2d4	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4aaae670-1bb7-45b1-96e0-5777ce905ed4\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"d0e6317e-3cab-4b92-9965-1973a9c27eca\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T20:55:48.155Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"d0e6317e-3cab-4b92-9965-1973a9c27eca\\",\\"user_id\\":\\"6e29a3f8-9d8d-4bd8-99b5-1203d02ad2d4\\",\\"title\\":\\"Map test 1775249745813\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 20:55:49.36803+00
28e677f6-7504-4904-8eb2-fb39d68b15fe	2e6f59e0-5dcb-4aae-9105-f2186a35f5e1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4eeb6569-e4cc-4d95-9c01-de34fe6064fb\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"70465624-1d7a-470c-bf06-9d4e405f5476\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T20:56:04.334Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"70465624-1d7a-470c-bf06-9d4e405f5476\\",\\"user_id\\":\\"2e6f59e0-5dcb-4aae-9105-f2186a35f5e1\\",\\"title\\":\\"Pet e2e 1775249762048\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 20:56:05.081966+00
4c2d995b-e0b9-4f86-997b-9251577cd4e9	18d234a0-521f-44f7-8565-6e90473d875d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"a84dca9b-89af-47fe-a06b-540de841e680\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"92d5f744-785b-4e31-af56-2f83b15b2dd5\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-03T20:56:17.664Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"92d5f744-785b-4e31-af56-2f83b15b2dd5\\",\\"user_id\\":\\"18d234a0-521f-44f7-8565-6e90473d875d\\",\\"title\\":\\"Integrity suite sysint-1775249775276\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-03\\"}}"}	0	\N	2026-04-03 20:56:18.116764+00
4e098e7d-d9e8-40a8-83e3-bdb3a495aa17	5bdfbd67-d11b-4822-8111-5272d711ec5d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"92617b83-7e04-4bf2-ad75-5b7c9ba5d824\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"b5064819-ec2a-463d-a579-5364b83f4101\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-04T04:39:19.184Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"b5064819-ec2a-463d-a579-5364b83f4101\\",\\"user_id\\":\\"5bdfbd67-d11b-4822-8111-5272d711ec5d\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-04T04:39:18.594Z\\"}"}	0	\N	2026-04-04 04:39:19.756532+00
7cb93f55-dae1-4040-a399-219e26ce901d	5bdfbd67-d11b-4822-8111-5272d711ec5d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"9e56abfe-41d7-45fd-a87d-16686c03f384\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"c27f8f69-315a-4a07-a0e9-7367d532b507\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-04T04:39:21.487Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"c27f8f69-315a-4a07-a0e9-7367d532b507\\",\\"user_id\\":\\"5bdfbd67-d11b-4822-8111-5272d711ec5d\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-04T04:39:21.477Z\\"}"}	0	\N	2026-04-04 04:39:21.590721+00
7a55225e-48d2-40f4-a443-a56271db16a1	3e7626b5-b0bf-43cf-a485-c7308a24265b	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"04bc9fab-7ae1-43eb-9394-04080f01c490\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"a12f16ce-57a4-43b5-b2e9-e3d8624572bb\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-04T04:39:25.237Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"a12f16ce-57a4-43b5-b2e9-e3d8624572bb\\",\\"post_id\\":\\"b5064819-ec2a-463d-a579-5364b83f4101\\",\\"user_id\\":\\"3e7626b5-b0bf-43cf-a485-c7308a24265b\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-04T04:39:25.148Z\\"}"}	0	\N	2026-04-04 04:39:25.384561+00
80fa4740-9dcd-4d39-95c2-309f850415ef	5bdfbd67-d11b-4822-8111-5272d711ec5d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"56187abe-e73b-40bc-80c5-aa61965433f3\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"20daa51b-3e1b-4342-9426-27e2784cd00a\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-04T04:39:37.304Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"20daa51b-3e1b-4342-9426-27e2784cd00a\\",\\"user_id\\":\\"5bdfbd67-d11b-4822-8111-5272d711ec5d\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-04T04:39:37.297Z\\"}"}	0	\N	2026-04-04 04:39:37.525853+00
8f60d6ff-921e-4f17-bbbe-715b37d831b3	3e7626b5-b0bf-43cf-a485-c7308a24265b	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"79630dc9-e5a0-44ca-8c1f-28757290d19d\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"13aa9b9c-84a2-476d-b364-3081bcbce05f\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-04T04:39:39.029Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"13aa9b9c-84a2-476d-b364-3081bcbce05f\\",\\"post_id\\":\\"b5064819-ec2a-463d-a579-5364b83f4101\\",\\"user_id\\":\\"3e7626b5-b0bf-43cf-a485-c7308a24265b\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-04T04:39:38.995Z\\"}"}	0	\N	2026-04-04 04:39:39.125373+00
0b0a375f-c116-414d-b0eb-8c699184b661	9f44dea4-2b31-4b35-9b32-433967869531	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"eb9193ca-c52b-4876-891a-1a25a5f74b2a\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"34c9e7c0-fdbf-48ae-90de-4bec51d2134c\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-04T04:41:08.274Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"34c9e7c0-fdbf-48ae-90de-4bec51d2134c\\",\\"user_id\\":\\"9f44dea4-2b31-4b35-9b32-433967869531\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-04T04:41:08.263Z\\"}"}	0	\N	2026-04-04 04:41:08.602785+00
fa5e61db-b6a6-4264-88fc-79782d28076e	9f44dea4-2b31-4b35-9b32-433967869531	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"33e03f44-1f99-4984-b570-1851a81046dd\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"4d97ecde-d95d-4d0e-ae3d-ec58f9873d24\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-04T04:41:08.968Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"4d97ecde-d95d-4d0e-ae3d-ec58f9873d24\\",\\"post_id\\":\\"34c9e7c0-fdbf-48ae-90de-4bec51d2134c\\",\\"user_id\\":\\"9f44dea4-2b31-4b35-9b32-433967869531\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-04T04:41:08.962Z\\"}"}	0	\N	2026-04-04 04:41:09.001012+00
d8348cce-27cc-43d1-bb68-c8061af40f6b	9f44dea4-2b31-4b35-9b32-433967869531	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"a61a3f32-604c-4e4d-95a4-2ee0ee0868ed\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"7185624c-279e-4faf-9e2a-2ab3faa22be8\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-04T04:41:09.880Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"7185624c-279e-4faf-9e2a-2ab3faa22be8\\",\\"user_id\\":\\"9f44dea4-2b31-4b35-9b32-433967869531\\",\\"read_at\\":\\"2026-04-04T04:41:09.879Z\\"}"}	0	\N	2026-04-04 04:41:10.076455+00
0cb95d8d-ded2-4360-ba23-a832cc2f70ac	cf779af3-74c4-412e-8f5d-ff4f57f12ff0	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1714286a-ae79-4310-9d8e-04abf86dc5f9\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"84e80551-435a-4e4e-a882-cc1b730a5057\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-04T05:12:40.919Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"84e80551-435a-4e4e-a882-cc1b730a5057\\",\\"user_id\\":\\"cf779af3-74c4-412e-8f5d-ff4f57f12ff0\\",\\"title\\":\\"Quiet studio e2e-1775279556434\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-04\\"}}"}	0	\N	2026-04-04 05:12:43.264151+00
b244aac2-fec0-413b-9bdb-b3432046b42d	c73b1935-2139-49da-b1dd-6c04e250509c	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"eac154b0-3de0-420a-bc9f-6665dfb39cc0\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"804a42d3-7270-4d53-bbdd-cb4e49264f7e\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-04T05:12:42.715Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"804a42d3-7270-4d53-bbdd-cb4e49264f7e\\",\\"user_id\\":\\"c73b1935-2139-49da-b1dd-6c04e250509c\\",\\"title\\":\\"Map test 1775279561740\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-04\\"}}"}	0	\N	2026-04-04 05:12:44.168015+00
55bc11f6-c554-40d9-a52a-e56c5f5cff0f	a571eba8-ffdd-469f-b75e-ad29961c5b7e	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"d8f9e3cf-f389-4722-9a94-4cf8c8520efc\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"82bcea10-2054-4bef-bbcc-358a497b77e5\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-04T05:12:52.857Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"82bcea10-2054-4bef-bbcc-358a497b77e5\\",\\"user_id\\":\\"a571eba8-ffdd-469f-b75e-ad29961c5b7e\\",\\"title\\":\\"Pet e2e 1775279571676\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-04\\"}}"}	0	\N	2026-04-04 05:12:53.27862+00
e47183ff-8f5b-41b9-9597-f441f2677e03	53ab663e-eb51-415c-ae22-3d4d35469899	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4161cc66-8cef-4746-8c1f-32e8b61d666d\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"785dd86c-cb7e-4b9f-8c38-657c2f5ff285\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-04T05:13:08.038Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"785dd86c-cb7e-4b9f-8c38-657c2f5ff285\\",\\"user_id\\":\\"53ab663e-eb51-415c-ae22-3d4d35469899\\",\\"title\\":\\"Integrity suite sysint-1775279585497\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-04\\"}}"}	0	\N	2026-04-04 05:13:10.057756+00
5b0ce8b3-7bfa-4d2b-b7d0-074c85723780	3ec0f654-d69f-4d85-8786-8fa827b4531e	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"e906fd2d-3798-4f25-b591-4ccd69342d4c\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"b55c8d37-89c2-4ee1-b8ba-8fabc3e6a7c0\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T15:32:00.586Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"b55c8d37-89c2-4ee1-b8ba-8fabc3e6a7c0\\",\\"user_id\\":\\"3ec0f654-d69f-4d85-8786-8fa827b4531e\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T15:31:59.831Z\\"}"}	0	\N	2026-04-06 15:32:01.766267+00
08116d60-5d87-4d29-a20c-33fb325fe91b	3ec0f654-d69f-4d85-8786-8fa827b4531e	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"75faaddd-4e9d-45d0-a448-269717ac294d\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"9e0323f1-0451-461d-92ac-78496067f93a\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T15:32:05.023Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"9e0323f1-0451-461d-92ac-78496067f93a\\",\\"user_id\\":\\"3ec0f654-d69f-4d85-8786-8fa827b4531e\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T15:32:05.011Z\\"}"}	0	\N	2026-04-06 15:32:05.152795+00
64e88edb-c75d-4520-8d60-d1847827021d	2e4ce474-cb2a-425c-aabf-fe5f640e3536	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4c442667-44b5-49b2-9761-2e0f3806eb71\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"bee96625-2ff2-4e37-8f73-20ec1ff226d8\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T15:32:10.275Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"bee96625-2ff2-4e37-8f73-20ec1ff226d8\\",\\"post_id\\":\\"b55c8d37-89c2-4ee1-b8ba-8fabc3e6a7c0\\",\\"user_id\\":\\"2e4ce474-cb2a-425c-aabf-fe5f640e3536\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-06T15:32:10.216Z\\"}"}	0	\N	2026-04-06 15:32:10.339319+00
30a8addf-577c-4fa7-bb2a-fda5902aca59	2e4ce474-cb2a-425c-aabf-fe5f640e3536	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4c442667-44b5-49b2-9761-2e0f3806eb71\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"bee96625-2ff2-4e37-8f73-20ec1ff226d8\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T15:32:10.275Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"bee96625-2ff2-4e37-8f73-20ec1ff226d8\\",\\"post_id\\":\\"b55c8d37-89c2-4ee1-b8ba-8fabc3e6a7c0\\",\\"user_id\\":\\"2e4ce474-cb2a-425c-aabf-fe5f640e3536\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-06T15:32:10.216Z\\"}"}	0	\N	2026-04-06 15:32:14.391028+00
ec2c65a7-3927-4819-9a2e-7501da5dcb77	3ec0f654-d69f-4d85-8786-8fa827b4531e	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1d2d68df-ac39-441e-91b0-40b0f456fd38\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"0463aa75-21eb-4a61-a2e8-092561b5eb4a\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T15:32:22.034Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"0463aa75-21eb-4a61-a2e8-092561b5eb4a\\",\\"user_id\\":\\"3ec0f654-d69f-4d85-8786-8fa827b4531e\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T15:32:22.029Z\\"}"}	0	\N	2026-04-06 15:32:23.16492+00
a6814a71-883a-4097-b082-e92e584ac8ec	2e4ce474-cb2a-425c-aabf-fe5f640e3536	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"827ce341-b964-48b0-b977-ae55748938f6\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"4803e910-b094-40e1-9d7e-84b9d841acb0\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T15:32:26.855Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"4803e910-b094-40e1-9d7e-84b9d841acb0\\",\\"post_id\\":\\"b55c8d37-89c2-4ee1-b8ba-8fabc3e6a7c0\\",\\"user_id\\":\\"2e4ce474-cb2a-425c-aabf-fe5f640e3536\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-06T15:32:26.701Z\\"}"}	0	\N	2026-04-06 15:32:26.974243+00
4fb19833-a678-4c21-a04c-3da37540103a	8238a460-79ea-4fbe-bcf9-b6319b43338d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"e241579e-fee4-4860-84b2-3d7441fb2bfa\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"d602cd52-6357-4164-9bab-b1297bd0c797\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T15:34:01.162Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"d602cd52-6357-4164-9bab-b1297bd0c797\\",\\"user_id\\":\\"8238a460-79ea-4fbe-bcf9-b6319b43338d\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T15:34:01.142Z\\"}"}	0	\N	2026-04-06 15:34:01.576077+00
6bed3723-27a9-4adc-b1e4-2e70a6c0a1f3	8238a460-79ea-4fbe-bcf9-b6319b43338d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"981d7d26-aa1d-4f84-af41-28dce19ac3fc\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"21203091-b2d8-444a-95d8-a007d8cb5e3e\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T15:34:02.784Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"21203091-b2d8-444a-95d8-a007d8cb5e3e\\",\\"post_id\\":\\"d602cd52-6357-4164-9bab-b1297bd0c797\\",\\"user_id\\":\\"8238a460-79ea-4fbe-bcf9-b6319b43338d\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-06T15:34:02.775Z\\"}"}	0	\N	2026-04-06 15:34:02.838193+00
df3ba897-7ab8-4d44-8be3-9f878dd978f0	8238a460-79ea-4fbe-bcf9-b6319b43338d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"8765d20d-d8e0-4dff-80c3-575c63bfb5d2\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"21802cb9-a40b-418f-9478-7fb8a47a8999\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-06T15:34:03.643Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"21802cb9-a40b-418f-9478-7fb8a47a8999\\",\\"user_id\\":\\"8238a460-79ea-4fbe-bcf9-b6319b43338d\\",\\"read_at\\":\\"2026-04-06T15:34:03.643Z\\"}"}	0	\N	2026-04-06 15:34:03.854899+00
e24ae412-cd3b-44a7-ba00-601e4a4646ee	3f5a4937-559f-433e-ab8e-a972e4ab6d6f	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c124b56f-1a25-40d4-8ae0-ed074c6e0f1b\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"a8108b46-1259-4e35-992b-a1043dabf633\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T16:08:35.772Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"a8108b46-1259-4e35-992b-a1043dabf633\\",\\"user_id\\":\\"3f5a4937-559f-433e-ab8e-a972e4ab6d6f\\",\\"title\\":\\"Map test 1775491713019\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 16:08:37.704144+00
dba3943d-889f-443d-ba09-dd52df947446	bb6bac7e-cb7c-4316-b512-7ec35e032f33	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"bf47d224-3b3f-491a-8039-16bd84d409e1\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"15050859-1925-407b-bba5-0ac805d6a2ce\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T16:08:35.743Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"15050859-1925-407b-bba5-0ac805d6a2ce\\",\\"user_id\\":\\"bb6bac7e-cb7c-4316-b512-7ec35e032f33\\",\\"title\\":\\"Quiet studio e2e-1775491704946\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 16:08:39.4771+00
81d991c6-dc0f-416c-a697-9978725c59bf	9512ddc9-3df9-483b-9247-3345e1af1c14	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"32124089-eff0-4109-9a1f-8cef04727800\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"feca837e-8e73-4fcb-99dc-173dcbf62dc6\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T16:08:51.132Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"feca837e-8e73-4fcb-99dc-173dcbf62dc6\\",\\"user_id\\":\\"9512ddc9-3df9-483b-9247-3345e1af1c14\\",\\"title\\":\\"Pet e2e 1775491729048\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 16:08:52.540448+00
93d74318-cbe9-476b-aafd-342e612dfb68	73f28758-ccc1-4d2a-8557-b51e48f79614	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"cd8912fe-192f-4c0f-a5fa-46b83abdae9c\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"9e07d66b-7ea7-44e4-8a4b-79de06ff0225\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T16:09:04.075Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"9e07d66b-7ea7-44e4-8a4b-79de06ff0225\\",\\"user_id\\":\\"73f28758-ccc1-4d2a-8557-b51e48f79614\\",\\"title\\":\\"Integrity suite sysint-1775491740660\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 16:09:04.699058+00
cab29b0f-e83f-45e4-b6b8-0916777e2717	860dab15-ba7f-4ad6-ab22-b247c4d57eb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"958e63f8-f9d6-4d7b-aebc-96ed230be278\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"56a3a986-d9ae-4b83-ad41-db3b1aefd252\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T17:26:50.610Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"56a3a986-d9ae-4b83-ad41-db3b1aefd252\\",\\"user_id\\":\\"860dab15-ba7f-4ad6-ab22-b247c4d57eb5\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T17:26:50.512Z\\"}"}	0	\N	2026-04-06 17:26:52.005046+00
b7d891e1-7701-4374-84a0-eab620af0e02	860dab15-ba7f-4ad6-ab22-b247c4d57eb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"036c9ac2-26e4-40f8-870b-476c7e7d383c\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"86b41bff-860b-4b67-83be-f00664ae5fbc\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T17:26:56.436Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"86b41bff-860b-4b67-83be-f00664ae5fbc\\",\\"user_id\\":\\"860dab15-ba7f-4ad6-ab22-b247c4d57eb5\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T17:26:56.371Z\\"}"}	0	\N	2026-04-06 17:26:57.461645+00
af5a2a7a-412f-4a30-b1c6-cd83104acf56	ddbc9a2e-3399-4e4e-8b03-1a6da3bdc608	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"46d263f8-b9d0-4770-aba8-ac0c4c703162\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"51b18104-f8f8-45fa-b8b8-dbaefa166deb\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T17:27:00.944Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"51b18104-f8f8-45fa-b8b8-dbaefa166deb\\",\\"post_id\\":\\"56a3a986-d9ae-4b83-ad41-db3b1aefd252\\",\\"user_id\\":\\"ddbc9a2e-3399-4e4e-8b03-1a6da3bdc608\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-06T17:27:00.911Z\\"}"}	0	\N	2026-04-06 17:27:01.091701+00
44ec1fab-2131-42fa-9325-b68cce0d1d5e	860dab15-ba7f-4ad6-ab22-b247c4d57eb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"0e4b2ca3-1631-4d11-a9a5-9c273a813069\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"b608eaeb-e5d1-482d-8f97-2d6f18ef1a30\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T17:27:11.989Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"b608eaeb-e5d1-482d-8f97-2d6f18ef1a30\\",\\"user_id\\":\\"860dab15-ba7f-4ad6-ab22-b247c4d57eb5\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T17:27:11.972Z\\"}"}	0	\N	2026-04-06 17:27:12.087369+00
0054f521-16e3-4be9-b63e-93f14429d62d	ddbc9a2e-3399-4e4e-8b03-1a6da3bdc608	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"64fff7b2-d67b-4ffb-97a8-1acc1b7dbd0c\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"76049105-6830-434c-8db0-1ecf785c66fb\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T17:27:13.350Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"76049105-6830-434c-8db0-1ecf785c66fb\\",\\"post_id\\":\\"56a3a986-d9ae-4b83-ad41-db3b1aefd252\\",\\"user_id\\":\\"ddbc9a2e-3399-4e4e-8b03-1a6da3bdc608\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-06T17:27:13.338Z\\"}"}	0	\N	2026-04-06 17:27:13.4605+00
9fe3b7f4-bd9c-46df-b27d-e09e77bc3987	effafec9-24de-4269-b99a-eea4fe7d8e14	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"d6624592-5e7e-43ff-ae2b-49add5bb2945\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"464457bf-8fa4-4149-a24f-343222be9f7c\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T17:29:33.771Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"464457bf-8fa4-4149-a24f-343222be9f7c\\",\\"user_id\\":\\"effafec9-24de-4269-b99a-eea4fe7d8e14\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T17:29:33.733Z\\"}"}	0	\N	2026-04-06 17:29:34.293155+00
70e277da-8205-4773-b703-83a224f907ff	effafec9-24de-4269-b99a-eea4fe7d8e14	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"84f83760-a107-48aa-903d-4401248cb18d\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"2b8e16b7-196c-4fdb-abda-a5040ee7af33\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T17:29:35.042Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"2b8e16b7-196c-4fdb-abda-a5040ee7af33\\",\\"post_id\\":\\"464457bf-8fa4-4149-a24f-343222be9f7c\\",\\"user_id\\":\\"effafec9-24de-4269-b99a-eea4fe7d8e14\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-06T17:29:35.029Z\\"}"}	0	\N	2026-04-06 17:29:35.09979+00
beb6e6dc-b306-4d18-bf35-c01341d64537	effafec9-24de-4269-b99a-eea4fe7d8e14	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"77bb3ce8-696c-4430-86e5-960a5a9e5da1\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"6fbb0f5f-cdd0-42e6-badc-8d10a19a30f7\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-06T17:29:36.563Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"6fbb0f5f-cdd0-42e6-badc-8d10a19a30f7\\",\\"user_id\\":\\"effafec9-24de-4269-b99a-eea4fe7d8e14\\",\\"read_at\\":\\"2026-04-06T17:29:36.563Z\\"}"}	0	\N	2026-04-06 17:29:36.641975+00
eb74f2e1-8963-4013-9d92-5f1c9956598f	d9e39089-aa81-4cd9-bf58-41ccc08fa4be	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"850e9880-22bb-40d1-8484-5d488626094f\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"b40b2361-9f91-4dfa-8e13-f8a78f4111a8\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T18:00:26.824Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"b40b2361-9f91-4dfa-8e13-f8a78f4111a8\\",\\"user_id\\":\\"d9e39089-aa81-4cd9-bf58-41ccc08fa4be\\",\\"title\\":\\"Quiet studio e2e-1775498421348\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 18:00:29.04348+00
9744e69b-2bfc-432c-bd36-de3280253e28	c6167b1c-38db-42fc-9f65-bc44ce1e37d2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"a2ea496c-b52f-4578-a799-b199288a6ac4\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"cd602d12-9f3a-47e9-9cde-bdc1d8346fe1\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T18:00:27.880Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"cd602d12-9f3a-47e9-9cde-bdc1d8346fe1\\",\\"user_id\\":\\"c6167b1c-38db-42fc-9f65-bc44ce1e37d2\\",\\"title\\":\\"Map test 1775498426008\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 18:00:30.850812+00
977aba7c-515e-4e70-afa6-dfde631e4e59	83ba7363-4694-4b13-ac5e-2be52a126684	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c1adb5e9-9ad9-4b05-82e8-0c04b1e18f58\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"f2024632-1025-4073-9095-617302a6631f\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T18:00:38.978Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"f2024632-1025-4073-9095-617302a6631f\\",\\"user_id\\":\\"83ba7363-4694-4b13-ac5e-2be52a126684\\",\\"title\\":\\"Pet e2e 1775498435648\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 18:00:39.693143+00
9826ac66-1655-4f29-bf88-6add1e85e796	6d644fce-cf5d-4a25-b8e6-8065489a0450	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"258c3057-4453-4c08-a5ce-3a4ca3fefb4e\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"032e624e-9c32-4876-b355-97374f2a1e4f\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T18:01:02.448Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"032e624e-9c32-4876-b355-97374f2a1e4f\\",\\"user_id\\":\\"6d644fce-cf5d-4a25-b8e6-8065489a0450\\",\\"title\\":\\"Integrity suite sysint-1775498457582\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 18:01:03.378477+00
b694f44d-62ce-4c10-8a2b-aad16178d0eb	3f51812e-ca31-4868-9041-fb663528e8d2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"4bd507b5-b116-4968-8ddf-0a22fa29eed2\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"1f3267b6-19c0-4261-9bb1-a047dc23d1b1\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T19:28:17.301Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"1f3267b6-19c0-4261-9bb1-a047dc23d1b1\\",\\"user_id\\":\\"3f51812e-ca31-4868-9041-fb663528e8d2\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T19:28:17.085Z\\"}"}	0	\N	2026-04-06 19:28:18.764436+00
a74cb8dc-cdcf-4895-94c1-ce82ec79cc90	3f51812e-ca31-4868-9041-fb663528e8d2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"5ef1e2c2-e1a6-4f22-b671-2e31f04acf96\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"1924ce21-0a47-47f1-b98f-ad2cdde4f559\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T19:28:28.260Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"1924ce21-0a47-47f1-b98f-ad2cdde4f559\\",\\"user_id\\":\\"3f51812e-ca31-4868-9041-fb663528e8d2\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T19:28:28.226Z\\"}"}	0	\N	2026-04-06 19:28:28.762318+00
0917a08c-bf02-4f89-9fd8-edb9e2a565a3	b3f1d64f-72ae-4966-829a-c347d9335b9f	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"820fd55e-a1b3-4da9-ab62-e994ab7f32cb\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"3c022d3a-0881-4619-9992-2f8e4f551dd8\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T19:28:34.181Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"3c022d3a-0881-4619-9992-2f8e4f551dd8\\",\\"post_id\\":\\"1f3267b6-19c0-4261-9bb1-a047dc23d1b1\\",\\"user_id\\":\\"b3f1d64f-72ae-4966-829a-c347d9335b9f\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-06T19:28:34.056Z\\"}"}	0	\N	2026-04-06 19:28:34.377413+00
6ba7cf47-c5f9-4406-bbf5-5969abb30cca	3f51812e-ca31-4868-9041-fb663528e8d2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"19a96315-6f5d-4e3b-abb2-c1370818be1c\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"98830fa3-cbb4-4b0d-9124-d5144bf2db86\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T19:28:51.145Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"98830fa3-cbb4-4b0d-9124-d5144bf2db86\\",\\"user_id\\":\\"3f51812e-ca31-4868-9041-fb663528e8d2\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T19:28:51.107Z\\"}"}	0	\N	2026-04-06 19:28:51.363401+00
ff6620ea-0cb6-4586-b073-ff53cf07e849	b3f1d64f-72ae-4966-829a-c347d9335b9f	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1e7b069e-4ba6-4d0e-85e6-e075f101ec79\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"780f6534-e459-40f7-b0b4-7c982d4c71ef\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T19:28:56.323Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"780f6534-e459-40f7-b0b4-7c982d4c71ef\\",\\"post_id\\":\\"1f3267b6-19c0-4261-9bb1-a047dc23d1b1\\",\\"user_id\\":\\"b3f1d64f-72ae-4966-829a-c347d9335b9f\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-06T19:28:56.289Z\\"}"}	0	\N	2026-04-06 19:28:56.510058+00
9f5bd9a9-f867-41d1-8657-69ec9cab6182	6cf84d1c-609d-4bea-8904-4186150ccb9d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"7eb8773b-4635-4e33-a1db-4fabcaf8451a\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"a6ab85e8-11fc-4107-8cbc-1f4bd3286ade\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T19:31:02.084Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"a6ab85e8-11fc-4107-8cbc-1f4bd3286ade\\",\\"user_id\\":\\"6cf84d1c-609d-4bea-8904-4186150ccb9d\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T19:31:02.062Z\\"}"}	0	\N	2026-04-06 19:31:02.220556+00
8472d478-aa0a-4169-8dc0-2185c9617a55	6cf84d1c-609d-4bea-8904-4186150ccb9d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"afbc0715-9765-4acf-a834-d89de05c84b0\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"21a99828-5128-4779-b5a8-b97cf0c99d0e\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T19:31:02.438Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"21a99828-5128-4779-b5a8-b97cf0c99d0e\\",\\"post_id\\":\\"a6ab85e8-11fc-4107-8cbc-1f4bd3286ade\\",\\"user_id\\":\\"6cf84d1c-609d-4bea-8904-4186150ccb9d\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-06T19:31:02.435Z\\"}"}	0	\N	2026-04-06 19:31:02.459667+00
5a16bfdb-cce9-4cee-8436-d18fd3f30d48	6cf84d1c-609d-4bea-8904-4186150ccb9d	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"e8d93d97-1797-4985-8e4d-aa1d0806d1de\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"21700ab6-d045-496f-aeb6-20fb2cc83b16\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-06T19:31:04.300Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"21700ab6-d045-496f-aeb6-20fb2cc83b16\\",\\"user_id\\":\\"6cf84d1c-609d-4bea-8904-4186150ccb9d\\",\\"read_at\\":\\"2026-04-06T19:31:04.299Z\\"}"}	0	\N	2026-04-06 19:31:04.61892+00
f22396ad-66d1-4599-a377-c1be0c57e872	b14fc01b-4bdd-44f9-8155-17773046c62c	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"dd3c8fc3-8159-4c0f-9aa3-404717e0d498\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"4bdeb3fe-2479-4d9b-8219-09fe6f08cd28\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T20:06:47.782Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"4bdeb3fe-2479-4d9b-8219-09fe6f08cd28\\",\\"user_id\\":\\"b14fc01b-4bdd-44f9-8155-17773046c62c\\",\\"title\\":\\"Quiet studio e2e-1775506002826\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 20:06:49.600722+00
cef16e38-9214-432a-adf8-a64df2bfb24e	137b7daa-0132-4f61-850e-f43bfd3b65cd	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c0caebdd-542f-43dd-bc8b-4a89a20152f5\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"df37117e-237c-408e-a377-04dc091706b6\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-06T20:07:10.103Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"df37117e-237c-408e-a377-04dc091706b6\\",\\"user_id\\":\\"137b7daa-0132-4f61-850e-f43bfd3b65cd\\",\\"title\\":\\"Integrity suite sysint-1775506028776\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-06\\"}}"}	0	\N	2026-04-06 20:07:10.39139+00
db8dbccc-e925-43b6-8dd3-9e467cba5476	ae75a908-c0b0-4532-92d2-a9e4beb4eaf7	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"9bb3096e-0902-4d20-b144-d8ae9a42cec1\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"315720e5-1068-4a46-8405-826f97d469a1\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T21:26:51.407Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"315720e5-1068-4a46-8405-826f97d469a1\\",\\"user_id\\":\\"ae75a908-c0b0-4532-92d2-a9e4beb4eaf7\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T21:26:51.361Z\\"}"}	0	\N	2026-04-06 21:26:51.877385+00
a501cf41-5386-4563-a3d6-81cca965831d	ae75a908-c0b0-4532-92d2-a9e4beb4eaf7	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"ddad1193-a8eb-4308-96d0-eed034ae9965\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"f8cb8da5-04fe-44d6-974a-e9abaf467811\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T21:26:53.313Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"f8cb8da5-04fe-44d6-974a-e9abaf467811\\",\\"user_id\\":\\"ae75a908-c0b0-4532-92d2-a9e4beb4eaf7\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T21:26:53.302Z\\"}"}	0	\N	2026-04-06 21:26:53.365985+00
c82f4207-5646-47f4-a7e4-9ea74c7b0373	f1ea8431-b4e8-4854-9e79-a5cf8e1b6196	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"689238ee-6c3a-4a53-94ea-f1cfb1197e63\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"ec182ba5-8ae6-481b-9a2e-8d45cd13c63e\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T21:26:55.235Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"ec182ba5-8ae6-481b-9a2e-8d45cd13c63e\\",\\"post_id\\":\\"315720e5-1068-4a46-8405-826f97d469a1\\",\\"user_id\\":\\"f1ea8431-b4e8-4854-9e79-a5cf8e1b6196\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-06T21:26:55.194Z\\"}"}	0	\N	2026-04-06 21:26:55.285069+00
19d8f9eb-8df8-4d94-926e-b2a624ba8207	ae75a908-c0b0-4532-92d2-a9e4beb4eaf7	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"692f5878-2565-44ef-be3f-34e15659cbac\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"cae243e0-210c-4afd-b9b7-ab8b9b913f6a\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T21:27:04.841Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"cae243e0-210c-4afd-b9b7-ab8b9b913f6a\\",\\"user_id\\":\\"ae75a908-c0b0-4532-92d2-a9e4beb4eaf7\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T21:27:04.838Z\\"}"}	0	\N	2026-04-06 21:27:04.862424+00
3366f545-5df4-4c9f-9e9b-8a20a2fdf439	f1ea8431-b4e8-4854-9e79-a5cf8e1b6196	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"16684600-3cea-47e5-b203-3b9df86b0782\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"42265e09-6191-4457-b8b0-d32475fe8133\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T21:27:06.181Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"42265e09-6191-4457-b8b0-d32475fe8133\\",\\"post_id\\":\\"315720e5-1068-4a46-8405-826f97d469a1\\",\\"user_id\\":\\"f1ea8431-b4e8-4854-9e79-a5cf8e1b6196\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-06T21:27:06.161Z\\"}"}	0	\N	2026-04-06 21:27:06.245686+00
e359b070-2da4-4196-806d-884c150f99a0	f02d443b-d917-4ac8-8f7b-322f149ecdf0	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"671b93fc-699e-4f7d-a069-bfc8dd9e0ace\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"3673141f-6b93-4ffe-ab0f-044b9f467790\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-06T21:28:36.797Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"3673141f-6b93-4ffe-ab0f-044b9f467790\\",\\"user_id\\":\\"f02d443b-d917-4ac8-8f7b-322f149ecdf0\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-06T21:28:36.785Z\\"}"}	0	\N	2026-04-06 21:28:37.094454+00
630e5c17-d902-406c-8b7f-33d189878bcc	f02d443b-d917-4ac8-8f7b-322f149ecdf0	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c12945da-cdc8-44f2-9dc4-7c3383abe17a\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"6098620c-f75f-4e1f-998d-17612a50f9e7\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-06T21:28:37.271Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"6098620c-f75f-4e1f-998d-17612a50f9e7\\",\\"post_id\\":\\"3673141f-6b93-4ffe-ab0f-044b9f467790\\",\\"user_id\\":\\"f02d443b-d917-4ac8-8f7b-322f149ecdf0\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-06T21:28:37.269Z\\"}"}	0	\N	2026-04-06 21:28:37.28962+00
bf049075-57e4-4a48-a952-454b7d4bb759	f02d443b-d917-4ac8-8f7b-322f149ecdf0	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"d46b8dca-11e8-4df8-8d91-159370db1f28\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"6d54c0a0-140b-499a-9b94-52abbfd8cdac\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-06T21:28:37.878Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"6d54c0a0-140b-499a-9b94-52abbfd8cdac\\",\\"user_id\\":\\"f02d443b-d917-4ac8-8f7b-322f149ecdf0\\",\\"read_at\\":\\"2026-04-06T21:28:37.878Z\\"}"}	0	\N	2026-04-06 21:28:37.907333+00
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.processed_events (event_id, processed_at) FROM stdin;
8ecd7581-10bd-4ab7-9007-27e18fa46e52	2026-04-02 16:16:15.140737+00
ad6e7256-aad4-441a-8192-b989d2369f63	2026-04-02 16:16:17.013452+00
69182df4-9b82-4d77-9aa2-942055bd5bb8	2026-04-02 16:16:18.858066+00
e9340a52-08fc-44b1-aa07-cb140cdc8e1e	2026-04-02 16:16:25.451427+00
f1c6ef9e-490c-4323-87d9-3c4d8bda14ee	2026-04-02 16:16:26.91038+00
162f4560-67f6-49f4-af7b-f71881b33139	2026-04-02 16:17:26.673344+00
0c928011-d57b-4ff7-a463-53abeef39624	2026-04-02 16:17:26.946725+00
dc3a8361-16db-41a6-9bd5-7a47f0820d8e	2026-04-02 16:17:27.98006+00
c328255a-ff8b-4737-b783-58b53354705d	2026-04-02 16:50:27.943158+00
ba2e1ef9-0ba3-4ff7-88ab-028936cc3e7d	2026-04-02 16:50:28.513615+00
35dcf26f-b78a-4cea-8783-b4dab1cc8b3b	2026-04-02 16:50:43.313014+00
04a1ce2d-b5d5-4489-b753-0d3b70d3d817	2026-04-02 16:51:01.44575+00
92575871-8359-4b96-b08a-0989afa880e1	2026-04-02 19:15:48.751178+00
7e3f9424-68f2-46dc-886b-793e55883920	2026-04-02 19:15:50.588505+00
aaced507-f295-4327-85fc-f45c30eb4d41	2026-04-02 19:15:52.371576+00
4e7f1443-c450-4a33-a6f1-85c5d07581b9	2026-04-02 19:16:00.299694+00
e7d8c3ab-84e1-45d2-842a-7ffe5c8d434d	2026-04-02 19:16:01.722906+00
d489e1fb-0ad8-44ae-bc4d-814e68ad8fbb	2026-04-02 19:17:35.436807+00
b374e094-5ee4-4eb3-ab05-33837dd1498d	2026-04-02 19:17:35.965533+00
4d43b69d-0793-4881-94bb-4ea1f39dadf8	2026-04-02 19:17:37.130923+00
51853975-d075-4b67-ba16-e749bd8a7b52	2026-04-02 19:49:03.587042+00
12b1656d-1c5e-478a-a35d-6cc8c13e64ff	2026-04-02 19:49:04.091388+00
b65b4ca8-1573-4f4b-bd5f-2a7f378130cd	2026-04-02 19:49:12.928952+00
546efd01-81dd-4d9e-928f-d2f5185b5ef8	2026-04-02 19:49:21.929235+00
3b133254-e8e8-4cd3-99e6-325f7f40f3f9	2026-04-03 17:03:27.198252+00
6721650e-7f89-431f-af8b-c88fb209624f	2026-04-03 17:03:28.688366+00
de6515e9-903f-454e-a587-cbdc2d1ba1e8	2026-04-03 17:03:30.046174+00
7de3e572-afd7-4e63-9e35-714743a697eb	2026-04-03 17:03:41.008874+00
ba934235-a5a0-4282-ba51-38d4db6ec6b4	2026-04-03 17:03:42.202137+00
5845e355-2d15-4b8d-84b6-4870a5b91c54	2026-04-03 17:04:51.313552+00
dfaf6929-d01b-465d-a90d-89c17f16f69a	2026-04-03 17:04:52.162818+00
02c54d3a-4beb-44b4-bf84-268337b6b45c	2026-04-03 17:04:52.933569+00
40a457db-fe32-4697-a67f-e1982f4878a2	2026-04-03 17:36:03.217591+00
d0fdfe6b-d1ac-46cc-9d26-e3049aeea30f	2026-04-03 17:36:03.520844+00
52b72de1-d3b3-4171-9155-9ade4a631841	2026-04-03 17:36:12.738918+00
985b88e0-9958-4002-b4b1-eb56558d030a	2026-04-03 17:36:23.506045+00
c47cc3b5-2f46-47a6-9133-e131170e4050	2026-04-03 20:21:41.002809+00
580762e2-f4a9-4539-82b6-59b833faab27	2026-04-03 20:21:42.971351+00
3389db44-274e-4f5b-9168-3a0a3e73886e	2026-04-03 20:21:44.869039+00
ba4de807-48dc-4bf9-bcf2-9c77bf4097d4	2026-04-03 20:21:55.06442+00
5fa10015-5b89-46de-96b8-df7d9286891e	2026-04-03 20:21:56.78561+00
c8a64c21-0137-4ebf-b1f1-822c5a3310d2	2026-04-03 20:23:10.941518+00
6af0afe4-d83c-4f9c-b6f9-e3609cc2415b	2026-04-03 20:23:11.288016+00
b9d6d0dd-3889-4418-9e02-d366303d1d68	2026-04-03 20:23:11.940613+00
c3efa094-7036-4d76-b00b-773bf723ffcb	2026-04-03 20:55:44.673591+00
b4f12331-3a13-40fa-b250-b4ee3d7a035a	2026-04-03 20:55:49.318359+00
38924212-6c5a-4253-b6d1-29650de241d9	2026-04-03 20:56:05.008974+00
cf98e7a2-d62e-478a-be10-ded55f73b9af	2026-04-03 20:56:18.039259+00
33ea5650-df3b-4e94-89a7-781dcc74b8b4	2026-04-04 04:39:19.712975+00
aad2ffcc-fc86-49e4-bc92-f4c39873b0b5	2026-04-04 04:39:21.578706+00
98b8d783-794b-465d-8d60-ef8080f6602b	2026-04-04 04:39:25.370158+00
81ee9233-4962-4b5f-b1c9-a5406bc3872c	2026-04-04 04:39:37.488438+00
ae422f3f-1c38-4844-a4de-46e0aec34c46	2026-04-04 04:39:39.117481+00
896225d8-80da-4bc6-ab1c-76f5afa3b7a3	2026-04-04 04:41:08.580589+00
f9fb7c5c-7fd4-4b5b-bd36-1d82405a875a	2026-04-04 04:41:08.999215+00
03c218dd-12f5-4607-9f8e-0845a922b9a2	2026-04-04 04:41:10.069595+00
02313380-7691-45ef-99d7-c4de38efdecb	2026-04-04 05:12:43.187929+00
e15d6743-ebed-4f00-8557-75d54249332b	2026-04-04 05:12:44.016175+00
75e3dadb-8cc4-414e-bdf6-465dbf4657dc	2026-04-04 05:12:53.220671+00
064936cc-5940-4de5-9b14-ef980f8e6f3a	2026-04-04 05:13:10.039487+00
d416ce3d-254c-4224-a459-fe77ab2b4a70	2026-04-06 15:32:01.604687+00
3be07fdb-750b-4f67-b704-6dc83829a79b	2026-04-06 15:32:05.145469+00
4161ee6c-e295-487b-954a-6b355c816e78	2026-04-06 15:32:10.328045+00
b3155c72-8a08-4fa2-8833-967dea5406f2	2026-04-06 15:32:14.365246+00
f6bfc95e-edd7-4ae6-8cf0-e9d2186850ec	2026-04-06 15:32:23.138719+00
4a45a9d8-fca4-4d09-9ffc-0bf5fab967c8	2026-04-06 15:32:26.937354+00
82f84c56-06f0-4e47-82c2-d4a62a49d3f1	2026-04-06 15:34:01.538783+00
9dc383e1-c695-4224-a5ec-2fabfa166edf	2026-04-06 15:34:02.832849+00
5147a153-031d-4c10-842e-52809d7173d0	2026-04-06 15:34:03.847819+00
a2f6c581-bdc6-4963-9ac1-aafce393a738	2026-04-06 16:08:37.592359+00
ee6054d3-2ff0-402f-8082-ee2d81bcbee0	2026-04-06 16:08:39.428513+00
06c15ece-e3fc-4f59-bfa6-bfc1054a443a	2026-04-06 16:08:52.516425+00
5bf38565-dd02-457f-b414-3e78ca14e6fe	2026-04-06 16:09:04.613823+00
20fabd2a-2ac0-479b-bcb1-bae337cadaa6	2026-04-06 17:26:51.944297+00
9eebab5b-60ef-4d41-884a-1646bf8ab6f8	2026-04-06 17:26:57.417339+00
6b6b9ceb-36e7-498d-a35a-1dfe2d69a703	2026-04-06 17:27:01.039157+00
3e5ef4a4-e63a-40a9-a6a4-f174c7722bd8	2026-04-06 17:27:12.04927+00
35ab3197-0d70-4b95-9f39-db68a376290a	2026-04-06 17:27:13.44669+00
01bf433c-732c-4198-9bdf-ec5c09be5ba0	2026-04-06 17:29:34.164958+00
ae916e26-ca86-42a8-9c8c-2912f5b59376	2026-04-06 17:29:35.091274+00
fa4e7040-db1d-4c87-85e6-1c2ea7db691a	2026-04-06 17:29:36.631019+00
b02b82a3-3462-4f79-9e6d-8f5ae6cf475c	2026-04-06 18:00:28.620757+00
00054dc7-1ca2-4f35-b8ef-885563eecdb8	2026-04-06 18:00:30.771684+00
f5ba4dd5-c549-4074-b06d-c9512b76bb4c	2026-04-06 18:00:39.648353+00
ccc57697-d3fd-4256-aa00-24c8ee0ab874	2026-04-06 18:01:03.289637+00
01dce643-0517-42c2-9bd2-bb42fdcd2d31	2026-04-06 19:28:18.706074+00
b4e17d20-6910-415a-81d2-36b2a51a13b1	2026-04-06 19:28:28.74487+00
f49cf20d-7bf9-4f32-81c8-fa3b9331db0b	2026-04-06 19:28:34.322123+00
99053fcc-c134-4b91-adcd-cdc4455d1a5c	2026-04-06 19:28:51.302063+00
89865b7e-4b57-4790-af02-614430a0e2a2	2026-04-06 19:28:56.498105+00
daf6a7a5-3d52-45be-bdd1-edd864f88293	2026-04-06 19:31:02.19185+00
b67465d5-efe4-485a-ac85-e79ed0acb023	2026-04-06 19:31:02.454939+00
527ad751-a55e-4eae-b49f-8760cd5b5a5b	2026-04-06 19:31:04.510081+00
88eb13fa-4066-435f-aab7-edd589bd6417	2026-04-06 20:06:49.564529+00
59e3ac57-e4c8-4937-974e-12ee9e4756a2	2026-04-06 20:07:10.313511+00
71dc8f19-fe26-4344-b08c-be1b7e96b61e	2026-04-06 21:26:51.866946+00
48e635f9-46d5-4f50-b814-a745a59c7e67	2026-04-06 21:26:53.362975+00
1f059ca5-1366-4f05-a009-c9831c7a5fa7	2026-04-06 21:26:55.280321+00
7e003841-a48e-4042-ae79-37806a9f5e36	2026-04-06 21:27:04.85938+00
26e29cf0-c048-425a-8820-1d2f38932e77	2026-04-06 21:27:06.236351+00
e101e9eb-315a-47ff-a817-8a2162f8f44e	2026-04-06 21:28:37.082644+00
eb5bad23-e036-47c9-8344-b3c099f528de	2026-04-06 21:28:37.280738+00
a5bb8403-4e9b-4421-a8b4-d3b4928c4306	2026-04-06 21:28:37.905002+00
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.user_preferences (user_id, email_enabled, sms_enabled, push_enabled, booking_alerts, message_alerts, moderation_alerts, updated_at) FROM stdin;
79c8c1ff-df19-4702-987e-0b60f0ee3fb4	t	f	t	t	t	t	2026-03-29 05:11:32.416199+00
ae456eb6-60fa-4b43-9fdb-aaefc61472fd	t	f	t	t	t	t	2026-03-29 05:15:02.927335+00
3f0abec3-950a-45af-a8b9-27a70b9b9792	t	f	t	t	t	t	2026-03-29 05:45:56.131204+00
f99aaced-de3d-47dd-8349-defe2545da34	t	f	t	t	t	t	2026-03-29 05:53:26.548842+00
05b56e24-98c9-42d2-8a38-daa48bc96f45	t	f	t	t	t	t	2026-04-02 16:51:10.428447+00
8c008efc-755f-4122-a81e-039ffc40cccf	t	f	t	t	t	t	2026-04-02 19:49:24.39832+00
dae02d42-2558-4bbe-87d4-04b9dc8e7d08	t	f	t	t	t	t	2026-04-03 17:36:27.968627+00
18d234a0-521f-44f7-8565-6e90473d875d	t	f	t	t	t	t	2026-04-03 20:56:21.651939+00
53ab663e-eb51-415c-ae22-3d4d35469899	t	f	t	t	t	t	2026-04-04 05:13:13.461691+00
6d644fce-cf5d-4a25-b8e6-8065489a0450	t	f	t	t	t	t	2026-04-06 18:01:07.818891+00
137b7daa-0132-4f61-850e-f43bfd3b65cd	t	f	t	t	t	t	2026-04-06 20:07:12.723151+00
\.


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: idx_notification_outbox_unpublished; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notification_outbox_unpublished ON notification.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_notifications_pending_retrying; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_pending_retrying ON notification.notifications USING btree (status) WHERE (status = ANY (ARRAY['pending'::notification.notification_status, 'retrying'::notification.notification_status]));


--
-- Name: idx_notifications_status; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_status ON notification.notifications USING btree (status);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_user ON notification.notifications USING btree (user_id, created_at DESC);


--
-- Name: user_preferences tr_user_preferences_updated; Type: TRIGGER; Schema: notification; Owner: -
--

CREATE TRIGGER tr_user_preferences_updated BEFORE UPDATE ON notification.user_preferences FOR EACH ROW EXECUTE FUNCTION notification.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict i02m31kbyBhuEaD3jfOpoFR9R9QdSZcC2YAbpCV6dRBGJf8dyNFBeNFXgp1lgOG

