--
-- PostgreSQL database dump
--

\restrict jy0rsbbQNBzF1AMm4cQDjyWrpB0OoHiQ6IIVRiXgPjBhp87LN7oe8JQiZrGfKm5

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notification; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA notification;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: notification_channel; Type: TYPE; Schema: notification; Owner: -
--

CREATE TYPE notification.notification_channel AS ENUM (
    'email',
    'sms',
    'push'
);


--
-- Name: notification_status; Type: TYPE; Schema: notification; Owner: -
--

CREATE TYPE notification.notification_status AS ENUM (
    'pending',
    'sent',
    'failed',
    'retrying'
);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: notification; Owner: -
--

CREATE FUNCTION notification.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: notifications; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type text NOT NULL,
    channel notification.notification_channel NOT NULL,
    status notification.notification_status DEFAULT 'pending'::notification.notification_status NOT NULL,
    payload jsonb NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE notifications; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.notifications IS 'Every notification attempt. Update status after delivery/retry; optional notification.sent event for analytics.';


--
-- Name: outbox_events; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.outbox_events IS 'Transactional outbox for optional NotificationSentV1 emit; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON COLUMN notification.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON COLUMN notification.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.processed_events IS 'Idempotent consumer: check event_id before processing; insert after successful handle; then commit offset.';


--
-- Name: user_preferences; Type: TABLE; Schema: notification; Owner: -
--

CREATE TABLE notification.user_preferences (
    user_id uuid NOT NULL,
    email_enabled boolean DEFAULT true NOT NULL,
    sms_enabled boolean DEFAULT false NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    booking_alerts boolean DEFAULT true NOT NULL,
    message_alerts boolean DEFAULT true NOT NULL,
    moderation_alerts boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_preferences; Type: COMMENT; Schema: notification; Owner: -
--

COMMENT ON TABLE notification.user_preferences IS 'Per-user notification preferences. Check before sending; never block domain flows.';


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.notifications (id, user_id, event_type, channel, status, payload, attempt_count, last_attempt_at, created_at) FROM stdin;
e96e1622-ac99-49b9-8e2f-dc92a56cbff6	7234bc99-006e-4f5c-9a83-47d6d67fdb43	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"77ad49ce-7ec4-439c-a003-d8034f989e79\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:16:14.399Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"user_id\\":\\"7234bc99-006e-4f5c-9a83-47d6d67fdb43\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:16:14.084Z\\"}"}	0	\N	2026-04-02 16:16:15.172204+00
55908fba-18cb-4ce3-9707-d7c9cbe0043c	7234bc99-006e-4f5c-9a83-47d6d67fdb43	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c05fa408-abba-4706-814d-151114fbbed6\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"5268cde9-5de0-4bd5-9b36-80dc9b9c9938\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:16:16.919Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"5268cde9-5de0-4bd5-9b36-80dc9b9c9938\\",\\"user_id\\":\\"7234bc99-006e-4f5c-9a83-47d6d67fdb43\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:16:16.910Z\\"}"}	0	\N	2026-04-02 16:16:17.027629+00
eab8b50c-4eff-4f3b-96d7-0d894fd41a52	5c5cf9bf-b32e-4c82-99a6-4261cf4442b2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"f89ae113-820a-451f-8871-b582f63c4d36\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"2298648c-53ab-4b65-b8cc-ec9bf8560b26\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T16:16:18.828Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"2298648c-53ab-4b65-b8cc-ec9bf8560b26\\",\\"post_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"user_id\\":\\"5c5cf9bf-b32e-4c82-99a6-4261cf4442b2\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-02T16:16:18.789Z\\"}"}	0	\N	2026-04-02 16:16:18.861345+00
4d9ee792-9bb6-4d61-be04-1f78add86d3b	7234bc99-006e-4f5c-9a83-47d6d67fdb43	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"16094db1-94a5-48eb-8da7-2dd58cff3166\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"aad3eef7-4ffb-4a31-9d6f-12bddbd9e86e\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:16:25.432Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"aad3eef7-4ffb-4a31-9d6f-12bddbd9e86e\\",\\"user_id\\":\\"7234bc99-006e-4f5c-9a83-47d6d67fdb43\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:16:25.428Z\\"}"}	0	\N	2026-04-02 16:16:25.461145+00
cff2e941-0d07-47ed-8245-f7b9a1a35177	5c5cf9bf-b32e-4c82-99a6-4261cf4442b2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"04fd8ae9-d0b5-438f-9e2f-7a6c2fff4a62\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"e9d45dbe-c909-4de7-aec6-59a77684f5ce\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T16:16:26.828Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"e9d45dbe-c909-4de7-aec6-59a77684f5ce\\",\\"post_id\\":\\"1acbd0a3-7708-44b3-b5e0-b82ba1f44935\\",\\"user_id\\":\\"5c5cf9bf-b32e-4c82-99a6-4261cf4442b2\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-02T16:16:26.821Z\\"}"}	0	\N	2026-04-02 16:16:26.924038+00
a9044e3c-d05b-42fe-9c29-bc6084d124b4	c0808d18-707c-46b1-867f-bdd3084f1cb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"5d0f9028-e4f9-4e7f-bcf6-75ee9e36d92e\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"fa63cdbf-5614-4cab-86f2-8bf14c0e3b71\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T16:17:26.611Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"fa63cdbf-5614-4cab-86f2-8bf14c0e3b71\\",\\"user_id\\":\\"c0808d18-707c-46b1-867f-bdd3084f1cb5\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T16:17:26.604Z\\"}"}	0	\N	2026-04-02 16:17:26.681922+00
06b0a1dc-b19c-4a82-a3bb-bc994e24a5de	c0808d18-707c-46b1-867f-bdd3084f1cb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"3704e34d-a81b-423e-afcf-148f6b64b9cb\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"bcbe72d8-f26b-4e38-a482-df9e020e02c8\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T16:17:26.922Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"bcbe72d8-f26b-4e38-a482-df9e020e02c8\\",\\"post_id\\":\\"fa63cdbf-5614-4cab-86f2-8bf14c0e3b71\\",\\"user_id\\":\\"c0808d18-707c-46b1-867f-bdd3084f1cb5\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-02T16:17:26.917Z\\"}"}	0	\N	2026-04-02 16:17:26.951697+00
711aa652-d106-4a03-8af0-4239034a1d89	c0808d18-707c-46b1-867f-bdd3084f1cb5	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"f5d24bb3-5e71-47e7-9900-4046634acaaf\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"3ca7d813-43ed-4ab6-94f0-b9101f3524a2\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-02T16:17:27.963Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"3ca7d813-43ed-4ab6-94f0-b9101f3524a2\\",\\"user_id\\":\\"c0808d18-707c-46b1-867f-bdd3084f1cb5\\",\\"read_at\\":\\"2026-04-02T16:17:27.963Z\\"}"}	0	\N	2026-04-02 16:17:27.982935+00
a2769cf6-9fa0-453d-8cf4-5bea81c14870	8e571065-a208-49df-a748-0b30dc7109b2	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"32c7ae82-f53f-4b39-833a-bc222bd4144b\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"cb3c69fc-5472-471a-b1a1-adce749dc602\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:50:25.324Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"cb3c69fc-5472-471a-b1a1-adce749dc602\\",\\"user_id\\":\\"8e571065-a208-49df-a748-0b30dc7109b2\\",\\"title\\":\\"Map test 1775148624961\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:50:28.112175+00
e0334a80-81fe-4f74-a6be-232aeb00527e	a738ea17-952d-4b04-b945-1cf62cd5d870	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c5c9159f-4ecd-4866-ba84-f40743a77e6e\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"571ea9a8-d6b8-4585-998c-6943b2253c7b\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:50:24.610Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"571ea9a8-d6b8-4585-998c-6943b2253c7b\\",\\"user_id\\":\\"a738ea17-952d-4b04-b945-1cf62cd5d870\\",\\"title\\":\\"Quiet studio e2e-1775148616063\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:50:28.524995+00
3dd17471-4334-433d-bfca-9f1bef3cd1cf	3d5426a3-26a7-455d-ab4e-e850cb2e2ea3	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"012d9593-e387-4799-8d50-05d537c8a1cf\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"8b5575eb-c9b7-4518-9523-336b5a096d43\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:50:41.971Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"8b5575eb-c9b7-4518-9523-336b5a096d43\\",\\"user_id\\":\\"3d5426a3-26a7-455d-ab4e-e850cb2e2ea3\\",\\"title\\":\\"Pet e2e 1775148639915\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:50:43.422709+00
d6f5febf-adaf-4797-a4ea-15903ed957e8	05b56e24-98c9-42d2-8a38-daa48bc96f45	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"1fe19c75-7633-4098-8597-5377db90256a\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"aa9cbaba-87aa-4613-b428-e0b10f2443dd\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T16:51:01.133Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"aa9cbaba-87aa-4613-b428-e0b10f2443dd\\",\\"user_id\\":\\"05b56e24-98c9-42d2-8a38-daa48bc96f45\\",\\"title\\":\\"Integrity suite sysint-1775148656980\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 16:51:01.464955+00
8d0b8220-4625-43fe-abd7-8e53a8f1eabb	1aff089b-4f63-4f41-bed2-20f9a76d79c1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"80d38ebc-2e24-49e8-b2ef-9945f40c2cde\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:15:47.817Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"user_id\\":\\"1aff089b-4f63-4f41-bed2-20f9a76d79c1\\",\\"title\\":\\"Test Forum Post\\",\\"content\\":\\"This is a test post via HTTP/2\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:15:47.735Z\\"}"}	0	\N	2026-04-02 19:15:48.768132+00
da60ea13-a3b3-4215-a3f0-af337e27b1b2	1aff089b-4f63-4f41-bed2-20f9a76d79c1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"f92ffafb-e4e7-43a0-84fe-fb5ca9a109b3\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"973baa40-f132-4c8a-9359-c7842709da47\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:15:50.443Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"973baa40-f132-4c8a-9359-c7842709da47\\",\\"user_id\\":\\"1aff089b-4f63-4f41-bed2-20f9a76d79c1\\",\\"title\\":\\"Test Forum Post H3\\",\\"content\\":\\"This is a test post via HTTP/3\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:15:50.433Z\\"}"}	0	\N	2026-04-02 19:15:50.59729+00
c98cc2e5-1612-424f-8196-2e5a981def49	20ee7a8d-1d81-4c42-9b4b-2963329a4756	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"6829d687-24f6-4917-8c04-40cf51e89d56\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"946794d5-e445-4baa-86ab-89951c36da94\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T19:15:52.321Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"946794d5-e445-4baa-86ab-89951c36da94\\",\\"post_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"user_id\\":\\"20ee7a8d-1d81-4c42-9b4b-2963329a4756\\",\\"parent_id\\":\\"\\",\\"content\\":\\"Great post! This is a test comment via HTTP/3 from User 2\\",\\"created_at\\":\\"2026-04-02T19:15:52.295Z\\"}"}	0	\N	2026-04-02 19:15:52.378087+00
1246946f-7cfa-4f03-a3ae-676268548683	1aff089b-4f63-4f41-bed2-20f9a76d79c1	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"ba257aea-04fb-4084-8a63-10aeddc76d3f\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"b97890b6-aaf6-489d-84ee-69f9481745a1\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:16:00.150Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"b97890b6-aaf6-489d-84ee-69f9481745a1\\",\\"user_id\\":\\"1aff089b-4f63-4f41-bed2-20f9a76d79c1\\",\\"title\\":\\"Test Image Post\\",\\"content\\":\\"This is a test post with upload_type=image\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:16:00.128Z\\"}"}	0	\N	2026-04-02 19:16:00.31162+00
e29643f4-cb91-429b-8ae1-f8251f68cd3f	20ee7a8d-1d81-4c42-9b4b-2963329a4756	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"120072a5-ac8e-4550-86d3-2a917f79a8df\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"841f1700-53fa-403e-bd06-039b161ef407\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T19:16:01.637Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"841f1700-53fa-403e-bd06-039b161ef407\\",\\"post_id\\":\\"4344c91e-3608-44d2-9bc7-1a231ac4e3ad\\",\\"user_id\\":\\"20ee7a8d-1d81-4c42-9b4b-2963329a4756\\",\\"parent_id\\":\\"\\",\\"content\\":\\"This comment will have an attachment\\",\\"created_at\\":\\"2026-04-02T19:16:01.624Z\\"}"}	0	\N	2026-04-02 19:16:01.734442+00
92b1191e-2fd9-4d3a-aed2-f14db82ed253	a9341364-d6e8-4040-87c3-4cf400a832aa	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"d238ba83-ef57-43d5-9fb4-10f37f351278\\",\\"event_type\\":\\"PostCreated\\",\\"aggregate_id\\":\\"21856eb1-a9bb-4df4-a5e2-bdd2368c39e2\\",\\"aggregate_type\\":\\"post\\",\\"occurred_at\\":\\"2026-04-02T19:17:35.361Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"post_id\\":\\"21856eb1-a9bb-4df4-a5e2-bdd2368c39e2\\",\\"user_id\\":\\"a9341364-d6e8-4040-87c3-4cf400a832aa\\",\\"title\\":\\"Social comprehensive test post\\",\\"content\\":\\"Body here\\",\\"flair\\":\\"general\\",\\"created_at\\":\\"2026-04-02T19:17:35.357Z\\"}"}	0	\N	2026-04-02 19:17:35.444479+00
e8f682cd-cf40-4aa2-806e-45c093789a6a	a9341364-d6e8-4040-87c3-4cf400a832aa	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"c6cd0861-5e85-4409-9635-9af61f87e173\\",\\"event_type\\":\\"CommentCreated\\",\\"aggregate_id\\":\\"6de41213-57bd-4919-86e6-b65b49920bb7\\",\\"aggregate_type\\":\\"comment\\",\\"occurred_at\\":\\"2026-04-02T19:17:35.795Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"comment_id\\":\\"6de41213-57bd-4919-86e6-b65b49920bb7\\",\\"post_id\\":\\"21856eb1-a9bb-4df4-a5e2-bdd2368c39e2\\",\\"user_id\\":\\"a9341364-d6e8-4040-87c3-4cf400a832aa\\",\\"parent_id\\":\\"\\",\\"content\\":\\"A test comment from social comprehensive\\",\\"created_at\\":\\"2026-04-02T19:17:35.784Z\\"}"}	0	\N	2026-04-02 19:17:35.989529+00
c602cd26-418d-4595-a6a5-8e14bc7d6c0b	a9341364-d6e8-4040-87c3-4cf400a832aa	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"6f4c7007-1ba6-4517-bc27-4589901124c9\\",\\"event_type\\":\\"MessageMarkedRead\\",\\"aggregate_id\\":\\"00215cc1-2d02-4ac9-aef0-88335b9658e7\\",\\"aggregate_type\\":\\"message\\",\\"occurred_at\\":\\"2026-04-02T19:17:37.091Z\\",\\"correlation_id\\":\\"\\",\\"causation_id\\":\\"\\",\\"producer\\":\\"messaging-service\\",\\"version\\":\\"1\\"},\\"message_id\\":\\"00215cc1-2d02-4ac9-aef0-88335b9658e7\\",\\"user_id\\":\\"a9341364-d6e8-4040-87c3-4cf400a832aa\\",\\"read_at\\":\\"2026-04-02T19:17:37.091Z\\"}"}	0	\N	2026-04-02 19:17:37.137258+00
fd736f8c-d97d-4e95-94db-596f0b0e44e1	e501fce8-ac79-407c-914b-d298ef4994d8	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"633db336-2a1a-4609-913d-697573712772\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"6d09d27a-68e9-490a-a504-e233f40d787a\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:02.339Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"6d09d27a-68e9-490a-a504-e233f40d787a\\",\\"user_id\\":\\"e501fce8-ac79-407c-914b-d298ef4994d8\\",\\"title\\":\\"Map test 1775159341375\\",\\"price_cents\\":95000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:03.70491+00
52c84e20-d3b5-4028-a099-3eec33290d13	c727f598-56e9-46b8-8e11-05c44b7e2d3c	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"8a0a1eae-06c7-4a53-9194-548d41303522\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"0ea3f922-057e-43f2-bb22-d8214af91e27\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:00.886Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"0ea3f922-057e-43f2-bb22-d8214af91e27\\",\\"user_id\\":\\"c727f598-56e9-46b8-8e11-05c44b7e2d3c\\",\\"title\\":\\"Quiet studio e2e-1775159336341\\",\\"price_cents\\":110000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:04.115451+00
a1805e26-0e38-441c-9080-af953b9ab8c9	07b3f0c5-2878-4cf8-a23b-e523bf1a7f04	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"31632df7-7f85-4398-8133-2868daaf4ef1\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"bff25836-d0dd-4504-8437-1295aac5e21f\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:12.758Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"bff25836-d0dd-4504-8437-1295aac5e21f\\",\\"user_id\\":\\"07b3f0c5-2878-4cf8-a23b-e523bf1a7f04\\",\\"title\\":\\"Pet e2e 1775159351837\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:12.947569+00
e8ef7b4e-ab02-4a65-b619-e2684ce53317	8c008efc-755f-4122-a81e-039ffc40cccf	domain.event	push	pending	{"source": "kafka", "raw_preview": "{\\"metadata\\":{\\"event_id\\":\\"09e1a36a-4495-442c-a070-7c6793b35f6e\\",\\"event_type\\":\\"ListingCreatedV1\\",\\"aggregate_id\\":\\"31a82671-d478-4942-8f52-e020cb3217b8\\",\\"aggregate_type\\":\\"listing\\",\\"occurred_at\\":\\"2026-04-02T19:49:21.735Z\\",\\"producer\\":\\"listings-service\\",\\"version\\":\\"1\\"},\\"payload\\":{\\"listing_id\\":\\"31a82671-d478-4942-8f52-e020cb3217b8\\",\\"user_id\\":\\"8c008efc-755f-4122-a81e-039ffc40cccf\\",\\"title\\":\\"Integrity suite sysint-1775159360870\\",\\"price_cents\\":120000,\\"listed_at_day\\":\\"2026-04-02\\"}}"}	0	\N	2026-04-02 19:49:21.935337+00
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.processed_events (event_id, processed_at) FROM stdin;
8ecd7581-10bd-4ab7-9007-27e18fa46e52	2026-04-02 16:16:15.140737+00
ad6e7256-aad4-441a-8192-b989d2369f63	2026-04-02 16:16:17.013452+00
69182df4-9b82-4d77-9aa2-942055bd5bb8	2026-04-02 16:16:18.858066+00
e9340a52-08fc-44b1-aa07-cb140cdc8e1e	2026-04-02 16:16:25.451427+00
f1c6ef9e-490c-4323-87d9-3c4d8bda14ee	2026-04-02 16:16:26.91038+00
162f4560-67f6-49f4-af7b-f71881b33139	2026-04-02 16:17:26.673344+00
0c928011-d57b-4ff7-a463-53abeef39624	2026-04-02 16:17:26.946725+00
dc3a8361-16db-41a6-9bd5-7a47f0820d8e	2026-04-02 16:17:27.98006+00
c328255a-ff8b-4737-b783-58b53354705d	2026-04-02 16:50:27.943158+00
ba2e1ef9-0ba3-4ff7-88ab-028936cc3e7d	2026-04-02 16:50:28.513615+00
35dcf26f-b78a-4cea-8783-b4dab1cc8b3b	2026-04-02 16:50:43.313014+00
04a1ce2d-b5d5-4489-b753-0d3b70d3d817	2026-04-02 16:51:01.44575+00
92575871-8359-4b96-b08a-0989afa880e1	2026-04-02 19:15:48.751178+00
7e3f9424-68f2-46dc-886b-793e55883920	2026-04-02 19:15:50.588505+00
aaced507-f295-4327-85fc-f45c30eb4d41	2026-04-02 19:15:52.371576+00
4e7f1443-c450-4a33-a6f1-85c5d07581b9	2026-04-02 19:16:00.299694+00
e7d8c3ab-84e1-45d2-842a-7ffe5c8d434d	2026-04-02 19:16:01.722906+00
d489e1fb-0ad8-44ae-bc4d-814e68ad8fbb	2026-04-02 19:17:35.436807+00
b374e094-5ee4-4eb3-ab05-33837dd1498d	2026-04-02 19:17:35.965533+00
4d43b69d-0793-4881-94bb-4ea1f39dadf8	2026-04-02 19:17:37.130923+00
51853975-d075-4b67-ba16-e749bd8a7b52	2026-04-02 19:49:03.587042+00
12b1656d-1c5e-478a-a35d-6cc8c13e64ff	2026-04-02 19:49:04.091388+00
b65b4ca8-1573-4f4b-bd5f-2a7f378130cd	2026-04-02 19:49:12.928952+00
546efd01-81dd-4d9e-928f-d2f5185b5ef8	2026-04-02 19:49:21.929235+00
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: notification; Owner: -
--

COPY notification.user_preferences (user_id, email_enabled, sms_enabled, push_enabled, booking_alerts, message_alerts, moderation_alerts, updated_at) FROM stdin;
79c8c1ff-df19-4702-987e-0b60f0ee3fb4	t	f	t	t	t	t	2026-03-29 05:11:32.416199+00
ae456eb6-60fa-4b43-9fdb-aaefc61472fd	t	f	t	t	t	t	2026-03-29 05:15:02.927335+00
3f0abec3-950a-45af-a8b9-27a70b9b9792	t	f	t	t	t	t	2026-03-29 05:45:56.131204+00
f99aaced-de3d-47dd-8349-defe2545da34	t	f	t	t	t	t	2026-03-29 05:53:26.548842+00
05b56e24-98c9-42d2-8a38-daa48bc96f45	t	f	t	t	t	t	2026-04-02 16:51:10.428447+00
8c008efc-755f-4122-a81e-039ffc40cccf	t	f	t	t	t	t	2026-04-02 19:49:24.39832+00
\.


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: notification; Owner: -
--

ALTER TABLE ONLY notification.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: idx_notification_outbox_unpublished; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notification_outbox_unpublished ON notification.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_notifications_pending_retrying; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_pending_retrying ON notification.notifications USING btree (status) WHERE (status = ANY (ARRAY['pending'::notification.notification_status, 'retrying'::notification.notification_status]));


--
-- Name: idx_notifications_status; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_status ON notification.notifications USING btree (status);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: notification; Owner: -
--

CREATE INDEX idx_notifications_user ON notification.notifications USING btree (user_id, created_at DESC);


--
-- Name: user_preferences tr_user_preferences_updated; Type: TRIGGER; Schema: notification; Owner: -
--

CREATE TRIGGER tr_user_preferences_updated BEFORE UPDATE ON notification.user_preferences FOR EACH ROW EXECUTE FUNCTION notification.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict jy0rsbbQNBzF1AMm4cQDjyWrpB0OoHiQ6IIVRiXgPjBhp87LN7oe8JQiZrGfKm5

