--
-- PostgreSQL database dump
--

\restrict CyjorZS8m48uiMEruqHu6N5NcgoChQ67jbMxGr6ccshnZRh0q8TRslBYu8nNgjR

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: trust; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA trust;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: flag_status; Type: TYPE; Schema: trust; Owner: -
--

CREATE TYPE trust.flag_status AS ENUM (
    'pending',
    'reviewed',
    'resolved',
    'dismissed'
);


--
-- Name: review_target_type; Type: TYPE; Schema: trust; Owner: -
--

CREATE TYPE trust.review_target_type AS ENUM (
    'listing',
    'user'
);


--
-- Name: compute_reputation_score(integer, integer, integer, integer); Type: FUNCTION; Schema: trust; Owner: -
--

CREATE FUNCTION trust.compute_reputation_score(p_positive_reviews integer, p_negative_reviews integer, p_completed_bookings integer, p_flags_count integer) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
  total_reviews INT;
  avg_rating NUMERIC(4,2);
  raw_score NUMERIC(10,4);
BEGIN
  total_reviews := p_positive_reviews + p_negative_reviews;
  IF total_reviews > 0 THEN
    avg_rating := (5.0 * p_positive_reviews) / total_reviews;
  ELSE
    avg_rating := 0;
  END IF;
  raw_score := (avg_rating * 0.6)
             + (LEAST(p_completed_bookings, 50) * 0.2)  -- cap bookings contribution
             - (LEAST(p_flags_count, 20) * 0.3);
  RETURN LEAST(GREATEST(ROUND(raw_score::NUMERIC(4,2), 2), 0), 5.00);
END;
$$;


--
-- Name: FUNCTION compute_reputation_score(p_positive_reviews integer, p_negative_reviews integer, p_completed_bookings integer, p_flags_count integer); Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON FUNCTION trust.compute_reputation_score(p_positive_reviews integer, p_negative_reviews integer, p_completed_bookings integer, p_flags_count integer) IS 'Deterministic trust score 0-5: average_rating*0.6 + completed_bookings*0.2 - flags_count*0.3. Event-driven updates: booking.completed, review.created, flags.';


--
-- Name: set_reputation_score(); Type: FUNCTION; Schema: trust; Owner: -
--

CREATE FUNCTION trust.set_reputation_score() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.reputation_score := trust.compute_reputation_score(
    NEW.positive_reviews,
    NEW.negative_reviews,
    NEW.completed_bookings,
    NEW.flags_count
  );
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: set_reputation_updated_at(); Type: FUNCTION; Schema: trust; Owner: -
--

CREATE FUNCTION trust.set_reputation_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: trust; Owner: -
--

CREATE FUNCTION trust.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: listing_flags; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.listing_flags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    reporter_id uuid NOT NULL,
    reason text NOT NULL,
    description text,
    status trust.flag_status DEFAULT 'pending'::trust.flag_status NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE listing_flags; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.listing_flags IS 'Flags on listings. When resolved as confirmed, Trust emits listing.flagged; listing service sets status=flagged.';


--
-- Name: outbox_events; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON COLUMN trust.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON COLUMN trust.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.processed_events IS 'Idempotent consumer: before handling event, INSERT event_id; ON CONFLICT DO NOTHING skip; else process then commit offset. Kafka is at-least-once.';


--
-- Name: reputation; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.reputation (
    user_id uuid NOT NULL,
    completed_bookings integer DEFAULT 0 NOT NULL,
    positive_reviews integer DEFAULT 0 NOT NULL,
    negative_reviews integer DEFAULT 0 NOT NULL,
    flags_count integer DEFAULT 0 NOT NULL,
    reputation_score numeric(4,2) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE reputation; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.reputation IS 'Materialized reputation. Updated on booking.completed, review created, user.flagged, listing.flagged (if owner).';


--
-- Name: reviews; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    booking_id uuid NOT NULL,
    reviewer_id uuid NOT NULL,
    target_type trust.review_target_type NOT NULL,
    target_id uuid NOT NULL,
    rating integer NOT NULL,
    comment text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: TABLE reviews; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.reviews IS 'Post-booking reviews. Trust consumes booking.completed; allows review insert. Emits review.created and updates reputation.';


--
-- Name: user_flags; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.user_flags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    reporter_id uuid NOT NULL,
    reason text NOT NULL,
    description text,
    status trust.flag_status DEFAULT 'pending'::trust.flag_status NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_flags; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.user_flags IS 'Flags on users. Trust may emit user.warned or user.suspended; auth/listings/booking react via events.';


--
-- Name: user_spam_score; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.user_spam_score (
    user_id uuid NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_spam_score; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.user_spam_score IS 'Spam/abuse score from MessageSentV1 consumption. Rules: X msgs to different users in Y min, same content to many, frequency anomaly, user reports. If score exceeds threshold, Trust emits UserSuspendedV1.';


--
-- Name: user_suspensions; Type: TABLE; Schema: trust; Owner: -
--

CREATE TABLE trust.user_suspensions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    reason text NOT NULL,
    suspended_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    suspended_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_suspensions; Type: COMMENT; Schema: trust; Owner: -
--

COMMENT ON TABLE trust.user_suspensions IS 'Suspension state. Trust emits user.suspended; auth/listings/booking enforce via policy or event.';


--
-- Data for Name: listing_flags; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.listing_flags (id, listing_id, reporter_id, reason, description, status, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
15a0e741-2c39-4f46-a406-a186eaf576f2	5540f540-8b48-4004-9af0-649581332c5a	79c8c1ff-df19-4702-987e-0b60f0ee3fb4	e2e-system-integrity	automated cross-service check	pending	\N	\N	2026-03-29 05:11:21.538934+00	2026-03-29 05:11:21.538934+00
31b5eacc-7b66-4be5-b547-154995b047cf	82c88168-3a47-4c6c-a086-1e2ad6e78d3a	ae456eb6-60fa-4b43-9fdb-aaefc61472fd	e2e-system-integrity	automated cross-service check	pending	\N	\N	2026-03-29 05:15:01.451746+00	2026-03-29 05:15:01.451746+00
bbfe0436-de1d-4519-9a49-e27b58149e40	2c946beb-a9fe-4d53-a2f7-a521318e8e67	3f0abec3-950a-45af-a8b9-27a70b9b9792	e2e-system-integrity	automated cross-service check	pending	\N	\N	2026-03-29 05:45:55.329416+00	2026-03-29 05:45:55.329416+00
2713bfdf-6468-4421-82fa-6e74f10c0c86	2da75fd3-ab24-48d2-8b73-e088b49a8c50	f99aaced-de3d-47dd-8349-defe2545da34	e2e-system-integrity	automated cross-service check	pending	\N	\N	2026-03-29 05:53:25.653379+00	2026-03-29 05:53:25.653379+00
47c10eac-3701-4b9e-a195-a3827cc3c214	aa9cbaba-87aa-4613-b428-e0b10f2443dd	05b56e24-98c9-42d2-8a38-daa48bc96f45	e2e-system-integrity	automated cross-service check	pending	\N	\N	2026-04-02 16:51:07.897798+00	2026-04-02 16:51:07.897798+00
8f07c8fa-a903-45de-bbdd-59a4db7fdec5	31a82671-d478-4942-8f52-e020cb3217b8	8c008efc-755f-4122-a81e-039ffc40cccf	e2e-system-integrity	automated cross-service check	pending	\N	\N	2026-04-02 19:49:24.193059+00	2026-04-02 19:49:24.193059+00
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.processed_events (event_id, processed_at) FROM stdin;
\.


--
-- Data for Name: reputation; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.reputation (user_id, completed_bookings, positive_reviews, negative_reviews, flags_count, reputation_score, updated_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.reviews (id, booking_id, reviewer_id, target_type, target_id, rating, comment, created_at) FROM stdin;
\.


--
-- Data for Name: user_flags; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.user_flags (id, user_id, reporter_id, reason, description, status, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_spam_score; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.user_spam_score (user_id, score, updated_at) FROM stdin;
\.


--
-- Data for Name: user_suspensions; Type: TABLE DATA; Schema: trust; Owner: -
--

COPY trust.user_suspensions (id, user_id, reason, suspended_at, expires_at, suspended_by, created_at) FROM stdin;
\.


--
-- Name: listing_flags listing_flags_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.listing_flags
    ADD CONSTRAINT listing_flags_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: reputation reputation_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.reputation
    ADD CONSTRAINT reputation_pkey PRIMARY KEY (user_id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: user_flags user_flags_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.user_flags
    ADD CONSTRAINT user_flags_pkey PRIMARY KEY (id);


--
-- Name: user_spam_score user_spam_score_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.user_spam_score
    ADD CONSTRAINT user_spam_score_pkey PRIMARY KEY (user_id);


--
-- Name: user_suspensions user_suspensions_pkey; Type: CONSTRAINT; Schema: trust; Owner: -
--

ALTER TABLE ONLY trust.user_suspensions
    ADD CONSTRAINT user_suspensions_pkey PRIMARY KEY (id);


--
-- Name: idx_listing_flags_listing; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_listing_flags_listing ON trust.listing_flags USING btree (listing_id);


--
-- Name: idx_listing_flags_reporter; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_listing_flags_reporter ON trust.listing_flags USING btree (reporter_id, created_at DESC);


--
-- Name: idx_listing_flags_status; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_listing_flags_status ON trust.listing_flags USING btree (status);


--
-- Name: idx_reviews_booking; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_reviews_booking ON trust.reviews USING btree (booking_id);


--
-- Name: idx_reviews_booking_reviewer_target; Type: INDEX; Schema: trust; Owner: -
--

CREATE UNIQUE INDEX idx_reviews_booking_reviewer_target ON trust.reviews USING btree (booking_id, reviewer_id, target_type, target_id);


--
-- Name: idx_reviews_target; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_reviews_target ON trust.reviews USING btree (target_type, target_id);


--
-- Name: idx_trust_outbox_unpublished; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_trust_outbox_unpublished ON trust.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_user_flags_reporter; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_user_flags_reporter ON trust.user_flags USING btree (reporter_id, created_at DESC);


--
-- Name: idx_user_flags_status; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_user_flags_status ON trust.user_flags USING btree (status);


--
-- Name: idx_user_flags_user; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_user_flags_user ON trust.user_flags USING btree (user_id);


--
-- Name: idx_user_suspensions_expires; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_user_suspensions_expires ON trust.user_suspensions USING btree (expires_at);


--
-- Name: idx_user_suspensions_user; Type: INDEX; Schema: trust; Owner: -
--

CREATE INDEX idx_user_suspensions_user ON trust.user_suspensions USING btree (user_id);


--
-- Name: listing_flags tr_listing_flags_updated; Type: TRIGGER; Schema: trust; Owner: -
--

CREATE TRIGGER tr_listing_flags_updated BEFORE UPDATE ON trust.listing_flags FOR EACH ROW EXECUTE FUNCTION trust.set_updated_at();


--
-- Name: reputation tr_reputation_compute_score; Type: TRIGGER; Schema: trust; Owner: -
--

CREATE TRIGGER tr_reputation_compute_score BEFORE INSERT OR UPDATE OF positive_reviews, negative_reviews, completed_bookings, flags_count ON trust.reputation FOR EACH ROW EXECUTE FUNCTION trust.set_reputation_score();


--
-- Name: reputation tr_reputation_updated_at; Type: TRIGGER; Schema: trust; Owner: -
--

CREATE TRIGGER tr_reputation_updated_at BEFORE UPDATE ON trust.reputation FOR EACH ROW EXECUTE FUNCTION trust.set_reputation_updated_at();


--
-- Name: user_flags tr_user_flags_updated; Type: TRIGGER; Schema: trust; Owner: -
--

CREATE TRIGGER tr_user_flags_updated BEFORE UPDATE ON trust.user_flags FOR EACH ROW EXECUTE FUNCTION trust.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict CyjorZS8m48uiMEruqHu6N5NcgoChQ67jbMxGr6ccshnZRh0q8TRslBYu8nNgjR

