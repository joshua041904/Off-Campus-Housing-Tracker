--
-- PostgreSQL database dump
--

\restrict rcQF2PjcnH2NVzaTUzM8WDXl6KlNfYPZWngWSYNf26EfZKE8woCY5CuC4wqJWkc

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: booking; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA booking;


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: booking_status; Type: TYPE; Schema: booking; Owner: -
--

CREATE TYPE booking.booking_status AS ENUM (
    'created',
    'pending_confirmation',
    'confirmed',
    'rejected',
    'cancelled',
    'expired',
    'completed'
);


--
-- Name: enforce_booking_transition(); Type: FUNCTION; Schema: booking; Owner: -
--

CREATE FUNCTION booking.enforce_booking_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  -- created → pending_confirmation (submit to landlord) or cancelled
  IF OLD.status = 'created' AND NEW.status IN ('pending_confirmation', 'cancelled') THEN
    RETURN NEW;
  END IF;

  -- pending_confirmation → confirmed | rejected | cancelled | expired
  IF OLD.status = 'pending_confirmation' AND NEW.status IN ('confirmed', 'rejected', 'cancelled', 'expired') THEN
    RETURN NEW;
  END IF;

  -- confirmed → completed | cancelled
  IF OLD.status = 'confirmed' AND NEW.status IN ('completed', 'cancelled') THEN
    RETURN NEW;
  END IF;

  -- Terminal states: no transitions out
  IF OLD.status IN ('rejected', 'cancelled', 'expired', 'completed') THEN
    RAISE EXCEPTION 'Illegal booking state transition from terminal state % to %', OLD.status, NEW.status;
  END IF;

  RAISE EXCEPTION 'Illegal booking state transition from % to %', OLD.status, NEW.status;
END;
$$;


--
-- Name: FUNCTION enforce_booking_transition(); Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON FUNCTION booking.enforce_booking_transition() IS 'Enforces legal booking lifecycle transitions; terminal states (rejected, cancelled, expired, completed) allow no further changes.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: booking; Owner: -
--

CREATE FUNCTION booking.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  ELSIF TG_OP = 'INSERT' AND (NEW.version IS NULL OR NEW.version < 1) THEN
    NEW.version := 1;
  END IF;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    landlord_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status booking.booking_status DEFAULT 'created'::booking.booking_status NOT NULL,
    price_cents_snapshot integer NOT NULL,
    currency_code text DEFAULT 'USD'::text NOT NULL,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    completed_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    payment_status text DEFAULT 'unpaid'::text,
    payment_reference text
);


--
-- Name: TABLE bookings; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON TABLE booking.bookings IS 'Tenant requests on listings. tenant_id/landlord_id = auth users; listing_id = reference to listings DB (no FK).';


--
-- Name: COLUMN bookings.tenant_id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.tenant_id IS 'Auth service user id (consumer).';


--
-- Name: COLUMN bookings.landlord_id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.landlord_id IS 'Auth service user id (listing owner).';


--
-- Name: COLUMN bookings.price_cents_snapshot; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.price_cents_snapshot IS 'Price at time of booking; immutable. Never join to listing for price at payment.';


--
-- Name: outbox_events; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON TABLE booking.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.outbox_events.payload IS 'Serialized domain event (proto bytes), e.g. BookingCreatedV1; not JSON.';


--
-- Name: search_history; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.search_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    query character varying(256),
    min_price_cents integer,
    max_price_cents integer,
    max_distance_km integer,
    latitude double precision,
    longitude double precision,
    filters jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: watchlist_items; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.watchlist_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    source character varying(40),
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    removed_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.bookings (id, listing_id, tenant_id, landlord_id, start_date, end_date, status, price_cents_snapshot, currency_code, cancellation_reason, created_at, updated_at, confirmed_at, cancelled_at, completed_at, version, payment_status, payment_reference) FROM stdin;
04c74291-a6ce-4b64-87ed-c2d285a2884d	11111111-1111-1111-1111-111111111111	a3db427f-db20-4b3a-98e0-1b548e8b5529	a3db427f-db20-4b3a-98e0-1b548e8b5529	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 17:41:34.861+00	2026-03-20 17:41:34.861+00	\N	\N	\N	1	unpaid	\N
d6ca92fa-6d2d-46e2-83ea-5c6f0b43978e	11111111-1111-1111-1111-111111111111	8d5786df-a577-431b-a4a7-8dc5e67891c5	8d5786df-a577-431b-a4a7-8dc5e67891c5	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 17:51:30.05+00	2026-03-20 17:51:30.05+00	\N	\N	\N	1	unpaid	\N
afc23156-d478-4973-b534-1f35e78bf411	11111111-1111-1111-1111-111111111111	7bed0326-d09d-4672-af21-a0ad0a405772	7bed0326-d09d-4672-af21-a0ad0a405772	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 17:56:41.936+00	2026-03-20 17:56:41.936+00	\N	\N	\N	1	unpaid	\N
9fa51ea7-2c92-412b-b8d1-9d2f175e00bb	11111111-1111-1111-1111-111111111111	7b42367c-dc27-4f48-8e4b-440c7b9cbe76	7b42367c-dc27-4f48-8e4b-440c7b9cbe76	2026-04-01	2026-05-01	confirmed	0	USD	\N	2026-03-20 18:06:12.963+00	2026-03-20 18:06:15.871525+00	2026-03-20 18:06:15.866+00	\N	\N	3	unpaid	\N
bf9e9f63-6a6b-41c3-8f19-53b0e6b432d2	11111111-1111-1111-1111-111111111111	6687a92f-a32f-43ce-9232-7e924df7863f	6687a92f-a32f-43ce-9232-7e924df7863f	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:09:42.271+00	2026-03-20 18:09:42.271+00	\N	\N	\N	1	unpaid	\N
ee7464e3-6b34-4c47-a345-6dff70495144	11111111-1111-1111-1111-111111111111	e41cb5ca-9581-401c-94d3-818e49da8932	e41cb5ca-9581-401c-94d3-818e49da8932	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:18:31.248+00	2026-03-20 18:18:31.248+00	\N	\N	\N	1	unpaid	\N
f9f680c2-2b6f-4074-90b5-94140eb74a8d	11111111-1111-1111-1111-111111111111	b7bb52f4-f192-4ca4-a851-e5f974a833c5	b7bb52f4-f192-4ca4-a851-e5f974a833c5	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:29:57.752+00	2026-03-20 18:29:57.752+00	\N	\N	\N	1	unpaid	\N
8f453a0b-8421-4450-afb9-6288bff7594a	11111111-1111-1111-1111-111111111111	957c2087-edb5-4424-a4be-8e0f0954d704	957c2087-edb5-4424-a4be-8e0f0954d704	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:39:22.921+00	2026-03-20 18:39:22.921+00	\N	\N	\N	1	unpaid	\N
3ff8a847-be65-4b7c-854c-ec192b0e318b	c54f9572-990d-465a-9058-e010262a104b	0460b540-17ab-4e55-98bc-9a252172697a	0460b540-17ab-4e55-98bc-9a252172697a	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:41:08.096+00	2026-03-20 18:41:10.9098+00	2026-03-20 18:41:10.904+00	\N	\N	3	unpaid	\N
f3194ce1-e9b5-4000-bef2-da40825b5636	46fc0414-c76c-45a1-91aa-084ce12699d3	6b25e7e4-e762-4be1-80b3-263a7311df0f	6b25e7e4-e762-4be1-80b3-263a7311df0f	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:43:42.883+00	2026-03-20 18:43:46.701026+00	2026-03-20 18:43:46.697+00	\N	\N	3	unpaid	\N
9027af04-ed81-43f0-96a6-fd3f3c068ead	7ef1638f-3e86-4d50-842b-afc71d6545f2	db718a84-02cb-4f2c-bb50-c157b9ab68fe	db718a84-02cb-4f2c-bb50-c157b9ab68fe	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:52:00.388+00	2026-03-20 18:52:04.176896+00	2026-03-20 18:52:04.172+00	\N	\N	3	unpaid	\N
cf772423-7409-4e9b-acea-587054c92f09	933433fa-e3dc-4301-bfc9-1270aedbde76	cad46f19-7f10-44b6-ad6c-4d4b2b29f784	cad46f19-7f10-44b6-ad6c-4d4b2b29f784	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:53:30.578+00	2026-03-20 18:53:33.56066+00	2026-03-20 18:53:33.557+00	\N	\N	3	unpaid	\N
0142b556-c031-4b8f-bff1-aad9b81cab18	b66212b0-5fb6-48b4-90b8-91abb76e0ce4	93c294e6-7d73-46cc-9f03-0a61d42f6b52	93c294e6-7d73-46cc-9f03-0a61d42f6b52	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:54:32.937+00	2026-03-20 18:54:35.658847+00	2026-03-20 18:54:35.646+00	\N	\N	3	unpaid	\N
efe1db1a-c4fa-43d1-b059-2e0b593aec1f	c59649bc-66f2-4566-ba6a-606479e1223e	1b7b7bc3-dc50-48bd-a63b-ff50052a7b14	1b7b7bc3-dc50-48bd-a63b-ff50052a7b14	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:56:31.062+00	2026-03-20 18:56:34.341665+00	2026-03-20 18:56:34.338+00	\N	\N	3	unpaid	\N
c2362372-8a9f-4c8c-bf6a-f2997ec6345f	069a277e-487c-475b-869f-8eca9e4bf9d5	fb50945a-decd-407c-917e-45f8384a0ad9	fb50945a-decd-407c-917e-45f8384a0ad9	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 19:07:19.139+00	2026-03-20 19:07:23.504051+00	2026-03-20 19:07:23.359+00	\N	\N	3	unpaid	\N
7d087ad3-51f0-4a97-af82-80c304451c7f	90d1876a-3a48-4598-b991-705ea74d08ac	7489d12c-7978-4988-8575-e7d6f9f6c85c	7489d12c-7978-4988-8575-e7d6f9f6c85c	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 19:16:53.593+00	2026-03-20 19:16:56.621458+00	2026-03-20 19:16:56.619+00	\N	\N	3	unpaid	\N
d5036984-c448-4ce8-a2ca-a7a0193b8217	8ecb3baa-1c93-4c5a-9602-2e1554753b59	b6b197d6-51e5-40c5-a4bc-d5c460b77cf5	b6b197d6-51e5-40c5-a4bc-d5c460b77cf5	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 19:23:26.813+00	2026-03-20 19:23:30.754671+00	2026-03-20 19:23:30.506+00	\N	\N	3	unpaid	\N
19223cf3-76c2-47ce-87e0-9b27419357a8	1f10c9c6-52e7-41c3-a3ac-5b946d19b62c	5fed5110-652d-4fe0-b1b4-c6bf678a9122	5fed5110-652d-4fe0-b1b4-c6bf678a9122	2026-04-30	2026-05-30	confirmed	0	USD	\N	2026-03-21 22:33:54.262+00	2026-03-21 22:33:57.589622+00	2026-03-21 22:33:57.583+00	\N	\N	3	unpaid	\N
ffc5b922-0ad1-4518-aa84-6c1c27ad7016	7eb5e393-bd79-46cb-bf12-34d79dc3ea38	58ef6cfb-0509-41e8-9bec-d19847738a98	58ef6cfb-0509-41e8-9bec-d19847738a98	2026-04-30	2026-05-30	confirmed	0	USD	\N	2026-03-22 00:46:26.398+00	2026-03-22 00:46:29.629907+00	2026-03-22 00:46:29.618+00	\N	\N	3	unpaid	\N
380661c8-66c9-4b3f-83ca-5a77e35cf0e0	02ab5946-55ff-4985-b0f0-8ddc54b94f5c	6b90ec84-d747-4b28-b6b1-68f8eacc30a0	6b90ec84-d747-4b28-b6b1-68f8eacc30a0	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 14:41:49.131+00	2026-03-22 14:41:52.535484+00	2026-03-22 14:41:52.529+00	\N	\N	3	unpaid	\N
fa3d48b9-42ae-4d0d-9e85-f0b095f37a4b	4f785aa2-a908-4f59-a360-e1c53c66732c	6268e2d4-73e5-42af-aca4-cd7adf744f84	6268e2d4-73e5-42af-aca4-cd7adf744f84	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 17:32:03.478+00	2026-03-22 17:32:06.668601+00	2026-03-22 17:32:06.662+00	\N	\N	3	unpaid	\N
40577f6b-f231-45a5-b9df-9b4c497147ad	7d8eb5a5-2131-42e5-bf12-8a0fb804c1a1	c2c7db13-7cb7-4c31-a10b-864cbb816dd2	c2c7db13-7cb7-4c31-a10b-864cbb816dd2	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 19:18:01.163+00	2026-03-22 19:18:04.451006+00	2026-03-22 19:18:04.416+00	\N	\N	3	unpaid	\N
15194323-137e-4ee2-ac25-8706ca3a1957	76868ccf-beb0-479d-b505-b34f7195d0e7	60a7ff4a-4e43-446c-83a4-cffefd2c3511	60a7ff4a-4e43-446c-83a4-cffefd2c3511	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 20:15:05.186+00	2026-03-22 20:15:07.765286+00	2026-03-22 20:15:07.755+00	\N	\N	3	unpaid	\N
4ac50407-e76e-40f8-b41a-72cc0cd1a42f	0447a314-b222-4184-94ce-89a644b456fc	fc5e5366-76bd-4bb2-bbd5-8c11d85bd90d	fc5e5366-76bd-4bb2-bbd5-8c11d85bd90d	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 23:12:06.493+00	2026-03-22 23:12:10.435116+00	2026-03-22 23:12:10.428+00	\N	\N	3	unpaid	\N
3aaf6514-90f9-4df7-90b7-c57ab14b944f	dd4b93c2-3e7d-465b-b22c-743da9be0508	b9547d08-b08e-4094-b911-c0cd78d0f44b	b9547d08-b08e-4094-b911-c0cd78d0f44b	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-23 00:27:53.965+00	2026-03-23 00:27:58.554557+00	2026-03-23 00:27:58.545+00	\N	\N	3	unpaid	\N
b26fb40d-17c1-4ece-8a16-641bcebbf230	f9c1dad1-3208-4c93-a289-da13ff85db4f	9e4a4290-4d8f-4ea3-ab8b-50dd385c1d01	9e4a4290-4d8f-4ea3-ab8b-50dd385c1d01	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-23 01:15:34.274+00	2026-03-23 01:15:38.006193+00	2026-03-23 01:15:37.979+00	\N	\N	3	unpaid	\N
e0d64686-cb98-4f8b-a9d2-8435dba3f5aa	2846dc02-a99c-406f-a12e-159ac494ab17	9040b04c-f1ee-4188-b57e-36a45166cfde	9040b04c-f1ee-4188-b57e-36a45166cfde	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-23 03:29:09.993+00	2026-03-23 03:29:14.225756+00	2026-03-23 03:29:14.207+00	\N	\N	3	unpaid	\N
4eee1d47-3220-4491-916a-0896789fe1c6	d3ccab1d-a2d3-43de-96b9-01fb504bd8b9	3d4dc8a7-7c4e-46e7-9af8-16efc1f43e9b	3d4dc8a7-7c4e-46e7-9af8-16efc1f43e9b	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 04:08:38.929+00	2026-03-23 04:08:42.086334+00	2026-03-23 04:08:42.073+00	\N	\N	3	unpaid	\N
30f5e9a9-6f8a-4f24-955e-2a09bc78a19f	cf179d9a-eaf6-45d5-9956-d2ccfb267933	f1d93114-c5bb-4d01-b476-2d3be75cf4d4	f1d93114-c5bb-4d01-b476-2d3be75cf4d4	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 13:25:54.602+00	2026-03-23 13:25:56.788249+00	2026-03-23 13:25:56.778+00	\N	\N	3	unpaid	\N
36589cd0-3e64-43cf-ae24-8af3f2279987	0918148b-3fe5-4361-8274-55982e8045bc	0aa3da46-f299-4032-975a-0b21dec708dc	0aa3da46-f299-4032-975a-0b21dec708dc	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 17:16:19.124+00	2026-03-23 17:16:23.028719+00	2026-03-23 17:16:23.022+00	\N	\N	3	unpaid	\N
ce4c3811-9192-4225-8f80-66e639efca81	54192113-3ff2-47e4-af4f-e47c62770d2b	6bccc9c2-74c1-4377-bcf3-39a54e09d3e8	6bccc9c2-74c1-4377-bcf3-39a54e09d3e8	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 19:13:45.342+00	2026-03-23 19:13:48.774083+00	2026-03-23 19:13:48.762+00	\N	\N	3	unpaid	\N
f4360985-2492-433a-b5ed-309b8db12370	2e526d90-f07d-486a-a04f-0667aab7df7d	c600e1fa-52a6-4a13-b69f-c517886c7d29	c600e1fa-52a6-4a13-b69f-c517886c7d29	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-24 00:37:40.913+00	2026-03-24 00:37:44.688998+00	2026-03-24 00:37:44.681+00	\N	\N	3	unpaid	\N
63a491ff-a902-4891-8257-bfdbd0e3ffd1	242b5917-ba0e-47ba-9200-49bbe8ff51ea	644b1012-1b8e-4432-a8ac-b5d276b2ab78	644b1012-1b8e-4432-a8ac-b5d276b2ab78	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-24 02:57:54.928+00	2026-03-24 02:57:57.01204+00	2026-03-24 02:57:57.005+00	\N	\N	3	unpaid	\N
eac93982-0d8d-40fc-b282-035caf39a7f1	1c23118c-31fe-4b51-a09f-335e69cf1726	6459fa19-c9ea-4819-9e1c-d12f78c749ff	6459fa19-c9ea-4819-9e1c-d12f78c749ff	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-24 03:17:09.405+00	2026-03-24 03:17:10.765318+00	2026-03-24 03:17:10.76+00	\N	\N	3	unpaid	\N
73231b64-e84e-4a1b-bb04-2d0c9772031d	306376f4-4328-44b5-9903-c522b6ae60d4	e4976919-a542-41b7-89fb-5c2fae5523ac	e4976919-a542-41b7-89fb-5c2fae5523ac	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-24 03:31:06.651+00	2026-03-24 03:31:08.754858+00	2026-03-24 03:31:08.748+00	\N	\N	3	unpaid	\N
103add7a-05a1-4795-8955-1fd862348fea	691676a0-97b1-4ce5-88a1-cfecc02e19a3	56efa74a-768e-487b-9c37-56ceaf66af8b	56efa74a-768e-487b-9c37-56ceaf66af8b	2026-05-03	2026-06-02	confirmed	0	USD	\N	2026-03-24 17:52:47.741+00	2026-03-24 17:52:49.759593+00	2026-03-24 17:52:49.754+00	\N	\N	3	unpaid	\N
f61f1b01-da4e-4f3a-bf56-3f7c33942ee5	3be0c419-fffd-4015-990f-561784666fc0	c1000d32-b626-49e9-a315-925c106a31e7	c1000d32-b626-49e9-a315-925c106a31e7	2026-05-03	2026-06-02	confirmed	0	USD	\N	2026-03-24 18:24:33.719+00	2026-03-24 18:24:36.489702+00	2026-03-24 18:24:36.484+00	\N	\N	3	unpaid	\N
336d11dd-0bbb-4cfd-9ec7-552c07acb827	56ad016b-3ed3-4cbd-97ea-03fa10bd0a05	ce8e50a1-8f9b-45df-8e2b-d5f45eecf71a	ce8e50a1-8f9b-45df-8e2b-d5f45eecf71a	2026-05-03	2026-06-02	confirmed	0	USD	\N	2026-03-25 01:18:09.644+00	2026-03-25 01:18:12.304928+00	2026-03-25 01:18:12.299+00	\N	\N	3	unpaid	\N
a5f36719-ceaf-4c6d-98d1-7649ab0a93da	64380553-1d5d-4824-a7d1-97bf7744b07f	373fe8ce-42b6-4a23-809d-400f44b740df	373fe8ce-42b6-4a23-809d-400f44b740df	2026-05-03	2026-06-02	confirmed	0	USD	\N	2026-03-25 03:25:26.558+00	2026-03-25 03:25:29.974767+00	2026-03-25 03:25:29.968+00	\N	\N	3	unpaid	\N
3ad67d1f-aeb7-4676-b727-dcba32875ff9	f0c91322-a6b2-476b-a46c-7c92e604aead	da5a03a8-07c5-4add-815e-ed2b26ff2f35	da5a03a8-07c5-4add-815e-ed2b26ff2f35	2026-05-04	2026-06-03	confirmed	0	USD	\N	2026-03-25 16:27:02.851+00	2026-03-25 16:27:05.086253+00	2026-03-25 16:27:05.079+00	\N	\N	3	unpaid	\N
98e9508e-e27f-42a9-8095-7f258d4c8efa	f2e3d336-4ae2-4a01-bc87-72269003b7c6	20c0980e-3056-4e37-9c36-2a0a5c3649de	20c0980e-3056-4e37-9c36-2a0a5c3649de	2026-05-04	2026-06-03	confirmed	0	USD	\N	2026-03-25 20:06:13.059+00	2026-03-25 20:06:15.155643+00	2026-03-25 20:06:15.148+00	\N	\N	3	unpaid	\N
601bc570-3aa4-471e-bd11-9f3b3b55f678	c8b103ef-7cc2-46c2-8298-1384a94f52b0	d791e3f0-b0e2-4ebb-baa2-27538d4656d3	d791e3f0-b0e2-4ebb-baa2-27538d4656d3	2026-05-05	2026-06-04	confirmed	0	USD	\N	2026-03-27 02:38:50.199+00	2026-03-27 02:38:53.497131+00	2026-03-27 02:38:53.487+00	\N	\N	3	unpaid	\N
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: search_history; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.search_history (id, user_id, query, min_price_cents, max_price_cents, max_distance_km, latitude, longitude, filters, created_at) FROM stdin;
2e01a679-4bb1-4c2d-b677-c3e14b20e7ce	c2ac34e6-ba60-4ccf-b9d5-dbb06aa31785	2 bed near campus	80000	180000	5	\N	\N	\N	2026-03-20 16:37:21.081+00
5ad40f5a-c0c2-4ac2-8065-9d6a9fd6642e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.127+00
ea835f1e-b353-44be-9ea1-b880e017bbf6	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.228+00
b50c08b8-a608-4f8a-9a7f-1a1a2e549d66	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.23+00
5a32c065-b4fb-4a1f-8530-f37abeac5a8e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.265+00
008e14ab-1ef8-4f67-8953-b2329f79de37	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.227+00
30ab6393-ed24-43cc-a075-650300058f7b	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.177+00
c12dbdfe-f130-41f6-8421-99831cf683fe	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.085+00
3264add7-d342-463f-8a2c-3a6b6baf1409	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.083+00
481b6351-c42c-46cd-a3f9-ad26679420a9	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.092+00
8f01747b-b13f-4036-8562-48fc05a5cfc1	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.094+00
ff676ca5-5c39-4c06-95fd-ca319841c443	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.17+00
47963c33-56cb-4793-bfca-05e2b0056b51	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.171+00
d7be51de-6c5e-46da-a4eb-e432778c5849	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.708+00
73e90ea8-f9da-4a89-8d2c-0e2c7fe37e24	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.709+00
d3f03eaf-0a61-4b16-8f71-a8dbb732c633	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.728+00
69fe4ffd-4210-4d45-8976-4768f0d93e43	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.773+00
fbc127e9-648d-4c5f-9729-c0a9815687ba	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.796+00
b95234dd-75c1-495d-8290-60a534e8ca1b	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.86+00
a1d101bd-b0c3-4ffa-8784-975f6ec90aa6	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.316+00
f80fda00-abbb-428b-9338-4be34837900a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.318+00
e25f5005-d504-4fa4-9d9f-2c17f18b733a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.318+00
5c1bc9ba-7881-4ac6-a00c-0201465428e5	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.402+00
38e7c898-e18f-4950-a82d-11006425361f	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.467+00
a0219abe-ee39-4052-a4ad-f5c649b9544a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.471+00
ce0b36d7-d6db-427f-81da-311cdfe40190	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.995+00
68742073-c4a2-452b-a41c-ccfd3223a32c	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.996+00
cef8a776-d0fb-4249-b43e-2de30f566085	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.999+00
3a55889d-bc30-44be-805e-547f087c7aa3	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.103+00
2aa124cd-7900-4c49-a934-a443e4a18d4d	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.167+00
3fa1c117-456a-4522-a174-c39c20456574	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.172+00
5e0eb046-e33a-4607-9774-b39a46215084	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.578+00
9448e522-3605-4e30-85bf-fbfc0bef5313	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.578+00
de769bd3-c811-414d-9f75-d920901f14ad	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.579+00
0bf99613-5165-4338-a816-838454b52c5a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.637+00
531351e8-2374-4c01-8239-26defd373b77	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.725+00
5b692027-59cc-4b36-a683-4514c7c2ac6a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.727+00
ef9e473f-c7ee-468f-aeb6-a8ea659cbdf8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.182+00
a66c5467-5452-443b-842f-b7c8313970b0	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.181+00
b537b3bf-d6bc-4bb1-97ab-0e31e5bf1e8e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.196+00
606bebe2-68e0-4bee-a8c8-0ffaddb3b191	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.259+00
473d0b61-a656-406b-ba30-9f4f9f00e013	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.276+00
6f207623-7a22-43aa-8679-288506b06c96	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.277+00
3696677f-0393-4855-9921-4bfadffc6fe6	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.786+00
fdf0f422-f643-4032-92c3-9571acb1cce7	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.787+00
a8a5712d-b388-4218-a249-a42625c98fe4	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.789+00
0602f6bd-81fe-44e6-9666-830f872ec1b5	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.823+00
47df5f5d-c00f-4569-99af-84c29c734b16	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.872+00
966b7b28-29df-4483-a25d-e8ee85f04b77	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.895+00
7518a29f-4aa4-41bd-aa6a-7ab08aac2ba8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.443+00
9a9373f9-552e-469c-85bf-3d60df8af45e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.443+00
21ceb9ce-db5e-4dab-a747-69aaf8df7d02	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.444+00
823cc5d1-b9c9-4d78-af76-763a6a48df55	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.456+00
d72ee7a8-8a54-4786-a0cf-d4ce4536e6da	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.492+00
aa0be3cf-49f3-427b-bd77-c5e7ef2653f2	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.527+00
208fd01a-858f-4f44-8584-d608ee51b7ee	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.013+00
89533f70-f3bc-4622-be8f-27410262bd60	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.011+00
0fea9ee7-3f4a-4707-a6eb-d4c33b35c24d	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.014+00
bcf5648b-5ae7-4dc1-9a22-5fda8b04c325	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.038+00
59519d36-df6f-4dda-aa7b-02fe72de8e41	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.068+00
a180b0c6-a3fb-4c83-b092-a92f5a2bc566	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.071+00
7c22be30-532b-42aa-a369-bcd2f3b9ad5c	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.642+00
9da99ac7-6e61-4560-a971-e2b047063640	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.642+00
b0e63670-2772-422f-aa59-e762323478f8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.643+00
3b87627e-c00c-4538-aef2-1c5b7a7f2dec	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.66+00
2616698f-507f-459b-b166-e58e6149a421	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.687+00
88f4f7e4-7002-4f90-af13-f1dee29d2963	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.689+00
7267215b-1fac-4737-aa19-6c4bc1e462fd	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.226+00
b89d20bd-bc38-4040-91fb-a9eec49840c4	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.225+00
67308766-8274-4936-8fc9-ac836cb7c0d3	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.231+00
dd53e83b-d43e-4ebe-8be9-22656b7670cd	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.238+00
6c6654d5-bc41-4fa0-b2fe-7a0f61a7d800	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.253+00
1621779f-5cc6-4509-bd53-8d961bc6806a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.253+00
7448e9b3-7f9e-40f7-b5aa-7fbc17c4cead	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.075+00
1ff43693-7e1a-4643-b144-6726cd8a7c62	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
8168c8e4-9313-4303-b6d0-f9e6e1ddacde	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
ac0330ac-68ae-48ce-a131-12ec0ba27ba8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
b02742fb-c0ca-4c09-8adb-c3bb2bb34f34	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 0 21knmznx	80000	250000	3	\N	\N	\N	2026-03-25 01:31:31.337+00
a91e8dfb-66dc-4c81-baca-32c0396b817b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 0 mxwewyrc	80000	250000	3	\N	\N	\N	2026-03-25 01:31:31.371+00
c697f606-6683-4e12-b86d-579745ebdc3d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 0 569oaftw	80000	250000	3	\N	\N	\N	2026-03-25 01:31:31.382+00
9611f1d7-23c5-4142-983b-6206c92784a8	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 2 yajnr99v	82000	250000	5	\N	\N	\N	2026-03-25 01:31:32.846+00
16715185-bb74-4cf5-b43d-f3cc05bf9c57	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 2 iysvyxgs	82000	250000	5	\N	\N	\N	2026-03-25 01:31:32.868+00
9662c5f5-73e3-4ab6-9f75-f1189d0f7194	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 3 h4t93xr8	83000	250000	6	\N	\N	\N	2026-03-25 01:31:33.804+00
805ba701-0e3e-4f92-8a64-bcb6d7827139	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 3 xplopum2	83000	250000	6	\N	\N	\N	2026-03-25 01:31:33.892+00
647add53-7785-4e19-9cc0-8825d9992993	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 3 lo80hfni	83000	250000	6	\N	\N	\N	2026-03-25 01:31:33.943+00
6331e35d-79bc-4770-ad3f-603179cd8611	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 4 9ky05wvy	84000	250000	7	\N	\N	\N	2026-03-25 01:31:34.546+00
e3e8accc-77ee-4dee-818d-0478c869378c	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 5 3fuxal1x	85000	250000	3	\N	\N	\N	2026-03-25 01:31:35.148+00
33440bbe-6908-4aba-bffa-f1d641a4f1b2	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 7 rsekbwth	87000	250000	5	\N	\N	\N	2026-03-25 01:31:36.474+00
26088d2a-1ab2-4194-9221-27fffe349f35	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 8 ttagf55h	88000	250000	6	\N	\N	\N	2026-03-25 01:31:37.507+00
e0b89bad-d6f1-44bc-81cb-185da4114dfc	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 8 7dlx6up3	88000	250000	6	\N	\N	\N	2026-03-25 01:31:37.7+00
ae961f76-9abd-445e-a730-a1ce6a0bf04e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 9 vl2b2n6y	89000	250000	7	\N	\N	\N	2026-03-25 01:31:37.708+00
81ed7480-3d6d-47d5-8712-c593bf12aa23	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 9 3gcv2n8n	89000	250000	7	\N	\N	\N	2026-03-25 01:31:37.798+00
d4a48b4a-13ec-42ac-a1b5-0b826dfa00a3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 9 v09845b1	89000	250000	7	\N	\N	\N	2026-03-25 01:31:38.241+00
d14df29a-44af-4032-a8e7-ca3ee40588db	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 9 6cqta4h8	89000	250000	7	\N	\N	\N	2026-03-25 01:31:38.297+00
4053c6cd-e69a-46da-8e71-ac3561f1893c	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 10 fw508p0u	80000	250000	3	\N	\N	\N	2026-03-25 01:31:38.392+00
29f1d894-29e7-41d2-86c4-9169ca58ceae	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 10 36ynkf4t	80000	250000	3	\N	\N	\N	2026-03-25 01:31:38.466+00
0eaacd4a-5378-4b3a-908c-5d8bf2bf7cad	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 11 8znoyb44	81000	250000	4	\N	\N	\N	2026-03-25 01:31:39.057+00
fbae0652-18a1-4314-9921-dfa7a2b13f94	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 13 p16lwq6u	83000	250000	6	\N	\N	\N	2026-03-25 01:31:39.769+00
57cfbb5e-162c-4818-84f0-65521afcdce9	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 13 uifjmjk6	83000	250000	6	\N	\N	\N	2026-03-25 01:31:40.232+00
66d4af6d-cd6b-44c3-a412-7d3b90cc765d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 13 qre5ua68	83000	250000	6	\N	\N	\N	2026-03-25 01:31:40.337+00
e4589da4-d42c-4fee-91d2-d02555ffa4f2	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 14 andahi4a	84000	250000	7	\N	\N	\N	2026-03-25 01:31:40.735+00
489eacd5-22d0-4d52-8a87-62d7e09b958f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 14 ewx1eval	84000	250000	7	\N	\N	\N	2026-03-25 01:31:40.811+00
def9ec4e-f0fd-46f3-bc7c-2278f0daae2b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 15 jrtqcsv6	85000	250000	3	\N	\N	\N	2026-03-25 01:31:41.043+00
2762f898-a542-4d3d-8426-5910fabfb1d4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 15 fo4r8wts	85000	250000	3	\N	\N	\N	2026-03-25 01:31:41.301+00
44687e9a-7509-42ca-9ec7-bd1b1a17422a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 16 rch1mo14	86000	250000	4	\N	\N	\N	2026-03-25 01:31:41.536+00
46702e4f-8656-43ca-8ea8-999ce4e9c1f1	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 16 2pk788qt	86000	250000	4	\N	\N	\N	2026-03-25 01:31:41.791+00
56b8f27b-b5d6-455e-b0f8-66ae03df2f20	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 17 dp3l22o7	87000	250000	5	\N	\N	\N	2026-03-25 01:31:42.391+00
0337802e-a1b8-47f2-b5bd-f4343bdfc952	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 19 bmqba00e	89000	250000	7	\N	\N	\N	2026-03-25 01:31:45.05+00
29d84a78-d236-4f61-b6d0-cedd36f8c7ed	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 19 4ioji8vv	89000	250000	7	\N	\N	\N	2026-03-25 01:31:45.145+00
0f494948-2e22-405a-ba88-11d1081ec684	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 19 6qs13m3a	89000	250000	7	\N	\N	\N	2026-03-25 01:31:45.683+00
33ead0a2-42b4-4780-b524-b2f50e65b1c0	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 20 ex8vyj52	80000	250000	3	\N	\N	\N	2026-03-25 01:31:45.694+00
85c57a6e-5096-44ad-8c37-8e17af6366df	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 20 gkey400q	80000	250000	3	\N	\N	\N	2026-03-25 01:31:46.335+00
080dfa56-dfb4-4508-91e4-b9e9f4f2530f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 21 lgcyokxy	81000	250000	4	\N	\N	\N	2026-03-25 01:31:46.441+00
ba5ab6d7-248d-46d9-acf8-c24452ff142d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 22 vr565zte	82000	250000	5	\N	\N	\N	2026-03-25 01:31:47.642+00
15d20977-0e06-4b1e-960a-5b24bb4f8728	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 23 75yhp98d	83000	250000	6	\N	\N	\N	2026-03-25 01:31:47.784+00
d74bd197-93d1-4318-8c5c-a8ccd67553ec	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 23 df56j90r	83000	250000	6	\N	\N	\N	2026-03-25 01:31:47.79+00
464ab8e6-085d-40d6-9623-013b3a4fa498	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 25 imld2a8h	85000	250000	3	\N	\N	\N	2026-03-25 01:31:49.153+00
7044ccc0-a3e6-42fb-b43a-d9ecb7cf1260	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 26 o96w3yf5	86000	250000	4	\N	\N	\N	2026-03-25 01:31:49.434+00
57644173-7ec3-40ba-9485-d6964d7f30cd	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 26 24hi9ide	86000	250000	4	\N	\N	\N	2026-03-25 01:31:49.441+00
4fbe5669-5eae-413c-8d40-f41f3836d27e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 26 j0e0777k	86000	250000	4	\N	\N	\N	2026-03-25 01:31:49.607+00
3ee56a69-c8da-4988-9edc-af49da10d71f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 27 pqya3rtf	87000	250000	5	\N	\N	\N	2026-03-25 01:31:49.944+00
6702c3ae-a41b-4b44-a0f5-64608268e360	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 27 dseovohl	87000	250000	5	\N	\N	\N	2026-03-25 01:31:50.048+00
bbdcb8d0-8ecf-408f-b3e7-c3a1ffa2bc87	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 28 6yqzsp1r	88000	250000	6	\N	\N	\N	2026-03-25 01:31:50.418+00
36b33509-bea9-4a54-a8bd-ac1b8ccbb09b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 28 f5a4a5p3	88000	250000	6	\N	\N	\N	2026-03-25 01:31:50.508+00
5f3fcd50-9fcd-4247-9d8f-cc4a73e24c27	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 29 yc4fows4	89000	250000	7	\N	\N	\N	2026-03-25 01:31:50.58+00
3d78cf90-21cd-4e85-ab5a-a888b69affb3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 28 bn8dcpjp	88000	250000	6	\N	\N	\N	2026-03-25 01:31:50.587+00
5537d87b-5df3-44e4-a482-8971eb7b3551	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 30 km2y4lfb	80000	250000	3	\N	\N	\N	2026-03-25 01:31:51.144+00
affdfd55-8bd1-477f-800e-b76910050b1d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 30 042fmm1z	80000	250000	3	\N	\N	\N	2026-03-25 01:31:51.341+00
9f99de2c-4dc9-452d-8c39-175ba88ef16f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 30 0mzngypf	80000	250000	3	\N	\N	\N	2026-03-25 01:31:51.728+00
ad18c2c6-498e-4f6d-a0ea-0535e16fa467	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 30 q8vp99ze	80000	250000	3	\N	\N	\N	2026-03-25 01:31:51.738+00
0579e157-c874-4db1-9ff8-9294bff2e519	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 31 77hfyzjc	81000	250000	4	\N	\N	\N	2026-03-25 01:31:51.823+00
62d807ba-2b11-48cd-9b68-5a3c3cf0fcab	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 31 eh85v24x	81000	250000	4	\N	\N	\N	2026-03-25 01:31:52.392+00
0df5220d-988a-485f-9430-0e163100c6dc	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 33 jj9iy0gh	83000	250000	6	\N	\N	\N	2026-03-25 01:31:53.465+00
45551572-8256-4c10-9a47-7df2e30b8079	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 32 sow0hq5a	82000	250000	5	\N	\N	\N	2026-03-25 01:31:53.842+00
f6909cd5-4123-497b-99ce-509db95ca8e8	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 33 puz5g1a7	83000	250000	6	\N	\N	\N	2026-03-25 01:31:53.872+00
1d1fd77f-4feb-4557-b3da-8ff305e0ce1d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 33 f8e8nq7q	83000	250000	6	\N	\N	\N	2026-03-25 01:31:54.167+00
1b5ec36c-032d-4ca0-aaf4-27899391af9a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 34 ulzwtbpk	84000	250000	7	\N	\N	\N	2026-03-25 01:31:54.275+00
d8121694-30ec-4875-9946-4ad2b068af0e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 33 226qkupt	83000	250000	6	\N	\N	\N	2026-03-25 01:31:54.697+00
836771cf-bec5-44d9-9daa-afe6005b84c2	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 34 7a159h9s	84000	250000	7	\N	\N	\N	2026-03-25 01:31:54.844+00
2f98b667-195e-44e6-b559-0abd078d47f3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 35 ee7wjlku	85000	250000	3	\N	\N	\N	2026-03-25 01:31:55.12+00
7e83d3da-3f29-4c55-afe9-b995b0be0167	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 35 r1v0dzcv	85000	250000	3	\N	\N	\N	2026-03-25 01:31:55.389+00
aae8f31f-ea63-4158-bf0f-0cfb483c60d1	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 36 w8vwf0no	86000	250000	4	\N	\N	\N	2026-03-25 01:31:55.393+00
d92ae55b-9c49-4265-bcd5-d75da4688753	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 35 t33qf17o	85000	250000	3	\N	\N	\N	2026-03-25 01:31:55.567+00
a7545cab-ab42-4970-a95c-9f2686bac39d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 36 sx13537o	86000	250000	4	\N	\N	\N	2026-03-25 01:31:55.957+00
9d75d3e5-3052-4c06-85d2-d8ebe0820ebf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 37 iz3mtm0v	87000	250000	5	\N	\N	\N	2026-03-25 01:31:56.458+00
dad45d85-af65-43c9-ac53-fc0a9814412a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
f27a7188-e935-4e2b-b2d9-625de951b482	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 0 xv5sp4ip	80000	250000	3	\N	\N	\N	2026-03-25 01:31:31.345+00
655e6687-d76f-4ab2-9ea6-feca377ab6c3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 0 yrjab97c	80000	250000	3	\N	\N	\N	2026-03-25 01:31:31.367+00
71b47442-ed96-4247-9685-92dcb2244a98	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 0 hg09rrf2	80000	250000	3	\N	\N	\N	2026-03-25 01:31:31.457+00
1bb8a0a0-cd0d-4494-913b-24e8abea1610	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 1 6tuwnh4v	81000	250000	4	\N	\N	\N	2026-03-25 01:31:32.111+00
e63a0149-8d6c-4387-89f1-83ab976e0cbc	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 1 k3xbkr8d	81000	250000	4	\N	\N	\N	2026-03-25 01:31:32.115+00
c852e0a8-23f6-4c87-bb4f-0e014e004812	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 1 lfpgg1da	81000	250000	4	\N	\N	\N	2026-03-25 01:31:32.117+00
fc07e5cf-e22d-440f-9400-a4480ca7e8bf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 2 psib1cg3	82000	250000	5	\N	\N	\N	2026-03-25 01:31:32.845+00
d8e0bc56-8853-499a-ac6d-fdceab63e9ff	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 2 b5y3qyou	82000	250000	5	\N	\N	\N	2026-03-25 01:31:32.847+00
dbf83eb4-10c9-4d14-9c5a-38c4168447a6	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 3 ebg25uhe	83000	250000	6	\N	\N	\N	2026-03-25 01:31:33.912+00
6e8d8144-f3f8-4642-ad75-ccec12e39400	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 3 un056159	83000	250000	6	\N	\N	\N	2026-03-25 01:31:33.941+00
c35da468-dca1-42e3-98ce-25b856690c1c	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 4 927hw5k0	84000	250000	7	\N	\N	\N	2026-03-25 01:31:34.567+00
b4486f18-0996-4a05-9493-5820a30832c4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 4 25kf1s7o	84000	250000	7	\N	\N	\N	2026-03-25 01:31:34.945+00
901035fe-76ac-4e2f-93a9-66da7a8cf7b3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 4 cycupc8b	84000	250000	7	\N	\N	\N	2026-03-25 01:31:34.953+00
94d2cd7b-7b80-4875-8e0e-c7be70512713	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 4 bt2n3r4o	84000	250000	7	\N	\N	\N	2026-03-25 01:31:34.96+00
17d17439-43bd-4c52-89b8-806534b72757	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 5 m3po96m7	85000	250000	3	\N	\N	\N	2026-03-25 01:31:35.145+00
a5d22727-b8de-4b04-979b-55f7890152d3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 5 ce97qhdu	85000	250000	3	\N	\N	\N	2026-03-25 01:31:35.73+00
568d0faa-b74a-4db3-b237-560c45b4790e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 5 gyf6z02y	85000	250000	3	\N	\N	\N	2026-03-25 01:31:35.739+00
42d80484-6f83-42db-83e6-979268e84f5d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 5 2af1add7	85000	250000	3	\N	\N	\N	2026-03-25 01:31:35.793+00
8c735ada-b023-49fe-b3db-de33c9230761	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 6 3r5xnie8	86000	250000	4	\N	\N	\N	2026-03-25 01:31:35.833+00
a40cffaa-faa5-49bc-a1f4-69be22b5fe9a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 7 oljf8oys	87000	250000	5	\N	\N	\N	2026-03-25 01:31:36.476+00
1014e601-12dc-42eb-b922-a5b3657202d3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 7 9kspt90u	87000	250000	5	\N	\N	\N	2026-03-25 01:31:37.036+00
163485fc-e5c3-41de-974a-3d2c7d04db99	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 7 mlajp0js	87000	250000	5	\N	\N	\N	2026-03-25 01:31:37.112+00
e7e12991-ac4f-4820-8ef8-d56903e5ab54	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 7 roggu7sg	87000	250000	5	\N	\N	\N	2026-03-25 01:31:37.119+00
71a18402-f51c-4e79-86c2-70834c67dbf3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 8 ilzenwd9	88000	250000	6	\N	\N	\N	2026-03-25 01:31:37.148+00
b5f97056-ddce-46d1-8e31-af5899e2284a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 8 eft5horp	88000	250000	6	\N	\N	\N	2026-03-25 01:31:37.245+00
679f7108-e756-4d62-bee1-8a7074653bd0	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 8 pkw4os3y	88000	250000	6	\N	\N	\N	2026-03-25 01:31:37.71+00
19ac6dbb-d7a9-42af-8737-13626b775bf4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 9 8v2lv15e	89000	250000	7	\N	\N	\N	2026-03-25 01:31:37.74+00
eea855d4-d5df-49ae-89c8-a510756b48af	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 10 fh0dxn2g	80000	250000	3	\N	\N	\N	2026-03-25 01:31:38.337+00
97b73648-4b17-451f-ab7c-b90257e795a6	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 11 4khxhiqg	81000	250000	4	\N	\N	\N	2026-03-25 01:31:39.055+00
bdccd12c-4749-4bf5-8290-c81935813472	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 11 zp48eiki	81000	250000	4	\N	\N	\N	2026-03-25 01:31:39.143+00
4007e923-c8d6-4429-bfd9-2651ac751c73	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 12 zebsl76i	82000	250000	5	\N	\N	\N	2026-03-25 01:31:39.271+00
27ff02a7-cb55-4261-b647-4223815321bf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 11 u7yf8wr9	81000	250000	4	\N	\N	\N	2026-03-25 01:31:39.471+00
8d3d3c5f-4dfc-4f82-80d9-10c13734738a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 13 9zgulu0s	83000	250000	6	\N	\N	\N	2026-03-25 01:31:40.197+00
8fd2d854-5770-4f73-b712-5913e0289c55	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 14 1h0knlkl	84000	250000	7	\N	\N	\N	2026-03-25 01:31:40.287+00
e95b20fe-32b3-4115-a646-d66275452cab	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 14 ba785643	84000	250000	7	\N	\N	\N	2026-03-25 01:31:40.505+00
993a53fe-8237-41b6-af4f-e58480400e2d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 14 gs3cry1h	84000	250000	7	\N	\N	\N	2026-03-25 01:31:40.737+00
643f84c5-37c2-486c-ae4d-7371ed850750	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 14 t8yqxq64	84000	250000	7	\N	\N	\N	2026-03-25 01:31:40.978+00
232399cb-cbe6-457b-8a14-c82b5e6b2267	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 15 rvbkk7j6	85000	250000	3	\N	\N	\N	2026-03-25 01:31:41.591+00
ebf13ce7-1df7-4951-ba1e-b3fc3b845206	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 16 tic8xu1e	86000	250000	4	\N	\N	\N	2026-03-25 01:31:41.787+00
d6df109b-20bf-4885-b034-aa65e2cb1ec9	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 17 0dh41imd	87000	250000	5	\N	\N	\N	2026-03-25 01:31:42.243+00
6c7829f0-1128-477b-8d74-79e6dcee20a7	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 17 5cdqm8ex	87000	250000	5	\N	\N	\N	2026-03-25 01:31:42.611+00
72e99a25-b2e5-4828-a856-0973d9dd173b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 18 ghq3eh7y	88000	250000	6	\N	\N	\N	2026-03-25 01:31:43.141+00
5ab2f899-cf67-41d2-bc83-58440e6da8b2	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 17 cfecvrm3	87000	250000	5	\N	\N	\N	2026-03-25 01:31:43.17+00
b79ef434-78ef-42ce-9cd0-94d33915010f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 18 r2ak2adr	88000	250000	6	\N	\N	\N	2026-03-25 01:31:43.57+00
f88841f8-db4c-4878-a580-40fe5a859867	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 18 twgzwf3x	88000	250000	6	\N	\N	\N	2026-03-25 01:31:43.665+00
6cddfe95-498d-4754-92c0-374d10ca19d0	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 18 803zng7o	88000	250000	6	\N	\N	\N	2026-03-25 01:31:43.872+00
923a41e4-32bc-4482-a509-006aacaa28db	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 19 p51sgv9a	89000	250000	7	\N	\N	\N	2026-03-25 01:31:45.055+00
c0ae46ee-e3b4-492b-9d3d-1fa30ad9d78a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 20 e1jluglo	80000	250000	3	\N	\N	\N	2026-03-25 01:31:45.696+00
e7218734-b656-47cc-85f4-fa5cc157575a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 20 s6jwn1jo	80000	250000	3	\N	\N	\N	2026-03-25 01:31:45.704+00
fe43d67c-6cee-41aa-881c-65af2c8962ec	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 20 jma3ehvo	80000	250000	3	\N	\N	\N	2026-03-25 01:31:45.718+00
ce4de4bc-34a7-4f7c-8915-dd032fa6792f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 20 nlv2smsz	80000	250000	3	\N	\N	\N	2026-03-25 01:31:45.723+00
b1f4651b-8508-4a42-9f43-1632b85526a3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 21 98jjofdt	81000	250000	4	\N	\N	\N	2026-03-25 01:31:46.333+00
6fe2b15d-5531-4425-8049-6932fc7bc007	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 21 seczb3gi	81000	250000	4	\N	\N	\N	2026-03-25 01:31:46.41+00
b7f016ef-ec57-4669-ad6f-6eaf34bfafef	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 21 1tfvsxwy	81000	250000	4	\N	\N	\N	2026-03-25 01:31:46.416+00
fef6b6c2-1536-48a2-87f1-f6d8b471a00b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 21 yl7lqqdo	81000	250000	4	\N	\N	\N	2026-03-25 01:31:46.439+00
585c07b3-0047-43f9-b6cd-5129247eaec4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 22 y85b1j7x	82000	250000	5	\N	\N	\N	2026-03-25 01:31:47.005+00
8922763a-8962-483a-94a8-50e87b7b34fe	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 22 61jewfhf	82000	250000	5	\N	\N	\N	2026-03-25 01:31:47.103+00
31500292-38d2-493e-a276-9670f16fd4f7	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 23 sbyieexw	83000	250000	6	\N	\N	\N	2026-03-25 01:31:47.64+00
cd7e861e-77db-42c9-a9f1-fed84c42e36b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 23 sjmh3a4o	83000	250000	6	\N	\N	\N	2026-03-25 01:31:47.785+00
45db6dfa-3f74-4a63-a9a6-84105067a3e2	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 25 sl87iuuz	85000	250000	3	\N	\N	\N	2026-03-25 01:31:48.692+00
797ec3db-e518-46d6-9d72-f7e889c868f6	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 25 dyi66oml	85000	250000	3	\N	\N	\N	2026-03-25 01:31:48.931+00
4587c632-7ac9-4bf1-b85f-3d6fd7cc1943	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 25 afxz5s4d	85000	250000	3	\N	\N	\N	2026-03-25 01:31:48.976+00
208bb691-01a2-49ff-9504-9a388c19682e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 27 4txq3f7x	87000	250000	5	\N	\N	\N	2026-03-25 01:31:49.568+00
c2ff88b5-c6b7-42f4-9178-eb79a16755dd	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 28 u6irqtha	88000	250000	6	\N	\N	\N	2026-03-25 01:31:50.047+00
6a6b337e-2260-4f5a-b2c8-a0c20224adf3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 28 upo77wiy	88000	250000	6	\N	\N	\N	2026-03-25 01:31:50.504+00
b045db8c-bf6c-40da-9103-685b8851dc32	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 29 raad8skl	89000	250000	7	\N	\N	\N	2026-03-25 01:31:50.897+00
dd409956-7cee-4d98-9fd2-4fefdf2184f4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 29 q4ed0n7u	89000	250000	7	\N	\N	\N	2026-03-25 01:31:51.099+00
f3ae43ec-e346-460f-a465-63d47c871acf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 29 to8pyzc7	89000	250000	7	\N	\N	\N	2026-03-25 01:31:51.113+00
908764fe-7b89-4ffc-9f1e-182a4950ce5e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 29 gwyutnpn	89000	250000	7	\N	\N	\N	2026-03-25 01:31:51.137+00
f93c8a75-ceea-43f7-a539-6013e5dd2340	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.08+00
7647a888-68cb-44ab-b3ea-9d1c395f5e05	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:35.926+00
693737c8-f65e-49c5-afef-c745f03c500f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:35.928+00
eb8fba15-c8b5-44d6-a352-7005f8c86ebf	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:35.885+00
bbe7fa78-eccd-4067-bf44-6bbf0642fcbe	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:36.722+00
2db008ab-3a98-4dbb-9e93-fe9d8590fd06	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:36.73+00
5e73b0a8-9ecc-47f9-8067-794bead4af8f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:36.728+00
153eae74-171e-4d3c-99af-312ce8b7f7df	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:37.452+00
51251134-ef58-49b9-a1b2-556140523604	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:37.452+00
86b35679-c85b-45bb-b54d-de481538fc04	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:37.451+00
391532e4-2920-4a84-a7e5-37105f21aec6	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.094+00
a1321425-db4e-400a-9fac-afbf89dcc1bb	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.09+00
62bf344a-59ac-4d18-a71c-b7c5dbdf59ee	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.093+00
4807ffac-ebc5-491f-896c-1dbf550a9f84	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.726+00
8e2e406d-6e83-4f34-b0a1-22922463b6dc	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.726+00
607d46ee-7033-4478-a82e-c845a6e8ef46	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.724+00
a4d680e0-5814-4b2c-b733-bcfae36c2a7f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:39.424+00
332253db-394c-4005-8045-b7c461abe93f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:39.422+00
d3bd349a-b6e1-4548-933d-3e432894b13f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:39.588+00
128dc5d6-d55c-4e08-a720-b0224a6cc215	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:41.878+00
29fa120c-1f48-4050-9c66-1ccda298ae93	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:41.96+00
bb0d0ad2-fe5f-449f-a420-96c5440dd87e	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:41.981+00
addcb350-56fe-4224-a862-0ed7f6c86fe3	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:43.257+00
0994383f-f3f0-4fe6-82f2-0ebf44c83388	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:43.256+00
8f3a97c3-5460-417b-a5b6-f3836fdc59ca	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:43.258+00
d384d90c-fc1f-4f07-bc0c-3c1dd4901c79	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.027+00
3d0a57ed-f362-4feb-938c-5bd1bfe29589	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.034+00
fa565a48-ac60-455b-881a-57ea8c0a050f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.034+00
a1ca22f0-f091-4b57-8813-d28fee48e018	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.762+00
6e184925-dd26-4b33-888f-0be7c38d1dff	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.761+00
ad1007a8-2822-4713-979e-1ac3daec3659	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.758+00
33f95ae7-0374-4c81-b9b1-013b54c4ffd1	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:45.459+00
fb26f679-7215-4998-a118-281453507cc6	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:45.457+00
89baa660-d5e6-4867-b867-d69316a57e52	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:45.46+00
19a45bb1-9bfc-4873-9fb1-da6e2c1128c9	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.164+00
6a18f7c4-787f-42d2-837b-10dadbec496c	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.164+00
ebf618c2-4cf4-4474-9a2c-92282ae7444a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.162+00
e11418a1-e19e-4361-aea6-74baee3fe296	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.79+00
71e1072b-9117-4ea4-9650-438a084bebe3	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.789+00
b6e62ead-b51e-4773-9a90-7d84965439ec	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.79+00
50dd598b-29fd-413a-b1be-429756af59c4	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:47.46+00
0e0c1711-c07a-4b52-abdb-45aa1b291741	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:47.46+00
7b177ec4-f47b-45a0-b010-eaf87dac5404	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:47.457+00
013295cf-f46b-4519-b210-d4f5a4a9fa51	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:48.273+00
43763a9f-dcdc-467a-aa39-6f4461258309	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:48.268+00
8f2b1a99-c083-4bac-b9dc-e9ad520d89cb	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:48.274+00
a6357c6e-a88d-442b-a475-4497049059b0	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.047+00
9211637f-6eb8-420e-a7e8-c541753d0b88	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.052+00
e2ffbce4-3286-4cb7-ac2a-b9a9205ac08c	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.054+00
07efcbdc-fa0b-4093-9351-5688afe27b9d	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.692+00
23f9e38b-f274-484d-b592-d0e71b408272	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.695+00
eae37d37-df44-4c91-a5a8-ad49d1907949	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.696+00
afeca1ee-2a72-4e42-b0a3-c161d8d4909a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.351+00
c7550d22-6ff1-442b-9d7a-e8d4dffc4237	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.351+00
a4bc7eb1-f184-495f-a4ee-75e0de1143e9	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.35+00
3b4766ed-8756-47b6-a686-e7bacd0ce17a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.972+00
db5bfd89-a4af-459d-9f53-7a7a845c6da4	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.971+00
9e656feb-3f2a-41c3-993d-339a90986894	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.974+00
eec82d10-6321-4274-8085-e564effaa25e	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:51.614+00
e3decacc-874c-4af4-a09a-dbe4600655ec	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:51.613+00
85f32142-2e3b-42e4-8af2-4899ef679c33	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:51.614+00
e4684d4a-27b7-4a78-9680-0bf8d57b3e5d	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.19+00
bc4697bf-40f0-45b2-9695-a1bcd9e32dd6	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.191+00
0c8a2153-62bb-47d2-a502-62feb6e4980f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.191+00
2b86cadf-97cc-408e-a0e6-14a151e0adfe	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.744+00
b14b7fa9-4cc5-48bc-af86-f51c9867da8b	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.744+00
c95bfc84-5ae9-4141-9d3b-02ace68f413f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.744+00
1875f2b1-faa4-4c2d-8c00-2835db4f2d5f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.293+00
674c9742-7ac3-49ff-ac51-24413b9d7672	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.294+00
e4456999-0426-49c3-8d2e-178ab5043126	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.294+00
9de671e7-912b-436e-862f-197a38f6795a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.848+00
4729aa10-70a2-4d18-ac36-3664cb015db4	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.849+00
88914cef-54bc-4e79-b146-68466aaf820a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.849+00
768b71a1-0be7-44e4-bff5-cfca769e5fe0	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:54.407+00
4a3e8ed6-cb1d-42f0-ab73-aefb2dbc4290	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:54.408+00
daf0abd4-6bc2-43bb-972c-deb069686914	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:54.408+00
0cfe5959-984f-4c61-b0ab-2a18a89541c4	f872a417-3409-4bd0-bf41-c7129108554e	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-22 19:25:11.16+00
696a9825-05db-42d2-af6b-e2ff3d64e39d	958e471b-aa70-4374-a38d-8544ee85b5fc	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-22 20:20:56.49+00
556e9a92-6800-4b2a-b603-e1b459ee3089	a4a667b1-c43a-4092-a0d1-a437172faa7a	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-22 23:18:09.161+00
28dce675-a75e-4080-a93b-690d5a3da1f3	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 d3fqv97o	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.287+00
1ca4ced9-db5e-4237-a3da-91d532f7a450	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 oa8g6ftj	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.429+00
d0c5b17d-09f1-4ed3-8178-5d85b121a806	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 7ixsaye5	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.43+00
018b504b-4701-4bfa-8ee4-518184416c64	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 z63isngy	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.43+00
0f9d3b41-8310-48f4-a304-484f939d4ea2	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 ujrnetbw	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.458+00
f9586ece-22fe-4df7-acdc-cef9a4cb3e89	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 nj78shfz	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.463+00
d6764189-834f-4b0a-b85a-a1f33e137ed8	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 wacs91hb	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.156+00
b2b86f65-000b-4b42-b269-82018b158e70	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 d5p9s91o	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.162+00
489e4958-dbc8-4fbb-a003-ef9841bf2897	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 l3oxjbzw	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.165+00
f9484a58-8ec6-4bcf-a13f-f4858f0d2f1f	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 6223rgs0	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.227+00
b69ddf6b-7546-4dca-8761-493bbc58b6c7	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 8wt3zq4r	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.363+00
2b817540-864c-435c-bb2b-2e8090525dcc	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 xdwbur7j	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.26+00
21609c8c-0116-4516-a694-71d0ffdd8d9a	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 f73x0mql	82000	250000	5	\N	\N	\N	2026-03-23 00:33:12.987+00
163cc0c9-cbf2-4669-9e11-b66f6c8c330b	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 9i3vmmry	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.209+00
53872dc7-3157-41bf-bc07-ad158ecbacf4	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 3u2mpz9y	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.215+00
021d2187-6e8b-4cb5-86e3-ac9b6071e48d	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 lj1bsh6t	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.22+00
5cb76f5c-ad13-4c51-b27b-ae695edd2e46	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 zkxezp5t	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.223+00
3afd6b9b-0a2e-4730-a455-190218e49d4f	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 53yrjc3z	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.227+00
8f034492-df73-4f95-a048-dffef8ef0ef0	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 3 8otn1067	83000	250000	6	\N	\N	\N	2026-03-23 00:33:13.629+00
cea85453-d1ac-4fa2-98c6-475b508df9ea	d9c4b3a1-4517-459b-8e71-416b6f3a0df7	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 00:34:07.958+00
eab8e68a-e228-4d73-b1ec-9574c1a4afb1	f9b62a55-8b9d-4486-b719-129c4dca6d66	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 01:21:50.969+00
2389c5a1-c314-40f2-b3c0-c45b30095b61	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 aakekldu	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.561+00
41463d32-c367-414f-9e39-8deb3d7ded78	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 w96wd96o	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.562+00
aee5c23e-c0b4-4a99-8800-e11edc5501e9	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 7rx54kre	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.561+00
d911abe8-aec5-4fc9-bb32-b4d485d9b94c	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 rk4cw74z	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.563+00
7c025207-be84-4998-9f4c-64b11f9e788f	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 kdzuud02	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.638+00
d458baa9-f02d-45f6-9b7e-54e45d61206a	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 2uc9x2ad	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.638+00
18a0198f-0bae-4c0b-926d-91e582def4b8	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 othrlojn	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.845+00
9172c45c-3951-4be0-aca2-94917391306a	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 j8ujo3jm	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.896+00
01d37a76-f24e-4c6d-8dfe-8429ea9b109c	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 3sf5myg5	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.96+00
5e8d2a61-8f25-4391-82a3-c3f7fe8f8c32	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 c9ko6fd8	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.968+00
5126508e-7d5d-4e8b-a880-1e195d3053e0	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 z9rnwms5	81000	250000	4	\N	\N	\N	2026-03-23 03:34:53.038+00
c68264e7-d15f-4b16-bee2-4d1472e0c45c	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 aok74r8g	81000	250000	4	\N	\N	\N	2026-03-23 03:34:53.063+00
8242182d-2892-4c87-9806-8aa0bce2093e	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:02.439+00
a0ba847b-1151-4f90-8c7f-afbfedc5e40f	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:02.485+00
75a90fd4-e2bc-4d15-8d7a-102448b8ac23	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:02.519+00
a3ddbf0c-6b77-4ccf-bdc7-24e34742d4ad	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:03.578+00
27a0e510-797f-4537-823f-10da26751088	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:03.584+00
5cf6e456-5516-46c5-9ced-ae7cf5e1d5d1	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:03.591+00
1f94589d-faa0-4379-a28a-d8bc9f6c6394	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:04.704+00
4fcd365d-3ac9-4d01-9ffe-08558ba98745	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:04.725+00
557bba87-a34f-41d3-b12c-d6caa3ae715d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:04.813+00
5728ecf3-7768-476e-8f11-69c351767afb	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:06.551+00
db4c1a87-57f4-44aa-8c1d-92850f29d20c	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:06.863+00
e325ba6e-662e-472c-bdee-dd848978e9f2	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:06.87+00
f9d0bc20-67d5-42aa-9018-e2f63b52db18	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:07.296+00
c28a35f8-70c4-44a6-92ec-2019de3721d6	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:07.601+00
db3a5863-ed09-4145-aef3-95b484b0d65e	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:07.603+00
f9e45762-0e69-48c7-8851-852af84791dc	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:08.202+00
98ccd5a6-471e-4448-b7de-ca79d59d151c	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:08.71+00
3349e0b2-5418-4841-80bb-6ba02c38eaf7	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:08.793+00
215830af-5efb-4f36-9e17-88006d262283	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.228+00
8d674500-b8d0-4ca6-9395-5b47325ad556	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.697+00
3c6f548d-ef5a-4686-8d1f-5c5df482a5ea	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.701+00
ac13b8d7-20ee-4319-9752-e340005c637a	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.872+00
5d941fb1-8923-4908-9af8-b795e2817907	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:10.362+00
ecb91dd8-13bc-41bc-ac85-749b104e879e	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:10.366+00
d2e5b70c-6348-4947-95e5-0a4b78e89a43	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:10.589+00
184eb7ca-26be-407b-9433-d562e945db9d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.045+00
6227117d-79ca-4160-b7bf-8672d3c3e472	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.047+00
fb974df6-8ddd-409b-b7dc-50121f208d55	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.245+00
46fc2e02-0f80-4097-a36c-22bcd348e458	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.724+00
83345794-e45c-4983-9e0e-8824caab77a1	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.728+00
ef24d56e-d0b3-434c-b96e-e8253fd5286b	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.906+00
1d6e4bf9-cd75-4d7a-93e5-e4c4d1b95356	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:12.39+00
6fc97707-8255-4c8c-b8a6-e88d89db6034	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:12.392+00
d97c9a5a-e8b5-4629-bdd4-354730d5e482	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:12.553+00
f5f6f1d6-196c-4093-a7f6-01a263792e9f	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.026+00
2a1937d3-cb6b-44b1-bb23-b3524c319fa4	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.045+00
e2412593-38dc-4630-bc9e-cc8cdfe67b6b	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.161+00
1ab9e06e-7068-46df-a118-fd5d4467b678	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.686+00
c68bba76-48be-4be3-9009-cd5437494c73	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.803+00
5274b74e-4e8d-4df8-815f-595bd37eb8b3	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.097+00
d7ddfd62-000c-46bf-86e6-0bc17446cbe5	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.257+00
e1714111-6201-4e63-8914-cd14cda1ed32	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.27+00
fcd2a483-b236-425d-b2a4-3cd60a8e9d29	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.707+00
ca8498a7-5219-4c5c-9d72-a6b1a7b5523b	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.871+00
06855dae-10b5-4142-b550-bea6aa383dc3	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.925+00
dbfe76bd-4639-49f1-819e-842c496db424	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:16.616+00
b0108857-1458-4997-8758-4cf53fc8d688	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.39+00
d182cdcb-5d2a-4082-bd23-9622cedf6b73	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.79+00
6a9638cf-8e70-4d3a-bbe9-aa3abdd4fef3	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:18.387+00
19058681-e4ad-4b05-bfb1-ee73f97abf74	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:19.392+00
fca6e87d-5c9a-45a7-9c5d-d97ffe2757dd	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:19.992+00
14008c91-740a-44b7-b641-126e54b19e78	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:20.09+00
62f6eefa-0e7f-41cc-9667-5eb312010717	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 1 b0g1r3y3	81000	250000	4	\N	\N	\N	2026-03-25 01:31:32.097+00
8ea16e01-7543-4eee-8112-52b7c1078350	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 1 y2taock8	81000	250000	4	\N	\N	\N	2026-03-25 01:31:32.109+00
a88d0141-e910-4f29-933f-a3d7fa5e0e38	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 1 6shskque	81000	250000	4	\N	\N	\N	2026-03-25 01:31:32.113+00
a06e78f9-74f9-403e-b72c-918835bde35e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 2 fmguya4s	82000	250000	5	\N	\N	\N	2026-03-25 01:31:32.843+00
8ae148b5-6482-4383-b91a-a6b66232f9bc	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 2 ymz7wqzz	82000	250000	5	\N	\N	\N	2026-03-25 01:31:32.866+00
35453442-ed73-45af-9807-225e292faa8d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 3 tr6v1yek	83000	250000	6	\N	\N	\N	2026-03-25 01:31:33.806+00
d3998877-a5c7-460d-b22f-66f5b68cdbfc	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 4 cnhs8h1p	84000	250000	7	\N	\N	\N	2026-03-25 01:31:34.957+00
914cbd15-a0ae-4470-8a66-f6ad00dee8e3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 5 fjg0hhpd	85000	250000	3	\N	\N	\N	2026-03-25 01:31:35.724+00
3c198bc5-dcbb-4d0d-b7a2-57665567ae86	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 6 4948u1ht	86000	250000	4	\N	\N	\N	2026-03-25 01:31:35.836+00
59d3885d-1778-4869-9ca2-30fdb658cc2e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 6 m6emngbb	86000	250000	4	\N	\N	\N	2026-03-25 01:31:36.309+00
382074d1-b357-4603-b115-efef9e2e8cc9	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 6 qqoupmsz	86000	250000	4	\N	\N	\N	2026-03-25 01:31:36.407+00
d29c9ae2-eef4-4a8c-9127-e75742c91d33	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 6 osthdozt	86000	250000	4	\N	\N	\N	2026-03-25 01:31:36.411+00
ce2dacc9-86dc-432f-abbf-85b36a3c81e8	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 6 jfw35yc2	86000	250000	4	\N	\N	\N	2026-03-25 01:31:36.471+00
25dcaf4e-ce4a-443b-83e1-e4636669ceed	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 7 5n42e1g0	87000	250000	5	\N	\N	\N	2026-03-25 01:31:36.78+00
255f47f2-25df-458a-9a14-33f2ecfd3889	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 8 ap9uop91	88000	250000	6	\N	\N	\N	2026-03-25 01:31:37.121+00
8fd31caf-581f-4449-8d23-d25f68167382	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 9 ezihuh34	89000	250000	7	\N	\N	\N	2026-03-25 01:31:37.973+00
6068cb8f-6ba1-4bfa-9e3b-6b3aa3220773	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 10 xsq4ioux	80000	250000	3	\N	\N	\N	2026-03-25 01:31:38.298+00
dc2a42af-6614-4b19-9556-a38f2b140c91	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 10 ivfbrom5	80000	250000	3	\N	\N	\N	2026-03-25 01:31:38.691+00
92caee3d-e3ff-4204-974d-6267af7426f1	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 11 3cdidr6r	81000	250000	4	\N	\N	\N	2026-03-25 01:31:38.805+00
9a7d6e1f-0779-499f-977d-6f11b81ea393	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 10 dxxh0lvl	80000	250000	3	\N	\N	\N	2026-03-25 01:31:38.901+00
2d7acad4-b7e1-47af-94eb-abccaa9e327c	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 11 47yqyqiv	81000	250000	4	\N	\N	\N	2026-03-25 01:31:38.968+00
3a609421-dce9-42cf-a1fe-e68ea3c04ed5	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 12 dbz91z9r	82000	250000	5	\N	\N	\N	2026-03-25 01:31:39.584+00
c874caac-4775-4f43-b5e4-02324643a546	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 12 9exr38tq	82000	250000	5	\N	\N	\N	2026-03-25 01:31:39.644+00
9d97de2a-7c03-47b1-90fd-84fa626ff845	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 12 uu19jtp8	82000	250000	5	\N	\N	\N	2026-03-25 01:31:39.668+00
c076c575-050a-4eca-8fb0-be9ffcb301a1	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 12 rx21wckt	82000	250000	5	\N	\N	\N	2026-03-25 01:31:39.709+00
58efaeef-fbf1-424e-9b64-ab3a6081745c	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 12 erxhxz3c	82000	250000	5	\N	\N	\N	2026-03-25 01:31:39.912+00
c63a9102-c35e-4397-8bf9-13f1cbf1d59f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 13 g79s288a	83000	250000	6	\N	\N	\N	2026-03-25 01:31:40.08+00
2e8e8122-d61e-4fb9-bdc6-48c236585f59	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 13 vr6gegsu	83000	250000	6	\N	\N	\N	2026-03-25 01:31:40.195+00
13045ef7-f6aa-461b-9ed9-d9b758c31042	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 15 hzsn0roj	85000	250000	3	\N	\N	\N	2026-03-25 01:31:40.976+00
a4506707-414e-4dc6-828e-a97f7695a6da	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 15 5rn5vblx	85000	250000	3	\N	\N	\N	2026-03-25 01:31:41.303+00
53865d08-7cdd-4f06-9d1e-5218c494b69e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 15 lydh0q6h	85000	250000	3	\N	\N	\N	2026-03-25 01:31:41.469+00
e5001439-9202-4c91-99fc-2958c0555bc8	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 16 txq5sgjn	86000	250000	4	\N	\N	\N	2026-03-25 01:31:41.589+00
694f40f2-8e8a-43a2-9a48-863427503116	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 16 qs1h4lxr	86000	250000	4	\N	\N	\N	2026-03-25 01:31:42.067+00
a483af42-4a8e-49de-af89-448d9c7922a9	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 17 0smeq0v5	87000	250000	5	\N	\N	\N	2026-03-25 01:31:42.208+00
784ac655-e2bd-4373-bab6-6265602ef615	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 16 8nlqggf3	86000	250000	4	\N	\N	\N	2026-03-25 01:31:42.313+00
3f6f0cad-b10c-4a20-b888-5c66f8e1c7e7	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 17 4xxvmyeb	87000	250000	5	\N	\N	\N	2026-03-25 01:31:42.387+00
6b82aa55-b231-4b9e-8e1c-e113cab85403	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 18 r859ijhh	88000	250000	6	\N	\N	\N	2026-03-25 01:31:43.168+00
156b86d7-1462-4899-9576-9537c2c14db3	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 19 crshfa88	89000	250000	7	\N	\N	\N	2026-03-25 01:31:45.037+00
5d36336b-8125-43ed-ae54-d4b32426e6f5	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 18 euyuhdi3	88000	250000	6	\N	\N	\N	2026-03-25 01:31:45.047+00
56c9eb05-7383-4bbb-9c54-53c854b47e67	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 19 z69ge897	89000	250000	7	\N	\N	\N	2026-03-25 01:31:45.052+00
46acbdc2-084f-4bff-836c-d74a153b69e5	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 21 euihhb02	81000	250000	4	\N	\N	\N	2026-03-25 01:31:47.007+00
664cae3b-5ff2-4ea3-801f-0301ecc2fb52	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 22 r7bbwcin	82000	250000	5	\N	\N	\N	2026-03-25 01:31:47.064+00
4979e25a-302f-43ed-9369-03cc5edd2862	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 22 r244g5bj	82000	250000	5	\N	\N	\N	2026-03-25 01:31:47.068+00
2cd2ff4f-1144-4126-952e-2dae515e25bf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 22 vv9vgf94	82000	250000	5	\N	\N	\N	2026-03-25 01:31:47.101+00
c4d641a7-ec3a-4ab5-81f2-a01ee2bb096b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 23 dz3kum2n	83000	250000	6	\N	\N	\N	2026-03-25 01:31:47.787+00
d8f851ff-9f57-403b-ab3a-67dfddd962bf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 24 y608u7ib	84000	250000	7	\N	\N	\N	2026-03-25 01:31:48.244+00
7d91b5a9-ba19-43b1-8bef-435d9fbe7b79	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 23 7ibwiqeh	83000	250000	6	\N	\N	\N	2026-03-25 01:31:48.27+00
074cab4e-f037-469d-963f-985eb1df992d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 24 xoho4lln	84000	250000	7	\N	\N	\N	2026-03-25 01:31:48.39+00
f344b126-a63c-4572-b9fb-f8ee36d1d520	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 24 3r67klhp	84000	250000	7	\N	\N	\N	2026-03-25 01:31:48.395+00
0644987e-ea25-4e83-a960-705db5155cbf	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 24 gqaslgg7	84000	250000	7	\N	\N	\N	2026-03-25 01:31:48.402+00
b736df5b-67a7-4f9a-b66c-01ed536fb522	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 24 55ylhhm0	84000	250000	7	\N	\N	\N	2026-03-25 01:31:48.407+00
257dda68-f2af-4546-b7ae-1e0c48747ece	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 24 6urh6y4d	84000	250000	7	\N	\N	\N	2026-03-25 01:31:48.694+00
e60d1cea-53d9-4105-9635-3e30a7f1e1fb	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 25 wub0v93o	85000	250000	3	\N	\N	\N	2026-03-25 01:31:48.929+00
50d52e76-3e77-4128-a3c5-95af25014fc7	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 25 ehu4u8zy	85000	250000	3	\N	\N	\N	2026-03-25 01:31:48.978+00
fdccf677-2829-4661-8ff7-791c1b177c62	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 26 zkee4b8x	86000	250000	4	\N	\N	\N	2026-03-25 01:31:49.151+00
92e6a5d4-8582-4d8a-9d8e-8fc6dbb0612d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.689+00
15acdfbf-979c-42f8-861d-1a6bf1ed6421	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:14.454+00
4ad621d9-9cb4-4957-b299-00d1f9f3dc91	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:14.527+00
01be74e9-4cb9-42e8-96b9-165b8e1d2261	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:14.604+00
2f7e989d-f88f-4e56-b517-3574c818872d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:16.363+00
efde0fb7-db57-48d6-bf27-1f03fab7b9af	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:16.557+00
cbff0a0c-7f66-4e21-a3f5-a89cdd670b44	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.027+00
080ac91c-1e06-4f0d-961b-62a831105beb	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.292+00
86bf0494-5120-4284-9097-ab5a658aeca1	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:18.785+00
086134dc-88c8-4841-917b-c4f6e2066951	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:18.994+00
a8e873e0-964c-4032-b7cf-bd0a457a9a83	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:20.392+00
6453ad95-ad7a-4c76-a867-33f0d730db02	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:20.914+00
49b2b199-ef41-42fd-a625-b607af12f996	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:21.012+00
40c060c9-b8bb-46b4-ad72-c30956840aa0	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:21.134+00
76bcfc2b-f3a8-4dfb-a76b-e807de65e134	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:21.559+00
da8bff4c-469b-4c97-b78c-0865c40259fd	ed711d1f-2108-4fbc-bf9c-f915dc2d4c36	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 15:12:40.917+00
69bbe2f5-7b9e-4147-94f8-540d51e600e2	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:29.915+00
3de6f47a-242b-4a08-a58f-c2f2bfab220f	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:29.852+00
5f376e14-7fcb-4381-9414-47a8d197e951	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:29.913+00
382028c8-d37e-4104-8a11-d33a5fb11f77	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:31.842+00
f55eac3d-1c1a-46f5-8b6b-3f5199660beb	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:31.919+00
3d0be33b-d4c9-408b-8ccb-ac6efbb649a8	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:31.928+00
111f1c18-c56c-490d-bbc8-9fba18fc071e	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:34.647+00
0a0c5a42-2cf1-4fdb-ad20-47326a95d8a9	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:34.699+00
1263acfe-6128-4e96-ba7b-9acd3cbedc31	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:34.702+00
0952329d-aac2-48dc-9688-e40ce9c9a8a9	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:35.343+00
0c954591-38b5-4471-b8d3-250b4a059360	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:35.366+00
5f64b93f-c0f1-482f-bc5b-83fa75828ab7	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:35.37+00
5eb06824-b242-410f-8ab4-9a532356c5a3	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:36.272+00
8a528b60-c397-4bd5-b31c-fb615b2adc26	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:36.276+00
cd9c38c2-fd44-45b6-ae9b-3e8b1d4d5215	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:36.279+00
e8da43f0-478e-4600-accd-011bcea92f8c	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:37.336+00
7fba9a6d-67ad-4a3a-868b-5518af9fe97c	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:37.321+00
f1cd8442-ab33-4d12-803d-afae720d7977	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:37.328+00
1beecb68-1b4b-4769-b461-285ea3e097d1	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:39.316+00
554e1951-e348-46d0-b25a-fca4524e6d2a	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:39.321+00
1079a768-a455-4f57-b70f-032ffac4eb97	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:39.323+00
6c959953-011c-4909-85fd-c07a7c5e4245	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:40.323+00
f888bbd4-7e04-4eb9-9478-27bfe0797346	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:40.398+00
a7fb9991-b7ab-4589-9c64-4adf70baac1d	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:40.415+00
40a76ab4-fcfa-4fce-80e8-007b7c60b48a	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:41.616+00
f61658c6-5732-495e-84e2-e41903766e4e	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:41.705+00
954b99c1-cf49-4d3e-9e20-1eaeb5887447	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:41.718+00
f3d322a8-8f35-41d2-9f97-4c2ebb21b831	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:43.096+00
ce3ce617-eb41-4731-8cbd-08838c17d7f0	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:43.201+00
1249b16f-a566-428f-9e4e-61a78e6ecb99	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:43.215+00
e9b1589f-e78c-48e0-9caf-027af9d5efee	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.041+00
247d979c-e459-4e4b-b367-9a6597fd5979	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.133+00
b7dfede5-53f7-4937-b6a9-d3b9c5c27279	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.136+00
1afa5cdc-4918-41ca-a906-1cf1f6dc0c06	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.865+00
b7a62606-f5ba-41a5-ba07-e5c94342ea28	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.917+00
2a22f52e-59b6-41bd-98a9-d6092f00d860	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.922+00
7726a3c2-7f2a-4d0e-9d7d-0e998f909246	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:45.685+00
1d3e837a-dfe0-4705-ae27-5034fe682ae1	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:45.695+00
8b55d781-aab4-43ef-a92c-ba5d2acc01a8	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:45.703+00
4e91b3ac-35f9-4820-9f46-ef3720f138a1	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:46.423+00
c3959d01-103b-4844-a8f7-f4872b00ac90	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:46.425+00
09be8578-76fa-403a-9244-d6fa0a6847d0	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:46.428+00
3bd23656-7e61-422f-a1c8-fc41499d7017	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:47.502+00
f8db5f0c-e253-4315-9651-b7fe4aed8b42	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:47.517+00
92359d49-70cc-46a7-a0b1-bccb76c5a205	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:47.52+00
34e26bed-f992-4f75-9d5c-2b9d76d2efc3	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:48.31+00
c52a862d-d7b1-4d42-abfe-2c43dc15e914	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:48.314+00
b669c080-c359-4134-83bd-96f3b92db6bc	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:48.317+00
62b8549c-f85c-4bb0-bbaa-d5fe70cbddb2	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.162+00
dd522a68-eb6e-4d81-be1b-8eba23f7a958	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.166+00
fee1aea7-5cd9-42a5-a553-1ac7885dda04	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.17+00
2d7be938-4734-42a5-9678-eb9bb9f9631f	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.936+00
ec2eb833-3a62-4dfd-85a5-862965225537	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.939+00
835e4f98-5689-4f33-8ad7-d59d5ab96211	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.948+00
31a6ede3-705f-42ba-8002-9eb0b41e1d96	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:51.036+00
b77a6f34-c560-4409-a72c-b7b3c6d09824	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:51.12+00
dd3876e5-c9e4-48a7-8b04-2dbcf20cf6f4	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:51.123+00
f919a017-b73f-491e-9233-78e834c4f544	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:52.203+00
fc6e5206-0523-4d9a-8bbd-0f3732a87cf3	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:52.224+00
3dc97fb1-8382-4050-aae7-740c5bb0464f	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:52.288+00
73bd5a3c-0e9b-40fa-9c9c-6ea567ac1abd	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:53.621+00
4258ddf6-d2a8-44a0-84ed-3f24ff72e0ba	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:54.465+00
b734f0ed-55bd-4321-a7e6-4de985f220b5	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:54.471+00
3e0bf8bb-b99e-45a1-8e5b-f2b489e0e7ba	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 j1g82etk	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.025+00
18972edf-ef7d-4368-9cf7-d63c88320d9a	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 mukt6z30	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.143+00
e1db18af-959a-4838-8080-e3825a533ed1	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 ccvyti5r	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.162+00
c015c6ff-540f-4645-809f-eb89d62e7704	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 9zyrnu0h	86000	250000	4	\N	\N	\N	2026-03-23 17:22:22.817+00
490215af-9737-44e3-b788-73861a835cee	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 o0lkelqz	86000	250000	4	\N	\N	\N	2026-03-23 17:22:23.016+00
37a672df-d524-4029-be96-8ed046fc884b	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 2indx9b9	86000	250000	4	\N	\N	\N	2026-03-23 17:22:23.116+00
1a050554-0ff5-4574-9ef7-8a6e9f7ed62b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 26 7al46kl5	86000	250000	4	\N	\N	\N	2026-03-25 01:31:49.4+00
82cd5096-ac00-482a-b21d-4aa62f99d53a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 26 daknp3h8	86000	250000	4	\N	\N	\N	2026-03-25 01:31:49.432+00
bbe68099-795f-4c53-a7b0-07aecdc888ba	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 27 qfeo9p8i	87000	250000	5	\N	\N	\N	2026-03-25 01:31:49.891+00
13911ec7-eda2-49f3-a5b5-c56e467ebce6	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 27 abigwhjm	87000	250000	5	\N	\N	\N	2026-03-25 01:31:49.901+00
6fb3693d-77e9-451a-8655-f9327e04e7af	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 27 xpaxmrkm	87000	250000	5	\N	\N	\N	2026-03-25 01:31:49.939+00
c5878126-c25b-4d08-a1a3-7d0a771789ad	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 28 0inwmcpt	88000	250000	6	\N	\N	\N	2026-03-25 01:31:50.506+00
a0cf8553-037a-4ad1-b754-6fb34f978da9	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 30 mgggfy92	80000	250000	3	\N	\N	\N	2026-03-25 01:31:51.73+00
3a441268-79e7-4f04-892b-4b0d3687dd1b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 31 b1ig1u6i	81000	250000	4	\N	\N	\N	2026-03-25 01:31:51.736+00
e8603a20-96fb-43ce-8322-a49086b0c93d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 31 0g95h9bp	81000	250000	4	\N	\N	\N	2026-03-25 01:31:52.327+00
06ec53b2-c71c-4219-bc49-7e7f1bb2869a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 31 6jhzitvs	81000	250000	4	\N	\N	\N	2026-03-25 01:31:52.336+00
190f95b3-9e08-4877-aeae-850de0a5ef4a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 32 kecm4usw	82000	250000	5	\N	\N	\N	2026-03-25 01:31:52.968+00
45e34be0-2dc9-4105-bdde-041ac039cd16	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 32 3tndwwnw	82000	250000	5	\N	\N	\N	2026-03-25 01:31:53.34+00
c27c8082-92b2-4cd8-a7d5-fb50e911c7cc	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 32 7b69h297	82000	250000	5	\N	\N	\N	2026-03-25 01:31:53.442+00
f2ac18aa-3ec7-4d86-94c3-657d08c19c6e	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 33 6v3e2s6d	83000	250000	6	\N	\N	\N	2026-03-25 01:31:54.14+00
f8077c8e-d16a-48a8-9f6a-1f60a645f5eb	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 34 unwn8yn4	84000	250000	7	\N	\N	\N	2026-03-25 01:31:54.699+00
1711b526-c2ec-4922-bae1-5ff442957fde	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 34 oer88pde	84000	250000	7	\N	\N	\N	2026-03-25 01:31:54.846+00
d870a4de-67f5-4cb3-a0d0-da7de46c9d89	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 34 75fzncnw	84000	250000	7	\N	\N	\N	2026-03-25 01:31:54.855+00
cb0c70fb-66f4-4fa9-b25e-fad4af1e9222	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 35 3fgngmrq	85000	250000	3	\N	\N	\N	2026-03-25 01:31:54.88+00
139e335e-f138-43ec-9fda-341bc9a63cba	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 35 4reg93h7	85000	250000	3	\N	\N	\N	2026-03-25 01:31:55.396+00
51995a98-4872-4bd0-bbb7-38a5c7a24291	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 36 291ec5lh	86000	250000	4	\N	\N	\N	2026-03-25 01:31:55.568+00
191ab725-c8e5-431a-ad54-77efd1f99e76	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 36 y693fnq0	86000	250000	4	\N	\N	\N	2026-03-25 01:31:55.916+00
b82ad568-29ba-4d43-befc-6344810ad174	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 36 cjux2639	86000	250000	4	\N	\N	\N	2026-03-25 01:31:55.954+00
3d66c38d-4e16-420c-b10b-ce723f7fcc68	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 38 4igdxiiz	88000	250000	6	\N	\N	\N	2026-03-25 01:31:56.459+00
8eacd349-6747-479f-9328-449d63fcff1b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 37 smz39787	87000	250000	5	\N	\N	\N	2026-03-25 01:31:56.476+00
8add2c88-9bda-4ea5-8b88-8466d4dfb82b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 38 50zx9tt5	88000	250000	6	\N	\N	\N	2026-03-25 01:31:56.624+00
80e63ae2-09da-4d0a-8a2c-188bd7222ca4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 38 4u7o25t8	88000	250000	6	\N	\N	\N	2026-03-25 01:31:57.23+00
dff0d44a-a9f1-400c-8ec7-fe00742f23e6	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 39 g1qzag6k	89000	250000	7	\N	\N	\N	2026-03-25 01:31:57.866+00
c20a3c99-dac9-4bf6-a3bd-e9d7a746ad14	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 40 g7sqmd4l	80000	250000	3	\N	\N	\N	2026-03-25 01:31:57.87+00
a5588c28-37df-4188-a45e-c9fd085dadae	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 40 2y5jat6q	80000	250000	3	\N	\N	\N	2026-03-25 01:31:58.77+00
fae9d191-dcbb-4408-b077-4421a86c98e5	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:04.848+00
fa02a4ab-ac03-4da2-a6c7-5bded3cb6416	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:04.865+00
a1880b49-a1c5-41ec-81c5-6f74964183fa	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:05.595+00
ab13d568-8134-44e4-892f-be9018ce128f	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:06.252+00
1a107060-5a93-4239-aecc-b6c0e68cf83c	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:07.648+00
626f72e3-b650-4d21-acda-d92acfad83ca	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:08.674+00
f21b2ae1-02b5-46b1-8f7d-d3f0b03a22eb	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:09.418+00
fc51ed84-aa1c-46c4-bafe-5b281b6963ad	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:10.08+00
3fd99d3c-1bfb-4075-ad07-cefa67a93a23	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:11.495+00
3976d33c-03a0-449c-9b56-7464412a3551	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:12.669+00
d6557698-b559-420a-a9e9-f062b5e6a6e5	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:12.864+00
94660660-b05a-49ee-8d52-9f10aebedea9	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:19.062+00
19882395-3804-465c-8ad5-ef51b5db74da	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:19.645+00
d1bc6413-b697-4d14-acd3-2e23944b7355	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:20.282+00
57cabbea-33bd-4124-97e9-5924ca7a1962	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:20.958+00
7d7dedf5-aac3-4ca4-87b5-5e27b996c82e	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:21.68+00
fe96f5c2-b1ff-49c4-b3d5-f022e1f1007d	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:19.651+00
0230ee9d-b13d-4086-910d-1e03825c20be	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:19.648+00
ea110316-46a7-471b-bc09-cdf6c4b6acd1	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:19.661+00
57a0b1cf-68b0-41d0-a85e-bf828a9d62d1	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:20.479+00
0e4a7f30-d088-48dc-babe-a67fbcdd7503	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:20.481+00
1997065d-a2b0-4f7b-990a-20873b2ea232	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:20.483+00
e0c4d2ff-c4d0-405e-94f4-dae4bf1cf12d	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:21.154+00
b364e9b0-205d-490a-9d40-46776db61fcc	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:21.155+00
164bade9-c0d8-4ce2-b790-a9b5c94069ee	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:21.158+00
3e1b48dd-c3d0-420f-b4cf-e66f134bd58e	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:21.96+00
50b32874-95fb-4a92-866e-d92e3302d764	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:21.967+00
5aa7ec5d-0ce0-4428-8587-0a061ba5372d	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:21.974+00
c56caa88-8b5d-4928-b5b1-d8c0ce2688f0	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:22.801+00
2f3dd5ed-45e3-45e2-b2b4-2be1a1706ba4	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:22.81+00
56122226-01de-441f-853e-654533c1ae92	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:22.819+00
850e2d33-1883-445f-83d5-463ed069aa46	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:23.73+00
6f8d4b51-d0c9-48b9-9d94-def76a5d562c	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:23.733+00
a68fd61c-a47b-47d0-8e59-1719d5c76c05	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:23.738+00
10969ed3-6430-40d0-8836-e93f5f8e4920	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:53.531+00
255406e7-3609-4dd1-84f9-ed925d67dc87	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:53.619+00
d0bd076a-fa01-4e5a-8bdd-27d90c3576d6	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 4dsmq797	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.018+00
6c104cbb-d7a5-4101-957f-38828ae8ec9d	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 xonirtaw	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.222+00
b243a5c9-3328-4405-99d1-7a1094e81d22	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 29 3gpvsr6k	89000	250000	7	\N	\N	\N	2026-03-25 01:31:51.143+00
324bc536-6b57-4c74-ae8b-160adeef9ce2	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 30 r8u4vf9s	80000	250000	3	\N	\N	\N	2026-03-25 01:31:51.725+00
bd8fc082-47f5-4268-bbbb-70cb8a111fab	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 31 rwj5q95f	81000	250000	4	\N	\N	\N	2026-03-25 01:31:52.338+00
e0b126ab-b175-46eb-aafe-4de6ca5b6509	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 32 7rztzsdj	82000	250000	5	\N	\N	\N	2026-03-25 01:31:52.37+00
cab1180e-89a3-455e-abd9-d609fd5711fd	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 32 iaynrht5	82000	250000	5	\N	\N	\N	2026-03-25 01:31:52.437+00
a0e3b3ab-ed70-4e3b-a44d-a702b655a4e0	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 33 8g3fzooq	83000	250000	6	\N	\N	\N	2026-03-25 01:31:54.273+00
643624c6-c955-48c6-9ac0-d735eaa0a65a	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 34 kbjf4exb	84000	250000	7	\N	\N	\N	2026-03-25 01:31:55.118+00
db45c923-4527-418b-9413-a2fcefe899d4	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 35 as0pnal8	85000	250000	3	\N	\N	\N	2026-03-25 01:31:55.395+00
da5216f7-14d2-49d1-a13c-5bc33e7ab065	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 37 ma85vzge	87000	250000	5	\N	\N	\N	2026-03-25 01:31:55.914+00
74e46d7b-7d9c-498a-b1bf-2c4bc6633f70	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 36 sz2qtj5j	86000	250000	4	\N	\N	\N	2026-03-25 01:31:56.07+00
db98b379-ec97-45ea-aab4-c86e64dae578	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 37 6te9xp9w	87000	250000	5	\N	\N	\N	2026-03-25 01:31:56.093+00
c3fe0e0a-8cf7-4961-a475-f837a44f21f5	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 39 y9arkq5p	89000	250000	7	\N	\N	\N	2026-03-25 01:31:57.231+00
93716d75-9d78-4ba2-95a8-d639648ef317	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 39 3mz8fwgt	89000	250000	7	\N	\N	\N	2026-03-25 01:31:57.865+00
75505340-113c-4afa-bc7d-a05e2c81d505	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 40 ijjzbi1u	80000	250000	3	\N	\N	\N	2026-03-25 01:31:58.371+00
aa00ae24-e351-4755-9b3b-84e8c3d9310b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 41 gyvmks0l	81000	250000	4	\N	\N	\N	2026-03-25 01:31:58.743+00
b6091285-ff9f-4702-9db0-17344bf0d742	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 40 rdh08xcp	80000	250000	3	\N	\N	\N	2026-03-25 01:31:58.772+00
77be1ee3-2723-4f6d-b6e3-04762b9f0ae1	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 40 h6z9ppe3	80000	250000	3	\N	\N	\N	2026-03-25 01:31:58.875+00
ef354b49-6023-4b85-991a-6cc58e436cba	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:06.256+00
1616c41d-2cac-46d9-af9f-18bdb38be176	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:06.892+00
844ceeef-c9ca-4c58-b9e7-e186f1c525df	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:06.9+00
27752747-5e03-49b8-a558-63041d2475aa	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:07.644+00
667c7210-f924-4f36-8b08-96836a3b43ed	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:08.665+00
d4e3a1bd-85a7-4863-98fd-25254848c1c2	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:09.422+00
8a347e4d-e55c-49da-a57a-f4ad7fcb5f71	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:10.077+00
82936812-3fb9-4425-becf-62eb118b73f7	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:10.082+00
8e20084f-a262-4115-bbb3-7bbbefc8a9ba	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:10.811+00
83485852-c1d0-4213-8ea7-86b7ee4479df	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:11.493+00
aebddb5f-80f4-443c-81f8-9d0498b99206	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:12.868+00
19d83813-151e-4915-8206-ed6510aa7198	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:13.824+00
3fb85307-8b8c-41ca-98ff-7e5807c13ee1	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:13.993+00
4dcab2c9-784a-48ef-b407-7257cb13e7ea	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:14.459+00
ac26ecd8-1e07-4cdf-834a-bbe7517e8e34	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:14.662+00
16616b17-a911-45fc-a32a-4fdb86d22c76	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:15.067+00
91d75a24-baa6-4670-ab4e-8e92a8ec49dd	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:15.353+00
4b5e8571-ace3-465c-8cae-568f1df129f3	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:15.709+00
65b8849a-bd06-414e-a96c-c9d63cea4607	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:16.044+00
ca33ba7b-4ab9-4d20-b4bd-bfbe6d7a1d14	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:16.335+00
4ad9cab3-167f-4a2b-8c7b-fbbbcc89f9eb	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:16.687+00
b4b23ff9-127c-4a20-81fc-10ac82b1cacc	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:17.009+00
82fb463d-e7f7-4fbb-a5f4-bb1dd8f41b7f	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:17.319+00
36f26659-c803-4ec2-ad4d-b8d07fb22959	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:17.644+00
65bf2fc9-420c-4e3e-b155-34b86839d4c8	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:18.052+00
54c560ca-e63d-4c21-87f3-6400784b9882	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:18.419+00
c815023c-97fa-4fd6-8ea1-4b2a6a42717a	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:18.849+00
bfab7c54-94da-4167-a072-ea6677c504cc	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:19.714+00
5d18320f-ad67-4112-8df8-759b53ff25bb	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:20.34+00
a70745f3-52ac-4acb-b171-55fe4b92201a	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:21.676+00
705c8045-6607-4074-8863-49f2bd36d9b8	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:21.743+00
18ec844d-0cbf-462e-a6d9-6bed2b7d2a74	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:24.411+00
c8b7a5a1-4cfa-4d2a-9272-898de6c37154	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:25.761+00
d29fcb93-552c-481d-aa7a-759328b4b4ee	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:26.428+00
01875b55-c2e7-4dff-bac6-00caa51dc0ba	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:27.234+00
7d9e4dcc-cc22-4952-babf-c0706cac730d	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:28.216+00
004418b4-aba2-4860-b432-856543a35692	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:28.238+00
3089e396-300b-4070-8583-1fd06493d500	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:29.387+00
5b198b0d-f1ba-4ed5-b30d-4bd8a44f1d94	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:31.392+00
9a88ca34-e6a7-4b44-9509-0c1461b59890	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:31.398+00
7ad645dd-8135-424a-bf95-cfe59fac72c1	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:32.157+00
d6460256-4541-432d-82b9-0a6c10ba41a8	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:32.827+00
217d1a2d-854d-43bf-867f-e3d3b101ee62	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:33.606+00
b0d12e5a-b1ac-405d-8ded-7f4f94877237	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:34.272+00
a8993ce9-e981-4712-935f-211b18de190f	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:35.03+00
1b4c4ef8-9456-426e-b7ab-f21e0c4460be	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:36.18+00
40caf2fe-fca7-48ca-8f41-d029b7d986a7	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:37.024+00
e36fe7fd-3bad-40dc-8693-fd31e7918398	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:37.704+00
99f14886-3cc5-4f92-865b-7af39b81e165	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:42.207+00
16515b0b-0b5b-4d97-b227-03dc2e0c5d0e	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:43.046+00
f966c8df-5490-45c6-9832-334a8b1ee062	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:43.78+00
2bd69dc9-9ba9-497f-86d3-801f7ff8faed	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:43.992+00
371d1d7c-3ff2-4b2e-8667-67b1f0178fbb	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 0 7skh98rc	80000	250000	3	\N	\N	\N	2026-03-25 16:52:11.477+00
5448d77d-3268-4f8e-a46a-f6aa827975a5	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:54.468+00
e13b67d5-1f51-4ce1-a9e5-e80e66232c96	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 2px5larw	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.001+00
392cb83b-570a-43ea-8ac1-bcbaa5095fa1	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 g6htwdc1	86000	250000	4	\N	\N	\N	2026-03-23 17:22:22.72+00
464821bb-0ff3-4f80-966a-144ceeec3886	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 orm6gm15	86000	250000	4	\N	\N	\N	2026-03-23 17:22:22.814+00
1d7705ef-21fa-49d7-8504-6c59a7d86b70	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 77 pk0f9kzk	87000	250000	5	\N	\N	\N	2026-03-23 17:22:23.796+00
7c5712e2-e4c2-4d16-bf87-3b69a3683d95	9e72c822-2ee5-46aa-89cc-3f982efa2929	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 17:22:47.338+00
c6228220-0d19-4e51-ad9d-ecdc57c06c90	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:18:58.316+00
c8603dcd-44ea-40a6-847c-2fa2a6c8a5a6	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:18:58.314+00
325b1cff-a0b0-492b-8f3d-eff0d72d563f	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:18:58.509+00
c8f6afd7-68e1-4eaf-8937-005b9fdefb75	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:18:59.77+00
dc3d0e12-5f7e-4859-94e8-9e1e5c6ae4fa	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:18:59.774+00
0312332f-f808-4c36-9040-0843df0c199e	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:18:59.776+00
bff3fb51-b50d-4fe7-9d31-91be34867fe7	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:00.674+00
ea3e78a3-f19c-4b51-bb21-a55156cc63e7	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:00.708+00
7b71925c-9817-446a-af88-c068f584f3dc	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:00.712+00
0c807524-6c44-49b4-b3af-436e79299e10	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:01.522+00
c132c72c-a824-4daa-a381-d3833f72cd0e	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:01.529+00
1837b21e-41a8-4806-995f-277a05fc9129	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:01.656+00
58dc75d5-f3cb-4386-95b6-0953b88b39dd	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:03.216+00
e915f0e0-eec9-4860-95f1-7ced271d9048	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:03.227+00
65eb487e-959d-499e-bca4-b24dbff13bc3	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:03.229+00
136c2872-d102-4284-b614-b9417ecb168d	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:04.692+00
ad6a656c-9897-4348-8c1f-e3ecfdc3259c	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:04.694+00
f92ed8ca-91c5-4c0b-b71d-8178f5d7aede	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:04.614+00
7e8a5762-5f17-4824-99d2-7568dff09382	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:05.842+00
4f99b176-bebf-441b-8025-87271ddb0158	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:05.853+00
4706fecf-3c0a-4d61-abfe-187dd580c14d	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:05.857+00
aa521275-48b1-41e8-adf6-2b8deaedf853	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:06.911+00
47d494c0-d4b2-4517-839d-61f412ddc073	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:06.914+00
677a6cb8-2f30-4fe1-ad34-1f30456edcdb	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:06.916+00
e037ce4e-e9d6-4019-b9f1-d0554f58da0a	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:07.87+00
3c049fce-1364-44c0-a2de-63d4aacc539c	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:07.88+00
7ac9872f-19c5-4085-8156-c680cd66f4be	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:07.886+00
49376f97-c799-4fb7-ace7-170bea757c57	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:08.64+00
333178f8-15d9-42af-8423-6f4534c7f374	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:08.676+00
7c8a66e7-d568-42c2-9a66-2a1eae9ef498	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:08.678+00
c2f6497a-3424-467a-8041-d31cff2000f9	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:09.439+00
c5a23fac-d0fa-4929-b364-081a574137de	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:09.443+00
0b7484ef-5e8b-4cd9-93d1-5d96f488cf27	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:09.461+00
1227fd31-567e-4656-95ee-25d1ce32d794	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:10.167+00
1d2bc7a7-b8ea-49c8-8be2-ae08639df44f	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:10.171+00
1722795c-577c-44b5-9af5-386d38f3a0ba	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:10.177+00
9fcd2fe7-d579-4d19-a8e4-625e596a4b2f	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:10.869+00
350eafc3-50a8-437d-8ec3-55486aedbd3a	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:10.872+00
c503d404-c04d-4745-99c7-4e853fea3f6c	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:10.881+00
1fc5d27f-de27-4316-a2c9-2b2cc0add140	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:11.958+00
19f6f533-18c9-41b5-90f2-8c722b1234ab	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:11.971+00
9121a2b6-06c6-447c-a75e-b217ffa9953c	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:11.974+00
f419cad5-a226-4fd0-928d-772ee392b935	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:12.673+00
b6255f53-99f4-45c9-a09f-896e8e49e424	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:12.675+00
cd2c5bab-e82b-44f1-9eb7-f71e211d0abe	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:12.76+00
aa716671-0410-4d02-af3c-69a7fe227f72	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:13.62+00
9650baf7-0c21-4aeb-beb9-723b2bbfa6f7	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:13.707+00
b81bbdb4-e8c2-4e0e-a048-30ee7835722e	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:13.714+00
d65524c1-ec91-4ee8-b6b2-d6ab9a2511f3	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:14.771+00
94cacaf3-d1e3-4dae-a999-84fac41193ee	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:14.943+00
9eda273e-646a-4a3c-9268-3e1c34ea9a11	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:14.945+00
bfb55a96-d5ac-4530-b028-8d35f24f7915	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:15.434+00
cd9dc89a-e6c8-4095-b27f-404041edff92	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:15.564+00
a11f15b7-22ca-4723-929f-80ac574d7234	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:15.634+00
2d9545ed-91a0-4b53-aa72-00faf4a39faf	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:16.052+00
14d2b8ca-b178-4da3-ac01-e83f1c4b534f	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:16.214+00
2c20b876-c7e6-4b96-b446-8928c2513350	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:16.505+00
bf486521-8bf8-4061-82bd-3b8bc80da9a0	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:16.914+00
da182bdf-9eb8-45b9-91d3-42fc46aed9b4	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:17.412+00
dedd1ed3-bd83-46cf-a6cd-8c62e3f02d74	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:17.612+00
3c2349bf-cb7e-4ce0-b732-2e80ae766e62	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:18.331+00
f366a126-86ee-44d0-b896-14f09ef0a234	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:18.514+00
1abaf031-5da4-4723-9f86-ec518f3ec537	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:18.561+00
97c969d1-4629-4bcc-94f7-b1efc301c2d2	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:19.111+00
c4f72d3c-5f91-43aa-961a-c709dabecd5c	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:19.587+00
79e4e6a8-d6fe-4c96-93c5-9208c1eb7329	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:19.756+00
8f18c6ec-ac03-4b83-8eef-b9e2e644ccbb	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:20.178+00
7d74bca0-3427-45f6-98ee-3aa5e79a1401	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:20.234+00
8af1e654-a60f-41a3-9194-e8f278db053c	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:20.418+00
31353fd9-1ea9-42c7-9b1f-5ce8091b5127	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:21.12+00
c711d55a-4c54-4664-a882-53be0d48e712	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:22.183+00
dbb70fb6-9009-4aad-bd37-acc276eb2c36	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 0 mscylf3q	80000	250000	3	\N	\N	\N	2026-03-23 19:19:23.482+00
0d3f5aee-b817-4464-a902-4db0698328dd	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 0 g6bcu23h	80000	250000	3	\N	\N	\N	2026-03-23 19:19:23.489+00
21bc667b-b23a-4b22-9a2f-db5b371d152a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 0 k710ef61	80000	250000	3	\N	\N	\N	2026-03-23 19:19:23.52+00
dcc5649d-aa42-4d0b-bd35-04eab8b8837c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 1 4i4fc6m6	81000	250000	4	\N	\N	\N	2026-03-23 19:19:24.789+00
9edcb586-b528-4a8b-aea3-c3c0335d8280	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 1 fogp4hms	81000	250000	4	\N	\N	\N	2026-03-23 19:19:24.87+00
b5695dd4-4260-49a8-8d8d-f3478dd6a3cf	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 2 7xntx341	82000	250000	5	\N	\N	\N	2026-03-23 19:19:25.678+00
0bf2bc8b-b20a-4eb0-ad95-4d8b3920591c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 2 4bodjtvd	82000	250000	5	\N	\N	\N	2026-03-23 19:19:25.682+00
e4674503-25f4-42d3-8a37-f6a251b0cb9d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 3 zj1yxpvh	83000	250000	6	\N	\N	\N	2026-03-23 19:19:26.704+00
f70b0cf2-4272-4aa8-8416-e10f97230a65	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 5 oozytxue	85000	250000	3	\N	\N	\N	2026-03-23 19:19:30.108+00
260a7b74-0852-4bb2-9060-2236abbff1f4	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 6 3tmym4qu	86000	250000	4	\N	\N	\N	2026-03-23 19:19:30.612+00
6618e92a-64ad-4fee-ab12-fd0a46314228	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 6 8a0cerxv	86000	250000	4	\N	\N	\N	2026-03-23 19:19:32.12+00
17562a11-aeae-45ad-ae6d-1e72814f9bae	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 6 lqvaugfa	86000	250000	4	\N	\N	\N	2026-03-23 19:19:32.307+00
c5039f73-09c0-406c-8d8b-9254612c05c2	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 7 6ttfujme	87000	250000	5	\N	\N	\N	2026-03-23 19:19:33.016+00
bdaae7b2-24ab-4aa1-b2de-9c1d3aac7b9d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 8 7jwujtzc	88000	250000	6	\N	\N	\N	2026-03-23 19:19:33.811+00
a6dde65d-58f2-432d-870d-4c8dc092f6b1	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 8 3itwi10k	88000	250000	6	\N	\N	\N	2026-03-23 19:19:34.019+00
e99275b7-ba41-4740-b94a-614819b4ac03	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 9 nalwd26p	89000	250000	7	\N	\N	\N	2026-03-23 19:19:36.061+00
9727a6e2-fc40-45fa-97e5-c819fe70ad03	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 10 jn99itxg	80000	250000	3	\N	\N	\N	2026-03-23 19:19:36.317+00
d94817e4-fc8b-450b-a62a-e7e2152ee33b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 10 qkeas261	80000	250000	3	\N	\N	\N	2026-03-23 19:19:37.018+00
aa714a62-24de-4abf-af85-4e23cec376f3	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 10 0t0cb6sh	80000	250000	3	\N	\N	\N	2026-03-23 19:19:37.286+00
4581738c-8653-43d2-b6d2-7930ac5696fb	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 11 3grvt2sn	81000	250000	4	\N	\N	\N	2026-03-23 19:19:37.416+00
c8b1c4bb-7058-4d86-907f-b3c52d78e0fa	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 12 0764rye5	82000	250000	5	\N	\N	\N	2026-03-23 19:19:38.315+00
19e72d43-9097-451a-ae0d-eec80c1bed03	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 12 fgv28cjh	82000	250000	5	\N	\N	\N	2026-03-23 19:19:39.107+00
dcc9e5ad-dcaf-4102-ab99-797bd7cd67a8	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 13 lx0qmfy0	83000	250000	6	\N	\N	\N	2026-03-23 19:19:39.64+00
e4e0abbb-efd0-494b-acd1-f00e9f8cae37	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 13 oy13lgq4	83000	250000	6	\N	\N	\N	2026-03-23 19:19:39.649+00
58bd92bd-28d4-4743-8cbb-e509e5faa212	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 14 qq2uf306	84000	250000	7	\N	\N	\N	2026-03-23 19:19:40.312+00
5c925ff7-b621-474d-835f-fd4761dfa584	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 14 tbolko16	84000	250000	7	\N	\N	\N	2026-03-23 19:19:40.348+00
5befa667-a476-4953-99fd-793a0b481495	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 14 wj7t17sy	84000	250000	7	\N	\N	\N	2026-03-23 19:19:40.507+00
1b7c116f-6734-4e4d-a147-d502d599ef91	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 15 22p6jncb	85000	250000	3	\N	\N	\N	2026-03-23 19:19:40.612+00
4ee643f7-b351-44f5-8a50-f2586e84b68e	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 16 nheeqi29	86000	250000	4	\N	\N	\N	2026-03-23 19:19:41.37+00
1cc2d1f8-10a6-4c53-86e2-72bddecaa4a0	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 17 emnb2up9	87000	250000	5	\N	\N	\N	2026-03-23 19:19:42.183+00
f5c435b2-28bd-40fa-8086-d4334babbe14	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 18 09pwyg58	88000	250000	6	\N	\N	\N	2026-03-23 19:19:43.014+00
18e40872-3968-491f-94bc-8ea8bc877b05	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 18 rojb8j6w	88000	250000	6	\N	\N	\N	2026-03-23 19:19:44.207+00
1a5be849-709b-4cee-982c-132c4afda87c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 19 ryaayqpx	89000	250000	7	\N	\N	\N	2026-03-23 19:19:44.408+00
628f617d-ecd5-430c-8b79-39fa2ececedf	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 19 epcbsgsd	89000	250000	7	\N	\N	\N	2026-03-23 19:19:45.014+00
ff2540bd-b6f4-4bf4-8cbf-d695550f865b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 20 8ulpvwfy	80000	250000	3	\N	\N	\N	2026-03-23 19:19:46.108+00
729b1a65-679a-43e2-b9b1-0a4456ae3dad	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 21 n57wjw14	81000	250000	4	\N	\N	\N	2026-03-23 19:19:47.908+00
b2a1838e-fde8-4910-9568-5e739975b184	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 21 htz343m1	81000	250000	4	\N	\N	\N	2026-03-23 19:19:48.312+00
8774b663-6852-4bc5-b306-5f78cd5dda03	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 22 xmdir49h	82000	250000	5	\N	\N	\N	2026-03-23 19:19:48.843+00
c7dd3d5b-1aed-4cba-ba17-40e16681b3c0	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 22 d1e3mtl1	82000	250000	5	\N	\N	\N	2026-03-23 19:19:48.863+00
12a725b5-daa2-4b96-9556-fc00e2938997	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 23 2hozkguu	83000	250000	6	\N	\N	\N	2026-03-23 19:19:49.118+00
99561842-c963-4f76-a7d5-d67837c91cdb	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 25 82qj7wuo	85000	250000	3	\N	\N	\N	2026-03-23 19:19:50.434+00
3c59b5ba-72ee-4fc0-9cec-9176362bcd59	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 24 g2r295n5	84000	250000	7	\N	\N	\N	2026-03-23 19:19:50.444+00
d67324d3-df56-4619-8416-1a134e26f530	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 26 auape36l	86000	250000	4	\N	\N	\N	2026-03-23 19:19:51.028+00
26be8e9d-badf-4ed2-b5a5-6426eea8618b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 26 w8oerdzv	86000	250000	4	\N	\N	\N	2026-03-23 19:19:51.506+00
8c9b60a8-9cef-4d83-b1da-72031be0d08d	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 37 xvx5nyn9	87000	250000	5	\N	\N	\N	2026-03-25 01:31:56.556+00
5e6dae7a-0d55-4e4e-ab18-5b2e69ab3d14	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 37 1xd0n8s5	87000	250000	5	\N	\N	\N	2026-03-25 01:31:56.622+00
2bd445d9-19e4-42e1-a48a-e8fd21a36605	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 38 f0567swa	88000	250000	6	\N	\N	\N	2026-03-25 01:31:57.173+00
76fe7587-84fa-4e67-b273-96a7318c5b13	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 39 j4o7z5mw	89000	250000	7	\N	\N	\N	2026-03-25 01:31:57.178+00
e9a8cac9-0ac5-49f9-a147-ffcfb2a90855	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 38 wli9eo80	88000	250000	6	\N	\N	\N	2026-03-25 01:31:57.182+00
af62a71f-7167-438e-9379-7151727e1aaa	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 38 ipoly6eb	88000	250000	6	\N	\N	\N	2026-03-25 01:31:57.228+00
598b0411-7350-436c-987d-f637740eec3f	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 39 14m2u48g	89000	250000	7	\N	\N	\N	2026-03-25 01:31:57.718+00
60df3433-b7d2-4475-8839-0e9c44fbfe4b	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 40 s0nso9wh	80000	250000	3	\N	\N	\N	2026-03-25 01:31:57.841+00
892f198f-97d4-4806-bd14-93dc5e75b6fe	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 39 u6dp4bxy	89000	250000	7	\N	\N	\N	2026-03-25 01:31:57.868+00
3036b555-3b55-4335-adba-b730d2494341	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 41 i1h760r6	81000	250000	4	\N	\N	\N	2026-03-25 01:31:58.873+00
f98423a5-5f95-48c5-8730-a7c4de2414f7	646a708d-9379-48ae-836d-5a5272ab09ba	k6 search 41 vz2ak6d7	81000	250000	4	\N	\N	\N	2026-03-25 01:31:59.272+00
4b3ef3bf-b8ae-4584-9291-20122cb4486d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 0 f9spevsx	80000	250000	3	\N	\N	\N	2026-03-25 16:40:02.846+00
4fc67f27-53eb-4c07-8a7f-f887d7329a4e	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 0 qg9z5rr3	80000	250000	3	\N	\N	\N	2026-03-25 16:40:02.859+00
4e46da60-de74-49f4-bb81-073af6e5523a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 1 dqokm2zr	81000	250000	4	\N	\N	\N	2026-03-25 16:40:03.895+00
cf221b02-dc6d-443c-b376-a081a696843a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 2 x9eoq3fw	82000	250000	5	\N	\N	\N	2026-03-25 16:40:04.555+00
2ada4080-d00d-4ae9-9446-d1e91f0bd2e0	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 2 mwnv29al	82000	250000	5	\N	\N	\N	2026-03-25 16:40:04.65+00
fdec2491-b9c0-417e-a828-e0a8faddc54b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 3 wuwo1qws	83000	250000	6	\N	\N	\N	2026-03-25 16:40:05.08+00
7c9a73ab-9940-45c2-ba30-1f8387451447	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 5 kfw2a7di	85000	250000	3	\N	\N	\N	2026-03-25 16:40:06.156+00
3e546e34-1194-4ac3-8c86-af88a3c18d32	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 5 gel62nn3	85000	250000	3	\N	\N	\N	2026-03-25 16:40:06.423+00
1d84c014-c405-4c01-be22-90904e4eafbf	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 6 a5zzis4h	86000	250000	4	\N	\N	\N	2026-03-25 16:40:06.975+00
0546ac47-381c-46b1-881c-ee976d406b6d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 6 ba4dwszl	86000	250000	4	\N	\N	\N	2026-03-25 16:40:07.05+00
9f04b1a4-fb74-48f6-842e-6c3682d21ab6	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 7 fbpt4nqb	87000	250000	5	\N	\N	\N	2026-03-25 16:40:07.655+00
8a99af40-15cb-4561-9ac9-388400341363	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 7 ibas9nqo	87000	250000	5	\N	\N	\N	2026-03-25 16:40:09.224+00
bc70042e-fb08-45ad-9011-aeadef2694e1	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 9 swukl3gq	89000	250000	7	\N	\N	\N	2026-03-25 16:40:12.453+00
3ee6b9c2-cf68-4402-beff-487842034211	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:21.196+00
b26863c1-86ef-453b-bc0d-e299d612bac6	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:21.25+00
2d3cfce3-7308-4e02-b315-53e60dfbe6c4	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:22.186+00
d458be58-954c-4b71-8572-5bafb35461af	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 0 o4jet1fx	80000	250000	3	\N	\N	\N	2026-03-23 19:19:23.486+00
0290657a-2eb2-40e6-8974-df5f203989fc	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 0 ju95nc4c	80000	250000	3	\N	\N	\N	2026-03-23 19:19:23.528+00
4d010372-1f6f-4f19-9549-3745db7ff26d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 0 8ob1o7m5	80000	250000	3	\N	\N	\N	2026-03-23 19:19:23.63+00
ec8b837d-e1b1-410a-8eb2-c67d8d36dae5	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 1 fx1vwy4m	81000	250000	4	\N	\N	\N	2026-03-23 19:19:24.792+00
408c248f-ee7f-4564-a535-aba463d1b2ae	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 1 z8ek1lh7	81000	250000	4	\N	\N	\N	2026-03-23 19:19:24.869+00
0f904f07-f509-4e5c-869b-6bdc11082a3d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 1 607dd8is	81000	250000	4	\N	\N	\N	2026-03-23 19:19:24.872+00
b580d7ab-a182-4c59-a897-8ab51c374f3a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 1 3wk8tvaq	81000	250000	4	\N	\N	\N	2026-03-23 19:19:24.875+00
fee66669-c55d-43c6-963b-2943c54a729a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 2 66618ic0	82000	250000	5	\N	\N	\N	2026-03-23 19:19:25.508+00
102c2be7-c444-4cca-a08a-d94dcb00d2d7	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 2 oc5wlczg	82000	250000	5	\N	\N	\N	2026-03-23 19:19:25.528+00
2d773d03-9501-4fa2-8266-594b31f48b0f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 2 ml1viwqc	82000	250000	5	\N	\N	\N	2026-03-23 19:19:25.665+00
ca6d2f07-5f52-4b23-a9cd-5712432a2505	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 3 zo2oa8eo	83000	250000	6	\N	\N	\N	2026-03-23 19:19:26.113+00
c0d5de39-0311-4c19-bc1e-a6cb36de0f9c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 3 pjmm3472	83000	250000	6	\N	\N	\N	2026-03-23 19:19:26.222+00
4caf852c-6efa-4d92-ad0f-454e27ea8a9a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 3 yd6nhwc3	83000	250000	6	\N	\N	\N	2026-03-23 19:19:26.511+00
81fa2a71-b002-4d1a-b789-248a5529ae6c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 4 osfuuurr	84000	250000	7	\N	\N	\N	2026-03-23 19:19:27.409+00
da3f5dad-21e7-4f57-89be-3cf1e8c70bf7	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 4 80ezzya5	84000	250000	7	\N	\N	\N	2026-03-23 19:19:28.105+00
b81eed73-f632-4b22-b475-396237ceb3f5	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 4 ks2sz9l2	84000	250000	7	\N	\N	\N	2026-03-23 19:19:28.505+00
ae4e39e7-0685-441c-956a-2b561f55c643	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 5 960ds9t0	85000	250000	3	\N	\N	\N	2026-03-23 19:19:30.31+00
bffbc0d2-f55f-44c4-a5b6-8c92c7d0b09f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 6 uyvta84g	86000	250000	4	\N	\N	\N	2026-03-23 19:19:30.616+00
7f4759da-de2f-4109-ac0a-ae2e9dc85cca	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 6 pnl1ttdj	86000	250000	4	\N	\N	\N	2026-03-23 19:19:32.432+00
71a0c69c-abad-414d-b4b9-5b395cdbc37a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 7 rjondy2z	87000	250000	5	\N	\N	\N	2026-03-23 19:19:32.617+00
329aa5a4-0f0e-49db-a411-facb0466cb25	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 7 d1dqp9zu	87000	250000	5	\N	\N	\N	2026-03-23 19:19:33.591+00
8c85326c-2722-47bc-a04f-d283f138eb04	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 8 zd86d4wl	88000	250000	6	\N	\N	\N	2026-03-23 19:19:35.041+00
a4c497cd-9240-49bc-84fb-7e7fdc185664	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 9 r01hajlj	89000	250000	7	\N	\N	\N	2026-03-23 19:19:35.097+00
4123f014-e9c7-4c98-88cb-2b9a07c3387f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 9 h66t869y	89000	250000	7	\N	\N	\N	2026-03-23 19:19:35.136+00
b37bf445-1e01-4a8d-b9e2-a2dffdb701bc	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 9 1nwatike	89000	250000	7	\N	\N	\N	2026-03-23 19:19:35.863+00
664c47cf-c306-48af-8770-819b2574d35b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 9 tmovubor	89000	250000	7	\N	\N	\N	2026-03-23 19:19:36.059+00
9a861a27-44da-49fc-9358-962e2e274503	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 10 u0xfvzz1	80000	250000	3	\N	\N	\N	2026-03-23 19:19:36.065+00
81e841c2-3582-4859-8b88-752a9467ee85	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 10 g146c80t	80000	250000	3	\N	\N	\N	2026-03-23 19:19:36.067+00
8eedddc4-7297-45ce-923e-c57fa93c9f93	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 10 ik87k963	80000	250000	3	\N	\N	\N	2026-03-23 19:19:36.07+00
7ae954e6-4927-4301-9474-75a827e3ab06	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 11 qbhahe75	81000	250000	4	\N	\N	\N	2026-03-23 19:19:37.222+00
4314bc10-edd6-45f3-b4b4-d5ad303f3b6b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 11 f5uaewgb	81000	250000	4	\N	\N	\N	2026-03-23 19:19:37.304+00
115fb189-8253-4f2d-bbcd-f614d31b2a91	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 11 j7cc3tof	81000	250000	4	\N	\N	\N	2026-03-23 19:19:37.307+00
93633961-d0ba-4fcf-98b7-3a6145b35451	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 12 c6w8m6n4	82000	250000	5	\N	\N	\N	2026-03-23 19:19:38.16+00
370c58c0-5115-482f-82d4-ec95f0f1c482	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 13 qaby4il9	83000	250000	6	\N	\N	\N	2026-03-23 19:19:39.752+00
a6d6f5ae-a0b4-488a-8ab2-0b960d8642ff	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 14 bicbjzwt	84000	250000	7	\N	\N	\N	2026-03-23 19:19:40.085+00
5e33480b-f61a-4305-991d-8e646c711d02	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 14 aq6a4ycf	84000	250000	7	\N	\N	\N	2026-03-23 19:19:40.51+00
1566cb84-9cfc-46fd-8ea8-c603d2a315ee	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 15 d1ioya46	85000	250000	3	\N	\N	\N	2026-03-23 19:19:40.943+00
3db676a0-a3c2-427e-bd6f-4d29fbf65276	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 15 vov266iu	85000	250000	3	\N	\N	\N	2026-03-23 19:19:40.989+00
8a3021d4-0dfd-4786-bcf6-695911bb9723	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 15 m2cfo6jo	85000	250000	3	\N	\N	\N	2026-03-23 19:19:41.336+00
0950f84b-8d76-4c3c-814a-6c421217070f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 15 637gb3ky	85000	250000	3	\N	\N	\N	2026-03-23 19:19:41.359+00
e1ed74bc-8171-42a5-9253-f2c6a0a1453c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 16 0l8lsexd	86000	250000	4	\N	\N	\N	2026-03-23 19:19:41.376+00
a55e1cd0-526f-46b2-a311-7480e0d691db	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 16 9sex5s04	86000	250000	4	\N	\N	\N	2026-03-23 19:19:41.859+00
ce9bdf08-e37e-4888-b75f-076c66ca4b95	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 16 kaxoyhx0	86000	250000	4	\N	\N	\N	2026-03-23 19:19:42.174+00
4c728ea6-9092-4be4-b1d3-2d82b7ede0fa	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 17 ftkd95xz	87000	250000	5	\N	\N	\N	2026-03-23 19:19:42.703+00
be851cd3-cd54-43c6-ba65-85e6047bb89f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 17 6w0p5ikr	87000	250000	5	\N	\N	\N	2026-03-23 19:19:43.005+00
91b330c9-950d-4f7b-992a-90914dea9c85	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 19 41fiwx8e	89000	250000	7	\N	\N	\N	2026-03-23 19:19:44.307+00
a603590a-e174-4b7c-9cb7-b941f5a66e6a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 18 ieun6yp9	88000	250000	6	\N	\N	\N	2026-03-23 19:19:44.41+00
91cef65f-18f0-4eca-bf4f-452e329f78ef	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 19 ysbzj9ej	89000	250000	7	\N	\N	\N	2026-03-23 19:19:45.838+00
7d911331-5b3e-4983-a2c6-936f20dbb60b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 20 ar4z3lwc	80000	250000	3	\N	\N	\N	2026-03-23 19:19:46.008+00
d7c86a6b-c6e3-49a9-8f23-64bdab161962	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 20 8zvrk7a6	80000	250000	3	\N	\N	\N	2026-03-23 19:19:46.032+00
31a19581-2d5b-4360-b1d4-d550c1d4c0f8	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 19 xuj57yyg	89000	250000	7	\N	\N	\N	2026-03-23 19:19:46.105+00
fbb54c43-38e5-494a-bca2-9e3ec68476ed	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 21 wupn0pjq	81000	250000	4	\N	\N	\N	2026-03-23 19:19:46.984+00
197da513-f88e-451d-bad8-e4aff9055003	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 21 7dvmzwbn	81000	250000	4	\N	\N	\N	2026-03-23 19:19:47.228+00
d3a55a4a-be04-415e-a283-35d9fe5847de	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 21 lbe2fwii	81000	250000	4	\N	\N	\N	2026-03-23 19:19:47.911+00
eefbcdb1-4416-437c-827b-a3a74226833e	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 22 3dl18lji	82000	250000	5	\N	\N	\N	2026-03-23 19:19:48.408+00
c375a95b-b9d5-45b8-82c7-b8ed73330e28	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 21 oq452kvk	81000	250000	4	\N	\N	\N	2026-03-23 19:19:48.839+00
e67df4f8-7a63-416a-963d-11dfd665a820	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 22 za09pc8x	82000	250000	5	\N	\N	\N	2026-03-23 19:19:49.022+00
8b721efc-ccf6-4906-9778-79ab0502c6af	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 23 t9m6jni7	83000	250000	6	\N	\N	\N	2026-03-23 19:19:49.583+00
8895bcf1-b062-4a8f-9616-edba73468c77	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 23 lockc0e1	83000	250000	6	\N	\N	\N	2026-03-23 19:19:49.807+00
87c36f43-f38a-41b4-a329-26307bfc59b4	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 24 d2y7ea1w	84000	250000	7	\N	\N	\N	2026-03-23 19:19:49.814+00
d948578d-55ec-46ba-af29-42713205607e	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 23 71vfrs1f	83000	250000	6	\N	\N	\N	2026-03-23 19:19:50.105+00
d80b44a9-4efe-4c2d-8119-2644ca54df85	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 24 wmeh79se	84000	250000	7	\N	\N	\N	2026-03-23 19:19:50.128+00
a5009260-cf4e-4e9f-87bd-1ffee424f47e	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 24 hn85zm2u	84000	250000	7	\N	\N	\N	2026-03-23 19:19:50.668+00
44f96bc6-32ee-43db-a5bb-dc9dd9b8a1c2	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 25 egt2pm2k	85000	250000	3	\N	\N	\N	2026-03-23 19:19:51.116+00
11c8e45e-ba9a-407b-9c3d-b27bce83c703	3f6a5abf-3ca2-4f3c-936a-be3826420ec7	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 19:20:04.227+00
8f9945d7-0706-4f77-8507-b93e3b0354c9	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:32.16+00
13c472ec-4ab5-43dd-b87b-688b7616be53	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:33.167+00
b6b50e96-0d44-4b46-a291-bba4511a5444	d54193dc-859b-4720-838e-4d1e3040216a	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:19:22.19+00
3c6eb708-8032-4c2d-9a1b-81627d7f079f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 2 oak12zfu	82000	250000	5	\N	\N	\N	2026-03-23 19:19:25.68+00
ff602c2c-7178-4176-baf8-f25b25c11993	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 3 c4xseonj	83000	250000	6	\N	\N	\N	2026-03-23 19:19:26.519+00
4e95b4e0-1820-4aeb-beab-53c4e3aa921c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 3 cm9ys3j0	83000	250000	6	\N	\N	\N	2026-03-23 19:19:26.622+00
f543dab8-a2d3-435a-95e6-657ad3011852	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 4 mb3n65w1	84000	250000	7	\N	\N	\N	2026-03-23 19:19:27.384+00
53f5aa4e-743d-493f-b35e-f74fbe4404e4	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 4 mjk2tium	84000	250000	7	\N	\N	\N	2026-03-23 19:19:28.031+00
71cf7536-929e-48b3-a890-5cdd4c0320c0	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 4 zphuuem6	84000	250000	7	\N	\N	\N	2026-03-23 19:19:28.503+00
8df364cc-a0d8-4bd1-9874-3e33488ff66e	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 5 em6h13he	85000	250000	3	\N	\N	\N	2026-03-23 19:19:28.819+00
96de7b23-03a8-4188-92e4-9ec3c362f8af	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 5 7nqy5mxo	85000	250000	3	\N	\N	\N	2026-03-23 19:19:29.012+00
658267e5-22ca-438e-9ee3-24175eec39a1	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 5 edczjeg3	85000	250000	3	\N	\N	\N	2026-03-23 19:19:30.315+00
a34ed20d-fbb4-4f16-ba93-defc97ca7564	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 5 xxjf1m4k	85000	250000	3	\N	\N	\N	2026-03-23 19:19:30.419+00
76a94d1f-3e82-4e2b-895b-2322cda219b6	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 6 991zdemy	86000	250000	4	\N	\N	\N	2026-03-23 19:19:32.31+00
5019716b-bc47-483a-917e-91b68e679817	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 7 z5obk9ic	87000	250000	5	\N	\N	\N	2026-03-23 19:19:32.624+00
91b2e108-b0d5-4f20-a165-24d65f845b9f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 7 0aieh8rx	87000	250000	5	\N	\N	\N	2026-03-23 19:19:33.604+00
5e10ae57-9090-41ba-b944-8490311f18ff	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 7 6xhyy6gq	87000	250000	5	\N	\N	\N	2026-03-23 19:19:33.706+00
1a140246-c889-4811-ae7f-09e97244a238	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 8 giw31vsj	88000	250000	6	\N	\N	\N	2026-03-23 19:19:33.882+00
9aa6ec31-9bc5-47ff-8a24-b60873a60346	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 8 zkecxgec	88000	250000	6	\N	\N	\N	2026-03-23 19:19:34.854+00
9115e57a-8c5e-4c54-abce-d9aff00f3fdb	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 8 yrsudgh1	88000	250000	6	\N	\N	\N	2026-03-23 19:19:34.985+00
0615861f-f703-490c-8e18-d9a9c241db42	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 9 m3en4tkc	89000	250000	7	\N	\N	\N	2026-03-23 19:19:35.171+00
5f109b57-a458-4cec-8cac-22491f466924	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 11 xg3333ta	81000	250000	4	\N	\N	\N	2026-03-23 19:19:38.038+00
f170e47c-1572-4018-8f3c-fc82f433468d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 11 ett3sham	81000	250000	4	\N	\N	\N	2026-03-23 19:19:38.094+00
016813c6-c822-492c-b8fa-5ef776095032	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 12 sd6twhvm	82000	250000	5	\N	\N	\N	2026-03-23 19:19:38.313+00
acb227e6-d0a5-471c-bb69-b40e1c25338b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 12 1zr0mfqu	82000	250000	5	\N	\N	\N	2026-03-23 19:19:38.319+00
57af59c6-b875-438a-beff-d60226fa7ad9	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 12 hn9i7t9r	82000	250000	5	\N	\N	\N	2026-03-23 19:19:39.128+00
a3510e39-ca48-4892-98b0-0d252652510f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 13 zshasqat	83000	250000	6	\N	\N	\N	2026-03-23 19:19:39.535+00
c3d955dc-ed39-4a11-bf81-e0ae04f77e8b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 13 rum5ti9h	83000	250000	6	\N	\N	\N	2026-03-23 19:19:39.547+00
d2ac15c1-8256-4c78-98e9-90bcde0985f0	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 13 gfxrmu8d	83000	250000	6	\N	\N	\N	2026-03-23 19:19:39.751+00
13e01002-1874-4038-9156-0f02ba8bff4f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 14 yo2qlkht	84000	250000	7	\N	\N	\N	2026-03-23 19:19:40.053+00
d1f0373b-3a6e-405c-856c-c56faca1809b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 15 dbhbntij	85000	250000	3	\N	\N	\N	2026-03-23 19:19:40.615+00
4ea2a114-b2b4-4211-b652-91c993f5a8d1	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 16 ojqnr1zt	86000	250000	4	\N	\N	\N	2026-03-23 19:19:42.041+00
9d9e9f03-aa63-4721-9ce1-8f085327560b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 16 gfdnaxa1	86000	250000	4	\N	\N	\N	2026-03-23 19:19:42.176+00
5b829412-9155-4baa-9387-a34a64af1c7e	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 17 snwordz9	87000	250000	5	\N	\N	\N	2026-03-23 19:19:42.18+00
48409ab8-7319-4457-8ce4-108f3eb8eead	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 17 n6bl5p30	87000	250000	5	\N	\N	\N	2026-03-23 19:19:42.411+00
47562ff0-443b-4c35-a92b-4b43475e13a8	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 17 8t5pfcno	87000	250000	5	\N	\N	\N	2026-03-23 19:19:42.916+00
b421d71e-c67d-4817-9898-83e775996a1f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 18 x1on9v1f	88000	250000	6	\N	\N	\N	2026-03-23 19:19:42.951+00
65697e64-b113-468f-9ea3-5b1358579c7b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 18 v2fsf8c5	88000	250000	6	\N	\N	\N	2026-03-23 19:19:43.43+00
aaf43a67-88f6-43e7-a396-37bb3fdeddd9	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 18 0srzx8b4	88000	250000	6	\N	\N	\N	2026-03-23 19:19:43.888+00
a7c47685-1b34-4f58-a8e7-c57cbf2a402b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 19 deq41l0g	89000	250000	7	\N	\N	\N	2026-03-23 19:19:44.707+00
4109060f-8248-4251-8ab4-5a1485ee7f72	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 20 ivf1ozfd	80000	250000	3	\N	\N	\N	2026-03-23 19:19:46.111+00
242fb4fc-4839-4ff4-89d6-65fee8eac11f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 20 0tvv6j8u	80000	250000	3	\N	\N	\N	2026-03-23 19:19:46.411+00
c9120500-e67f-4a0a-858a-6baf2b9f1139	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 20 18839yah	80000	250000	3	\N	\N	\N	2026-03-23 19:19:47.817+00
6f4e46a1-b00f-4ae9-84ea-bce083938bbc	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 22 vr2k6jz7	82000	250000	5	\N	\N	\N	2026-03-23 19:19:48.635+00
926cf641-63f5-432f-b889-d8f25dcccd42	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 23 surheqqb	83000	250000	6	\N	\N	\N	2026-03-23 19:19:49.017+00
130d82dd-2e10-497b-b254-5d73fca815f0	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 22 57qhrztd	82000	250000	5	\N	\N	\N	2026-03-23 19:19:49.578+00
8fdf9231-78e3-4cd2-8788-3354d2de408f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 23 f298l1n9	83000	250000	6	\N	\N	\N	2026-03-23 19:19:49.659+00
c0e3087c-7de8-4300-9d40-55b828c43bb4	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 24 sx7seds8	84000	250000	7	\N	\N	\N	2026-03-23 19:19:49.816+00
ace8e9cf-029e-4de2-9494-66a1b3bdf898	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 24 kg4cuhw6	84000	250000	7	\N	\N	\N	2026-03-23 19:19:50.206+00
8ecf2762-8884-4559-9ccc-868ddd8da2c5	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 25 8jd0f6jk	85000	250000	3	\N	\N	\N	2026-03-23 19:19:50.446+00
523003dc-9945-4a2a-a8ec-ffada2599619	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 25 8ssim6i1	85000	250000	3	\N	\N	\N	2026-03-23 19:19:50.665+00
4a430f71-986a-450b-8c59-70c79115eccd	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 25 vw7r45gw	85000	250000	3	\N	\N	\N	2026-03-23 19:19:50.748+00
71ac555d-2478-4e29-863a-990de5a1c3ab	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 26 qmmoh8po	86000	250000	4	\N	\N	\N	2026-03-23 19:19:51.114+00
6ef37acb-4b85-4840-b338-bbe1d033ce7a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	k6 search 25 bxpilfdx	85000	250000	3	\N	\N	\N	2026-03-23 19:19:51.509+00
aa84cdbc-cc9e-41a3-b9a0-2b8b360ceb10	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:22.802+00
d388fed1-9e83-483f-a3c8-70cb7d4ebf38	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:22.914+00
afb26cac-0625-4893-be3b-67a4af05ca00	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:22.726+00
97bb6ee9-8419-4ec4-828d-e88df49e976c	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:24.032+00
e15f549e-8e80-487a-9735-c4f8a042e632	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:24.035+00
b6614eb1-c6e3-48fc-9b95-de99474310a1	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:24.039+00
28d46590-8ae7-470f-8f76-04a28e3258c9	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:24.806+00
b776ad6e-83bd-4ce4-ae88-f5c511d40d2e	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:24.911+00
888489bb-52b9-44ec-980a-202fa2d60640	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:24.983+00
3c790760-7032-42c3-ad32-5d329b2f56d2	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:26.711+00
248ca1a7-ec65-4190-938b-1b06578b301a	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:26.717+00
74090c84-62d5-4613-ac9b-3ea837dc7e69	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:26.812+00
a5a1f783-90c8-44a7-8dd2-1060cdff8b31	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:28.716+00
0b245652-0c55-451e-bb6a-834da18633ec	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:28.723+00
35c7d97f-09d8-4d79-96b2-1e0e4a565278	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:28.805+00
58b6ad29-3123-4bd0-865e-55ac884e094d	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:29.926+00
dadba95f-6080-48ef-9d4d-3a3bf3bd9713	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:30.007+00
31e7741e-3f0d-4552-8e5b-0feab9ab387c	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:30.022+00
ffb52a6c-2377-4acc-83e4-03577449b58d	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:33.344+00
6d044419-41c9-4f31-9172-c79fe69c519a	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:33.42+00
21294c3d-f26f-4ce7-9d88-f40cd80abae0	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:34.18+00
75548c6d-a472-443f-97a3-90ad2a485d30	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:35.028+00
0c2d7002-e306-48ba-af1d-efbd396bceb2	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:35.713+00
54e48d5f-dc5c-4e28-8a89-2e9f6262394b	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:35.74+00
380d5939-ba71-4fe0-8f71-bccb3f8fe4ae	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:38.608+00
9f4a1888-462b-4d39-9028-45a74ba456a2	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:39.065+00
52a8f989-1f68-4ff3-8c72-85218390a847	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:39.348+00
185ce341-da4c-46c3-856d-1d975fa50583	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:40.051+00
3a6260cd-a5a2-4b15-bf99-86307be000b3	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:41.452+00
2f263a02-e586-412e-8c99-090c3c1a74b6	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:42.227+00
f9c4ca5a-6cd3-4b10-8ae9-2251255818bb	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:42.885+00
c8dfe2b7-d0da-471f-a24c-cdcff35dc9bf	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:43.707+00
b7953b58-ef20-48b3-bece-5a5a0ea36a09	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:44.892+00
a3093372-57e9-4b6d-9779-89f71eae7540	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 0 jjq1fv3y	80000	250000	3	\N	\N	\N	2026-03-23 19:24:48.629+00
27bf30d7-fe57-48e8-96c7-9bd0ef8d69d7	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 0 4hbll0uf	80000	250000	3	\N	\N	\N	2026-03-23 19:24:48.709+00
f76172c2-2abf-4105-a621-2ff6ce03d166	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 0 r05786ir	80000	250000	3	\N	\N	\N	2026-03-23 19:24:48.716+00
26d55da1-5918-4e0b-aea6-d18f84ade163	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 1 cj588a9n	81000	250000	4	\N	\N	\N	2026-03-23 19:24:50.106+00
1190c818-94dc-4aca-b664-adb737825cab	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 1 nu2zkw82	81000	250000	4	\N	\N	\N	2026-03-23 19:24:50.113+00
f7e266fc-669f-4331-a28c-5155700b231a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 1 bzer8yrq	81000	250000	4	\N	\N	\N	2026-03-23 19:24:50.264+00
b3738548-a720-42b9-aa57-d1c3b9fd2c22	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 1 zb9hm4kq	81000	250000	4	\N	\N	\N	2026-03-23 19:24:50.361+00
67380779-241c-49c0-9461-5b358ce84ef0	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 2 3yegb9j0	82000	250000	5	\N	\N	\N	2026-03-23 19:24:50.669+00
0f10a6c1-4bf2-470f-8e1e-75e9cec004ec	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 2 e8brps5j	82000	250000	5	\N	\N	\N	2026-03-23 19:24:50.809+00
ee575983-1a66-485f-af2b-b63e340dfd63	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 3 oeijh74r	83000	250000	6	\N	\N	\N	2026-03-23 19:24:51.479+00
3e779b20-a2ae-45ea-831a-197761fa5509	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 3 2ojqaxwi	83000	250000	6	\N	\N	\N	2026-03-23 19:24:51.49+00
cfe18d21-6b1c-47d3-9959-5350a830bc49	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 4 o8gytge3	84000	250000	7	\N	\N	\N	2026-03-23 19:24:52.134+00
cf58bc2b-f141-47ab-b0a9-9c0d0f5bd823	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 4 x3az63zz	84000	250000	7	\N	\N	\N	2026-03-23 19:24:52.469+00
d0a1e18a-e258-43d3-947c-bd685f9d0103	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 5 nh8jphym	85000	250000	3	\N	\N	\N	2026-03-23 19:24:54.105+00
0da5218b-7d72-4083-aeed-e4d13321ada4	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 6 5c45au2d	86000	250000	4	\N	\N	\N	2026-03-23 19:24:54.314+00
23532599-a256-472a-9c82-07c9f3325197	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 6 a7g2ip5q	86000	250000	4	\N	\N	\N	2026-03-23 19:24:54.465+00
8b9b19c2-2dc2-41b4-86a8-ce71b8075143	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 6 4f9lkf6j	86000	250000	4	\N	\N	\N	2026-03-23 19:24:54.832+00
a79cce59-82bf-45e9-abe0-05454e7142a4	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 6 2be1rohj	86000	250000	4	\N	\N	\N	2026-03-23 19:24:55.406+00
e0db548c-e7d0-42e3-8dea-d911423331da	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 7 0ntm51e3	87000	250000	5	\N	\N	\N	2026-03-23 19:24:56.041+00
238a6429-36a6-484b-8d50-cb3b4159efd6	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 7 z047me7m	87000	250000	5	\N	\N	\N	2026-03-23 19:24:56.315+00
2bff0648-ba8e-4a16-ad58-aa87af8f5e38	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 8 9v3cdhks	88000	250000	6	\N	\N	\N	2026-03-23 19:24:56.404+00
af4811ea-8aee-47be-85d8-dee5dfc45e44	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 8 7lkqs1gy	88000	250000	6	\N	\N	\N	2026-03-23 19:24:57.003+00
d5aaf532-dc0f-4656-bb56-31574b275580	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 8 nxdds9it	88000	250000	6	\N	\N	\N	2026-03-23 19:24:57.408+00
a76575d9-a199-4b79-8467-28ca7965451f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 8 lifsg8x9	88000	250000	6	\N	\N	\N	2026-03-23 19:24:57.519+00
4cb6f6f3-e48b-4ace-8246-592e82c8a165	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 9 919vx55y	89000	250000	7	\N	\N	\N	2026-03-23 19:24:57.725+00
8ecbc876-97a1-423d-b749-b9a3ea9925c1	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 9 8niehztm	89000	250000	7	\N	\N	\N	2026-03-23 19:24:58.008+00
b05d26c7-3121-4c07-8ef1-fe6e13a4546e	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 9 cfoyx4xg	89000	250000	7	\N	\N	\N	2026-03-23 19:24:58.818+00
902caddd-d236-41d0-84da-facdf6d15af3	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 9 yr2gajzn	89000	250000	7	\N	\N	\N	2026-03-23 19:24:59.005+00
9b40920a-99aa-4ede-b75a-9fbbe96ec308	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 10 1p0yswqz	80000	250000	3	\N	\N	\N	2026-03-23 19:24:59.514+00
5dc43073-5f0b-4982-b3be-c0531ea82142	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 10 ziszedx4	80000	250000	3	\N	\N	\N	2026-03-23 19:24:59.951+00
a1d2d12e-fc4c-4d9f-b055-fe00d87429d2	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 10 3c72fqp7	80000	250000	3	\N	\N	\N	2026-03-23 19:24:59.973+00
09aa77cf-e311-4fee-b7cf-c29f3aac463d	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 12 gdkw99af	82000	250000	5	\N	\N	\N	2026-03-23 19:25:00.736+00
ee112210-c2a0-43b2-b04b-a3b0cf0ea514	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 12 lss5t87k	82000	250000	5	\N	\N	\N	2026-03-23 19:25:00.814+00
338f10d6-1bb5-4f10-8a3d-e969d7839edf	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 12 tdyw7l7b	82000	250000	5	\N	\N	\N	2026-03-23 19:25:02.291+00
b6b0494a-8ed6-4c65-b11b-fbde9eae705a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 13 fymq8bid	83000	250000	6	\N	\N	\N	2026-03-23 19:25:02.386+00
49b49aa3-aaee-4360-bd3b-bb4e0bfc4f66	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 13 id7la962	83000	250000	6	\N	\N	\N	2026-03-23 19:25:03.457+00
bcb19ac6-b301-4321-afc8-36caa8a7fddc	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 13 bgzrnqj7	83000	250000	6	\N	\N	\N	2026-03-23 19:25:03.48+00
6eeab234-25c3-4d5a-a803-02ea9b97c48e	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 15 zwnduxe5	85000	250000	3	\N	\N	\N	2026-03-23 19:25:04.925+00
cc85022e-80f1-4ece-b42c-7a8286b67f9d	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 14 xxwqtim4	84000	250000	7	\N	\N	\N	2026-03-23 19:25:05.016+00
ed8e7b00-a45b-4c7d-8353-c21702fc6f3d	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 16 krawpcim	86000	250000	4	\N	\N	\N	2026-03-23 19:25:08.583+00
384833e8-ee5e-490c-92cb-7fa4e1eb5bb8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 16 crgjp1at	86000	250000	4	\N	\N	\N	2026-03-23 19:25:09.231+00
c8fe5372-5f38-4289-b72a-91d604f5fc2a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 17 9yfgpu7q	87000	250000	5	\N	\N	\N	2026-03-23 19:25:09.522+00
9ea367ba-7ad8-46ca-bbca-6a2a35d4c54b	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 18 e1hbx83w	88000	250000	6	\N	\N	\N	2026-03-23 19:25:10.175+00
3a040bfd-b7b2-4916-ac23-3a1ac17d8b8c	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 18 9dv2cgxz	88000	250000	6	\N	\N	\N	2026-03-23 19:25:10.185+00
209f220c-a61d-44bc-9e25-e97420a3705d	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 19 c5g04wj9	89000	250000	7	\N	\N	\N	2026-03-23 19:25:10.704+00
4b279dc0-cb51-4425-903c-a697bbe92d87	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 20 dpd90lj7	80000	250000	3	\N	\N	\N	2026-03-23 19:25:12.387+00
b1f9c639-d2ac-4237-a2e1-59a133c507f8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 20 73z727k0	80000	250000	3	\N	\N	\N	2026-03-23 19:25:12.822+00
c708be80-5e6e-413a-9319-75e5214332c6	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:32.18+00
adef2043-cc57-4296-be22-9226a5a2a7c3	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:33.065+00
5b707b40-23f4-41f8-b3f7-9431255e2303	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:33.149+00
1aa2ff85-8a7c-4dce-931b-86770592e29c	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:34.004+00
20ed6cd2-2ae4-4197-8e50-ceb21a75aa34	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:35.216+00
d2153086-66db-4c86-827e-f20ce6de1dc7	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:35.347+00
b64a7b28-63cc-46f7-ad01-f875fcb2d708	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:36.518+00
69942847-df04-4de2-842d-20bd537cbfa3	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:36.79+00
8a5a385c-3ebf-4452-8104-646f740eb47e	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:37.127+00
39db86e8-ef9a-48cb-94e9-28530e41f1da	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:37.566+00
59632715-cdbb-4af1-9097-b202c5a5d761	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:38.703+00
9d2a5b02-8f63-41db-a329-785c633a2601	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:33.425+00
5b6b3ae4-9b3c-4602-8132-725ee0d1a8e2	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:34.246+00
0c80eea9-72fc-4358-8a7d-8135243e4636	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:39.962+00
63f9062a-cdd2-4fd7-a5a4-c60daa981056	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:40.693+00
5b8beba0-7494-457b-8d2d-d959e03de6ee	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:40.704+00
f93862e3-ed55-42f5-98a3-584eecc52389	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:40.776+00
03d9290a-d78a-478d-8891-51693ebd664c	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:42.17+00
629f7571-b27a-4f2b-a7b3-2e4e033e0d99	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:43.705+00
5b763a24-3d8d-428a-a342-846900922137	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:44.883+00
cac7c845-710f-4383-84ce-dfb2ae5e1ea7	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:46.505+00
8f510f94-7ed9-468b-a0eb-db2e603c000f	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:46.705+00
390a8940-5cd4-476e-a9ad-9b67b96c7abd	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 0 6q80lzan	80000	250000	3	\N	\N	\N	2026-03-23 19:24:48.624+00
f94ea6b2-87dd-44bd-8065-227f0349b5e9	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 0 h7m568bd	80000	250000	3	\N	\N	\N	2026-03-23 19:24:48.713+00
905e9d20-73ba-43e3-ac49-752b15bb6009	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 1 nswwdp3r	81000	250000	4	\N	\N	\N	2026-03-23 19:24:50.405+00
e5fa034c-123c-4d98-adc1-92017c2cb034	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 2 4acqr5e4	82000	250000	5	\N	\N	\N	2026-03-23 19:24:50.771+00
c55d5814-88fb-4209-a22b-cae894fbdf7a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 2 jw5wkkwa	82000	250000	5	\N	\N	\N	2026-03-23 19:24:51.104+00
6c6c0561-e47c-41ba-aef0-ed216ba92e5f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 2 s3qyvq3d	82000	250000	5	\N	\N	\N	2026-03-23 19:24:51.11+00
34d32d9e-ee92-4bd1-9f52-7f95fda3b444	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 3 qembq7ia	83000	250000	6	\N	\N	\N	2026-03-23 19:24:51.335+00
77028160-26c7-44b8-864b-1130807ba8bc	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 3 cb5f5x3x	83000	250000	6	\N	\N	\N	2026-03-23 19:24:51.705+00
eaafb9a0-8781-4e5a-b2aa-73c471bf959d	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 4 74nfzwu0	84000	250000	7	\N	\N	\N	2026-03-23 19:24:52.14+00
88ca2ea6-b959-4101-8646-6d7b8be4a06c	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 4 9s6obsl1	84000	250000	7	\N	\N	\N	2026-03-23 19:24:52.505+00
0e30a2fb-be4c-4f0a-ae84-020bab8e7e52	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 4 nj32amec	84000	250000	7	\N	\N	\N	2026-03-23 19:24:52.832+00
7d0ed2c8-a782-413b-8f1f-038395f406c7	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 5 bcm27n94	85000	250000	3	\N	\N	\N	2026-03-23 19:24:54.208+00
25d2fc49-3a7f-4878-87ce-3317b698846b	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 6 75w5ztyc	86000	250000	4	\N	\N	\N	2026-03-23 19:24:54.604+00
1f7afc46-9ef4-4ebc-8f9e-bb27aca4d867	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 7 dv678t3l	87000	250000	5	\N	\N	\N	2026-03-23 19:24:55.937+00
abbe9008-7cc2-4e27-b8e2-4e5bfd0ac0ae	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 7 k52z3krl	87000	250000	5	\N	\N	\N	2026-03-23 19:24:56.405+00
2fe49d36-8528-4f93-bf7d-19f4986e027f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 8 vgizpeb4	88000	250000	6	\N	\N	\N	2026-03-23 19:24:57.607+00
d9daca3f-5a51-4cc7-ae27-cbf91349110e	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 9 j0bhjvb1	89000	250000	7	\N	\N	\N	2026-03-23 19:24:58.888+00
fb89c6b6-af10-4c40-855d-c64acad10cb8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 10 ee122yul	80000	250000	3	\N	\N	\N	2026-03-23 19:24:58.988+00
12af786b-b3ec-4a5a-b993-4333e6c9ae24	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 11 03ljksfc	81000	250000	4	\N	\N	\N	2026-03-23 19:25:00.784+00
864f10ca-689f-4e4c-9ab7-235c869a8d8a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 12 x6z0wa1z	82000	250000	5	\N	\N	\N	2026-03-23 19:25:02.315+00
4cd6335b-c561-4de0-b8ca-a4b0609b2071	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 12 kful0d33	82000	250000	5	\N	\N	\N	2026-03-23 19:25:02.386+00
b35473cb-e3bd-456e-aa49-e341bbf84461	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 14 cq6ftpj0	84000	250000	7	\N	\N	\N	2026-03-23 19:25:03.483+00
2de827ed-43a0-47b3-ab79-d527ee240dc8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 14 3tquu7sc	84000	250000	7	\N	\N	\N	2026-03-23 19:25:03.51+00
d80c4391-6da7-42eb-9f51-71bd59afc06e	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 14 f5xckjwy	84000	250000	7	\N	\N	\N	2026-03-23 19:25:05.007+00
3b272de8-b989-46dc-8194-efdb6731f8e0	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 15 e9x2s287	85000	250000	3	\N	\N	\N	2026-03-23 19:25:05.017+00
bf34d691-9d28-440f-8707-65fe7bdf6c17	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 15 af0qlysr	85000	250000	3	\N	\N	\N	2026-03-23 19:25:08.451+00
402e64c0-5d03-4ef6-889c-1283fa8cbaf4	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 17 qvo86gou	87000	250000	5	\N	\N	\N	2026-03-23 19:25:09.525+00
4cf926fb-a209-46fe-9d90-2042b6ce40b9	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 17 3qw1hzcc	87000	250000	5	\N	\N	\N	2026-03-23 19:25:10.138+00
d8c2a10a-c74e-48b0-a0a8-e1cab78c3e23	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 18 25uezopm	88000	250000	6	\N	\N	\N	2026-03-23 19:25:10.362+00
e970eb1a-aa4f-4433-8e7a-bb901ff9eebb	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 18 fg4iqs0a	88000	250000	6	\N	\N	\N	2026-03-23 19:25:10.698+00
2e93db1d-34f8-4240-b361-5567c5519db6	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 19 14378b7g	89000	250000	7	\N	\N	\N	2026-03-23 19:25:11.052+00
7c44aa70-3ff1-479d-ab63-2683f9c6c153	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 21 zt376rbu	81000	250000	4	\N	\N	\N	2026-03-23 19:25:13.322+00
2ce8d78a-6c2d-4044-a0bf-002315891556	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:32.18+00
ff6b0e9b-29e3-4d94-9b2c-241bb6bf6297	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:33.958+00
31608d93-8e74-4cf4-b525-953c10fac8bb	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:34.001+00
4dbd00e1-b1e3-4ed6-9582-491bf25e4b55	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:34.595+00
e3c11a75-a261-47b7-a068-f015796f7870	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:34.669+00
4b75c4d5-14af-4d36-b00b-5d87c89c7c32	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:34.678+00
580ed584-6e46-4902-870f-8518b18ae286	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:35.352+00
dfa68f55-8bc1-4d2e-84f6-81872132e886	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:35.902+00
76637607-9216-40d6-b922-aa332b13cc46	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:36.15+00
a7503fa5-2043-4fe6-b3d5-be46e9eb6310	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:36.157+00
1e70216b-7009-46ce-8d71-c98363566be5	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:36.794+00
664680f2-c4f6-422e-895c-2e81c8a44588	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:37.574+00
88b71eeb-a3fa-4283-8154-87d194e905d8	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:37.894+00
0effdc93-9408-4ac3-b1ec-303027fbc1b0	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:38.705+00
f5111de0-792b-4ee2-982f-60ed24ce25db	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:40.065+00
400ae3ea-105c-4306-a3fd-d2258ca0b6b8	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:43.138+00
6b818b80-3fc5-495a-a084-57023bc4a5ad	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:43.239+00
f5432d79-dd71-462e-af18-d52821a62dd9	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:43.268+00
5798055e-98e9-46b6-8f63-5090f9e8905a	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:45.13+00
747131dd-e8ff-4ca8-b553-c3b58b43ba7f	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:45.838+00
154bb0e4-daa9-43ce-bc3c-ab3204babf13	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:46.58+00
f2f2ef07-bc39-4273-8ca2-a5b3017d623a	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:47.327+00
367dacbe-ffc0-43db-98f7-a2ff708fb7ad	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:48.729+00
87cd2fd8-24f5-4fc4-8393-19b1f913a474	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:49.407+00
95a584f4-6b23-4af7-a41d-98bcc3ac671b	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:49.43+00
fe9f1478-d32d-41b0-9795-df64bb95f1d1	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:50.117+00
665ee586-0730-4535-8e39-71890a0ae058	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:50.815+00
d6e2e793-6a72-4caf-b448-b6c0b3420d96	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:51.5+00
4a692fe2-0806-43a2-b34e-063d97273496	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:52.158+00
cc3cf7b5-fbc6-42be-9e6d-f9cab5e98676	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:52.845+00
d61b1fff-b60d-4373-8c9a-b8421305c545	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:34.248+00
ccb67b7e-9d33-4799-a735-65a38a17e12d	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:34.872+00
6fa08a19-f953-4335-b4be-f339b198c739	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:35.024+00
1601fc5e-508d-485e-b095-3c4d978a075e	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:35.56+00
32101063-1a87-4249-b1c1-0f793dbbac5f	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:36.611+00
69bda0a9-7e6d-41b9-9b03-b1e548598068	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:37.514+00
0a8cb08a-b663-4719-81ff-02e8f37e86e1	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:37.608+00
f0556fe0-e6f4-4922-acb1-3bb89cd6fb87	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:39.068+00
7abec8f2-a20a-4f6a-b9ea-82772f6e2dfc	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:39.959+00
a492e36c-7b8d-4dfd-9313-2f7a48822abb	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:41.449+00
50ea1d9e-67bf-48c9-afcf-efbf252353b1	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:41.496+00
c89ad7a8-f90e-4c15-83c1-bf1cff43f5b2	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:42.173+00
621f9fe0-0ef3-4ad0-ae6b-71cb09d4381b	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:42.881+00
43ae9f2e-c7af-42cc-9b18-38bd8cb452a8	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:42.888+00
bb181ef7-2631-416f-8c8b-24db8853b150	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:43.71+00
58abcb6a-51ff-432c-a3b6-17db2773cf54	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:44.889+00
7e0967d8-b17c-45cd-8406-8b2ae203423f	54394bda-0a5e-47ec-9565-d2b43297c616	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 19:24:46.52+00
d4840437-9753-49a5-9d1b-d323961b7a9c	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 0 cwse6dxj	80000	250000	3	\N	\N	\N	2026-03-23 19:24:48.615+00
3152f9f4-ec5b-491c-a471-e51819c183fb	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 1 rkr0gboc	81000	250000	4	\N	\N	\N	2026-03-23 19:24:50.11+00
4012d98a-28d1-4a79-8bd1-e426f973aa71	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 2 k8jqeosr	82000	250000	5	\N	\N	\N	2026-03-23 19:24:51.008+00
06158f7e-8c30-45b7-8d5e-5a7c0b77efcb	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 3 7vzwd2s3	83000	250000	6	\N	\N	\N	2026-03-23 19:24:51.64+00
83db380d-fe95-4513-84d4-a3e14d4003cd	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 3 51jh7qcn	83000	250000	6	\N	\N	\N	2026-03-23 19:24:51.655+00
dc37696c-e2e0-4433-8cd6-835c1c9541cd	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 4 edkm40t3	84000	250000	7	\N	\N	\N	2026-03-23 19:24:51.913+00
0aa6f52f-447a-4fed-b1bb-20c98a97580a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 5 l5ifsf4o	85000	250000	3	\N	\N	\N	2026-03-23 19:24:53.428+00
333a78bf-58f3-4a51-8043-b3faef34b00b	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 5 yn0mym0a	85000	250000	3	\N	\N	\N	2026-03-23 19:24:53.881+00
145b6348-5154-41e1-a5e1-66a50de3caaa	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 5 vuig5bza	85000	250000	3	\N	\N	\N	2026-03-23 19:24:53.906+00
87d5ccc2-e329-48ad-9dbf-e44da1a4df51	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 5 0bfle8ac	85000	250000	3	\N	\N	\N	2026-03-23 19:24:53.984+00
651f7062-65ce-49f3-8115-08666deb624f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 6 ps5bvw4w	86000	250000	4	\N	\N	\N	2026-03-23 19:24:54.595+00
ad9b4355-27ef-452e-9d2e-dc749b637648	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 7 py32t7od	87000	250000	5	\N	\N	\N	2026-03-23 19:24:55.416+00
d1f6a7bd-a541-4418-af84-4add29ba75d9	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 7 92z0l0op	87000	250000	5	\N	\N	\N	2026-03-23 19:24:56.044+00
cf5ad49b-15a9-41df-92c4-20e38fcd7fd8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 8 ttjhvxzv	88000	250000	6	\N	\N	\N	2026-03-23 19:24:57.806+00
cfb0530a-c8b2-4e5b-a6e7-18e90cd2bd2f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 9 ccidwhpi	89000	250000	7	\N	\N	\N	2026-03-23 19:24:58.511+00
b72bcaea-35f8-4c68-9d33-c68f8c8f668f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 10 533u2qv2	80000	250000	3	\N	\N	\N	2026-03-23 19:24:59.008+00
e40e3a7c-4d78-4797-9878-7afab3d8ce85	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 10 hrlsmhau	80000	250000	3	\N	\N	\N	2026-03-23 19:24:59.908+00
953b1b6c-066c-4729-9aad-ea1b3579768a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 11 hssfgb8j	81000	250000	4	\N	\N	\N	2026-03-23 19:24:59.953+00
9b1ffe5d-33a8-4fa0-89c5-353ccd2175c1	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 11 ibuevvuz	81000	250000	4	\N	\N	\N	2026-03-23 19:24:59.972+00
0704deea-8cf2-48f5-9ecd-000f606d2ef2	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 11 094flb9f	81000	250000	4	\N	\N	\N	2026-03-23 19:25:00.085+00
2a23084b-b544-4263-8917-fe5428737452	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 11 xu5m388d	81000	250000	4	\N	\N	\N	2026-03-23 19:25:00.626+00
9c4d7cd3-8477-4c7c-8ca4-82fd82465ca4	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 11 285a095l	81000	250000	4	\N	\N	\N	2026-03-23 19:25:00.731+00
cdba26e0-f6dd-481a-9ba7-a86dc0e2044b	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 12 vckens94	82000	250000	5	\N	\N	\N	2026-03-23 19:25:00.809+00
5f57881d-329d-48b9-afa3-03e03660a50f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 13 mkqyyslc	83000	250000	6	\N	\N	\N	2026-03-23 19:25:02.32+00
f23b3847-efa6-4eca-be41-c7742d792846	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 13 ijx7lb6u	83000	250000	6	\N	\N	\N	2026-03-23 19:25:02.389+00
1957ccfe-b546-4035-96fd-f90221883734	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 13 wuv1jmy4	83000	250000	6	\N	\N	\N	2026-03-23 19:25:03.488+00
fe0cc613-a561-46ce-ad7e-73d0270bf867	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 14 yleodhl9	84000	250000	7	\N	\N	\N	2026-03-23 19:25:03.506+00
386d5405-178b-4160-8757-1ee64bd07823	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 14 v4bzf2bz	84000	250000	7	\N	\N	\N	2026-03-23 19:25:04.905+00
dcb20ed5-12fc-4497-8958-7d1707042fb9	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 15 ivmwrc87	85000	250000	3	\N	\N	\N	2026-03-23 19:25:05.014+00
7cd34bb6-b76b-452c-ab02-cb3d7cc48e99	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 15 sb9tqswb	85000	250000	3	\N	\N	\N	2026-03-23 19:25:08.449+00
36c1f108-3f6b-481e-a4ab-f1c58b2ccfcc	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 16 2a3zz1ds	86000	250000	4	\N	\N	\N	2026-03-23 19:25:08.571+00
5255576c-df0c-47c5-9af9-7090ea0d89db	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 16 n4yhs99x	86000	250000	4	\N	\N	\N	2026-03-23 19:25:08.581+00
f4593746-8fcc-4699-8a64-75f32e2cb86b	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 15 lfqzrc9z	85000	250000	3	\N	\N	\N	2026-03-23 19:25:08.606+00
7ebae79d-8f40-4f65-b09a-12319a6d09ab	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 16 yz1fd1pa	86000	250000	4	\N	\N	\N	2026-03-23 19:25:09.228+00
c5285afc-26cb-44d5-b152-577e0600f2af	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 16 542gh8hu	86000	250000	4	\N	\N	\N	2026-03-23 19:25:09.519+00
75457a76-b218-4c08-aa3c-0fa8276cd25a	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 17 7kvpt9wl	87000	250000	5	\N	\N	\N	2026-03-23 19:25:09.524+00
b1908f34-8b95-4a1e-a81a-e9e4d8aa17f6	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 17 5y4s2kfx	87000	250000	5	\N	\N	\N	2026-03-23 19:25:09.899+00
d4311472-5671-4162-8a1d-b41d56cd5db8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 17 vsrl5no5	87000	250000	5	\N	\N	\N	2026-03-23 19:25:09.949+00
52f1ed02-d835-419f-85d1-0ea403cc2803	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 18 kgzpwciw	88000	250000	6	\N	\N	\N	2026-03-23 19:25:10.136+00
4a0a942b-9692-401e-b7e9-09662c785248	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 18 m9f60y8c	88000	250000	6	\N	\N	\N	2026-03-23 19:25:10.412+00
3ffcfb14-04bf-4aef-a33b-ed21c51bb8a0	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 19 gj4rkcud	89000	250000	7	\N	\N	\N	2026-03-23 19:25:10.702+00
2d3d7e0b-316f-4f0e-8d73-67dc65ea1e18	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 19 aothrohv	89000	250000	7	\N	\N	\N	2026-03-23 19:25:10.793+00
4764c097-48fc-49e9-9609-efe4552716dd	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 19 uyafdv39	89000	250000	7	\N	\N	\N	2026-03-23 19:25:11.048+00
13860eb6-c730-4d99-ade1-5103a8c30c74	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 19 31zpv8dr	89000	250000	7	\N	\N	\N	2026-03-23 19:25:11.634+00
de8ffba5-dc81-432e-9ba9-1cbfb950d5b6	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 20 6otxms0a	80000	250000	3	\N	\N	\N	2026-03-23 19:25:11.713+00
453e89bb-65da-47d3-8b19-ae5e36580d5d	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 20 5oqte12b	80000	250000	3	\N	\N	\N	2026-03-23 19:25:11.914+00
09aa56a2-3141-4a7b-8667-0c7c069300d9	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 20 43dh529s	80000	250000	3	\N	\N	\N	2026-03-23 19:25:12.83+00
fd68615c-3ac5-4d3b-9e57-17147b2006a8	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 20 nevcyuhz	80000	250000	3	\N	\N	\N	2026-03-23 19:25:13.308+00
4675e1fc-d12b-4332-8324-4cf1c2ba17dc	bf0ca156-d0ce-4c63-b02c-bc0081755d44	k6 search 21 ukizkx0o	81000	250000	4	\N	\N	\N	2026-03-23 19:25:13.318+00
288d3324-d92d-42be-8f55-cfc73a807537	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:17.838+00
defd39af-47ac-48ab-8100-7fad4805d8f7	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:17.841+00
2232fd1a-53ba-4c7c-a462-6a0e958aa394	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:17.864+00
915bdd72-aab1-4c5c-acd5-07ac76258ce9	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:19.473+00
ebac5c3d-5f05-49e0-b9b3-b0dd48520736	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:19.484+00
2c5214b7-bb7c-4bb7-b8bb-de50fc1416f7	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:19.488+00
95bae5cb-3bc7-4b4a-8b78-ada44b496ba7	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:21.026+00
99333b0e-1452-4380-8854-d1577290c356	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:22.836+00
488c5e25-2bf9-4ebb-a265-33e19c75d8d0	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:25.061+00
815255f1-e78d-421e-b438-a515ebcbe9ea	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:30.466+00
1dddb808-734a-4db0-81f9-baa9b5f3b9ca	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:30.63+00
d022fddc-c3cc-4d50-bcf3-65260e17834d	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:30.66+00
2eb2cda1-3efc-4340-923f-e797f83377aa	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:31.467+00
8acc2338-f80c-4f87-84fc-b18cdac0d988	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:33.18+00
67c3a287-d446-4a1b-a462-d3d1829c50d7	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:34.03+00
16238d64-9173-4004-b242-fdf7984da1c3	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:34.932+00
bf2ab0b6-6be1-4a7b-a1bb-c80a4ad25109	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:35.986+00
ba32e9b5-f607-4e63-9e80-77543df72398	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:37.131+00
90502387-d570-44de-bc04-2ea0252c2eec	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:38.809+00
bc42f21f-ea5e-4249-b5d2-9c6f8cc167ef	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:40.437+00
0d15d4d2-54d9-4931-a824-cbdab1e991a3	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:42.436+00
430b67f8-be68-4563-9e9b-bbb723212510	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 0 k92emsw2	80000	250000	3	\N	\N	\N	2026-03-24 00:47:03.059+00
e63e4307-e040-4abc-abb5-6c45a0b01c3f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 0 nqkos202	80000	250000	3	\N	\N	\N	2026-03-24 00:47:03.067+00
5dd5c044-95f8-466b-8a09-ba24f1e57414	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 1 7nvlso15	81000	250000	4	\N	\N	\N	2026-03-24 00:47:05.118+00
89dde1ee-4fc9-48c1-bbb5-89792606def4	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 1 e3n5dq7c	81000	250000	4	\N	\N	\N	2026-03-24 00:47:05.469+00
db26b5f3-be13-4cd8-ad8f-4745b6aa1eb5	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 2 59y1xox0	82000	250000	5	\N	\N	\N	2026-03-24 00:47:07.234+00
86277c5a-c895-4630-93d2-100acfec1b1f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 2 4bewhbjk	82000	250000	5	\N	\N	\N	2026-03-24 00:47:07.252+00
7c4d825f-a582-41e3-807d-b91ab23ad744	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 2 jss5m886	82000	250000	5	\N	\N	\N	2026-03-24 00:47:07.438+00
69a0c287-2809-4219-8104-827079f18da4	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 3 ohwyrgbc	83000	250000	6	\N	\N	\N	2026-03-24 00:47:08.332+00
3bca001e-4830-436a-b3e4-8150d5eb3340	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 4 r708koxr	84000	250000	7	\N	\N	\N	2026-03-24 00:47:08.871+00
f06043b8-e04c-42e6-9ede-103220e8c1c2	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 6 is7iik7e	86000	250000	4	\N	\N	\N	2026-03-24 00:47:12.654+00
d1570a79-2d23-48d9-9f4e-53f1e5f9bad5	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 6 inch6xkq	86000	250000	4	\N	\N	\N	2026-03-24 00:47:14.033+00
3db959f0-e7eb-4910-8005-4d5fc6e67533	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 7 itmoxw7p	87000	250000	5	\N	\N	\N	2026-03-24 00:47:14.5+00
92b87f7a-95f6-4978-9a37-a8705bfa6b22	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 9 4b1takc5	89000	250000	7	\N	\N	\N	2026-03-24 00:47:16.456+00
b8992a67-56fd-48cb-9a23-15594e3a630c	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 9 bqutqjkf	89000	250000	7	\N	\N	\N	2026-03-24 00:47:16.908+00
f14fa0eb-700b-404d-a522-a0e5d027dce6	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 10 d2e5jm0s	80000	250000	3	\N	\N	\N	2026-03-24 00:47:17.268+00
c2b17a2a-3210-40be-be0b-7f170e4a764f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 11 gjddo5rj	81000	250000	4	\N	\N	\N	2026-03-24 00:47:17.634+00
f05382f9-8c8b-41b3-9017-3654603c0f0b	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 10 iomb4gfv	80000	250000	3	\N	\N	\N	2026-03-24 00:47:17.638+00
4420bbad-df97-45fd-ac98-aa26dda694fd	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 11 77knyxh0	81000	250000	4	\N	\N	\N	2026-03-24 00:47:18.105+00
5c38e924-ef00-43d3-ab8e-114d45bda6d2	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 12 7ev0jjhd	82000	250000	5	\N	\N	\N	2026-03-24 00:47:18.85+00
1895ed30-1a6c-497d-bd4a-2e14c625e1ec	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 11 rg79l8sj	81000	250000	4	\N	\N	\N	2026-03-24 00:47:18.863+00
466be3e9-8712-45e7-913a-b74b3c228b49	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 12 kwtpb56d	82000	250000	5	\N	\N	\N	2026-03-24 00:47:19.051+00
a57ad097-05da-4430-931b-7d6cfe78f895	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 13 7202en15	83000	250000	6	\N	\N	\N	2026-03-24 00:47:19.464+00
3b3cfdf5-7955-45be-88c1-3fc01115f8b0	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 13 hhvd1vxd	83000	250000	6	\N	\N	\N	2026-03-24 00:47:19.719+00
ad21f181-b309-42f1-9a3d-9edaa532c82a	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 13 21qai168	83000	250000	6	\N	\N	\N	2026-03-24 00:47:19.816+00
a1ffceab-1b75-43d5-8027-0be09ec281ff	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 13 l0randkg	83000	250000	6	\N	\N	\N	2026-03-24 00:47:20.805+00
59d9ac33-b5bc-4e3f-95a6-d18eacddac72	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 15 fq282p74	85000	250000	3	\N	\N	\N	2026-03-24 00:47:26.411+00
00d08cba-4b47-44fc-a74c-c5257f8ac974	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 15 zm8scknm	85000	250000	3	\N	\N	\N	2026-03-24 00:47:26.878+00
2ff01ee5-6811-495d-aba0-8519739467a4	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 16 ntpsriaq	86000	250000	4	\N	\N	\N	2026-03-24 00:47:28.499+00
f98b42f4-45db-4620-9193-1f940dedd3a0	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 16 p0xebkpw	86000	250000	4	\N	\N	\N	2026-03-24 00:47:28.527+00
d5fca40d-6b4c-4463-bcb0-4eb8cbded9a5	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 17 oralf8fr	87000	250000	5	\N	\N	\N	2026-03-24 00:47:28.667+00
4538795f-1f98-4334-b3b7-c2299b6e63c3	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 17 mzfcx9bl	87000	250000	5	\N	\N	\N	2026-03-24 00:47:29.184+00
9a1249c5-e4f8-4ad4-82a7-0c8fa7f406ef	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 17 zcnjjnfn	87000	250000	5	\N	\N	\N	2026-03-24 00:47:29.209+00
6bb3d027-3bff-48e7-a827-6933a3f30420	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 16 bt1ynb5l	86000	250000	4	\N	\N	\N	2026-03-24 00:47:29.242+00
675eaef7-c29c-4dfa-8920-011482da37db	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 17 socwyiw6	87000	250000	5	\N	\N	\N	2026-03-24 00:47:29.268+00
b6a3bcf9-fb13-4f8b-bdcc-55f8cae361c1	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 18 4rxl4gj6	88000	250000	6	\N	\N	\N	2026-03-24 00:47:29.964+00
3c1b3044-b87c-473f-9019-f74d73450c53	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 18 vmib5j2k	88000	250000	6	\N	\N	\N	2026-03-24 00:47:30.142+00
69d188da-07b7-48d2-a3b3-a78e6b12b67f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 18 fzbrgt5c	88000	250000	6	\N	\N	\N	2026-03-24 00:47:30.153+00
21cb2b49-2956-41df-9e69-0610981a6681	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:38.707+00
4259cc3a-df01-4f0f-8c75-83c18d67feaf	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:39.393+00
c0c51152-2c0d-4ea1-aafb-ae6bc111f901	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:39.402+00
5991209a-36ee-4085-83c4-a33ed22465e8	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:40.063+00
9fe4c05f-e8e5-4cd4-8b5b-848aa6ff8a94	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:40.721+00
edb939ea-0c4c-4c66-b4b8-0e363085c454	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:40.786+00
d24bdbfd-892e-4c24-9ca2-acaf811cc40c	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:41.472+00
c192a321-6e39-4bdf-9b1d-dc095274a1ed	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:42.089+00
ec1ee953-6094-4cb4-8f39-d31b53973c96	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:42.118+00
b8a95b34-4c7d-458c-b198-71cb77bfd6a7	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:42.158+00
2cc8fb60-4c1d-4187-8877-5c605e888a9f	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:45.132+00
356dc95a-8884-456b-8339-1818316dc669	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:45.832+00
4321ffb3-4f56-4a3a-8f82-b7d2c1693912	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:46.574+00
f214efcc-3377-4057-bd25-2077217e3511	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:47.335+00
008a8f45-11e9-489e-9338-9bf5af4130ad	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:48.052+00
92efd183-1171-481d-b110-0ab52de0ba82	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:48.767+00
1676cfa9-efde-4767-8d92-bd03343c557b	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:49.432+00
22e35f91-2211-4e6c-adcc-f45c0e771177	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:50.12+00
49b02184-2354-4545-973d-1acd327c23fe	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:50.813+00
ba29c9d4-0374-4d80-81fc-14e9656a8cdb	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:51.498+00
b4885531-a78b-49e8-ab89-c31f12f92fa9	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:20.906+00
39f00064-fbf7-4040-aef4-0499d5d28098	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:22.841+00
4426ad5d-6859-4bb2-b64b-b9de50914a74	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:25.233+00
81a3f75d-2107-4981-9ec0-0db20b74c0ce	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:27.417+00
fc8df911-3f23-4b66-8059-f60b40361f4a	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:28.258+00
398312e2-9f4e-47e7-ace9-15d0484da56c	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:28.427+00
a5a76be1-ce31-494a-ba08-44c340173c83	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:29.053+00
37f88417-9e62-4fe0-ad51-83543404b183	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:29.812+00
acff8467-d4d0-41dc-bc30-6218015ecd20	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:32.253+00
37a58b3c-be09-4102-9efe-43ae210c0336	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:32.983+00
c9624080-b125-476a-afb5-bb58a51534dd	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:34.025+00
0b75294b-b54c-446b-ac36-044e24bbd83f	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:34.97+00
c7724b5d-f708-401e-a717-aae8a33b4cbe	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:35.998+00
a7491038-fcd8-45ec-87f9-4d1e5352dd2e	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:37.122+00
03d7ead7-0ade-4d66-84d5-4e85b240f12d	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:38.655+00
fc3ef1d3-9e07-4a2a-a702-3ea36fdc23b0	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:40.445+00
b362e2c0-3da0-45a5-8649-531d0f08a289	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:42.444+00
397af0ab-46ab-4fbc-8d2a-8b6c42748430	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 0 jkcmo5au	80000	250000	3	\N	\N	\N	2026-03-24 00:47:03.047+00
88826de3-ced7-412a-8fb0-00560bfe9dcf	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 0 esdtlqj4	80000	250000	3	\N	\N	\N	2026-03-24 00:47:03.064+00
1aa621d3-2001-4430-9cbe-0832ee235c70	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 0 98asliuh	80000	250000	3	\N	\N	\N	2026-03-24 00:47:03.069+00
bc004fcd-73b1-49e3-8b41-f9ddb55bdfe9	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 3 jpudjj7m	83000	250000	6	\N	\N	\N	2026-03-24 00:47:08.433+00
4eaeb698-86a4-4818-b0bd-cf390eeeda43	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 4 h83v2684	84000	250000	7	\N	\N	\N	2026-03-24 00:47:09.029+00
7b24b31d-f8c1-4ec6-9447-47d316a495f1	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 4 2qlr519o	84000	250000	7	\N	\N	\N	2026-03-24 00:47:09.835+00
5b518534-3ebf-4bf9-aacb-b603112daed4	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 4 cyqc72ep	84000	250000	7	\N	\N	\N	2026-03-24 00:47:09.837+00
350bc209-b946-4d80-96ae-a9626e7a701b	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 4 y8eficep	84000	250000	7	\N	\N	\N	2026-03-24 00:47:10.251+00
cfa301f1-1922-47da-9b8a-0bb5401ef9f0	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 5 yt32y232	85000	250000	3	\N	\N	\N	2026-03-24 00:47:11.439+00
23c5ffc2-278c-41ba-995e-0b2bc2e18b92	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 5 3z2unq60	85000	250000	3	\N	\N	\N	2026-03-24 00:47:12.623+00
ab6f6410-97e3-4bb6-bc66-b55b0813ab1f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 6 p1906uhx	86000	250000	4	\N	\N	\N	2026-03-24 00:47:14.228+00
228860a6-0a0c-4094-aff1-e9020106aa8b	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 6 2f9ea8z3	86000	250000	4	\N	\N	\N	2026-03-24 00:47:14.498+00
c3b580fb-7b2f-45f1-8e4a-6128743b91d4	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 7 sm0iqmzn	87000	250000	5	\N	\N	\N	2026-03-24 00:47:14.718+00
e5db756c-a49e-4bf8-8aae-0e0ee214267f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 7 6b3b2997	87000	250000	5	\N	\N	\N	2026-03-24 00:47:14.893+00
eae3c408-9a87-4d78-9162-1d0b9488e49c	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 7 zawhv9c4	87000	250000	5	\N	\N	\N	2026-03-24 00:47:15.217+00
df6ec46d-e20d-49ad-9f70-419543f7b129	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 8 x2zesq8n	88000	250000	6	\N	\N	\N	2026-03-24 00:47:15.23+00
d0a760aa-7b17-4c60-8acf-b08a2aedd7d1	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 8 gko6x1d9	88000	250000	6	\N	\N	\N	2026-03-24 00:47:15.239+00
fcf5e868-b9b6-4931-80a8-bf492f4ba907	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 8 m3qqqlzx	88000	250000	6	\N	\N	\N	2026-03-24 00:47:15.418+00
369239e1-67df-4126-855e-f2d9711be2e1	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 8 nmmsx0uh	88000	250000	6	\N	\N	\N	2026-03-24 00:47:15.423+00
7878dd21-c1b1-47cb-97a1-858cb316b210	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 8 0u5ib9tp	88000	250000	6	\N	\N	\N	2026-03-24 00:47:15.433+00
31de9cc3-b232-4cb6-90d1-c2d8a4d5111d	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 8 5qv8thfg	88000	250000	6	\N	\N	\N	2026-03-24 00:47:16.17+00
eacd75ac-cd1d-40ea-ae7a-f0572cb3e4ae	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 9 g513d5dx	89000	250000	7	\N	\N	\N	2026-03-24 00:47:16.194+00
1280acdb-71a1-4b44-890d-20b67190e927	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 9 1nu91asy	89000	250000	7	\N	\N	\N	2026-03-24 00:47:16.28+00
98e2f547-c246-45d2-8b2f-4cb6fe56c84f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 9 l5rn19h0	89000	250000	7	\N	\N	\N	2026-03-24 00:47:16.467+00
671ad081-cfb6-4abf-99f0-fd4e1773cd49	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 10 kxn6xkhn	80000	250000	3	\N	\N	\N	2026-03-24 00:47:17.229+00
a1245d37-716a-4d73-8f6c-7267e42eeeb8	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 10 1t4d49ie	80000	250000	3	\N	\N	\N	2026-03-24 00:47:17.246+00
ffee8963-5562-46ff-b5ce-a35a1add07bf	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 11 dsr5uqh0	81000	250000	4	\N	\N	\N	2026-03-24 00:47:18.516+00
a3419fdd-4de5-4ff7-9fe0-d12e8c13590c	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 12 xdphedcv	82000	250000	5	\N	\N	\N	2026-03-24 00:47:18.848+00
d2aca400-7af6-4643-9e89-d05b35a343a3	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 12 z2p0wqfq	82000	250000	5	\N	\N	\N	2026-03-24 00:47:18.961+00
0d4fc754-772c-45f3-b9d1-dad311a12930	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 12 3dkr1e0f	82000	250000	5	\N	\N	\N	2026-03-24 00:47:19.028+00
795eed94-1bd7-4392-98db-1f5848346f41	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 13 hpcravwr	83000	250000	6	\N	\N	\N	2026-03-24 00:47:19.826+00
ab4aaf0b-ebff-4d53-b2eb-2f3b1de1792a	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 14 nnxlecfz	84000	250000	7	\N	\N	\N	2026-03-24 00:47:20.225+00
c5ab4663-3502-40e9-a851-e25e6eddd17d	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 14 k7fwi6mi	84000	250000	7	\N	\N	\N	2026-03-24 00:47:20.235+00
8e1641f1-8d12-4112-8aa3-906acb1c264d	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 14 p2p708ai	84000	250000	7	\N	\N	\N	2026-03-24 00:47:20.829+00
dffbb7d9-252a-4fa3-9b52-6e92d0372eb1	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 14 u2hkg80z	84000	250000	7	\N	\N	\N	2026-03-24 00:47:20.836+00
9092e79a-0aee-4de3-8da8-51b3915f2c87	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 15 dq2otwwg	85000	250000	3	\N	\N	\N	2026-03-24 00:47:26.883+00
8cb71e8c-7889-460d-b024-530ea29cfeb5	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 15 dlpc4yzo	85000	250000	3	\N	\N	\N	2026-03-24 00:47:27.006+00
2eabb632-a6d8-4a81-9dc9-3593c68814a2	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 16 efjsal84	86000	250000	4	\N	\N	\N	2026-03-24 00:47:28.168+00
973e1fc4-8b09-43d0-8ef9-5230c4d556c0	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 16 lzbxveul	86000	250000	4	\N	\N	\N	2026-03-24 00:47:28.35+00
6817221d-cb26-4cc9-b7fb-cfbdc84b0b85	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 15 xcc4raok	85000	250000	3	\N	\N	\N	2026-03-24 00:47:28.485+00
73424224-135b-43a1-820e-56bee1c9a8eb	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 16 wqqr4rp3	86000	250000	4	\N	\N	\N	2026-03-24 00:47:28.529+00
49803509-767e-40e0-be8c-8da8bdf0c08a	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 17 192f5ryg	87000	250000	5	\N	\N	\N	2026-03-24 00:47:29.272+00
91c175f0-58d4-4e39-b78d-e591a9dd2d9b	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 18 eziqv69x	88000	250000	6	\N	\N	\N	2026-03-24 00:47:29.312+00
092953e1-cf3c-4844-b4ed-ca876378772e	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 18 tqfc5tfu	88000	250000	6	\N	\N	\N	2026-03-24 00:47:30.148+00
fad71934-45d2-4090-860a-5d9e667f59c1	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:39.391+00
142eee05-f336-4286-9bc3-2ade38e28f72	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:40.059+00
f3110044-b306-47c7-aa66-dae8f386040d	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:40.788+00
206925d5-362e-437c-b872-80b98dc6cdaf	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:41.406+00
a4f72dd6-a2d6-44cd-8ea9-b47ce077bfb8	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:41.47+00
807c9493-9bf1-46da-be7e-11704b8ceb04	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:44.343+00
964c3899-6bf9-496d-81f1-93f2a6e2ba19	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:44.368+00
34f8ab6a-d5fe-4a24-81f6-d18c0f28a641	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:44.44+00
eec8d2cc-54c0-480a-8481-7d6d1b5ada70	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:45.128+00
bef908e2-e22d-401a-970e-31478981f19a	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:45.835+00
fb25268a-673a-4719-a2a8-fc384ac32fd2	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:46.578+00
731cf5d8-14b5-4f41-990a-6c3b04d19bcd	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:21.027+00
91e28380-0337-492f-8469-7124ed9f7f60	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:22.842+00
311565c1-ea7f-49b0-897b-86591cdb588f	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:24.642+00
b1e098f3-04f6-47f2-a255-76925c2dcc1d	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:26.904+00
3c6eff31-39c4-46bf-8234-d30a079b1f9a	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:27.409+00
0ed2fc6e-705c-4cc1-b667-76eff35cad40	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:27.64+00
9ec5b46b-2362-4b63-86d9-697ce21b55bc	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:28.261+00
b8deb226-1ab0-43c1-ac00-f42c35e0c23c	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:29.048+00
8f88d5f7-af0c-4b6a-9936-c6cf390960cd	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:29.566+00
033f28e0-1d86-4aee-873e-3076f390b8aa	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:29.836+00
071ed2fc-6996-44c0-8969-8e7cf7e23fc2	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:31.227+00
83c30ee0-7963-4648-92db-f63dc47b6bb6	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:31.462+00
927c58a5-6946-4574-b853-b607da93974e	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:32.973+00
a0a4e309-c6cb-433c-8382-78e179d7950a	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:34.034+00
886fe5c3-4fe6-4f09-b887-37cafd250329	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:34.962+00
026b4a97-7dcd-448b-b394-90b92a5f27e1	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:35.971+00
0d9eb516-f1f0-4505-9781-577b1c4bc212	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:37.097+00
03611c23-5175-40f8-b421-87e50fc6cd29	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:38.806+00
5a30be7f-ec8f-4b5e-b182-e44a9492a297	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:40.442+00
ddd3e230-fd3e-4b18-9245-a1ea852b783c	21fb5ed4-2a99-499a-9fae-4a705f894836	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 00:46:42.242+00
821f30b2-97bf-44c6-9068-fc7b9270c765	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 0 b7f7tr96	80000	250000	3	\N	\N	\N	2026-03-24 00:47:03.063+00
6b4f15d2-3808-4f4a-9317-fab3d05ad515	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 1 55jc6rxo	81000	250000	4	\N	\N	\N	2026-03-24 00:47:05.114+00
a9291f61-81e8-4ad5-b041-7b4dd4db5d4c	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 1 5fv143e6	81000	250000	4	\N	\N	\N	2026-03-24 00:47:05.125+00
04358f59-9323-4aca-b083-490680423fda	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 1 joctmptt	81000	250000	4	\N	\N	\N	2026-03-24 00:47:05.451+00
962aa4ca-9cb6-44d3-bb4f-28f5353b6226	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 1 jmnf35x5	81000	250000	4	\N	\N	\N	2026-03-24 00:47:05.464+00
b6a27bc1-abbf-440c-a8be-ab0b48119251	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 2 rr3fsrbq	82000	250000	5	\N	\N	\N	2026-03-24 00:47:06.652+00
d899fa31-2111-497d-a661-35d91fc31f12	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 2 2rnpqzyw	82000	250000	5	\N	\N	\N	2026-03-24 00:47:06.67+00
7c165549-5fdd-4043-b049-cdb1001a09b9	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 2 8goby0z7	82000	250000	5	\N	\N	\N	2026-03-24 00:47:07.432+00
00e41195-f19a-4585-86ff-3c0b18dbed99	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 3 jtt5kuj0	83000	250000	6	\N	\N	\N	2026-03-24 00:47:07.802+00
913ce146-fe5f-491b-9157-bfbc14fd4872	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 3 wr5mk66b	83000	250000	6	\N	\N	\N	2026-03-24 00:47:07.828+00
05f281c0-d6a2-4325-84a6-2cb09784b2d9	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 3 s6huthaz	83000	250000	6	\N	\N	\N	2026-03-24 00:47:08.34+00
63383d70-7e20-4458-b89b-a188c9fc0171	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 3 68uxq40h	83000	250000	6	\N	\N	\N	2026-03-24 00:47:08.429+00
84caadac-4f3c-4b19-8eba-5268b44afc98	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 4 fofyhufq	84000	250000	7	\N	\N	\N	2026-03-24 00:47:09.839+00
6bfa7e21-73c0-4a3d-b4f6-b6d2c57eb33a	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 5 jwfw9q13	85000	250000	3	\N	\N	\N	2026-03-24 00:47:10.255+00
81b81158-02c1-4b40-83ce-d79da0b065e6	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 5 6gm0bp2g	85000	250000	3	\N	\N	\N	2026-03-24 00:47:10.268+00
2508bc1e-d39f-4ed8-85b5-aa1c0f36069b	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 5 r2ewmcgl	85000	250000	3	\N	\N	\N	2026-03-24 00:47:11.441+00
bf5711ae-98b0-4b57-986b-b965042a91c7	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 5 ftz6xztq	85000	250000	3	\N	\N	\N	2026-03-24 00:47:11.664+00
8bda4bbc-914c-4b75-be11-2e34042da1c8	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 6 fe48qtei	86000	250000	4	\N	\N	\N	2026-03-24 00:47:12.453+00
1d6ba9ca-d6a6-4f3f-a093-0aa76771d9da	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 6 jl3zqvop	86000	250000	4	\N	\N	\N	2026-03-24 00:47:14.031+00
dbde9f03-ede1-4ad1-b1a6-c73b2b88d974	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 7 ma51xmfh	87000	250000	5	\N	\N	\N	2026-03-24 00:47:14.495+00
c17af24a-0782-4a73-a55c-cb4081664f8c	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 7 ym0v5dmq	87000	250000	5	\N	\N	\N	2026-03-24 00:47:14.715+00
55d2b835-fe1e-4d41-abfe-da2961a339c3	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 9 1zzf22c5	89000	250000	7	\N	\N	\N	2026-03-24 00:47:16.472+00
e9102564-4fc6-42f4-addb-d565e338ae8f	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 10 obot6n6z	80000	250000	3	\N	\N	\N	2026-03-24 00:47:17.008+00
f1f06392-aec6-4fd4-b6c5-377cb07ad945	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 10 jkj2f0q8	80000	250000	3	\N	\N	\N	2026-03-24 00:47:17.038+00
7ebcf09c-0f37-474b-93c4-792e5e38a6ad	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 11 80g0hsxm	81000	250000	4	\N	\N	\N	2026-03-24 00:47:17.64+00
a839db68-9828-4055-9380-748b76e01ab8	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 11 a03astno	81000	250000	4	\N	\N	\N	2026-03-24 00:47:18.098+00
525267ea-e0ce-4302-909d-04736d07447e	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 13 y2tm9p1g	83000	250000	6	\N	\N	\N	2026-03-24 00:47:19.462+00
2d649952-dbc8-4579-962b-1c78130cea69	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 12 guial701	82000	250000	5	\N	\N	\N	2026-03-24 00:47:19.467+00
5f3b86ba-9f0f-4740-9a9d-332bd85694a0	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 14 dv41w510	84000	250000	7	\N	\N	\N	2026-03-24 00:47:20.833+00
6712373f-dda3-4046-8dce-b228b26c4062	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 15 e2b4nb1m	85000	250000	3	\N	\N	\N	2026-03-24 00:47:25.606+00
143f25c3-d20f-4d45-8e1e-7ceb715579e3	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 14 iiqexf7y	84000	250000	7	\N	\N	\N	2026-03-24 00:47:26.88+00
be4e8896-11f1-4958-a511-9af49caa421c	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 17 nuc01p6r	87000	250000	5	\N	\N	\N	2026-03-24 00:47:30.157+00
80d49832-9c0b-47d3-a72b-89554a47a8ce	2089d278-bdf5-4cbf-871d-74c319bc81f1	k6 search 19 sd8emqwa	89000	250000	7	\N	\N	\N	2026-03-24 00:47:30.231+00
e98500c7-2355-47e3-b44b-bc49b121f69e	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:47.33+00
3da09f98-5b70-4acc-bc47-751e9f89c6d8	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:48.005+00
d206fdc4-6123-4e20-94bd-bd54c834f243	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:48.047+00
9a29f54e-4ab6-4f26-b535-2071af09c522	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:48.766+00
22d07f5a-af11-4719-ab71-8bde73d92bc7	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:50.115+00
ea3fe6da-c269-4772-b29e-c04b6ba71399	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:50.811+00
93df895c-9ea0-4d40-8d36-12d3e8fffd1d	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:51.502+00
66380292-fd86-42cf-8a19-3219dd7d2e27	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:52.161+00
6e8dc931-5d20-46a4-9bb2-83d89540ef51	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:52.842+00
177e6512-1cd1-479f-bf72-9f0f0aa28efa	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:54.472+00
ef9f97fe-efc4-43aa-9e82-53760ee2955e	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:55.161+00
52b22033-5f3f-418b-875d-3dfba749c4be	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:55.879+00
7fe78ed7-6983-446b-babd-d84ab67b1500	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:55.884+00
7beb779c-05af-44e0-88b3-fbdc08ab23c4	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:56.57+00
58e1c6f2-4690-4f69-a114-1aab9be3084b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 0 b3jkrfmd	80000	250000	3	\N	\N	\N	2026-03-25 16:40:02.853+00
dc023caa-8aaa-403d-8090-98381861769f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 0 pi2tq2hn	80000	250000	3	\N	\N	\N	2026-03-25 16:40:02.867+00
b0e816a3-9246-40d0-b8ae-af0d311859ea	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 1 nzg2vpn7	81000	250000	4	\N	\N	\N	2026-03-25 16:40:03.89+00
b09c25b7-3ecd-4a59-8a3e-ceea4b418e4c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 2 kw7rm362	82000	250000	5	\N	\N	\N	2026-03-25 16:40:04.648+00
8d3b3421-6fc6-4688-b094-b0ae53a327d2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 3 8u30svba	83000	250000	6	\N	\N	\N	2026-03-25 16:40:05.218+00
98f543d8-4cf1-47df-9c68-e16d41e34084	b96c6ed5-209f-40dd-b1ed-80343789e241	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-24 00:48:16.248+00
09403753-0175-4c95-bc04-8c9a45cff1c9	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:44.623+00
1b32adb5-0fd0-4a36-a4f9-d5e4d03aa3f5	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:44.632+00
8f8809d9-374b-46eb-9308-232fecfc9563	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:44.63+00
9e6534ca-bc39-4ccb-a66b-e79133ed765a	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:45.656+00
15395440-54b0-4761-aa5b-056838f0429b	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:45.66+00
5bfcaac5-de64-4bae-8a49-c493cfe9c20b	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:45.663+00
d31dbccc-568f-4d49-944f-4157e2cc1da3	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:46.36+00
1a700adf-9a0a-40b6-a240-b9f8739a6e2e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:46.363+00
2674ff91-db09-4e1a-a87e-cddce3e37f32	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:46.365+00
c06b3d35-4171-4590-8de2-81c4522fd5d7	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:46.982+00
fd253d39-3ce5-49e5-b572-31588802145e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:47.018+00
ac176d8d-3196-4b97-8095-4393846e3e6d	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:47.021+00
00ecc738-3161-4ab9-b172-c7ed1a8e4a90	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:47.741+00
c9af17d1-600a-413f-abdf-baface222837	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:47.84+00
c37f4fc3-9e04-4e21-a365-a125d2c6896d	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:47.843+00
93963978-6c1f-4149-ab8d-eab022e0fcf0	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:48.539+00
282084e1-9d9a-4a7d-b750-5ee0ec5a97d4	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:49.663+00
ae410761-b4cb-4eec-b114-0d75212814da	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:49.691+00
4da153ab-a8e1-43c3-aade-cba752f804b7	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:49.744+00
e7d6f112-ed02-4981-bf6e-3336b5d53797	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:50.384+00
90f6d6e2-e947-4854-861d-2dba2c388f3c	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:50.49+00
4ab82f99-4689-4b07-bc16-920f23e6f2d6	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:50.512+00
773cd5d6-2546-4c38-9af5-e9ed0ce5db0b	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:51.702+00
51fdd9b2-8929-42c8-82d0-2291a0110f64	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:51.915+00
0c9b8f42-a174-4ec3-b837-fc3022f652ad	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:51.916+00
9c082f86-6f4f-44de-8d2f-f6fc20f874a1	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:52.287+00
21e9f75f-f9b4-446e-8fa4-4b1f34151d6c	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:52.539+00
55d8e5f2-4197-4063-ae2b-7f391653da9a	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:52.542+00
7582a733-87b1-45b2-b44c-c7781d7c5ff7	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:52.951+00
ff75a3cb-0035-42a8-8bb1-556bfdc878d4	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:53.153+00
33bc74c6-b1b3-400d-8049-e3b85d1aee33	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:53.155+00
f75e5dfe-6c7d-4da9-b458-1696c5bf12d5	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:53.534+00
8e166968-7b0b-40f9-90cf-b4421500316d	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:53.764+00
a383d818-2c82-46cf-a96f-4ba5744ba10a	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:53.766+00
4c5c2962-35aa-4c6f-86f0-756cfd9f30d2	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:54.139+00
e8f69fa0-a3af-407b-993f-147d04c2b4fd	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:54.597+00
4f102c5f-5bc7-49f0-8772-b717dc5e929c	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:54.599+00
88dd7624-751b-4227-9ac0-5413623ff9c0	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:55.105+00
0169204f-2986-4c60-ac60-17c50da5228e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:55.245+00
7a9c4a26-6fc8-45ca-b57f-b3c5d62631b2	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:55.246+00
2e7d940f-95fb-4194-bda5-6197e5739ec1	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:55.689+00
30c13120-db49-40ed-99b0-27570574c6b9	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:55.872+00
8d5e290a-d54a-4567-85c1-40fd2d329d99	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:55.874+00
32820b29-ba95-4e4a-9fb5-6bde9efabf93	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:56.285+00
cc249468-1d67-4bbe-8e13-8d84e8948516	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:56.471+00
c9b5a0ac-6355-4b37-904f-99da562d915e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:56.473+00
839e399f-1248-4432-91ca-2285375f39d8	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:56.874+00
6834af72-39be-43f1-8e95-7e7ab7504268	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:57.11+00
12188388-6960-402e-9240-8be879c778a6	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:57.112+00
e6f2d778-c247-4eab-9250-135188259c6e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:57.471+00
d0804e99-eeed-489e-8ee2-a00f2f569763	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:57.737+00
0b85393b-7957-4c70-a69a-4d7b559f2b87	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:57.824+00
a4c05bef-0cd8-4806-aa4e-ba004a978730	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:58.07+00
5f752c43-5cc8-480d-bc98-d14e160d665f	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:58.359+00
915e552c-793d-40c4-87b3-333108793f8c	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:58.412+00
440b67bb-5ba8-4d6a-a085-759ad6f8211c	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:58.737+00
9a4b9097-66c0-4b06-87c7-0473066384af	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:58.972+00
b103c470-de03-4694-a274-f2d358f191a7	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:59.019+00
a03a3541-bec3-4173-8b7d-e1ed6fef0068	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:59.347+00
ae83cc06-5bae-4521-93c3-04d50258c064	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:59.586+00
8d2c12df-65b0-4076-9f27-495ad803a155	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:59.648+00
552b70e7-d9b8-4fc0-a71d-2eb062decc77	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:40:59.955+00
9fa14851-27f2-4463-a3c4-a49de229fdab	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:00.23+00
f4d29f8a-28ac-4479-8591-73c3deb9b0a8	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:00.313+00
6cc4bed9-6070-4d38-afe8-2a4748019083	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:00.585+00
1164c7c4-2a13-4346-9ab9-253a85cd9971	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:01.046+00
9e851c67-fc63-4054-9d2d-960c52d8a6d9	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:01.132+00
0210da85-3de4-425f-b77c-d231d67adb01	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:01.336+00
2c4090a5-2291-4352-9fb1-d0f31787fe05	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:01.651+00
a1c56c8a-f26a-45c1-9863-2c8bf60f1278	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:01.728+00
1ea830ce-ba0d-418f-b1ef-f2900c0c407e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:01.925+00
01622c30-9913-490e-b809-55862266e760	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:02.311+00
3b20cb8f-c96c-40ad-94af-bf408545701d	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:02.369+00
e19bd30d-3f35-448a-9812-96387bfea602	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:02.524+00
9a5e5a68-d2c6-41eb-9eef-69033041c609	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:02.944+00
58370b4f-5d01-4c6a-a8bc-3229240a1ed8	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:03.062+00
e8babfd6-1589-47cb-9d2f-28ef3aeacca3	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:03.121+00
0043c760-45cd-4e4f-8156-388607b8697e	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:03.546+00
aa6aec98-7000-452c-85fc-0cf80a7c06c1	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:03.734+00
d6c7644d-e50d-49b6-b9c3-c167c132c6dc	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:03.76+00
205ff530-07e6-4b65-bad5-4b00ec065657	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:04.96+00
6a44639f-99d2-4a81-8cde-7655256d3eea	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:05.615+00
0154fb04-05eb-4a98-a54d-b54b0862d40f	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:06.237+00
1790fa1b-cb90-4c40-987c-70c80d2eaa32	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:06.443+00
293057ec-f18b-44c4-83fd-4f019ab0fc62	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:06.539+00
9d3f7e31-aca4-476c-8aca-77deff591052	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:06.891+00
b36dfee0-e608-428d-aa73-8f20e0f2c7fb	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:07.026+00
17f44a60-8efa-4fd6-8b9e-2351e92c54e2	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:07.133+00
ead25f2a-20c2-4d52-a2c3-e01777e31208	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:07.474+00
62da1393-26a9-43f0-bc3e-c3e807e0f201	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:07.607+00
fe45def1-8381-43a2-8d1f-c4b12a22e2ff	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:07.72+00
80f8e5cb-8032-411b-a8d7-f5ca7dc29799	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:08.063+00
6bdab233-7e0f-43c0-87e9-03e7f24aa920	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:08.202+00
478bc315-f811-4c3b-a802-2c49e9685052	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:08.317+00
68477428-aafe-454b-9c2e-46dc3819a4b8	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:08.657+00
f549bd37-4b9f-4648-a64a-2bab874a24b9	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:08.827+00
cd91fd90-0b48-46f6-94e5-5b80e04888d2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 0 9vlclbrb	80000	250000	3	\N	\N	\N	2026-03-24 03:41:45.146+00
cd94e7ba-8f55-487f-94b3-f98b1ece1c8b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 0 ltszrpkq	80000	250000	3	\N	\N	\N	2026-03-24 03:41:45.156+00
bc4ce737-c276-4096-8427-0d34aa0d15ad	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 1 7kosiqnj	81000	250000	4	\N	\N	\N	2026-03-24 03:41:45.948+00
ed40ac58-ad64-4564-9167-e92320ad446d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 1 r4c1hfcu	81000	250000	4	\N	\N	\N	2026-03-24 03:41:46.041+00
ed8d2afa-e638-4a5a-9cf7-c51ce88e890b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 3 59dg4j5m	83000	250000	6	\N	\N	\N	2026-03-24 03:41:46.822+00
e2e07bfe-e829-41ef-a56d-04bbd1570f7f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 3 oyqyewak	83000	250000	6	\N	\N	\N	2026-03-24 03:41:46.984+00
7bc125b5-1c26-4088-b13e-c7959ec11046	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 3 150sauwj	83000	250000	6	\N	\N	\N	2026-03-24 03:41:47.082+00
dee67fdc-b216-4228-94e3-3651cc15449b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 3 oydir250	83000	250000	6	\N	\N	\N	2026-03-24 03:41:47.181+00
d2639f3a-1c8d-4ccd-8e05-8023d78ff564	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 5 l8j2vaph	85000	250000	3	\N	\N	\N	2026-03-24 03:41:48.11+00
aa24cdef-c01f-47d8-9753-14bfc16464bb	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 5 ld9gvpxs	85000	250000	3	\N	\N	\N	2026-03-24 03:41:48.44+00
5efcac64-d36f-43aa-a72a-214189394808	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 5 aw608ogv	85000	250000	3	\N	\N	\N	2026-03-24 03:41:48.54+00
52cc58cc-0669-46bd-a047-abf608a315b4	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 6 oj8vt96w	86000	250000	4	\N	\N	\N	2026-03-24 03:41:48.896+00
0525ead3-47ed-4d3a-8bdc-f4fd3ae6ab32	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 6 d8q7rhd4	86000	250000	4	\N	\N	\N	2026-03-24 03:41:49.064+00
b4b76b66-45e6-47bd-b444-a43842b52ee3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 6 vj8qfa5n	86000	250000	4	\N	\N	\N	2026-03-24 03:41:49.13+00
8b0aaf22-d960-4215-bf5a-394a9a7612d3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 7 wn83wcg4	87000	250000	5	\N	\N	\N	2026-03-24 03:41:49.137+00
14b44578-86eb-4178-ab38-a0760594aa9f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 9 xfsvgmkh	89000	250000	7	\N	\N	\N	2026-03-24 03:41:50.208+00
623e07e4-c740-4e3a-9904-64efa6c5ff35	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 9 rwtytao4	89000	250000	7	\N	\N	\N	2026-03-24 03:41:50.313+00
0e8e9544-f5f2-46a8-a399-35fc6866b8e9	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 9 rmrwwauq	89000	250000	7	\N	\N	\N	2026-03-24 03:41:51.382+00
4704fe09-69a4-4b9d-966c-25eca75ba526	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 10 vtwb1rbp	80000	250000	3	\N	\N	\N	2026-03-24 03:41:51.582+00
3185f093-14e3-4bb7-9f12-fce5d56edc9d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 10 swrb6i1q	80000	250000	3	\N	\N	\N	2026-03-24 03:41:51.612+00
c4d9759a-1300-46f5-b061-ea52972ddf54	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 10 i461sqwp	80000	250000	3	\N	\N	\N	2026-03-24 03:41:51.686+00
a50efd72-c40a-431a-a602-541aa02056b4	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 11 5kqqtrdk	81000	250000	4	\N	\N	\N	2026-03-24 03:41:52.11+00
ae170760-111c-42ae-b39e-20556d7fcdc6	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 12 1svprg7s	82000	250000	5	\N	\N	\N	2026-03-24 03:41:52.639+00
4cb97d6f-a4ab-43ba-a67f-b214ad34c398	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 12 m654kom3	82000	250000	5	\N	\N	\N	2026-03-24 03:41:52.745+00
3a6e2934-90e3-4e48-b3c5-15de929d38a5	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 12 1spibqnz	82000	250000	5	\N	\N	\N	2026-03-24 03:41:52.784+00
0ad80d9f-5053-4b98-b393-cecfbb6ba6f0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 13 sek933gj	83000	250000	6	\N	\N	\N	2026-03-24 03:41:53.11+00
f0960e85-b069-4a1f-acc5-30b9b0fff390	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 12 kbj3ci6p	82000	250000	5	\N	\N	\N	2026-03-24 03:41:53.13+00
9f3dab59-915e-49e3-aa7b-745d1a7f969f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 13 1w1ilqls	83000	250000	6	\N	\N	\N	2026-03-24 03:41:53.328+00
d1e41548-fbbf-435b-85d9-8e3979d101ad	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 13 s9m46ld8	83000	250000	6	\N	\N	\N	2026-03-24 03:41:53.349+00
c5861074-ed62-469b-8254-d20f650fdc61	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 14 dmyo020k	84000	250000	7	\N	\N	\N	2026-03-24 03:41:53.946+00
f5c4613d-fec0-4f93-a369-1279e1d335cd	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 14 uyod2xvm	84000	250000	7	\N	\N	\N	2026-03-24 03:41:54.087+00
725c96ce-2eff-4684-9571-30c52788cf64	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 15 79qwklf5	85000	250000	3	\N	\N	\N	2026-03-24 03:41:54.463+00
0a038e4a-22a3-485e-9083-54aad36f1aac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 15 ug433nw6	85000	250000	3	\N	\N	\N	2026-03-24 03:41:54.5+00
9bf30568-06b1-45d0-8f16-7f71f41f5ebd	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 15 0qxy80vc	85000	250000	3	\N	\N	\N	2026-03-24 03:41:54.543+00
a7afb97e-71f0-4ab3-9d8a-5dda3f9e7dcc	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 16 s9z5djfk	86000	250000	4	\N	\N	\N	2026-03-24 03:41:54.659+00
cf32f95f-660f-4339-9c05-11830cc7398d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 16 9qroq92b	86000	250000	4	\N	\N	\N	2026-03-24 03:41:54.926+00
b6d2238e-0080-4d87-b97e-3d494812d047	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 16 7ho6pi9k	86000	250000	4	\N	\N	\N	2026-03-24 03:41:55.003+00
da27e602-4bae-45a1-83de-b9c24cc5028e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 17 07ik0fyj	87000	250000	5	\N	\N	\N	2026-03-24 03:41:55.222+00
33174597-34c2-48f9-841a-3ad5ec940880	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 16 6vvf02ml	86000	250000	4	\N	\N	\N	2026-03-24 03:41:55.224+00
c7d36953-4fcb-4a32-9673-1ea3283a6c5a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 18 nzg6vgs2	88000	250000	6	\N	\N	\N	2026-03-24 03:41:56.211+00
8323bf71-9166-4b22-bc6f-93416508371d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 18 dgv56ge6	88000	250000	6	\N	\N	\N	2026-03-24 03:41:56.453+00
85d40c07-5138-4a91-a30f-fb3fb57d6092	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 19 v7rasnpd	89000	250000	7	\N	\N	\N	2026-03-24 03:41:56.55+00
6cace400-f9f7-4e12-8fe9-f47ed0f2ac38	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 19 qum3fe1v	89000	250000	7	\N	\N	\N	2026-03-24 03:41:56.681+00
bd12223d-897d-4f09-bc9e-1c013558cca6	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 20 pi647fwk	80000	250000	3	\N	\N	\N	2026-03-24 03:41:57.177+00
585168e1-66eb-46cc-8daa-699f3cc677aa	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 22 fb5qx5d9	82000	250000	5	\N	\N	\N	2026-03-24 03:41:58.182+00
2b100e5c-9e56-4424-8e6f-ffdf8d087705	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 22 7bslksjp	82000	250000	5	\N	\N	\N	2026-03-24 03:41:58.208+00
f74e0528-2aea-4969-94f6-4858d1e8ea5e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 23 zp7653p8	83000	250000	6	\N	\N	\N	2026-03-24 03:41:58.541+00
138118d3-2f83-4dcc-be9b-38bc8451b5cd	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 23 i318m1dz	83000	250000	6	\N	\N	\N	2026-03-24 03:41:58.719+00
42efd46b-d4d1-42a9-a0a6-fbfedbd00e40	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 23 rcju2vud	83000	250000	6	\N	\N	\N	2026-03-24 03:41:58.763+00
4f8fe0d8-faea-4517-be90-59c3728087df	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:04.151+00
02d16aef-25d0-4223-971c-d32995c9da29	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:04.345+00
e0b386a6-14e4-446b-a466-dac2c5757b0b	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:04.355+00
6dda8e87-7f30-4514-859f-14585ad6acf5	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:04.784+00
c2b42209-7430-4ccc-914d-67b4124da7d2	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:04.958+00
db0eee59-fc97-4965-9b91-70b003c3595f	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:05.409+00
466aacf8-de97-4683-bf05-3c880e8a7192	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:05.708+00
3ce51d6a-b28c-4164-970f-19c2e81b9b9a	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:08.911+00
1f662437-fd15-4dd1-993a-52c2865a1067	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:09.277+00
9b4d9b79-4937-4467-82cc-947a7f85fd46	698187d0-a03d-4e91-bc59-fafd35e4741b	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 03:41:09.532+00
7634e1d0-30b9-484f-80e1-895fc851613c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 0 junlfyw3	80000	250000	3	\N	\N	\N	2026-03-24 03:41:45.143+00
9a3322f7-96fc-49f6-aa6a-78888f33eaa1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 0 2yghe5j2	80000	250000	3	\N	\N	\N	2026-03-24 03:41:45.158+00
6571d434-1cee-404b-ad81-35347c163fad	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 0 tec5ch0s	80000	250000	3	\N	\N	\N	2026-03-24 03:41:45.17+00
1aa60be1-04cd-43f5-b1aa-2e001e030ce8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 0 azqshzz5	80000	250000	3	\N	\N	\N	2026-03-24 03:41:45.21+00
00a9a49a-b429-496f-8178-5f1da6c75457	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 1 ajnqnt82	81000	250000	4	\N	\N	\N	2026-03-24 03:41:45.86+00
588c08f9-3431-41cf-b5af-8a9d403a51fe	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 1 nba0jwqm	81000	250000	4	\N	\N	\N	2026-03-24 03:41:45.889+00
d3386614-3bb7-40f0-af6f-5fb9d62a3c21	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 1 ielatukh	81000	250000	4	\N	\N	\N	2026-03-24 03:41:45.937+00
27af3085-bb22-4129-b616-b0c3deaec73d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 1 1wi1ymf6	81000	250000	4	\N	\N	\N	2026-03-24 03:41:45.946+00
4ff7afd3-19d2-4415-8aac-1cbff92370b8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 2 57vnmr7c	82000	250000	5	\N	\N	\N	2026-03-24 03:41:46.381+00
8bcca325-f49b-40c6-82d0-5fa5d758813f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 2 luse51dy	82000	250000	5	\N	\N	\N	2026-03-24 03:41:46.434+00
ea6c3391-f37b-4130-aa4a-8a1122b2668d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 2 xy436vqa	82000	250000	5	\N	\N	\N	2026-03-24 03:41:46.515+00
b7cba205-8a33-4256-9e8d-d03fa44a7ab8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 2 maieklxb	82000	250000	5	\N	\N	\N	2026-03-24 03:41:46.523+00
5f1c5bcc-5c39-4042-95c3-dfbaf81a05b0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 2 ded39c7o	82000	250000	5	\N	\N	\N	2026-03-24 03:41:46.58+00
40708750-8044-4780-acf1-16db990f9e23	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 4 bkgt3kgp	84000	250000	7	\N	\N	\N	2026-03-24 03:41:47.59+00
12a54c3f-5340-44d7-b68f-967ed48f167c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 4 1887vil6	84000	250000	7	\N	\N	\N	2026-03-24 03:41:47.927+00
16c4e77c-9975-47df-854a-1cac5c16b241	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 4 vs57rnqz	84000	250000	7	\N	\N	\N	2026-03-24 03:41:47.95+00
8806322b-6d44-4380-aeb6-e1852d0118ef	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 4 dskk2vu9	84000	250000	7	\N	\N	\N	2026-03-24 03:41:48.01+00
0ed0d71d-4c73-405f-b0bb-946240ea956c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 4 kepts2hh	84000	250000	7	\N	\N	\N	2026-03-24 03:41:48.017+00
9c3992cd-99ee-42a1-a435-84b7ceaa54d4	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 5 jkrskuk6	85000	250000	3	\N	\N	\N	2026-03-24 03:41:48.441+00
112fa829-196d-47b8-a513-4993d4e73980	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 6 ui72chw4	86000	250000	4	\N	\N	\N	2026-03-24 03:41:48.617+00
30124912-1743-47fd-948b-47ce8f7661ff	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 7 vl79fypc	87000	250000	5	\N	\N	\N	2026-03-24 03:41:49.328+00
9f99e86b-a21b-4399-909b-e1c651469596	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 7 qk9s35eu	87000	250000	5	\N	\N	\N	2026-03-24 03:41:49.619+00
a52ba0f7-244c-4626-96d5-5312c71995d2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 8 cc8urli4	88000	250000	6	\N	\N	\N	2026-03-24 03:41:49.762+00
5974e295-b139-4fba-8f48-6756d422d367	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 8 9i639z24	88000	250000	6	\N	\N	\N	2026-03-24 03:41:49.817+00
fd9b7740-7310-4367-9cc1-f7dc92b0f39c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 8 cl9234t6	88000	250000	6	\N	\N	\N	2026-03-24 03:41:50.182+00
e6e09807-0dfb-4b40-bd93-7a01ab998efe	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 10 0tb632sa	80000	250000	3	\N	\N	\N	2026-03-24 03:41:51.407+00
47eb9f02-78c2-4d61-baec-4cd8a3ec3a7b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 11 m0twnr56	81000	250000	4	\N	\N	\N	2026-03-24 03:41:52.268+00
d9248839-a6ea-4535-8672-d16754ef0845	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 11 kr6gtg1d	81000	250000	4	\N	\N	\N	2026-03-24 03:41:52.641+00
87b934f0-dcc1-48f7-966a-7093ba59b244	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 12 3pzj28za	82000	250000	5	\N	\N	\N	2026-03-24 03:41:52.811+00
d41a71d9-2452-43c7-8d5d-aa94302e9863	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 14 318a7hbt	84000	250000	7	\N	\N	\N	2026-03-24 03:41:53.598+00
3d96c953-e208-4260-beef-668c4d4224fa	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 14 08043mjw	84000	250000	7	\N	\N	\N	2026-03-24 03:41:53.941+00
657ee1ec-29f8-4887-b7fc-080832f4bdc0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 14 naipudc4	84000	250000	7	\N	\N	\N	2026-03-24 03:41:53.945+00
1630dc40-8101-4200-89fd-c8eb5e0a8291	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 15 ye7wq9bt	85000	250000	3	\N	\N	\N	2026-03-24 03:41:54.544+00
8f492b9b-7873-4014-9bee-cabbdd49da6b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 15 i0qckqxi	85000	250000	3	\N	\N	\N	2026-03-24 03:41:54.681+00
e86450d5-c796-4882-b582-00640adb4b35	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 16 0ccz540n	86000	250000	4	\N	\N	\N	2026-03-24 03:41:55.054+00
fa2ea8ba-e544-463d-8a95-44d8b52dee87	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 17 sohibav4	87000	250000	5	\N	\N	\N	2026-03-24 03:41:55.783+00
7887915b-e63b-44b3-982d-6b1b6f96c320	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 18 i67ocsa9	88000	250000	6	\N	\N	\N	2026-03-24 03:41:55.807+00
ce3bedd5-e260-4fcf-b507-9f7b476e3d36	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 18 gsbx5g4r	88000	250000	6	\N	\N	\N	2026-03-24 03:41:56.184+00
2746ee45-7bfe-4703-8fcc-e7de9d5c3d8d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 19 t0onogyh	89000	250000	7	\N	\N	\N	2026-03-24 03:41:56.45+00
15c446c9-f4d5-468a-abc5-d0aeef5a0806	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 19 4uzt31gg	89000	250000	7	\N	\N	\N	2026-03-24 03:41:56.665+00
3f5247f2-39b9-4e2f-88b0-bc3f606815fa	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 19 7rgkckvk	89000	250000	7	\N	\N	\N	2026-03-24 03:41:56.994+00
77cc5803-49c7-4192-b02c-b3a443856313	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 20 5r9c4nn6	80000	250000	3	\N	\N	\N	2026-03-24 03:41:57.077+00
8fbd01a9-6961-4f48-ae72-cdb4c2136d11	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 21 zx39n9j0	81000	250000	4	\N	\N	\N	2026-03-24 03:41:57.514+00
cad5498f-5756-4e2c-bfa9-76ed83604769	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 21 vce2wpzb	81000	250000	4	\N	\N	\N	2026-03-24 03:41:57.619+00
de97b6cc-847e-49df-82fc-59fd17aa27cd	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 21 zppimrfv	81000	250000	4	\N	\N	\N	2026-03-24 03:41:57.624+00
869403f1-634d-477d-b539-39c66ef9b62c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 21 b7ehmojc	81000	250000	4	\N	\N	\N	2026-03-24 03:41:57.712+00
ba620722-69ed-49f7-8166-2b0ff94f922c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 21 sfprh21k	81000	250000	4	\N	\N	\N	2026-03-24 03:41:57.973+00
93e53b2d-740c-43e4-96b2-8ef565c717c1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 22 hs5vht2r	82000	250000	5	\N	\N	\N	2026-03-24 03:41:57.999+00
6954b945-14bc-4c72-8537-e5e5956245f4	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 22 vzvmrw1l	82000	250000	5	\N	\N	\N	2026-03-24 03:41:58.144+00
246da2c5-65e7-432f-bc8e-7a8a4b145823	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 22 mktic6tw	82000	250000	5	\N	\N	\N	2026-03-24 03:41:58.241+00
f154857f-9cda-42e6-902c-58f6d67058e0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 24 5tnfub9o	84000	250000	7	\N	\N	\N	2026-03-24 03:41:59.258+00
f8061de5-b3e3-4b07-a068-5ce0228a1f67	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 24 3qjylmnh	84000	250000	7	\N	\N	\N	2026-03-24 03:41:59.273+00
5f0058e4-6893-4910-a63c-e7f215f9173d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 25 11u9dixo	85000	250000	3	\N	\N	\N	2026-03-24 03:41:59.51+00
74220850-6776-4747-81ce-c0b9ba98bea7	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 25 bbsdljjl	85000	250000	3	\N	\N	\N	2026-03-24 03:41:59.9+00
4b402d41-0b7e-4041-8eec-c09664857e43	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 26 p8t3cirl	86000	250000	4	\N	\N	\N	2026-03-24 03:42:00.112+00
c52f541a-778b-481c-acfe-013b4c806140	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 26 zh86o80p	86000	250000	4	\N	\N	\N	2026-03-24 03:42:00.809+00
8ccfbb25-bf53-4eec-a91d-4ce83f05ac14	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 29 6aqr3b4c	89000	250000	7	\N	\N	\N	2026-03-24 03:42:02.116+00
154ec0ff-9739-4cd2-b5d2-6c4feac4541f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 29 pu2rqnwx	89000	250000	7	\N	\N	\N	2026-03-24 03:42:02.332+00
06f0174b-1e1c-4454-b28d-cd116f832d25	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 29 djfhvq6u	89000	250000	7	\N	\N	\N	2026-03-24 03:42:02.483+00
c13ae95e-89bb-4b2c-a2ee-91fb3bbdb9ca	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 31 sj2r2q93	81000	250000	4	\N	\N	\N	2026-03-24 03:42:03.068+00
ab68bcc6-5324-4ecb-9c59-ad8c0ba34b29	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 31 u5ie3q1d	81000	250000	4	\N	\N	\N	2026-03-24 03:42:03.133+00
d84dd219-5600-4e59-831f-7d810499f8d5	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 2 5amcvi02	82000	250000	5	\N	\N	\N	2026-03-24 03:41:46.525+00
e0261481-205f-4585-a2c3-066bfdc0cc22	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 3 gn4lwson	83000	250000	6	\N	\N	\N	2026-03-24 03:41:47.107+00
9b262134-4f2d-46c9-b503-427ab85eb215	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 3 94pp9d3e	83000	250000	6	\N	\N	\N	2026-03-24 03:41:47.114+00
9f20998f-561e-4e3d-a20e-c35e3380421d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 4 tgk2m13e	84000	250000	7	\N	\N	\N	2026-03-24 03:41:47.381+00
935355ff-8cc4-43d6-b395-c610f3fc8344	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 5 9kovw7ix	85000	250000	3	\N	\N	\N	2026-03-24 03:41:48.081+00
f7a4038c-22b2-45c5-b6be-aa871547908a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 5 efepkmxa	85000	250000	3	\N	\N	\N	2026-03-24 03:41:48.568+00
42c10d17-2409-4ad8-892c-f9ecd0a0868a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 6 8olr4ojn	86000	250000	4	\N	\N	\N	2026-03-24 03:41:48.619+00
5286e18f-1bde-401e-a63c-0ce0c1cca49b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 6 0914it0z	86000	250000	4	\N	\N	\N	2026-03-24 03:41:48.894+00
b69b41ed-0718-4678-8639-7b888ab71feb	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 7 kn89jopi	87000	250000	5	\N	\N	\N	2026-03-24 03:41:49.166+00
7b20aa42-4313-4419-8ce9-51ec497f675b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 7 9sgs5yly	87000	250000	5	\N	\N	\N	2026-03-24 03:41:49.33+00
6c66f39a-cee4-4471-9130-720d86629c58	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 7 2seuny3d	87000	250000	5	\N	\N	\N	2026-03-24 03:41:49.51+00
660c5ae1-0361-4b4f-8de4-8d5028158dcd	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 8 amutr9nh	88000	250000	6	\N	\N	\N	2026-03-24 03:41:49.615+00
20614de0-253d-4139-9c90-b70ab8efda79	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 8 ctt60043	88000	250000	6	\N	\N	\N	2026-03-24 03:41:49.618+00
5a839905-eeb3-49d4-b072-8f634208313f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 8 12gig84k	88000	250000	6	\N	\N	\N	2026-03-24 03:41:49.944+00
0496f1d7-33d2-4857-8c34-4892ea38f6c0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 9 l8txev2x	89000	250000	7	\N	\N	\N	2026-03-24 03:41:50.206+00
34a4aef5-3f1e-419a-8e9f-4d8421d4f2a7	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 9 vp2j0qm3	89000	250000	7	\N	\N	\N	2026-03-24 03:41:50.314+00
07579e67-e704-423e-be35-8ea58c24d855	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 9 dq4z0yhd	89000	250000	7	\N	\N	\N	2026-03-24 03:41:50.416+00
8c795606-2c6b-4180-b102-bc0f1497e85e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 10 v5szewn1	80000	250000	3	\N	\N	\N	2026-03-24 03:41:51.41+00
8bf41c44-625b-4e45-9938-2c783bb37dd7	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 10 pgs7lx02	80000	250000	3	\N	\N	\N	2026-03-24 03:41:52.109+00
4781faa8-930b-44f0-94f6-dddf47bc097d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 11 21z47uhx	81000	250000	4	\N	\N	\N	2026-03-24 03:41:52.157+00
e7f97409-4af0-4fb6-a95a-1efb27388616	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 11 xist7c3h	81000	250000	4	\N	\N	\N	2026-03-24 03:41:52.243+00
a07101d9-cdd8-4e08-90e7-df4dd2ebd5ac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 11 8v1encmc	81000	250000	4	\N	\N	\N	2026-03-24 03:41:52.264+00
e805c27b-b653-413d-80c8-63a6128757a4	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 12 8y28311y	82000	250000	5	\N	\N	\N	2026-03-24 03:41:52.813+00
b842dc1e-3719-4792-90ad-9d84b4f4b946	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 13 bgq3dfpl	83000	250000	6	\N	\N	\N	2026-03-24 03:41:53.352+00
fd0241c2-e307-4c63-a64c-b0e7543398cf	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 13 fnw3xet7	83000	250000	6	\N	\N	\N	2026-03-24 03:41:53.359+00
6d3b7df4-dc89-480a-a525-15856fbf19bf	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 13 x9v8h5zi	83000	250000	6	\N	\N	\N	2026-03-24 03:41:53.612+00
5146a461-a13f-4e85-95bf-9627699cbe62	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 14 qv150xu2	84000	250000	7	\N	\N	\N	2026-03-24 03:41:53.943+00
0ca9d71d-d37a-424c-9e91-b907a1347f3f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 15 vd6u5tgs	85000	250000	3	\N	\N	\N	2026-03-24 03:41:54.084+00
3c352cfb-71af-4d4d-8e53-6e118aec27b1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 16 gr6ewkkx	86000	250000	4	\N	\N	\N	2026-03-24 03:41:55.08+00
99f35a2b-6335-4232-899e-fccb4faa1a86	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 17 f8ca3ya7	87000	250000	5	\N	\N	\N	2026-03-24 03:41:55.338+00
f282f069-b64d-4b36-981e-486382f35bfc	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 17 v72w9bci	87000	250000	5	\N	\N	\N	2026-03-24 03:41:55.466+00
0a170af8-6d80-4cc2-9018-566b4f87ddcd	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 17 81f1o5j5	87000	250000	5	\N	\N	\N	2026-03-24 03:41:55.552+00
c2331fda-f459-4e25-b001-240eeb864fdc	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 17 1xe6jexz	87000	250000	5	\N	\N	\N	2026-03-24 03:41:55.561+00
7d24fb10-0e6f-4b2b-a44f-0c458156d2d8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 18 x2fpmrun	88000	250000	6	\N	\N	\N	2026-03-24 03:41:55.713+00
a22a0178-f39a-4eda-a836-503cb58d6c58	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 18 ybdd2c4o	88000	250000	6	\N	\N	\N	2026-03-24 03:41:55.923+00
c1e6d8fc-cbcb-45f6-a60b-eb3d786faf5e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 19 0d7jbfee	89000	250000	7	\N	\N	\N	2026-03-24 03:41:56.595+00
f7ea1582-d472-4b1e-885e-d566ef3aceac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 20 b18frj04	80000	250000	3	\N	\N	\N	2026-03-24 03:41:56.996+00
2b1450a6-402b-4ccd-8362-680452361362	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 20 uuxqa8tj	80000	250000	3	\N	\N	\N	2026-03-24 03:41:57.079+00
054af8a1-7ddd-4c3d-8362-69c285ad0443	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 20 i0yhd0hw	80000	250000	3	\N	\N	\N	2026-03-24 03:41:57.182+00
4d9cb107-1a02-47f6-bbbd-89f40e02964f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 20 46dna4af	80000	250000	3	\N	\N	\N	2026-03-24 03:41:57.513+00
38329866-d740-4370-b22b-a95616d86ad1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 21 am13yfjp	81000	250000	4	\N	\N	\N	2026-03-24 03:41:57.71+00
ad1b7976-7a8d-49be-a940-541552861010	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 22 vs9rd4i8	82000	250000	5	\N	\N	\N	2026-03-24 03:41:58.453+00
c85ba938-dce6-4404-b582-11c209811309	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 23 52q1qq63	83000	250000	6	\N	\N	\N	2026-03-24 03:41:58.716+00
291864ad-de71-4bd5-bfb0-dcc0b35ae80e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 23 08iw1f0j	83000	250000	6	\N	\N	\N	2026-03-24 03:41:58.721+00
19426f93-2794-4dca-9533-8524e0bb8473	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 24 nfenbb3g	84000	250000	7	\N	\N	\N	2026-03-24 03:41:59.011+00
8a62a6f4-a124-42dc-8415-702dac271bbf	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 24 muwrshqq	84000	250000	7	\N	\N	\N	2026-03-24 03:41:59.256+00
4d75325f-1ece-48bd-ba4d-071236a426ee	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 24 vlvl0k4u	84000	250000	7	\N	\N	\N	2026-03-24 03:41:59.417+00
faa9abe1-efe1-4900-9f11-432d97c705b1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 25 q3if0rag	85000	250000	3	\N	\N	\N	2026-03-24 03:41:59.903+00
ace5f604-fc24-4a3f-8b9d-247a55954934	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 26 5d93bs7w	86000	250000	4	\N	\N	\N	2026-03-24 03:42:00.484+00
18898991-fd8a-42e0-aff4-f98ddafed1f2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 26 tg42zgz4	86000	250000	4	\N	\N	\N	2026-03-24 03:42:00.585+00
aaef2290-9889-49f3-84eb-298c16861058	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 26 36kpcl7l	86000	250000	4	\N	\N	\N	2026-03-24 03:42:00.608+00
239c60c7-6546-4b80-92d3-fe243bc37235	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 27 byuzgu0o	87000	250000	5	\N	\N	\N	2026-03-24 03:42:00.884+00
2d147019-3400-49e1-a695-078519e6d189	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 27 be3iibvo	87000	250000	5	\N	\N	\N	2026-03-24 03:42:01.303+00
6b3bafe2-038f-43d7-af81-2e968b7a4582	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 27 oqauswer	87000	250000	5	\N	\N	\N	2026-03-24 03:42:01.335+00
f94a0d98-34e5-4415-b91c-7b473d1f8d56	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 27 z02llsuh	87000	250000	5	\N	\N	\N	2026-03-24 03:42:01.407+00
2292bced-2a2c-4253-b69d-7caa9a508a4e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 27 krbdede9	87000	250000	5	\N	\N	\N	2026-03-24 03:42:01.538+00
6f9ff6a2-8056-4393-b9b5-7e4941cb045c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 28 d5ydytkd	88000	250000	6	\N	\N	\N	2026-03-24 03:42:01.82+00
41820624-df04-4849-9e1f-a577d4df6320	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 29 dvoz6emb	89000	250000	7	\N	\N	\N	2026-03-24 03:42:01.984+00
b695e240-c090-4980-8dc3-e81fcf07b093	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 30 v3oxwgxq	80000	250000	3	\N	\N	\N	2026-03-24 03:42:02.568+00
4140528b-8d2b-4a54-b279-77712d6ee4ac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 30 3xdo3syb	80000	250000	3	\N	\N	\N	2026-03-24 03:42:02.685+00
201c0441-5fe3-453d-b4bb-cbca3f0de3a0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 30 lw4plvaw	80000	250000	3	\N	\N	\N	2026-03-24 03:42:02.734+00
85cd5bc6-f60a-45e6-b16e-b2f62de26375	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 30 3ie6jnab	80000	250000	3	\N	\N	\N	2026-03-24 03:42:02.939+00
a88af29e-b0a0-468d-833a-82ee063db1e0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 31 o0p0easg	81000	250000	4	\N	\N	\N	2026-03-24 03:42:03.209+00
5627ba54-060d-4cfc-bb32-9340325e0597	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 32 mq6a68ot	82000	250000	5	\N	\N	\N	2026-03-24 03:42:03.41+00
9fada887-de0c-407c-a93c-bc337995161e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 32 5hirvmr2	82000	250000	5	\N	\N	\N	2026-03-24 03:42:03.826+00
ae21ee11-e50f-4631-b307-ef3fa6178204	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 32 w6zy9x6i	82000	250000	5	\N	\N	\N	2026-03-24 03:42:03.972+00
6dd6603f-b87a-432e-919a-8b0d877f6177	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 32 14kma1m7	82000	250000	5	\N	\N	\N	2026-03-24 03:42:04.02+00
12195d3c-60d2-4c13-8e4a-1f68f84c8d96	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 33 s62r2gdm	83000	250000	6	\N	\N	\N	2026-03-24 03:42:04.058+00
f86b1a55-6935-41d0-a5be-ec414f8ab513	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 33 uhuwbb27	83000	250000	6	\N	\N	\N	2026-03-24 03:42:04.228+00
9b9470c7-e7ee-461d-8dde-1d0722e5dd9f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 33 3fy5ltmb	83000	250000	6	\N	\N	\N	2026-03-24 03:42:04.587+00
13ff1b03-2316-40aa-a84a-ba0fb0c79b8a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 23 suzagtj2	83000	250000	6	\N	\N	\N	2026-03-24 03:41:58.911+00
ff7022ab-650f-4eb1-86c2-2e9433db84a8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 24 h0fkpvj7	84000	250000	7	\N	\N	\N	2026-03-24 03:41:59.254+00
ebb62fed-aa69-45d5-8a72-811c137dcd29	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 25 zt1h8vp5	85000	250000	3	\N	\N	\N	2026-03-24 03:41:59.902+00
0014fbeb-3e82-4122-baef-113b775e9376	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 25 16ofsmbx	85000	250000	3	\N	\N	\N	2026-03-24 03:41:59.905+00
fd4bd244-7fb5-4d17-8b26-91f05b6994c0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 25 2mo4d8xi	85000	250000	3	\N	\N	\N	2026-03-24 03:42:00.11+00
b6490d66-04cb-45b2-86dc-9393a63b4541	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 26 k02o8y0k	86000	250000	4	\N	\N	\N	2026-03-24 03:42:00.507+00
a01dca0d-1191-4253-8c1c-a5f6da47a251	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 27 8fwcgyd5	87000	250000	5	\N	\N	\N	2026-03-24 03:42:01.239+00
bc915df8-c3f8-45b7-88ac-eeb3d75d12b3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 28 j1h3rmnh	88000	250000	6	\N	\N	\N	2026-03-24 03:42:01.54+00
1cfc4fbf-2380-4780-92d5-7c0e50325e08	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 28 e4xrs25a	88000	250000	6	\N	\N	\N	2026-03-24 03:42:01.649+00
5394abcd-debc-457d-bff0-0a11ddae4fb2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 28 e1ljv9jl	88000	250000	6	\N	\N	\N	2026-03-24 03:42:01.716+00
901ae0b7-b0c8-4f91-ade3-f440ed28b932	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 28 hdaowiuy	88000	250000	6	\N	\N	\N	2026-03-24 03:42:01.758+00
53b4b530-10e3-4505-8dc6-9ac841c30b36	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 28 l7c0k51x	88000	250000	6	\N	\N	\N	2026-03-24 03:42:02.007+00
47372a2b-3283-4641-8a00-f9bc056e6694	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 29 zrr8vwy6	89000	250000	7	\N	\N	\N	2026-03-24 03:42:02.162+00
0fe3641d-efc3-455b-9744-809800085533	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 29 p1cb8qfe	89000	250000	7	\N	\N	\N	2026-03-24 03:42:02.223+00
35537af9-a656-41be-83c4-ea63add45d2c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 30 t4nntygj	80000	250000	3	\N	\N	\N	2026-03-24 03:42:02.481+00
180c8c5b-4b14-4f36-80a6-f980a75bb96c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 30 d3pjocek	80000	250000	3	\N	\N	\N	2026-03-24 03:42:02.614+00
2e07b30a-d11e-4f4e-80ee-5945d516b7ae	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 31 esk1g1xi	81000	250000	4	\N	\N	\N	2026-03-24 03:42:02.941+00
cb2b810d-c516-4e34-8e2e-6427e7b24495	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 31 yjz7j2kq	81000	250000	4	\N	\N	\N	2026-03-24 03:42:03.411+00
bfb8d4b6-9b89-4b6a-8d6d-5fb8543c1f63	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 32 e6xy9vaf	82000	250000	5	\N	\N	\N	2026-03-24 03:42:03.526+00
cc13b2c4-a6f0-4478-9435-deb6afdabbe3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 33 fqpep4ci	83000	250000	6	\N	\N	\N	2026-03-24 03:42:04.061+00
d3c6fa7e-7e0d-4895-ba89-1400bb9cc93f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 34 dasyid6k	84000	250000	7	\N	\N	\N	2026-03-24 03:42:04.586+00
335a9d1c-e4dc-40fa-b76b-2e6b9f11b946	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 36 zcmc1pu9	86000	250000	4	\N	\N	\N	2026-03-24 03:42:06.014+00
132f74b6-101c-426c-9871-f7ffedf26cac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 37 0krr16yk	87000	250000	5	\N	\N	\N	2026-03-24 03:42:06.65+00
526969c8-e765-434b-9d37-df0073868b5e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 37 il7o0thc	87000	250000	5	\N	\N	\N	2026-03-24 03:42:06.739+00
351a102f-5293-4000-a0d1-4a7da7e89d49	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 37 xdmq7h8o	87000	250000	5	\N	\N	\N	2026-03-24 03:42:06.754+00
2a811b08-a545-4722-af7e-ff03d78eaeaf	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 37 wto3cf6z	87000	250000	5	\N	\N	\N	2026-03-24 03:42:06.807+00
1c65ab8e-8109-4e7e-b443-a5e26cb731cc	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 38 97f7mnf3	88000	250000	6	\N	\N	\N	2026-03-24 03:42:07.177+00
5e796f17-4d8b-42ab-8511-2eecc63f831b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 38 gv70xoob	88000	250000	6	\N	\N	\N	2026-03-24 03:42:07.383+00
5c70c67c-1d91-416e-9601-f5fcb65d27bf	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 38 2mydr8s1	88000	250000	6	\N	\N	\N	2026-03-24 03:42:07.408+00
fa325bd3-6354-426e-9fe1-170e1392762b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 39 h4j2nr8y	89000	250000	7	\N	\N	\N	2026-03-24 03:42:07.663+00
3afb84d8-f760-4381-8c9d-a8db567cf01b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 38 6puoaua8	88000	250000	6	\N	\N	\N	2026-03-24 03:42:07.75+00
24596fa7-d048-414f-9729-f6c62d8c7cd2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 39 bi1m666g	89000	250000	7	\N	\N	\N	2026-03-24 03:42:07.959+00
f6a49ae6-9273-44ba-8e4b-cc76b305d65a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 40 yb8xgkpf	80000	250000	3	\N	\N	\N	2026-03-24 03:42:08.107+00
c8fced0e-f356-434d-b45f-063ef342a183	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 40 6sqskzdf	80000	250000	3	\N	\N	\N	2026-03-24 03:42:08.182+00
3d970e4c-3fea-4542-a0d8-13dcc8c6b267	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 40 clh88u2k	80000	250000	3	\N	\N	\N	2026-03-24 03:42:08.431+00
b415f717-5cf7-48b4-96bd-6df27eafefa8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 40 30ivcmyv	80000	250000	3	\N	\N	\N	2026-03-24 03:42:08.44+00
15fe92f3-1cc8-4d0e-a6cb-b684d11a5406	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 42 fjdmxlhm	82000	250000	5	\N	\N	\N	2026-03-24 03:42:09.084+00
091b9be4-143e-4c36-8835-c9ac28589718	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 42 nsol5qxc	82000	250000	5	\N	\N	\N	2026-03-24 03:42:09.367+00
9045f24d-6d22-4f4c-a906-3ad7cf9b81a5	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 43 vqnrj6pc	83000	250000	6	\N	\N	\N	2026-03-24 03:42:09.509+00
5e620847-c044-46dd-9892-9a1d0557571c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 43 ursifdzt	83000	250000	6	\N	\N	\N	2026-03-24 03:42:09.539+00
a14ec804-a15c-487d-bcf1-3a32e72503e1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 42 xrlhv0t3	82000	250000	5	\N	\N	\N	2026-03-24 03:42:09.544+00
06b6b0b6-0e8c-445c-8ad1-fccaec705c43	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 43 vlbx5h7a	83000	250000	6	\N	\N	\N	2026-03-24 03:42:09.815+00
14f1a2ff-3d5e-4efe-a485-e14c2cbb0dd9	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 44 x1q5uujj	84000	250000	7	\N	\N	\N	2026-03-24 03:42:09.979+00
934b16a2-3ca0-406f-b247-ef4e8831965b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 44 dew3nesb	84000	250000	7	\N	\N	\N	2026-03-24 03:42:10.016+00
65c29c21-6966-464d-bdd4-29b9a1d9d01f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 45 lqnrqwui	85000	250000	3	\N	\N	\N	2026-03-24 03:42:10.711+00
4ae15941-05b5-4ac7-a44f-ccf209696b95	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 45 3i2jvg0f	85000	250000	3	\N	\N	\N	2026-03-24 03:42:11.64+00
785fe3bd-689b-4f97-8e0c-f5966a1ddc92	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 46 7zds4opd	86000	250000	4	\N	\N	\N	2026-03-24 03:42:11.913+00
ad56e946-4361-445c-892d-7e26b053fd47	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 47 dqtd06n8	87000	250000	5	\N	\N	\N	2026-03-24 03:42:12.568+00
22f5cded-45e9-47a1-b5d0-0c3e61f69c65	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:52.163+00
34d0ee6c-1172-454e-9d34-b03c8d5e79e3	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:52.844+00
36e5b4d4-3ba8-4ef1-a1f8-8acdfef000c9	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:53.698+00
5c91af81-2cdb-49c4-800d-e6f5bcda8f5a	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:54.474+00
4c8e0f20-2df2-42a5-b86d-644324aebcd9	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:55.163+00
e42ef63b-481f-449e-9256-6d5e55a496e6	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:56.573+00
314b85d3-4997-4041-8b6c-fe70404bade9	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 0 rvzelc8c	80000	250000	3	\N	\N	\N	2026-03-25 16:40:02.851+00
cc0238fe-57c5-4920-b87a-c48a8a306003	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 0 geduxups	80000	250000	3	\N	\N	\N	2026-03-25 16:40:02.866+00
62203ad1-7a96-4575-82f5-f80274034730	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 1 k4arb4jg	81000	250000	4	\N	\N	\N	2026-03-25 16:40:03.765+00
a71d0bf5-7a49-4202-a423-9a854ed0dc96	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 1 5l7k0vb0	81000	250000	4	\N	\N	\N	2026-03-25 16:40:03.79+00
f3b2c9b1-561f-46e8-9325-2dfdb4e43be3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 1 wni2runx	81000	250000	4	\N	\N	\N	2026-03-25 16:40:03.805+00
c74bbc0e-a942-4705-9919-bb07b848ee33	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 1 pzn4wgsj	81000	250000	4	\N	\N	\N	2026-03-25 16:40:03.81+00
4c1bde0a-9981-4a80-b65f-06d59b42e648	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 2 4mcktrmt	82000	250000	5	\N	\N	\N	2026-03-25 16:40:04.442+00
e5a68355-62f8-49d9-ac7a-d209bc15c25f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 2 rywc7n4o	82000	250000	5	\N	\N	\N	2026-03-25 16:40:04.474+00
75499b95-5b21-43e0-92a1-d442798ab723	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 2 jzizio9i	82000	250000	5	\N	\N	\N	2026-03-25 16:40:04.483+00
552b3e8e-0cca-461c-b35f-f7700c595973	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 3 ocpp2z19	83000	250000	6	\N	\N	\N	2026-03-25 16:40:05.013+00
a411748e-9d9a-48d6-9a9e-db7cdd43d805	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 3 q0tjtvhj	83000	250000	6	\N	\N	\N	2026-03-25 16:40:05.075+00
98bf514e-a668-4377-9da2-b984b03daa2b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 3 vm6q4vy5	83000	250000	6	\N	\N	\N	2026-03-25 16:40:05.276+00
b86e6c9c-14be-40ab-8920-e757e596898d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 4 e89eyaea	84000	250000	7	\N	\N	\N	2026-03-25 16:40:05.56+00
6fa301a7-1f27-4f4a-99bf-035aa79abcf3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 4 avsfu7bv	84000	250000	7	\N	\N	\N	2026-03-25 16:40:05.616+00
e7b68a3b-4da0-47d9-8ef5-d088747c5600	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 4 m0chu4nk	84000	250000	7	\N	\N	\N	2026-03-25 16:40:05.874+00
34aec3b8-1181-4bda-aeec-491cc0c6166f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 5 dieq6peh	85000	250000	3	\N	\N	\N	2026-03-25 16:40:06.453+00
519f1de3-2784-4bfd-857c-4be69f2a4457	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 31 7xkw0wr0	81000	250000	4	\N	\N	\N	2026-03-24 03:42:03.211+00
e6b48175-ac7d-40a6-837f-e28802a9c279	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 32 0qsktg3j	82000	250000	5	\N	\N	\N	2026-03-24 03:42:04.063+00
2bb0e92e-8ad3-4ec2-8e80-0b3019a32a62	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 33 ohubgzbs	83000	250000	6	\N	\N	\N	2026-03-24 03:42:04.415+00
81b1eebb-6779-46b2-b197-53be532e3b52	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 33 wttbubrj	83000	250000	6	\N	\N	\N	2026-03-24 03:42:04.537+00
24c82623-1d5c-4d43-aecd-a7b9a226de38	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 34 nfu7ayut	84000	250000	7	\N	\N	\N	2026-03-24 03:42:04.584+00
f3dc0b05-171d-4fa5-8123-ce60d8d21dac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 34 99aibsjr	84000	250000	7	\N	\N	\N	2026-03-24 03:42:04.706+00
a61686dc-5360-46e0-b627-c78cf978e70c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 35 rqnxicmg	85000	250000	3	\N	\N	\N	2026-03-24 03:42:05.184+00
a2159573-d8de-4a4b-8c2b-ec152c56d84a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 35 mj20pu5f	85000	250000	3	\N	\N	\N	2026-03-24 03:42:05.308+00
12f8131c-a992-49b4-b7ab-553e72238a48	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 35 9f052c8u	85000	250000	3	\N	\N	\N	2026-03-24 03:42:05.811+00
d13d0874-22b9-476f-b968-2c3d6c5feae3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 37 h6murs0x	87000	250000	5	\N	\N	\N	2026-03-24 03:42:06.649+00
3ce7ba8d-d4ae-422e-9a69-14d64f73ce19	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 38 3ufh4oo5	88000	250000	6	\N	\N	\N	2026-03-24 03:42:07.208+00
449c0237-38b0-4cf3-a250-8b8f6bdfcb1d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 39 9dsxtna6	89000	250000	7	\N	\N	\N	2026-03-24 03:42:07.751+00
7798a383-d23d-48ac-bf92-9430603d0529	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 41 nei4w2nh	81000	250000	4	\N	\N	\N	2026-03-24 03:42:08.518+00
63f20638-5cd6-4492-be11-1b95d3c2278e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 41 qvymffcc	81000	250000	4	\N	\N	\N	2026-03-24 03:42:08.613+00
d2b1001d-87d0-4227-9761-615d91a24445	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 41 zeltnrxh	81000	250000	4	\N	\N	\N	2026-03-24 03:42:08.884+00
c789a602-dd76-47ad-afd4-0f5009686fe9	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 41 znj2ktr3	81000	250000	4	\N	\N	\N	2026-03-24 03:42:08.9+00
ffd404e4-64da-42ef-bb73-711a21872994	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 42 tdusqlim	82000	250000	5	\N	\N	\N	2026-03-24 03:42:09.335+00
0198492d-3ed4-477b-97c9-80b325e9575e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 42 4pkjstyl	82000	250000	5	\N	\N	\N	2026-03-24 03:42:09.365+00
13181878-1a07-48e2-8469-b31df53f09e1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 43 mv8umnzm	83000	250000	6	\N	\N	\N	2026-03-24 03:42:09.817+00
f5e9baae-4c81-4c1c-9d7a-a34c8501806a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 43 lfie0v59	83000	250000	6	\N	\N	\N	2026-03-24 03:42:10.018+00
3f38f6ef-41c1-4876-9159-ecc6cb7fe560	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 44 9mte98wp	84000	250000	7	\N	\N	\N	2026-03-24 03:42:10.306+00
89f611b8-32c9-433b-bbe3-b7bf25d2fd60	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 44 xbuzmnhm	84000	250000	7	\N	\N	\N	2026-03-24 03:42:10.312+00
14eb8e02-4870-4d79-a447-321833f20f53	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 45 kj5odpjo	85000	250000	3	\N	\N	\N	2026-03-24 03:42:11.21+00
91eb0d63-48c7-4e36-a774-5f37109fe3b0	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 45 1pdg3e2p	85000	250000	3	\N	\N	\N	2026-03-24 03:42:11.33+00
98d2bd6a-fa6b-4e69-b7b3-f315f4a13778	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 46 zhkx5e8g	86000	250000	4	\N	\N	\N	2026-03-24 03:42:11.638+00
a265cc16-0c1e-4c35-ae7d-9f8cfa0085ad	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 46 mtkj4n30	86000	250000	4	\N	\N	\N	2026-03-24 03:42:11.917+00
c3fd696e-31ab-416f-836d-d0d407e20cce	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 47 5xoj0izu	87000	250000	5	\N	\N	\N	2026-03-24 03:42:12.415+00
7fb797f7-4c40-4d0d-85ab-4a4d0a2f5f2c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 48 bqoy2tnl	88000	250000	6	\N	\N	\N	2026-03-24 03:42:12.869+00
b2122752-eda0-4bc2-93a6-2416b04f32e3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 48 ikyb0h04	88000	250000	6	\N	\N	\N	2026-03-24 03:42:12.875+00
55317c69-2beb-4376-b631-f47838bd0383	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 48 cghl4gks	88000	250000	6	\N	\N	\N	2026-03-24 03:42:12.878+00
0c183eac-86bf-47a5-9299-78d9f17ef426	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:53.701+00
a232c387-fe9d-421a-aff6-3c5059843b0d	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:53.717+00
b61e4471-f202-407a-a278-b6420c83908d	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:54.476+00
de423588-aa59-4fec-b17d-e757137b772c	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:55.159+00
1c93b4e1-3e0b-4bdf-b4fb-3db18daed72b	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:55.882+00
bb45d781-ec6e-400f-9476-dd8b25d9b0c1	e578f15c-a49c-455c-8aab-078d1f550d74	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:42:56.575+00
f96295e9-06f7-4c6c-a2b8-49b7dcb4be4b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 3 vbpdt1jr	83000	250000	6	\N	\N	\N	2026-03-25 16:40:05.272+00
bf9ec4e4-4a80-423f-b7a1-fbc61bdd7cde	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 4 qfdqfto5	84000	250000	7	\N	\N	\N	2026-03-25 16:40:05.618+00
8cbb5d6a-7c43-4f31-a026-75b425362022	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 4 dt3gy0h8	84000	250000	7	\N	\N	\N	2026-03-25 16:40:05.838+00
62088985-0256-42ba-9c8c-158e44878b7f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 4 siqu8vrw	84000	250000	7	\N	\N	\N	2026-03-25 16:40:05.869+00
3ea24297-a7b4-4634-bd89-8b87f998c092	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 5 qz60tg7r	85000	250000	3	\N	\N	\N	2026-03-25 16:40:06.096+00
6773e6af-eb5b-48de-846b-c689df2e18fe	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 5 13axfdkv	85000	250000	3	\N	\N	\N	2026-03-25 16:40:06.153+00
f5764501-d4b2-42ef-b9fd-346baea533fd	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 6 i5qryceo	86000	250000	4	\N	\N	\N	2026-03-25 16:40:06.71+00
d04fdb6a-f540-40a0-b363-f0e8b47d5277	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 6 9vqdzl5k	86000	250000	4	\N	\N	\N	2026-03-25 16:40:07.054+00
90009ff0-20ce-4bfa-a04f-c608ecab3789	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 7 oc3ktpg9	87000	250000	5	\N	\N	\N	2026-03-25 16:40:07.647+00
7af2d3f8-3c72-482d-a710-2cf364cfc9eb	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 7 us9xn0sq	87000	250000	5	\N	\N	\N	2026-03-25 16:40:07.666+00
42c2ef8a-2efb-4acc-8da1-71cbe9e9b4b6	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 7 yzqum4q5	87000	250000	5	\N	\N	\N	2026-03-25 16:40:08.878+00
c23d4041-b9f4-4059-ba6c-5b74eb92bfae	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 8 9agn63qw	88000	250000	6	\N	\N	\N	2026-03-25 16:40:11.856+00
061d1279-6630-4354-aa8f-d3ea6f29b3f2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 8 ppx3m4hc	88000	250000	6	\N	\N	\N	2026-03-25 16:40:12.142+00
5f2065fc-706d-40ca-bf55-a3a260789ca9	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 8 kpvqmjkx	88000	250000	6	\N	\N	\N	2026-03-25 16:40:12.215+00
4053f61d-3174-49a8-8d36-c146b13c16e0	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 9 llfygt8l	89000	250000	7	\N	\N	\N	2026-03-25 16:40:12.409+00
caf8711b-9ac6-4365-b691-bfc80b6d563a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 9 uws0pkw4	89000	250000	7	\N	\N	\N	2026-03-25 16:40:12.438+00
eaed77a1-1c31-410d-9c09-c624f756b99c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 9 h8vmwh4z	89000	250000	7	\N	\N	\N	2026-03-25 16:40:12.48+00
b00903c4-68f0-4586-883d-c4b6933aeff8	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 9 pg7awfa2	89000	250000	7	\N	\N	\N	2026-03-25 16:40:12.663+00
ee36d240-e18f-4247-a222-6fec019d3296	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 10 2oim08tx	80000	250000	3	\N	\N	\N	2026-03-25 16:40:13.843+00
1533ad1b-ee7e-4ad5-8b0c-66ad90b6f674	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 11 kfzeud08	81000	250000	4	\N	\N	\N	2026-03-25 16:40:14.195+00
3d888eda-f60f-4c1b-adb0-5e111e3252a2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 11 lncus4d7	81000	250000	4	\N	\N	\N	2026-03-25 16:40:14.444+00
ee647ceb-c106-4a96-8aea-5e2f12ace2c2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 12 ztqcfpig	82000	250000	5	\N	\N	\N	2026-03-25 16:40:15.193+00
f88f5023-2ef8-489f-9616-7b4a132519d8	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 13 vzi57bo9	83000	250000	6	\N	\N	\N	2026-03-25 16:40:15.751+00
f49fe335-fd95-4936-bdd3-b3cdbf33c084	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 13 s7n6tc52	83000	250000	6	\N	\N	\N	2026-03-25 16:40:15.764+00
f2fc52e8-96d8-4a8e-8a4c-0a85453741a9	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 13 g11zb7ei	83000	250000	6	\N	\N	\N	2026-03-25 16:40:15.774+00
4848acdd-f5d1-4650-8828-273227b2b97f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 14 6f5isxfn	84000	250000	7	\N	\N	\N	2026-03-25 16:40:15.805+00
a087d43e-5a57-45c0-a203-b60f727c11e3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 14 cmfcul1q	84000	250000	7	\N	\N	\N	2026-03-25 16:40:15.97+00
08b17054-5236-4fd2-beae-16c5fdcc5a8a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 14 w003sgv5	84000	250000	7	\N	\N	\N	2026-03-25 16:40:16.41+00
42e71212-8a3f-4788-b792-dcac793c0aa1	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 16 5sbievn7	86000	250000	4	\N	\N	\N	2026-03-25 16:40:17.444+00
cf9dedc4-8252-4321-a5f1-070bf6f711f2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 16 dztlb95n	86000	250000	4	\N	\N	\N	2026-03-25 16:40:17.846+00
59b512a9-8114-497f-b71a-7cd0c033ac05	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 16 kaa8sdra	86000	250000	4	\N	\N	\N	2026-03-25 16:40:18.042+00
000b77ff-6c4d-44ec-8069-755659725f90	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 17 n1biowpx	87000	250000	5	\N	\N	\N	2026-03-25 16:40:18.049+00
68ddc0d0-d9af-4c72-955e-051c24331ac5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 18 jaopara2	88000	250000	6	\N	\N	\N	2026-03-25 16:40:18.989+00
e39424e7-7640-4eed-a786-e85c5ef65302	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 18 fw4vks56	88000	250000	6	\N	\N	\N	2026-03-25 16:40:19.003+00
6fac2d36-a73f-4b96-b2c2-2e7d5013713b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 34 vdfjy0ht	84000	250000	7	\N	\N	\N	2026-03-24 03:42:04.823+00
a4c5bc7e-d943-40d5-8d22-4c881fcfdc76	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 34 vh6o7lgk	84000	250000	7	\N	\N	\N	2026-03-24 03:42:05.03+00
21116be7-733d-4ec4-adaa-e1db9aa50667	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 34 lrq1dfxu	84000	250000	7	\N	\N	\N	2026-03-24 03:42:05.1+00
b732b9a5-fcce-43d3-9409-d2f917fc8821	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 35 v08c3iaa	85000	250000	3	\N	\N	\N	2026-03-24 03:42:05.116+00
e3c43ed3-161c-4346-8a07-2dc563890001	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 35 ds5w75ko	85000	250000	3	\N	\N	\N	2026-03-24 03:42:05.135+00
bb04e1eb-911e-411a-afd0-8fd3c5aaece8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 35 nb3oe9dz	85000	250000	3	\N	\N	\N	2026-03-24 03:42:05.51+00
b85e382c-543a-43a8-9d30-07c095b685f8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 36 lksqdn56	86000	250000	4	\N	\N	\N	2026-03-24 03:42:05.813+00
87acd1a8-f933-4a36-ba8e-2c2559502109	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 36 tjzhstod	86000	250000	4	\N	\N	\N	2026-03-24 03:42:05.882+00
857af959-fd76-43dd-ad17-5268d1619afe	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 36 gin9blk5	86000	250000	4	\N	\N	\N	2026-03-24 03:42:06.119+00
b928b6e7-a441-4c75-bb72-fa106bf71f00	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 36 w2rii4u9	86000	250000	4	\N	\N	\N	2026-03-24 03:42:06.324+00
74077f70-cd35-47a8-ae3e-960c30e2bbc2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 36 w8jv9bcw	86000	250000	4	\N	\N	\N	2026-03-24 03:42:06.647+00
caf13da9-0e4f-4e76-8942-e19b3e93357a	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 37 613k99id	87000	250000	5	\N	\N	\N	2026-03-24 03:42:07.206+00
681c7721-0ca2-4394-a059-89d7d3e06bb8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 38 bf9dkhg2	88000	250000	6	\N	\N	\N	2026-03-24 03:42:07.41+00
6a6e9d41-102a-49dc-9d25-13bb4bf8556e	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 39 c6x2zo6h	89000	250000	7	\N	\N	\N	2026-03-24 03:42:07.941+00
98cd8b4b-cba5-4e9d-96ce-2fb044cdb854	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 39 tudlp1gn	89000	250000	7	\N	\N	\N	2026-03-24 03:42:07.957+00
822682a7-ebbf-4dc5-ad31-f8778a108641	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 39 7t7zd1xp	89000	250000	7	\N	\N	\N	2026-03-24 03:42:08.183+00
cc49b177-a455-4b76-b63f-53da73b50f20	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 40 dmepmhll	80000	250000	3	\N	\N	\N	2026-03-24 03:42:08.43+00
31c31bea-d2f0-4b65-94bb-3271e76f878d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 40 9ac7k7b9	80000	250000	3	\N	\N	\N	2026-03-24 03:42:08.614+00
d87db7a4-a075-4595-b4de-07d31f38a141	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 41 3l3jnfti	81000	250000	4	\N	\N	\N	2026-03-24 03:42:08.926+00
9f2a8a29-da1e-446b-8a38-b6fac4cc45d6	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 42 dtgf1age	82000	250000	5	\N	\N	\N	2026-03-24 03:42:09.025+00
ebb9dc47-915d-4347-9d6e-f7bb3a39d3a2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 41 ggavkpxp	81000	250000	4	\N	\N	\N	2026-03-24 03:42:09.081+00
e9507465-c7d0-4b3b-9071-df250ce8cd83	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 43 se9zjjw7	83000	250000	6	\N	\N	\N	2026-03-24 03:42:09.761+00
54200cf8-3f36-45de-b0d4-4969e68e733f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 44 bmfi6c2s	84000	250000	7	\N	\N	\N	2026-03-24 03:42:10.314+00
4a6ea2bc-1aaa-4165-a7ca-404130943392	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 45 39tg731h	85000	250000	3	\N	\N	\N	2026-03-24 03:42:10.613+00
1847768e-78f7-4a3e-b9f9-11834ed66c19	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 44 ckdnq3mo	84000	250000	7	\N	\N	\N	2026-03-24 03:42:10.713+00
e29e50e6-8cfe-4aea-b67b-959f449ac854	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 45 32exj59b	85000	250000	3	\N	\N	\N	2026-03-24 03:42:11.332+00
4909eb20-b4de-4129-9c94-47c6bc6d00c1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 46 wip2j6x4	86000	250000	4	\N	\N	\N	2026-03-24 03:42:11.642+00
88c63a21-f18b-49ac-8bd3-b3456d97bbf9	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 46 pd89vpy6	86000	250000	4	\N	\N	\N	2026-03-24 03:42:11.915+00
8d1c724b-4c7f-4624-b858-eb112418026c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 46 v7g9r44p	86000	250000	4	\N	\N	\N	2026-03-24 03:42:12.106+00
4fa670f9-f3c1-418d-b9e7-7192ca79ae8c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 47 5anub97u	87000	250000	5	\N	\N	\N	2026-03-24 03:42:12.128+00
ea2d3ee3-ded5-474c-89fc-632e4783e1d1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 47 z45d1bxh	87000	250000	5	\N	\N	\N	2026-03-24 03:42:12.135+00
8bbad0de-45e0-4084-b2e3-5ff53d297cb8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 47 jlsbnofj	87000	250000	5	\N	\N	\N	2026-03-24 03:42:12.413+00
fe2ce054-aed1-43dd-943b-c3b39a3a45cc	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 47 7bvlbo68	87000	250000	5	\N	\N	\N	2026-03-24 03:42:12.418+00
05f49d33-095a-484f-89d6-1c46fd15d522	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 48 o24e4hww	88000	250000	6	\N	\N	\N	2026-03-24 03:42:12.57+00
cedb48a9-e7ee-4c94-8b00-600c5eda3fff	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	k6 search 48 t6j96908	88000	250000	6	\N	\N	\N	2026-03-24 03:42:12.581+00
5d85f181-89bb-48e3-aaf2-92a05268820b	748c3744-ce7a-4b25-ba3b-9d8d585853e7	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-24 03:45:21.936+00
a780052b-03ee-4884-8445-c81dc7cda3f0	c1b4fd1d-e276-4b96-a40b-3c686e9c37e8	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-24 03:56:14.242+00
a34b1118-dd8b-4e24-80af-4332ddf6fe5c	902bb881-e1d7-4fff-b5c6-a9b2bac3001d	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-24 05:12:27.555+00
62c03209-4891-4b7e-b474-a8aab7da2f9f	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:16.846+00
9c238dc7-29c8-43ce-b46a-265fee32dd2f	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:16.86+00
91611238-934a-4de9-ae27-4632153125d7	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:16.849+00
e72f28ba-06b3-4f8c-bb3b-4df3257c3251	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:17.695+00
64d9e808-660a-43ad-9d73-3d30bbd6b3e6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:17.711+00
6c0a00e5-1ba6-47dc-a9e7-532935e00ea3	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:17.718+00
d49ba8b5-71ed-4c28-8b1a-d1fc8891c1c8	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:18.385+00
8a3e0c76-8bd7-423f-9363-2274cb3ac0ef	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:18.388+00
35840e25-9498-43dc-bf87-c9a57e8b2bf7	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:18.4+00
c4a16c2f-c9cb-46be-9b00-fbb7955e4138	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:19.256+00
607df264-9d79-4ba6-beac-5dfde5fba97e	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:19.252+00
8de5e5f3-3910-4afb-ae34-3f604f28e740	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:19.258+00
a4e17533-ff9b-4f7c-a1f7-44e94d2bb85a	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:20.29+00
2bfedf4d-0d2d-4424-8bfb-80a5a8dca0db	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:20.295+00
1f3c2fe7-931d-410d-80cf-926e1f53f654	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:20.297+00
461a403d-275d-43c5-aaa8-0b5bd7ae265d	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:21.006+00
e426b6c7-c4ad-4e57-824c-d79fbea177a6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:21.011+00
58cc399e-60a6-470e-9bed-798f929aa873	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:21.015+00
ba539cac-4a2d-43d5-a0a5-e71b10e0893c	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:21.73+00
38092d6a-b4f0-4654-adb5-906a6577e9b7	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:21.734+00
d59ed7a2-c97c-463c-80c5-c10ca244519e	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:21.786+00
bb244647-8fea-4e09-a0bb-3931a9096df1	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:22.687+00
0aed864b-aab5-48f9-b051-3a08b37b0881	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:22.691+00
5929e4c3-5498-462f-b78e-ebf634dac175	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:22.696+00
fe064489-379e-475d-882c-f551e529c08b	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:23.418+00
d5905bba-dcc3-41e6-b7ab-5fdb9dc0baeb	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:23.547+00
d1b3e53a-14dc-440e-bcf0-2fd926b8636b	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:23.552+00
50f431b1-3ee2-44ff-bae0-2f9f4623dbbc	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:24.328+00
62292db9-5172-4a6a-9388-9adda02686b6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:24.583+00
0e9b475a-54ef-4616-9e6a-c07dd8eeda33	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:24.586+00
8bc678d6-a159-4fee-9e16-0f187604e90e	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:25.098+00
14bf267c-e02d-4eac-9e78-df5e956589ff	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:25.279+00
964af9ee-c783-470a-859e-a8ec3f8335f5	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:25.37+00
bc8627d8-cf2d-4558-a860-1697c91286c3	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:25.722+00
a12fd6ba-8eaf-4d4b-97e3-cb51637df0d8	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:25.888+00
e14435f7-cce0-414d-b6ed-947e4fdb69b4	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:25.981+00
751ed5c2-a64b-4480-9df9-548a81486399	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:26.65+00
1c907093-de65-4580-a0a6-105a818f1960	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:27.047+00
7b297186-3727-447d-acc0-f3f60e51b3c8	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:27.183+00
f9cf1cbf-2bc7-4b44-a6f5-95cadcc9cb6c	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:27.297+00
f7dfc828-e320-4cd0-aeef-9502d1081bf9	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:30.68+00
573fb05c-d036-4d5d-8a55-7cfe331b73c0	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:30.69+00
63e4e8d0-1dd9-47bd-a623-f0a534a0c73b	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:31.316+00
8017b9d3-22a4-4cc8-bfa8-becde7423890	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:31.392+00
89757d92-077d-47e3-ac13-8b0aee5fcce7	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:31.987+00
17bbb8c4-722f-485d-9a5c-ffaa5bd2d8c9	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:32.083+00
11df4e48-9173-40ed-bf08-adfddda3f0a5	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:32.863+00
b68e66d3-a6ad-435a-9328-fed39f816350	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:33.553+00
add6bf26-e5bf-443f-b747-464e6171639a	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:33.624+00
6e68e62d-757e-4094-a3a5-6e2382c857c1	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:34.948+00
227e08fb-e0d9-4be3-8412-088ee4374a2a	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:36.204+00
358ee2dd-86cd-49e6-a291-35b75f513a7b	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:37.756+00
e2a82785-74b0-4ec1-855e-e3c1f3525911	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:37.787+00
3fc0782b-111c-4d63-82d5-bac8e0f801fd	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:40.307+00
75d55de9-88f4-407a-a611-a18d98d8dc84	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:40.313+00
6b902000-437d-4f51-bda0-3f967b11a07b	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:41.008+00
8511c51f-9dbb-438f-8501-1c19d6d5874a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 0 u6i588z2	80000	250000	3	\N	\N	\N	2026-03-24 18:06:22.934+00
f5a2f988-4ec8-4481-9eff-39d4209fae5f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 0 imoz4z9x	80000	250000	3	\N	\N	\N	2026-03-24 18:06:22.956+00
21f78157-317c-4cb5-8146-13d760c5ac90	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 0 l4cfxq9q	80000	250000	3	\N	\N	\N	2026-03-24 18:06:23.025+00
524bc504-097e-4b72-8c92-75aab7fc8d22	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 1 jkq32zb2	81000	250000	4	\N	\N	\N	2026-03-24 18:06:23.719+00
45ff3380-fffd-4edd-8648-ea255122bfb4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 1 glxe87bu	81000	250000	4	\N	\N	\N	2026-03-24 18:06:23.946+00
1c69793d-7c94-44be-b1bc-97f9d2077bed	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 2 3ec5i4hv	82000	250000	5	\N	\N	\N	2026-03-24 18:06:24.549+00
e1bfb0ac-301c-42bd-9416-dd3b96f2d096	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 2 trw3d31z	82000	250000	5	\N	\N	\N	2026-03-24 18:06:25.161+00
e0f9cfea-172e-40bc-b9b7-38e837ec4afc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 3 x43l6pgw	83000	250000	6	\N	\N	\N	2026-03-24 18:06:25.749+00
ba7c23b5-bb6d-4798-8a75-85dbc10cede4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 3 ou9qohvd	83000	250000	6	\N	\N	\N	2026-03-24 18:06:25.778+00
3ea22812-8b55-4b63-b281-388ab5fb8c72	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 4 icv89m30	84000	250000	7	\N	\N	\N	2026-03-24 18:06:25.95+00
0b29500f-3948-4401-951f-23441ad7bca3	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 4 aya0m37c	84000	250000	7	\N	\N	\N	2026-03-24 18:06:26.086+00
afc3269e-6f12-4ea8-a467-138bea5cd124	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 4 9y46gjw3	84000	250000	7	\N	\N	\N	2026-03-24 18:06:26.152+00
dc74ab28-57a8-46e0-9ee7-f4c0b6b3bfa0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 5 0qieqy6s	85000	250000	3	\N	\N	\N	2026-03-24 18:06:26.466+00
a40ac8d1-4d31-4df6-9da1-1c6909ed0918	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 5 nbil481x	85000	250000	3	\N	\N	\N	2026-03-24 18:06:26.567+00
1f29df1d-7f41-4308-82fa-370acfbccfb2	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 6 nqb5v6qr	86000	250000	4	\N	\N	\N	2026-03-24 18:06:27.187+00
cb613d4b-2d91-4f22-9ab2-be81db547406	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 7 q7oeetif	87000	250000	5	\N	\N	\N	2026-03-24 18:06:28.607+00
b80630f9-d859-42ab-8988-9058c455a647	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 8 4afif1lo	88000	250000	6	\N	\N	\N	2026-03-24 18:06:28.905+00
d0133b7a-09a8-4076-92eb-a90c959c7b85	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 8 sici7lg0	88000	250000	6	\N	\N	\N	2026-03-24 18:06:29+00
c11cd782-d40e-4678-8060-f523b5c5d23e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 8 9bozphz9	88000	250000	6	\N	\N	\N	2026-03-24 18:06:29.01+00
84f6eb4c-f02b-4e5e-a300-b8c965700547	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 8 1ac3dfup	88000	250000	6	\N	\N	\N	2026-03-24 18:06:29.157+00
2f584cd2-9d0a-4363-9b48-40a2542aaa0f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 9 oh7blul4	89000	250000	7	\N	\N	\N	2026-03-24 18:06:29.407+00
4db18996-a2ac-42ee-af87-4c2a64a5ded1	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 9 25vb65tg	89000	250000	7	\N	\N	\N	2026-03-24 18:06:29.586+00
5f222056-7300-42c4-bc7e-b8d3b230db10	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 9 nbt4s6kl	89000	250000	7	\N	\N	\N	2026-03-24 18:06:29.595+00
8108b49c-ad1d-40c3-a2a0-69d973c2b25c	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 10 lsc0nqlj	80000	250000	3	\N	\N	\N	2026-03-24 18:06:29.633+00
d2adbb46-4ff2-4bea-953a-5d34785e3e08	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 11 qhhpy765	81000	250000	4	\N	\N	\N	2026-03-24 18:06:30.264+00
4e9c3103-6c3c-43f3-935c-c3dfcbc1dd2a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 12 tavl0bph	82000	250000	5	\N	\N	\N	2026-03-24 18:06:30.987+00
0337c589-df98-4040-9857-e01aa9cc0c30	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 12 rq6m0p2n	82000	250000	5	\N	\N	\N	2026-03-24 18:06:31.153+00
a18ac6e9-a11e-4a3f-9a5b-00a610ccc22b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 14 inaud44x	84000	250000	7	\N	\N	\N	2026-03-24 18:06:32.39+00
20bbf85e-86af-4547-87c1-4c500e0bfc94	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 13 p1ls4z7v	83000	250000	6	\N	\N	\N	2026-03-24 18:06:32.416+00
347cf828-f3e6-4e23-8306-8158c9087af3	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 14 os99201m	84000	250000	7	\N	\N	\N	2026-03-24 18:06:32.502+00
a2bddd65-a8e6-4438-b88c-9ff632aadb28	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 14 8vihs047	84000	250000	7	\N	\N	\N	2026-03-24 18:06:32.523+00
a7518b7b-eeda-4822-a2ab-c113ec451694	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 15 mk67m9af	85000	250000	3	\N	\N	\N	2026-03-24 18:06:33.217+00
7634714b-c592-4859-bbbb-407cc1dce1fe	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 16 mf4wg0jr	86000	250000	4	\N	\N	\N	2026-03-24 18:06:33.852+00
28a8b3c4-71c8-468e-94e9-70ef33901c38	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 16 r08j6s80	86000	250000	4	\N	\N	\N	2026-03-24 18:06:33.959+00
08e7a7b3-2b79-426b-ab5a-d18f73b88bae	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 16 62x93dof	86000	250000	4	\N	\N	\N	2026-03-24 18:06:34.654+00
fc869369-19d5-4c3e-9889-aab2060350fe	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 16 jx9bxa0i	86000	250000	4	\N	\N	\N	2026-03-24 18:06:35.322+00
0d8901b7-f7a0-42b8-bf4f-76d9dd02e5f0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 17 jlfvvvlr	87000	250000	5	\N	\N	\N	2026-03-24 18:06:35.351+00
a950af96-a3cb-4b4d-b310-27386c7abf14	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 17 e6d7k6iq	87000	250000	5	\N	\N	\N	2026-03-24 18:06:35.452+00
4400f474-1e00-460d-b17b-09f81a8a34d5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 17 9bmjroe8	87000	250000	5	\N	\N	\N	2026-03-24 18:06:35.95+00
3e9bb95f-7cc0-437e-a5b9-5bc805742cbd	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 17 22u6jpm8	87000	250000	5	\N	\N	\N	2026-03-24 18:06:36.335+00
746c44c8-27e2-48f6-805d-2136ca32406e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 18 y0knxeyf	88000	250000	6	\N	\N	\N	2026-03-24 18:06:36.425+00
74bdb8f4-00a6-4cf6-8832-494c7e6add0b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 19 sjz62s02	89000	250000	7	\N	\N	\N	2026-03-24 18:06:36.527+00
3ee164e9-7a0c-474e-b47b-1c35894cf279	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 19 otlsdnb9	89000	250000	7	\N	\N	\N	2026-03-24 18:06:37.422+00
1a6703fc-6bfa-446f-9335-9658ed5e0c68	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 20 s66fx2vz	80000	250000	3	\N	\N	\N	2026-03-24 18:06:37.622+00
fb40b5c0-be41-4334-a052-3b5e926cc2ea	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 19 7yt5ja0j	89000	250000	7	\N	\N	\N	2026-03-24 18:06:37.721+00
3efe8881-8fe6-45fe-a3cd-a4f8a4526885	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 20 p6m7gxkz	80000	250000	3	\N	\N	\N	2026-03-24 18:06:37.821+00
525c0609-58bb-4f85-a8ca-537e727e5d88	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 22 n1aumrcv	82000	250000	5	\N	\N	\N	2026-03-24 18:06:39.521+00
a8d7f899-28c8-4420-ae53-e963353550c8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 0 gvcv58j6	80000	250000	3	\N	\N	\N	2026-03-25 01:43:23.619+00
67f0d26e-9af2-4e78-ba55-1b333c83dd82	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 0 ww91uidd	80000	250000	3	\N	\N	\N	2026-03-25 01:43:23.629+00
b4ee61ed-423e-4eb3-8eb5-1d5c65f27c5a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 1 nrt8hxjy	81000	250000	4	\N	\N	\N	2026-03-25 01:43:24.321+00
dd4a235d-aa24-4a4a-af26-f5e04cfbbb53	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:26.358+00
c4abc8e5-f10c-42b6-becc-4f9afcd7e8cc	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:26.523+00
922036b9-455b-477f-95fe-5d1089a486a6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:27.649+00
79e59446-cd76-41f2-ad32-25d2ed451177	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:27.839+00
8eaa4fa8-0806-4124-959b-89472bc16a64	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:28.05+00
41cff2ab-949a-4d9a-8dc6-673f331ce74d	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:28.425+00
da3722a7-17dd-4fda-804c-652d403d02fb	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:28.519+00
eba74d99-cf8e-4048-84c1-42b513d28982	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:29.923+00
d6a09a60-ebe2-46ad-a394-900a60b58abc	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:29.961+00
fcd95557-2853-46f5-b8c2-3290b8f1c555	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:30.646+00
b1365cfa-012d-413d-9417-820af779d117	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:31.353+00
b6c43585-8b64-4c42-81a8-04434d893ad4	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:32.75+00
5a2e8c35-f474-42e4-a792-123f2e37a98f	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:32.796+00
aa375f0c-0e21-42d6-b258-c74022f573f3	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:33.648+00
9a4fa7b4-eef0-41a6-a1a8-63392ec62fb6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:34.923+00
d71dfd7d-e3ba-4919-ac42-6ae80b2bc985	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:36.201+00
e9a81429-8e8c-429c-9974-567941b7223c	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:36.933+00
62a2bc9b-6fbf-415f-8211-daac95e720b8	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:36.979+00
d7655821-d26e-4a4c-a8ac-85d83dca5911	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:36.984+00
037c981e-174f-4a69-bd60-9875c32136e9	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:38.547+00
dc553026-c451-490f-8b72-72ae75ec891e	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:38.557+00
be748ab5-0a18-4350-bb7b-33f3482882b0	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:39.605+00
66804cc2-7e1b-42ca-898b-e29b4f9606a7	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:39.614+00
11b23f94-8574-4d1e-8ae5-7565f0d2d7e6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:39.622+00
185e3bf9-3ce2-4bc1-bc6e-f4662f989096	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 0 2z3h3w9x	80000	250000	3	\N	\N	\N	2026-03-24 18:06:22.955+00
5fe2474a-d901-4dcd-b351-ee8c910616b7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 1 whpwqgzk	81000	250000	4	\N	\N	\N	2026-03-24 18:06:23.824+00
94423f93-eca7-4c0a-95a5-43a114d072cc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 1 1rfwb4xb	81000	250000	4	\N	\N	\N	2026-03-24 18:06:23.924+00
32e27201-0bb7-4803-bd61-c63c440eca50	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 2 7bb806pd	82000	250000	5	\N	\N	\N	2026-03-24 18:06:24.978+00
faa1bd8d-e251-481a-adac-9be87201fe56	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 2 8bd14yde	82000	250000	5	\N	\N	\N	2026-03-24 18:06:24.988+00
b48dc510-931b-4bfb-aae5-cda599fc6ddb	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 2 18o3y0fc	82000	250000	5	\N	\N	\N	2026-03-24 18:06:25.097+00
0069529b-7fd8-44e5-9b2d-407f9d343f4a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 3 m7jjsf10	83000	250000	6	\N	\N	\N	2026-03-24 18:06:25.252+00
367d7bfa-7933-45d8-b8ea-58e743c2a275	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 3 u3hfjwby	83000	250000	6	\N	\N	\N	2026-03-24 18:06:25.47+00
6b7155df-0d23-4d7e-a01e-1d252db86ac6	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 3 zurhq28x	83000	250000	6	\N	\N	\N	2026-03-24 18:06:25.583+00
cc7b92a2-cf60-40bd-9249-66e905515253	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 5 cdnt9k8u	85000	250000	3	\N	\N	\N	2026-03-24 18:06:26.752+00
b564ac11-5319-4a4f-b811-cfca082b39fd	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 5 v4krqhlg	85000	250000	3	\N	\N	\N	2026-03-24 18:06:26.761+00
72d617da-6a1d-4367-a33b-3d90453958e5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 5 sbjekp3r	85000	250000	3	\N	\N	\N	2026-03-24 18:06:26.921+00
26894fae-dd0d-45cc-8776-6f95f41a9917	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 6 ucu2rd0e	86000	250000	4	\N	\N	\N	2026-03-24 18:06:27.075+00
44e46153-44a4-4b25-bbc8-2e9851c61c59	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 5 u7fg64pu	85000	250000	3	\N	\N	\N	2026-03-24 18:06:27.08+00
4d6e90d4-97e8-4ac7-9d5b-8580e81a972f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 6 v5w6pz48	86000	250000	4	\N	\N	\N	2026-03-24 18:06:27.347+00
58e5a471-4f8e-4d0c-8c69-daec66994f26	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 7 tb4b33hl	87000	250000	5	\N	\N	\N	2026-03-24 18:06:28.046+00
9dfd7fbe-25a8-405b-9086-5cb964a42dfa	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 7 4sfr6bir	87000	250000	5	\N	\N	\N	2026-03-24 18:06:28.271+00
43aa1f81-6c63-4f2c-91af-01f99b385955	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 7 6vcmnha4	87000	250000	5	\N	\N	\N	2026-03-24 18:06:28.321+00
fb39eff7-6c06-41e8-a90f-12854625f5f0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 8 2r2nuy30	88000	250000	6	\N	\N	\N	2026-03-24 18:06:28.352+00
1ede413e-84c7-4c76-900a-8dd4e69690f5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 9 spz8yrug	89000	250000	7	\N	\N	\N	2026-03-24 18:06:29.014+00
16137fba-6a73-46bd-8064-0092847c1558	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 9 xcyk5o6j	89000	250000	7	\N	\N	\N	2026-03-24 18:06:29.636+00
630eb436-973f-4408-a5a6-5a201e8b8e94	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 9 x9jbecah	89000	250000	7	\N	\N	\N	2026-03-24 18:06:29.733+00
02e31ba7-3e22-43c3-9024-15db6841d3d8	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 10 d1gvyvf0	80000	250000	3	\N	\N	\N	2026-03-24 18:06:30.167+00
8afab765-9422-4fd2-a88c-4f67f88697a8	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 10 978x94yl	80000	250000	3	\N	\N	\N	2026-03-24 18:06:30.215+00
dbcf5ed9-fa2a-4f80-86bf-df5d6acc1db5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 10 z0fu2uod	80000	250000	3	\N	\N	\N	2026-03-24 18:06:30.267+00
54b58a8b-b059-4120-a8bf-1e9fcbc03541	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 10 71adjy50	80000	250000	3	\N	\N	\N	2026-03-24 18:06:30.348+00
fad54795-a5d9-4a78-8e87-f95166d43f47	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 11 fx4o66b9	81000	250000	4	\N	\N	\N	2026-03-24 18:06:30.981+00
41e01bc4-c62d-4056-8650-94385f9ef928	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 12 71u3yl22	82000	250000	5	\N	\N	\N	2026-03-24 18:06:31.445+00
444f6579-7795-4420-b134-4f03d0ad7b40	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 13 e6jseh5m	83000	250000	6	\N	\N	\N	2026-03-24 18:06:31.652+00
fc2e3bf4-b141-47f0-9976-f0201e60be9e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 12 af2qd0jx	82000	250000	5	\N	\N	\N	2026-03-24 18:06:31.683+00
316e285a-fc60-499b-ac0f-ce8876f84724	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 12 wilucd3i	82000	250000	5	\N	\N	\N	2026-03-24 18:06:31.721+00
0d3e7312-3785-413f-b0d6-679486870c4a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 13 98k1njuy	83000	250000	6	\N	\N	\N	2026-03-24 18:06:31.775+00
f5d076c5-df84-4aee-bb15-8c249cd91ecc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 14 1a30im7e	84000	250000	7	\N	\N	\N	2026-03-24 18:06:32.526+00
4641665c-54d2-4269-a156-312c7e5da422	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 15 v6hqxg8v	85000	250000	3	\N	\N	\N	2026-03-24 18:06:32.985+00
3097d86b-a79a-469c-9b9b-431e2a5591c4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 14 0rckcxcy	84000	250000	7	\N	\N	\N	2026-03-24 18:06:33.089+00
f643c69d-6e23-4ddd-b2c8-da6765fced85	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 15 b8gc6ky6	85000	250000	3	\N	\N	\N	2026-03-24 18:06:33.215+00
458fb1ff-c6eb-4958-9888-70c3bbff0706	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 15 943y5rbi	85000	250000	3	\N	\N	\N	2026-03-24 18:06:33.551+00
94b2a312-ad0a-4d29-be47-ef3985a8a8a7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 15 7u7j9j45	85000	250000	3	\N	\N	\N	2026-03-24 18:06:33.848+00
1b195b4b-c71b-47d3-887d-db9bb7a5b14b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 17 32kpj65c	87000	250000	5	\N	\N	\N	2026-03-24 18:06:34.355+00
2246a5c0-4f6a-4ad6-823b-8f0b18322545	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 19 mmxer8kl	89000	250000	7	\N	\N	\N	2026-03-24 18:06:37.032+00
7c73e3bb-ae79-4cee-ad08-576cc349e702	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 19 i0xrfbgu	89000	250000	7	\N	\N	\N	2026-03-24 18:06:37.077+00
4b7e15f5-4dcf-425d-a9ae-1c6b609122ca	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 18 wx20mfyg	88000	250000	6	\N	\N	\N	2026-03-24 18:06:37.188+00
8524b038-706c-4d21-940b-cae10edc4d01	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 20 8e0vkc3o	80000	250000	3	\N	\N	\N	2026-03-24 18:06:37.42+00
6b87d132-90d2-4811-b947-1d1bb1f9b819	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 21 vk70jacv	81000	250000	4	\N	\N	\N	2026-03-24 18:06:37.991+00
12291010-e60b-4849-9986-073b967dfc6a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 20 bsh3dsuf	80000	250000	3	\N	\N	\N	2026-03-24 18:06:38.011+00
fe28caf0-8c68-4f0b-89e0-a56be5b7a8a8	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 21 48mmssig	81000	250000	4	\N	\N	\N	2026-03-24 18:06:38.133+00
0d65f4b5-5a78-41e8-a0f8-61b1bd954708	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 20 nu9mjtce	80000	250000	3	\N	\N	\N	2026-03-24 18:06:38.449+00
5a52a6a1-b5e7-44b5-9284-05d86a255621	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 21 0ikkrs92	81000	250000	4	\N	\N	\N	2026-03-24 18:06:38.546+00
e3c3a152-7cef-4e5c-84a8-0e34afe6b3db	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:29.196+00
c2639cdc-1245-4f63-b30d-c880affe9820	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:29.257+00
ab962dcd-fb84-4c15-b394-d21eaa7220fc	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:29.268+00
f4040a4c-0730-40d7-82b5-1064cff6e9f3	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:29.882+00
d415fc33-1b88-47c6-9e35-043a18a33605	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:32.028+00
6ebd1442-4581-4d47-9e65-344e8e684d4f	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:34.953+00
1bff7f3e-6120-4a81-b5f5-7b226adf9ad9	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:36.197+00
de038984-6951-40cd-ac65-d2ce136bae47	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:37.791+00
687863f2-8b33-47bb-8c8a-37486f8f87ae	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:38.54+00
6082f659-c328-43aa-81d3-dd129eb3887a	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:40.31+00
44f9b39f-e759-4eba-9d90-8c9284f3e7dc	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:40.996+00
66ce7ee5-6ee1-4e34-84b9-925b9f62c9e6	a9346f8b-998c-45e1-99ca-339aa10b78be	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:05:41.005+00
a6d6dfa5-5bb7-4161-8f5f-d23e63026e39	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 0 c609z549	80000	250000	3	\N	\N	\N	2026-03-24 18:06:22.939+00
3c8390d1-bfff-4029-837b-3f42b42e19b1	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 0 68v628z0	80000	250000	3	\N	\N	\N	2026-03-24 18:06:23.022+00
e697dca9-1c56-4023-acbc-b322b4dad0eb	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 1 s71fegzx	81000	250000	4	\N	\N	\N	2026-03-24 18:06:23.825+00
51fe6558-4ab2-42c3-b4b9-b7fda64ffd0e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 1 6ajus2w8	81000	250000	4	\N	\N	\N	2026-03-24 18:06:23.854+00
660410fb-b87e-4932-ba63-c1e7ba3de7fd	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 2 cfqh01t3	82000	250000	5	\N	\N	\N	2026-03-24 18:06:24.991+00
6f93743b-ef92-40b7-b5f4-29520547e0c0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 3 kcnot055	83000	250000	6	\N	\N	\N	2026-03-24 18:06:25.586+00
c1d0b86e-d4fe-412e-9553-707717f8e5e5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 4 ahhqecv0	84000	250000	7	\N	\N	\N	2026-03-24 18:06:25.821+00
eca67da6-f507-470a-b2be-8adf2fbfbfd9	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 4 hhykprka	84000	250000	7	\N	\N	\N	2026-03-24 18:06:26.301+00
98e29254-d2b5-42cf-b719-fb476dcdc2d4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 4 7b7wfpgr	84000	250000	7	\N	\N	\N	2026-03-24 18:06:26.47+00
cd3cab71-5950-4539-a4b4-1294de3dafc0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 6 ljfjska1	86000	250000	4	\N	\N	\N	2026-03-24 18:06:27.349+00
dd7b91a9-a694-4677-97e6-463007a6958d	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 6 y25vixih	86000	250000	4	\N	\N	\N	2026-03-24 18:06:27.45+00
1b58fea0-5cc3-4626-8afc-2323211664a1	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 7 pxfg5184	87000	250000	5	\N	\N	\N	2026-03-24 18:06:27.59+00
824b9794-f74b-4b90-a782-8068e4651622	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 6 h8qf9x36	86000	250000	4	\N	\N	\N	2026-03-24 18:06:27.608+00
1a084fcb-be4b-4818-9396-780e0553ce74	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 7 eme5hvci	87000	250000	5	\N	\N	\N	2026-03-24 18:06:28.348+00
efe7c4f4-570d-45c3-815b-2a463e1fa479	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 8 nrjpx319	88000	250000	6	\N	\N	\N	2026-03-24 18:06:29.012+00
61535f24-27f6-484d-a81e-3ac7e1692a0e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 10 l12z1ril	80000	250000	3	\N	\N	\N	2026-03-24 18:06:29.826+00
238d8df3-8566-4cef-bf20-1f993258a7cc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 11 957dcz6s	81000	250000	4	\N	\N	\N	2026-03-24 18:06:30.369+00
17bb149c-40f9-461c-afcf-2efbb3347c69	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 11 jqiyhg48	81000	250000	4	\N	\N	\N	2026-03-24 18:06:30.682+00
625fbdbc-8686-401b-852e-27745a5c8cdd	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 11 859zj0ao	81000	250000	4	\N	\N	\N	2026-03-24 18:06:30.878+00
3a5a5c19-aabc-42cb-9b75-ce1c38d4ffac	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 12 uo74r3ex	82000	250000	5	\N	\N	\N	2026-03-24 18:06:30.949+00
ad4cbe6a-3884-4ecc-9de2-f8ceedd610f4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 11 vbzoksc6	81000	250000	4	\N	\N	\N	2026-03-24 18:06:30.959+00
7351e2b9-08f9-4b22-a295-d323f849609e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 13 333m9wsd	83000	250000	6	\N	\N	\N	2026-03-24 18:06:31.724+00
f13996d8-ef7c-4e7b-91cc-67bf5ea44174	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 13 33dqgt0p	83000	250000	6	\N	\N	\N	2026-03-24 18:06:31.866+00
dff8292a-f3a3-4774-8e4f-ecf9ac10c62b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 13 qfnoglzc	83000	250000	6	\N	\N	\N	2026-03-24 18:06:32.52+00
e684cb74-0490-42d2-a99d-3f505d17b671	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 14 jvn6orfv	84000	250000	7	\N	\N	\N	2026-03-24 18:06:33.213+00
87ff27f7-0b7c-4b8d-9f32-e86868a9b1a0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 15 qux5090r	85000	250000	3	\N	\N	\N	2026-03-24 18:06:33.218+00
8ea72506-e864-4ba6-b13a-9499b1610e1d	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 16 l59dd51g	86000	250000	4	\N	\N	\N	2026-03-24 18:06:33.457+00
d12df7c5-df02-402f-b4cd-e440f8cbde5a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 16 jsoo5pku	86000	250000	4	\N	\N	\N	2026-03-24 18:06:33.85+00
4efa32c6-26a3-4c56-9e1c-4f1aa70af45c	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 17 xtbwwgfv	87000	250000	5	\N	\N	\N	2026-03-24 18:06:35.349+00
4f7070eb-ab60-47c4-b45d-ff746fffb753	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 18 30vj558y	88000	250000	6	\N	\N	\N	2026-03-24 18:06:35.948+00
d4dd3e98-1f7c-40ff-a38d-de76f0aaf8f8	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 18 61fgouz5	88000	250000	6	\N	\N	\N	2026-03-24 18:06:36.313+00
b878096f-e35c-466c-b0ad-4269994023b7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 18 jf2kz1db	88000	250000	6	\N	\N	\N	2026-03-24 18:06:36.331+00
ecd3b261-08c3-421f-b833-2639e8152b29	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 18 no33gt2g	88000	250000	6	\N	\N	\N	2026-03-24 18:06:36.547+00
ab6463c9-8be6-4ff3-8b99-7218eb3c3602	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 19 g8hix2yo	89000	250000	7	\N	\N	\N	2026-03-24 18:06:37.275+00
2b9a5795-5e46-4f75-99dc-5bb1d456f572	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 20 npfnyny9	80000	250000	3	\N	\N	\N	2026-03-24 18:06:37.556+00
94998dda-f50b-45e8-9eb7-c37a4b927d42	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 21 3u8o9xfp	81000	250000	4	\N	\N	\N	2026-03-24 18:06:38.206+00
1936b8f4-7eb7-412a-9a8f-61da31d4ee66	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 21 3xx2chio	81000	250000	4	\N	\N	\N	2026-03-24 18:06:38.85+00
1f6352ac-ff77-444c-acf7-42d030ef4828	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 22 j4tukax9	82000	250000	5	\N	\N	\N	2026-03-24 18:06:39.475+00
56bc57bc-a4bf-405d-835e-a348ea8d174b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 21 6hdewmlh	81000	250000	4	\N	\N	\N	2026-03-24 18:06:39.488+00
cdb7d6fc-64f8-4c5f-979d-c0851650c362	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 0 92nh9grx	80000	250000	3	\N	\N	\N	2026-03-25 01:43:23.62+00
c3749ff8-e696-4ae0-984e-c850e37d6f46	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 0 3zbntvvp	80000	250000	3	\N	\N	\N	2026-03-25 01:43:23.668+00
328522e4-b574-4712-9902-65f3a9353cf2	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 1 gxo03j2p	81000	250000	4	\N	\N	\N	2026-03-25 01:43:24.372+00
56a0c143-1ad2-43e9-a5af-08aaad05cbce	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 1 athijabd	81000	250000	4	\N	\N	\N	2026-03-25 01:43:24.395+00
f56f1a29-5228-42f0-9cb6-2215be08e754	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 2 z48sghf3	82000	250000	5	\N	\N	\N	2026-03-25 01:43:25.171+00
b332b2ed-c35a-4dca-a7ff-ba2f3a910300	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 3 3m31v7z3	83000	250000	6	\N	\N	\N	2026-03-25 01:43:25.566+00
a4aa0e34-1830-4004-b2f5-dc2f4c5e292a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 3 4b0pzeh6	83000	250000	6	\N	\N	\N	2026-03-25 01:43:25.872+00
0664d24d-ff33-4432-b9f2-2169907fa887	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 3 dn6v8cb0	83000	250000	6	\N	\N	\N	2026-03-25 01:43:25.877+00
d1787ea7-244a-4b31-9012-faea90194948	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 3 gi91v8s2	83000	250000	6	\N	\N	\N	2026-03-25 01:43:26.078+00
2cae5bbd-5fef-4233-8dcf-36bece3356fc	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 3 s7sls720	83000	250000	6	\N	\N	\N	2026-03-25 01:43:26.089+00
50e2d061-efff-47b9-881c-129117bf6399	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 6 3qrcjk6t	86000	250000	4	\N	\N	\N	2026-03-25 01:43:28.071+00
c1300b86-e7e6-459a-aabd-0203d3ff326d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 7 z7fgoi3y	87000	250000	5	\N	\N	\N	2026-03-25 01:43:28.078+00
9701793e-3bb7-4ca5-930d-ca614b32f7fc	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 7 3shiddf0	87000	250000	5	\N	\N	\N	2026-03-25 01:43:28.869+00
effbea3a-cb43-431a-8998-3946c3fd305a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 7 ddnmtbz0	87000	250000	5	\N	\N	\N	2026-03-25 01:43:29.106+00
8c683ecc-ac81-40ce-a165-38b8eb1171dd	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 8 gnub0crn	88000	250000	6	\N	\N	\N	2026-03-25 01:43:29.346+00
1739c116-ded6-4fc5-858d-571ba988c931	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 8 uekpgpd7	88000	250000	6	\N	\N	\N	2026-03-25 01:43:29.639+00
cde9e9ea-54c8-4f68-a8e6-52924fb4c456	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 9 sz8mf7ge	89000	250000	7	\N	\N	\N	2026-03-25 01:43:29.766+00
6273fe3a-6e83-4f35-9445-fa94dd07286a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 9 76591k0q	89000	250000	7	\N	\N	\N	2026-03-25 01:43:29.771+00
47927fe1-cf26-4c8e-9f92-b592a1f105a1	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 9 wjl5fsj3	89000	250000	7	\N	\N	\N	2026-03-25 01:43:30.387+00
622a8147-45ca-4308-9be5-81b87a5e091e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 11 r4226w2b	81000	250000	4	\N	\N	\N	2026-03-25 01:43:31.494+00
97b4d242-4016-4b3a-9211-307f8a096cbf	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 22 fu88mwm6	82000	250000	5	\N	\N	\N	2026-03-24 18:06:38.847+00
69692a82-5e98-4f3e-827c-e90e3e4a29f5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 22 jmj0h71x	82000	250000	5	\N	\N	\N	2026-03-24 18:06:39.387+00
c96dcc40-0750-4a68-b40f-839dc42e7a04	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 23 sks7jauu	83000	250000	6	\N	\N	\N	2026-03-24 18:06:39.555+00
a3b7fcb0-82b0-4cf5-90b1-c9543beff896	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 22 e5sa9947	82000	250000	5	\N	\N	\N	2026-03-24 18:06:39.562+00
591cda47-97cc-44b3-a3b3-f6084a1c087f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 23 rp910bn3	83000	250000	6	\N	\N	\N	2026-03-24 18:06:39.871+00
ebaaeb07-6ec7-49e5-8126-a03ddfae0dc7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 23 5gastjte	83000	250000	6	\N	\N	\N	2026-03-24 18:06:40.041+00
7b8b6644-9e96-45bb-8f8c-fb2218ec57dd	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 22 aid4mrjk	82000	250000	5	\N	\N	\N	2026-03-24 18:06:40.083+00
a3ebe6f2-249f-475b-814b-f802df3bbcef	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 23 58r0nh0h	83000	250000	6	\N	\N	\N	2026-03-24 18:06:40.153+00
dd1d1953-e3ca-4cb2-a0cd-995078ccf518	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 24 tauz2pw6	84000	250000	7	\N	\N	\N	2026-03-24 18:06:40.195+00
da59242d-cd44-4b49-a0a6-dfe0a37e3f6b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 23 hczcnaxn	83000	250000	6	\N	\N	\N	2026-03-24 18:06:40.205+00
c9bd3dd6-124c-483b-bd05-954952f1fbd4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 24 urlqw0v0	84000	250000	7	\N	\N	\N	2026-03-24 18:06:40.321+00
ecac3112-3152-4524-bcab-df93eaac29c0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 24 sqy9ua6v	84000	250000	7	\N	\N	\N	2026-03-24 18:06:40.593+00
2f47ff9a-07de-4e96-84a8-6118608332bb	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 23 ba2t6mev	83000	250000	6	\N	\N	\N	2026-03-24 18:06:40.668+00
a987c795-56b7-4d76-85d8-7100b5bc7625	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 24 vdayciq5	84000	250000	7	\N	\N	\N	2026-03-24 18:06:40.746+00
183f59e2-a307-4e56-80b5-5bfc053c6b9f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 25 bntu4s3i	85000	250000	3	\N	\N	\N	2026-03-24 18:06:40.784+00
f09e385a-313d-46a2-b843-312f9b90b415	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 24 r15w3cml	84000	250000	7	\N	\N	\N	2026-03-24 18:06:40.786+00
fc442223-40d2-4020-a71d-4cb978bfd078	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 25 5ntxjwkw	85000	250000	3	\N	\N	\N	2026-03-24 18:06:40.849+00
84697fa5-7184-4e09-a76a-684d5a2c28a6	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 25 f2rtw4pn	85000	250000	3	\N	\N	\N	2026-03-24 18:06:41.047+00
d2dfe0f1-7bac-4bbf-b776-ce40b682e1aa	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 24 908ndy1a	84000	250000	7	\N	\N	\N	2026-03-24 18:06:41.197+00
48319728-6951-471d-856a-b88ab11319a1	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 25 xspmiq7d	85000	250000	3	\N	\N	\N	2026-03-24 18:06:41.289+00
3e73d2a2-7e3f-4557-8f7d-a6fd9d6e2bb3	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 26 siu3z9dx	86000	250000	4	\N	\N	\N	2026-03-24 18:06:41.4+00
e7cc930a-ff25-4a3c-997c-43ed89a42015	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 25 pb6oqp5d	85000	250000	3	\N	\N	\N	2026-03-24 18:06:41.41+00
86b891c4-76d4-4d94-9223-7eea7fbba8e4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 26 16uwsjf9	86000	250000	4	\N	\N	\N	2026-03-24 18:06:41.412+00
f2df2145-8adc-49eb-a9be-d19e32b27f79	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 26 j7hhu2oc	86000	250000	4	\N	\N	\N	2026-03-24 18:06:41.552+00
4889df53-5ff4-4819-86f7-181a7ef0cd1a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 25 w1r49czw	85000	250000	3	\N	\N	\N	2026-03-24 18:06:41.681+00
95f69591-7ade-4912-862a-41bd1ce697c4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 26 pfail9yc	86000	250000	4	\N	\N	\N	2026-03-24 18:06:41.793+00
59ff6124-08e4-4c3f-8f7b-02ffaec7bc5d	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 27 6he6z65k	87000	250000	5	\N	\N	\N	2026-03-24 18:06:41.937+00
a63a9ae7-732d-4655-a22a-71cda9730824	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 26 n2cp3uao	86000	250000	4	\N	\N	\N	2026-03-24 18:06:41.976+00
475b1fe6-7148-41b5-8951-f6f0aae34f9e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 27 emcjj8ts	87000	250000	5	\N	\N	\N	2026-03-24 18:06:41.979+00
ebf72aec-9f92-468b-865c-ee345e6318e9	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 27 259afjpd	87000	250000	5	\N	\N	\N	2026-03-24 18:06:42.054+00
330a50bd-65d3-40fd-879d-e02ec1e707d4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 26 o5202w6x	86000	250000	4	\N	\N	\N	2026-03-24 18:06:42.152+00
767d7f56-5e72-4f17-8cfa-8ded559b579d	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 27 og4uh80p	87000	250000	5	\N	\N	\N	2026-03-24 18:06:42.252+00
2b2eefe7-3f5e-4770-b6cc-170d6d49c32e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 28 7c7b21ht	88000	250000	6	\N	\N	\N	2026-03-24 18:06:42.425+00
3607dc72-604f-4589-ab74-508b8860f2ae	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 28 fgcyx2co	88000	250000	6	\N	\N	\N	2026-03-24 18:06:42.58+00
68d86d4f-646a-40c1-98d5-21209f880845	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 27 y14qg4jy	87000	250000	5	\N	\N	\N	2026-03-24 18:06:42.594+00
ffd59a38-c99d-4db2-85f8-bd87e94a5eda	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 28 g6i2ik45	88000	250000	6	\N	\N	\N	2026-03-24 18:06:42.75+00
84962510-ed5b-43e0-b5fe-f6dfaa89d2c6	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 27 sam5pta4	87000	250000	5	\N	\N	\N	2026-03-24 18:06:42.802+00
3310ff5a-6bd8-45c8-bd8f-9fc2fbac1d9a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 28 xc76ibgs	88000	250000	6	\N	\N	\N	2026-03-24 18:06:42.847+00
392fb995-9472-4f1c-99f9-7d89cc047727	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 29 w3ydufa6	89000	250000	7	\N	\N	\N	2026-03-24 18:06:42.979+00
73bdc302-12dc-49e5-a09c-0a52f58639ad	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 28 pcrezy71	88000	250000	6	\N	\N	\N	2026-03-24 18:06:43.213+00
c1818a64-8e75-4da4-8362-a8d511e203fe	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 29 jxn7k9hi	89000	250000	7	\N	\N	\N	2026-03-24 18:06:43.273+00
d8cda335-acd0-4824-9b03-c45653c90529	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 29 vf8y8273	89000	250000	7	\N	\N	\N	2026-03-24 18:06:43.423+00
7f7c667a-ef7d-4608-b5e5-831f6af18d9b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 28 erwr1ghv	88000	250000	6	\N	\N	\N	2026-03-24 18:06:43.447+00
265710c4-c3a9-47c2-a950-468687647938	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 29 0d840dh8	89000	250000	7	\N	\N	\N	2026-03-24 18:06:43.522+00
1c83acc2-db6d-4d61-85b9-efe5863e5dfc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 30 1cb13fsw	80000	250000	3	\N	\N	\N	2026-03-24 18:06:43.548+00
66646dc4-9fdb-42ad-99b0-dc16f97950da	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 29 t5tifao8	89000	250000	7	\N	\N	\N	2026-03-24 18:06:43.76+00
c7b9554f-5af6-4de1-a5e1-0e6b42da5c4f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 30 mxes5zhm	80000	250000	3	\N	\N	\N	2026-03-24 18:06:43.857+00
94f2402f-f876-40ae-8c5b-7167f59bf75b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 30 tsq0vsbi	80000	250000	3	\N	\N	\N	2026-03-24 18:06:44.648+00
50e427d8-6f2a-4406-9daf-e9fffebbb574	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 29 7pxgwa2w	89000	250000	7	\N	\N	\N	2026-03-24 18:06:44.654+00
696983cd-edba-4209-a68b-dca8944274da	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 31 e04b4hmb	81000	250000	4	\N	\N	\N	2026-03-24 18:06:44.859+00
b85c5b1b-adf6-414f-a56c-27792ec35cbf	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 30 hhmmz9bt	80000	250000	3	\N	\N	\N	2026-03-24 18:06:44.919+00
af9e56d4-cfa1-446b-9b2e-8f36b71cbc02	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 30 7vpcwc0r	80000	250000	3	\N	\N	\N	2026-03-24 18:06:44.954+00
7cbbdc0e-80ea-4fb2-8301-39fdb9de0987	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 31 xldji9y7	81000	250000	4	\N	\N	\N	2026-03-24 18:06:45.255+00
cd2afe9f-be3b-4385-90df-054f87d5ed3b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 31 5sq399mw	81000	250000	4	\N	\N	\N	2026-03-24 18:06:45.694+00
9bd17faf-312d-47d3-a2d0-4147ebbf504a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 30 ghgdmtpb	80000	250000	3	\N	\N	\N	2026-03-24 18:06:45.697+00
f8565f4f-f67c-449c-bf86-97ec6b7985ce	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 32 5hvnb6kb	82000	250000	5	\N	\N	\N	2026-03-24 18:06:45.699+00
26c1d92f-2c39-4456-8736-66a602d898fb	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 31 ysf6zsie	81000	250000	4	\N	\N	\N	2026-03-24 18:06:45.75+00
1deca610-d663-4c48-bcfc-cc3d35c6f926	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 31 i87lml25	81000	250000	4	\N	\N	\N	2026-03-24 18:06:45.758+00
bd102c08-e593-4edb-b12e-d549ba10f031	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 32 ts1oogiu	82000	250000	5	\N	\N	\N	2026-03-24 18:06:45.854+00
17cf3c40-4241-4265-a5cc-4f980d214777	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 31 ze2aih5e	81000	250000	4	\N	\N	\N	2026-03-24 18:06:46.344+00
c9c1f6f6-02bb-4335-8edb-5be6eceed8a4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 33 t8b80ima	83000	250000	6	\N	\N	\N	2026-03-24 18:06:46.403+00
69d36657-2c27-49fa-85b2-1ff4edd84110	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 32 t97u64td	82000	250000	5	\N	\N	\N	2026-03-24 18:06:46.563+00
42202f9c-03c8-4bc0-8bf2-648201783b8c	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 32 84ctvjoh	82000	250000	5	\N	\N	\N	2026-03-24 18:06:46.565+00
7ad238d4-3816-495a-a08f-b880afe5d541	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 32 rboqtp5q	82000	250000	5	\N	\N	\N	2026-03-24 18:06:46.573+00
b1ad1515-eebd-4232-a650-646cf7a78f8e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 33 lz0f045w	83000	250000	6	\N	\N	\N	2026-03-24 18:06:46.747+00
50bdc255-9898-4aa2-a05a-276e6db12597	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 32 cj11770p	82000	250000	5	\N	\N	\N	2026-03-24 18:06:47.303+00
4a48f42a-34a8-4ff3-86e8-653154770ce6	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 34 8kt27d5d	84000	250000	7	\N	\N	\N	2026-03-24 18:06:47.395+00
48462419-aaef-40e8-8b45-d4feee96a9de	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 33 6e3zaog9	83000	250000	6	\N	\N	\N	2026-03-24 18:06:47.412+00
90164f4b-f956-46c0-a698-b0465c9f94df	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 33 psmaapco	83000	250000	6	\N	\N	\N	2026-03-24 18:06:47.477+00
34a04e68-6a29-4de6-b38b-ae446d89fda5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 33 e0l2b0af	83000	250000	6	\N	\N	\N	2026-03-24 18:06:47.485+00
dd0cdbb5-a2f7-41a2-8035-c413e1e05854	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 34 kjr9xtdz	84000	250000	7	\N	\N	\N	2026-03-24 18:06:47.52+00
c8d234af-66cc-4712-b663-ea8953a47cd7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 34 syxor966	84000	250000	7	\N	\N	\N	2026-03-24 18:06:48.024+00
49bd457b-bc92-42e8-98c2-edc92e0f779d	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 35 zzrlhfa3	85000	250000	3	\N	\N	\N	2026-03-24 18:06:48.052+00
bfc3450b-dd21-452b-98ae-18719b0d97da	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 35 gi8zhb9y	85000	250000	3	\N	\N	\N	2026-03-24 18:06:49.649+00
43e915ac-02da-484d-ac9a-13efcc122843	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 36 v9ek5qr4	86000	250000	4	\N	\N	\N	2026-03-24 18:06:50.223+00
c1b1c4eb-e33c-43b1-95b3-74b19b533d13	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 36 lbojymxo	86000	250000	4	\N	\N	\N	2026-03-24 18:06:50.562+00
947e876b-27da-42c1-946d-27a79fe67e2f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 38 i4bvi1ng	88000	250000	6	\N	\N	\N	2026-03-24 18:06:50.573+00
9e740359-cd14-497b-89f4-7c334e3e9044	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 37 gr8xc0fz	87000	250000	5	\N	\N	\N	2026-03-24 18:06:50.72+00
bf0edaa7-947a-4d1e-ae35-0efb0f12cf64	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 37 feq9fy7z	87000	250000	5	\N	\N	\N	2026-03-24 18:06:50.781+00
f9ee7786-5d5c-47d1-acf3-6ab142a6687e	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 38 z8i6bwf9	88000	250000	6	\N	\N	\N	2026-03-24 18:06:50.85+00
1834da60-a94c-4c29-8c82-22a80efaa00a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 0 5tc202ec	80000	250000	3	\N	\N	\N	2026-03-25 01:43:23.622+00
2933cf7b-ccd4-4e09-99f9-cf741ec717d9	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 0 z512fhr3	80000	250000	3	\N	\N	\N	2026-03-25 01:43:23.667+00
694d00d5-b575-4509-8a6a-7c591946b408	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 2 5l33d2qt	82000	250000	5	\N	\N	\N	2026-03-25 01:43:24.995+00
84d1c9a4-4c73-4c26-b09b-b897640bf5d7	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 2 i2dgt7c8	82000	250000	5	\N	\N	\N	2026-03-25 01:43:25.103+00
bf2f31e6-0829-4637-ad6a-98203f54fb41	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 2 ze3zol2i	82000	250000	5	\N	\N	\N	2026-03-25 01:43:25.114+00
1560ee42-432e-4961-b713-b0c855f30f34	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 2 wvgm8p9u	82000	250000	5	\N	\N	\N	2026-03-25 01:43:25.137+00
d6fa3527-a8a9-4b48-a5d0-4caf4e7f06ee	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 4 bokj04ad	84000	250000	7	\N	\N	\N	2026-03-25 01:43:26.844+00
76537896-fb93-4e8d-921f-25869cefc7c7	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 5 s0jjv5dz	85000	250000	3	\N	\N	\N	2026-03-25 01:43:27.377+00
0d8e09aa-fd6d-4d6c-a872-e29ab017cadc	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 5 iglldwdk	85000	250000	3	\N	\N	\N	2026-03-25 01:43:27.4+00
47e51221-549d-402a-9f30-6b6c66dab1ec	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 5 fzf1w9d1	85000	250000	3	\N	\N	\N	2026-03-25 01:43:27.422+00
6614f97b-31ff-4ffa-801c-6ede4e07018b	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 6 ouqeflje	86000	250000	4	\N	\N	\N	2026-03-25 01:43:27.515+00
ae6b49ac-a1ec-4081-a042-344e30be05b9	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 6 pt5wjzop	86000	250000	4	\N	\N	\N	2026-03-25 01:43:27.894+00
1ca88b62-5e4a-43aa-b9b2-424942c786fa	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 6 zbv9oh6k	86000	250000	4	\N	\N	\N	2026-03-25 01:43:28.077+00
238167b6-6e37-4ed3-bd40-2d328d3a7796	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 8 pp8m2p53	88000	250000	6	\N	\N	\N	2026-03-25 01:43:29.11+00
f407208e-9fde-4a3e-906a-8ceec71be171	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 9 kty0t43j	89000	250000	7	\N	\N	\N	2026-03-25 01:43:29.642+00
680ff82c-45ae-497b-8d6a-0dee35ccdfe9	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 10 c8qf74kj	80000	250000	3	\N	\N	\N	2026-03-25 01:43:30.477+00
f0896a60-7d1c-4b73-ba77-f4bf39987c58	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 10 0xltmr34	80000	250000	3	\N	\N	\N	2026-03-25 01:43:30.768+00
9b16ff48-0c60-4cda-99e1-729f3c0b515a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 11 8q42yqjr	81000	250000	4	\N	\N	\N	2026-03-25 01:43:30.798+00
4123506c-1950-4c4c-b4ff-0cf3de85d467	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 10 aq6iz0bb	80000	250000	3	\N	\N	\N	2026-03-25 01:43:30.994+00
b72a4b54-ecd5-4ff3-b1ff-eec34364f4b5	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 11 b6k1wjj1	81000	250000	4	\N	\N	\N	2026-03-25 01:43:31.06+00
b345e814-dcd4-417b-87b7-1b693cb0d0b8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 11 papru85r	81000	250000	4	\N	\N	\N	2026-03-25 01:43:31.065+00
afe56431-b7f6-4989-b295-6059e63f6d03	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 12 wzbux16m	82000	250000	5	\N	\N	\N	2026-03-25 01:43:31.248+00
22fc5c95-2e87-409f-abcb-13040196f9d5	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 11 k5dzlnv6	81000	250000	4	\N	\N	\N	2026-03-25 01:43:31.496+00
34797c6d-5df0-4583-bbd7-0bae518865e2	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 12 lwi40l7z	82000	250000	5	\N	\N	\N	2026-03-25 01:43:32.075+00
bbc1d98f-a913-4bda-8b03-1ead4969ebcd	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 13 m4o423uf	83000	250000	6	\N	\N	\N	2026-03-25 01:43:32.183+00
2c691b21-6d03-43d3-9f06-626f8926af95	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 13 v0xjkyek	83000	250000	6	\N	\N	\N	2026-03-25 01:43:32.195+00
12a4f988-99b0-4de7-ab1f-f12c8c2abadf	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 13 0jcvir28	83000	250000	6	\N	\N	\N	2026-03-25 01:43:32.703+00
4580e322-fa47-43e0-8bcd-03647405a7cb	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 14 4v8trljd	84000	250000	7	\N	\N	\N	2026-03-25 01:43:32.722+00
f3ce20cd-4aad-42a7-ac24-80ad6d2c8535	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 13 9m1bgt32	83000	250000	6	\N	\N	\N	2026-03-25 01:43:33.275+00
5495c6bb-61e4-4cd7-83d0-1bb8fb3358f4	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 14 99ffblx1	84000	250000	7	\N	\N	\N	2026-03-25 01:43:33.467+00
42ca8262-3307-460a-9c27-0f34df2f6ff8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 15 brgckes9	85000	250000	3	\N	\N	\N	2026-03-25 01:43:33.775+00
16472345-a126-470f-925f-e0c84d123e7f	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 17 ru87bprv	87000	250000	5	\N	\N	\N	2026-03-25 01:43:35.568+00
1f68267f-f0ea-4a83-8768-42996ccd1272	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 17 ykv3baja	87000	250000	5	\N	\N	\N	2026-03-25 01:43:35.874+00
dcd2aec4-f0ab-44be-930a-019c110aaeae	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 18 y0da2m14	88000	250000	6	\N	\N	\N	2026-03-25 01:43:36.497+00
b0b5598f-ce43-4861-af12-b659db48ca13	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 19 ujihekb7	89000	250000	7	\N	\N	\N	2026-03-25 01:43:36.505+00
834c6c53-2f3f-468c-a2db-08b97884c21d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 18 jofejmmk	88000	250000	6	\N	\N	\N	2026-03-25 01:43:36.55+00
ad738b35-72e1-4377-abd8-35cec888296e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 19 5yckncs9	89000	250000	7	\N	\N	\N	2026-03-25 01:43:36.861+00
0513df5a-feb4-49cc-8cf6-4dd6ca5ec486	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 20 9zw5wmdn	80000	250000	3	\N	\N	\N	2026-03-25 01:43:37.107+00
c4f5b2a4-2252-4247-b554-945fd0e7656f	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 19 ic24k8z9	89000	250000	7	\N	\N	\N	2026-03-25 01:43:37.116+00
8fc7146e-7f2d-4939-ad40-85f74121c072	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 21 bg65xmjq	81000	250000	4	\N	\N	\N	2026-03-25 01:43:37.831+00
d2c08866-7e01-4696-8c92-8b2d0f7c1cca	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 22 fv4m4ac4	82000	250000	5	\N	\N	\N	2026-03-25 01:43:38.626+00
6d152110-b2da-4f97-8138-d22e3287dc5a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 22 cl7xcytk	82000	250000	5	\N	\N	\N	2026-03-25 01:43:38.64+00
eb365de6-1af0-490b-8337-8061591314e8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 23 u2xf43vc	83000	250000	6	\N	\N	\N	2026-03-25 01:43:39.024+00
230f6cad-234c-4028-99e0-c1b69be7c447	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 22 lu3diq4n	82000	250000	5	\N	\N	\N	2026-03-25 01:43:39.225+00
47acee3e-7e19-46ce-a144-e8d1eaec999b	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 22 c7npbkwn	82000	250000	5	\N	\N	\N	2026-03-25 01:43:39.288+00
5657ea6b-5720-45ce-9b62-97005ffe5b57	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 24 zc3ps2zg	84000	250000	7	\N	\N	\N	2026-03-25 01:43:39.485+00
e44a0219-0810-4576-8008-578d87b5c9e3	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 23 5uu4exct	83000	250000	6	\N	\N	\N	2026-03-25 01:43:39.796+00
ea6c9ab1-1d4a-4f44-ba37-3022fa6b2476	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 23 clrbuwbm	83000	250000	6	\N	\N	\N	2026-03-25 01:43:39.82+00
cf1c9d50-1d66-43b4-abb3-1eef548588e8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 23 xipfm7ew	83000	250000	6	\N	\N	\N	2026-03-25 01:43:39.91+00
94e596e1-5ce0-47b7-bac1-bc26f73173b2	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 25 zgfchf4i	85000	250000	3	\N	\N	\N	2026-03-25 01:43:40.051+00
00d2f72e-c6fd-46e9-8e61-7a338bec442f	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 24 8s58jjme	84000	250000	7	\N	\N	\N	2026-03-25 01:43:40.583+00
b1512030-043e-4ea5-a25b-1625594904b4	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 26 n8h7zcy7	86000	250000	4	\N	\N	\N	2026-03-25 01:43:40.609+00
bf8d014d-9ab9-4628-b168-e427822bdd67	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 26 crtrklgi	86000	250000	4	\N	\N	\N	2026-03-25 01:43:41.373+00
bc2ad9b8-310b-4aeb-818d-876a36086f6c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 25 howt90eh	85000	250000	3	\N	\N	\N	2026-03-25 01:43:41.511+00
b2519376-2a63-45f4-953c-82118216ff57	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 26 5mdf7w8x	86000	250000	4	\N	\N	\N	2026-03-25 01:43:41.588+00
3242eda9-1cb0-4259-8418-8a9a48c2ad23	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 27 qn3782is	87000	250000	5	\N	\N	\N	2026-03-25 01:43:42.076+00
55a70122-5e27-48ae-8a46-4cf1cb2a8fa8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 26 3uv63pap	86000	250000	4	\N	\N	\N	2026-03-25 01:43:42.226+00
04ccf645-27e0-46ca-a6ad-370a3e5318d8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 28 0sg0gs0f	88000	250000	6	\N	\N	\N	2026-03-25 01:43:42.232+00
4c0f1867-510b-4986-9c56-6fa1313108d1	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 27 wewv8nzo	87000	250000	5	\N	\N	\N	2026-03-25 01:43:42.273+00
dc5e3192-910c-4b56-adcc-b289f57e2b7e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 27 0hlbnwps	87000	250000	5	\N	\N	\N	2026-03-25 01:43:42.297+00
df8d1991-bb62-450c-8bab-eb8a510e7db7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 33 nx8i44q1	83000	250000	6	\N	\N	\N	2026-03-24 18:06:47.723+00
1edb071d-a0e4-4133-aabd-a81d1ae3ca43	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 35 i1ajnuwx	85000	250000	3	\N	\N	\N	2026-03-24 18:06:47.87+00
7e69b788-a83f-4be8-bdba-1ee0ea25f3b5	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 34 j29qv7kp	84000	250000	7	\N	\N	\N	2026-03-24 18:06:47.922+00
0e156795-a6f1-4c21-aec3-0bba93424fed	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 34 zc8mi52i	84000	250000	7	\N	\N	\N	2026-03-24 18:06:48.351+00
a79530ae-bcf1-49c4-968c-79781a3a58f7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 35 v7zwwhij	85000	250000	3	\N	\N	\N	2026-03-24 18:06:49.324+00
48b0295b-956c-4933-a37a-f721cf4eabf3	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 35 dqa3p4ff	85000	250000	3	\N	\N	\N	2026-03-24 18:06:49.425+00
a4426f57-e9cd-4e67-9c4a-98bbfba8af0a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 36 8qhl5m4x	86000	250000	4	\N	\N	\N	2026-03-24 18:06:49.453+00
bc93ded3-1552-427c-a2d3-3a60f94403ae	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 37 osky8kiy	87000	250000	5	\N	\N	\N	2026-03-24 18:06:49.651+00
22f457d1-47b4-4f8c-98a4-0705a67726cc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 36 ziqy0hku	86000	250000	4	\N	\N	\N	2026-03-24 18:06:49.751+00
f3fb6fcb-9b2e-4aa6-8b70-4516091d99c7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 36 iq9y51ph	86000	250000	4	\N	\N	\N	2026-03-24 18:06:50.355+00
9b567a1f-6e1f-41be-b46c-b5c57b462aed	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 37 07aja0kk	87000	250000	5	\N	\N	\N	2026-03-24 18:06:50.442+00
7cdf0abd-0e03-4319-8b76-1510438477ff	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 37 4xc1eoue	87000	250000	5	\N	\N	\N	2026-03-24 18:06:50.597+00
59c66b30-d3da-4d2d-82b3-8fe8983e33fc	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 1 qk8jio0v	81000	250000	4	\N	\N	\N	2026-03-25 01:43:24.37+00
6a38c2cc-9ac8-469f-abb8-433c9ced9c40	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 1 7pd3cvo4	81000	250000	4	\N	\N	\N	2026-03-25 01:43:24.41+00
5f9d4e6a-c4ed-4f42-ae45-4297465fd7e9	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 1 ra9z6go5	81000	250000	4	\N	\N	\N	2026-03-25 01:43:24.44+00
50f73c3c-65f1-4b2d-bf47-c5bb0aba39ff	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 2 0af3octw	82000	250000	5	\N	\N	\N	2026-03-25 01:43:25.159+00
8420cfd0-e95c-42d0-b077-be541978ce65	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 3 f99twns6	83000	250000	6	\N	\N	\N	2026-03-25 01:43:25.875+00
4e5cafd0-d6cd-4a74-afec-19c8fe6261c4	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 4 q8f0hz3x	84000	250000	7	\N	\N	\N	2026-03-25 01:43:26.669+00
3e5a6292-4bb3-4ca9-bfc6-becc13a2fa4b	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 4 0giw5tal	84000	250000	7	\N	\N	\N	2026-03-25 01:43:26.789+00
09907f74-e6d1-4d60-aec2-03f8923935d2	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 4 udqcupop	84000	250000	7	\N	\N	\N	2026-03-25 01:43:26.8+00
59cd4b05-81bb-4038-8c4f-bf33dccb991e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 4 m75m3x7g	84000	250000	7	\N	\N	\N	2026-03-25 01:43:26.818+00
93bdc416-2a6f-4fad-801d-221c2b080c36	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 4 il0yg0r3	84000	250000	7	\N	\N	\N	2026-03-25 01:43:26.846+00
236b5023-be58-4fe7-97a3-bbd0f9bc66f1	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 5 7jl0dcjk	85000	250000	3	\N	\N	\N	2026-03-25 01:43:27.084+00
370622d0-da55-42c6-843b-4221ebdee86c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 5 kopazo6y	85000	250000	3	\N	\N	\N	2026-03-25 01:43:27.316+00
835695f3-b2d0-4960-bcfa-591095233c05	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 5 jus0kvei	85000	250000	3	\N	\N	\N	2026-03-25 01:43:27.326+00
c3c50807-75e6-4d39-bcf3-cff6b003b8e7	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 6 fx2vkfet	86000	250000	4	\N	\N	\N	2026-03-25 01:43:27.97+00
d97e6668-5df1-4af6-8c35-78fd4bfb5259	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 6 q8ycohi1	86000	250000	4	\N	\N	\N	2026-03-25 01:43:28.074+00
797fd945-ed7b-403d-82e6-b3290e737d90	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 7 3mdrgx8b	87000	250000	5	\N	\N	\N	2026-03-25 01:43:28.908+00
f0d2244f-730a-4af2-ae52-0a2569df8d9e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 7 4w0g4ddk	87000	250000	5	\N	\N	\N	2026-03-25 01:43:29.104+00
1f03f011-29a9-40b9-9e80-504a56277552	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 7 el5v6a3x	87000	250000	5	\N	\N	\N	2026-03-25 01:43:29.108+00
a5aef1a6-4706-48fa-a648-9a77e587aecd	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 8 frxh1t0i	88000	250000	6	\N	\N	\N	2026-03-25 01:43:29.319+00
de4a14e6-4473-449e-8b77-626006bbfbf5	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 8 553784sk	88000	250000	6	\N	\N	\N	2026-03-25 01:43:29.64+00
1e2dcbe1-c0e9-47df-91ce-8842ecd9d5b8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 8 2akotc8n	88000	250000	6	\N	\N	\N	2026-03-25 01:43:29.644+00
87b43574-9f21-4668-b498-1fbf15c6867c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 9 ga4irwww	89000	250000	7	\N	\N	\N	2026-03-25 01:43:30.216+00
dd7340e8-8d10-4452-8a1f-9338eda046b6	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 10 k2mapam1	80000	250000	3	\N	\N	\N	2026-03-25 01:43:30.235+00
7390d9fa-6fb3-4a00-a560-8c4d47b3bd57	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 9 8fepltx2	89000	250000	7	\N	\N	\N	2026-03-25 01:43:30.39+00
8c71d832-326b-41ce-9607-2c4870bdd702	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 10 s6jnqmwa	80000	250000	3	\N	\N	\N	2026-03-25 01:43:30.479+00
12e80ef4-e744-4c15-aa35-e0a7917210d2	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 10 gote5kv1	80000	250000	3	\N	\N	\N	2026-03-25 01:43:30.992+00
ca11d5c4-d093-4f7f-b520-64648b133013	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 11 p1wxcget	81000	250000	4	\N	\N	\N	2026-03-25 01:43:31.202+00
030c4707-ce5b-404d-8a3c-faf61985eeb8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 12 sncvoz21	82000	250000	5	\N	\N	\N	2026-03-25 01:43:31.617+00
56d4e67e-9a58-41b5-9d7e-aa8cfa16d7cd	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 12 dclhzm30	82000	250000	5	\N	\N	\N	2026-03-25 01:43:31.767+00
ec2e288c-8ae2-4e71-af4d-6fbbc9dc3bff	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 13 6em5jr6b	83000	250000	6	\N	\N	\N	2026-03-25 01:43:31.807+00
3443b1b5-c8ef-4349-af67-b200fbdc1648	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 12 jlzfa457	82000	250000	5	\N	\N	\N	2026-03-25 01:43:32.082+00
3c5eeab6-bd3e-4151-b790-30b1944f1c6d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 13 vpmekvhq	83000	250000	6	\N	\N	\N	2026-03-25 01:43:33.272+00
332ce4ec-9c58-430e-a7c6-faf6d6e12a22	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 14 rfvhpjdx	84000	250000	7	\N	\N	\N	2026-03-25 01:43:33.274+00
1dc8a528-3dd9-4886-bc2b-36e35f699dab	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 14 l4nwxd8s	84000	250000	7	\N	\N	\N	2026-03-25 01:43:33.773+00
682444b7-6a15-460c-9e55-00fe7701e0d6	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 14 slzv43ko	84000	250000	7	\N	\N	\N	2026-03-25 01:43:34.138+00
e44b73b8-fb0e-4a72-a372-358db7d6fd35	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 15 q77k92gh	85000	250000	3	\N	\N	\N	2026-03-25 01:43:34.214+00
62b0ec8a-ba6d-4379-8df3-b22abf84d212	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 14 gokvjxzb	84000	250000	7	\N	\N	\N	2026-03-25 01:43:34.22+00
87b3b715-ce62-4455-ade5-f70fac0cd074	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 15 kajdjmqe	85000	250000	3	\N	\N	\N	2026-03-25 01:43:34.319+00
c2360825-ff3e-4e22-be70-bd07a2e649e0	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 15 4zpt2663	85000	250000	3	\N	\N	\N	2026-03-25 01:43:34.556+00
65d4b5f8-03a0-4a39-9eab-1f5ab03c0eec	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 16 wazfgsk4	86000	250000	4	\N	\N	\N	2026-03-25 01:43:34.72+00
51a4efb6-bf86-48f1-8cc2-d5312a6aad1d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 16 n1bwc5ao	86000	250000	4	\N	\N	\N	2026-03-25 01:43:35.014+00
b81e3050-d31d-4e89-8d77-c6db97e3af61	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 17 7ar7fyet	87000	250000	5	\N	\N	\N	2026-03-25 01:43:35.222+00
952e830e-9f45-42bd-91b4-43b4195ff0da	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 18 ob13ynbq	88000	250000	6	\N	\N	\N	2026-03-25 01:43:35.571+00
528b61ea-7a09-44cf-b9e0-989b044991ad	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 17 9s9rpqdf	87000	250000	5	\N	\N	\N	2026-03-25 01:43:35.877+00
a12f3a15-c084-4040-a7fc-c955b1504200	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 19 bj9x1fwx	89000	250000	7	\N	\N	\N	2026-03-25 01:43:36.573+00
f8152ae0-c1ad-4ab7-ad9e-823ccd23ab4c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 19 1jidn5j8	89000	250000	7	\N	\N	\N	2026-03-25 01:43:37.117+00
b3ca61a2-6bbc-4ba2-a776-bcd5b8557711	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 20 kcfaoehp	80000	250000	3	\N	\N	\N	2026-03-25 01:43:37.366+00
1a1589ad-3b91-4a03-a32a-e67d11523298	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 20 gm9n9ep7	80000	250000	3	\N	\N	\N	2026-03-25 01:43:37.827+00
0a700687-d6c2-43c0-8aa1-4ae566b7b6de	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 20 apepvmb2	80000	250000	3	\N	\N	\N	2026-03-25 01:43:37.903+00
eaf2a982-ab9a-4403-b45f-4ed24a39bbdb	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 21 dnkdm9wt	81000	250000	4	\N	\N	\N	2026-03-25 01:43:38.623+00
cd871ec6-e354-4d4c-944a-6809bf89c350	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 23 8rm23buo	83000	250000	6	\N	\N	\N	2026-03-25 01:43:39.29+00
d9abe942-dfac-45ed-ba45-00bbc6ca1dcf	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 24 k2irn9gp	84000	250000	7	\N	\N	\N	2026-03-25 01:43:39.943+00
be4ef4e6-4bb2-4836-9c6d-38db26a82e12	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 25 dkopl8id	85000	250000	3	\N	\N	\N	2026-03-25 01:43:40.582+00
3ce278b6-18a7-460e-ac8a-3c96e2596b01	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 25 ynkv3lam	85000	250000	3	\N	\N	\N	2026-03-25 01:43:40.774+00
6553108d-dc6c-421c-bbef-05810ecafc5e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 26 qtjus844	86000	250000	4	\N	\N	\N	2026-03-25 01:43:41.371+00
49659dac-a7b1-4cce-ae0b-a12b140a837e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 27 iommqk21	87000	250000	5	\N	\N	\N	2026-03-25 01:43:41.508+00
9a1f4b4a-6dd9-49c5-b532-4b18124fc9f8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 26 vck0gymf	86000	250000	4	\N	\N	\N	2026-03-25 01:43:41.619+00
5d0d444b-78e4-4639-8470-f0a004cdde8d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 27 op67t00r	87000	250000	5	\N	\N	\N	2026-03-25 01:43:41.947+00
072148da-6907-4ca6-b754-1ed9a97afddc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 34 ld6oq87x	84000	250000	7	\N	\N	\N	2026-03-24 18:06:48.026+00
e2b21115-5818-474a-8445-6bd76b276d6f	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 36 1y9a62go	86000	250000	4	\N	\N	\N	2026-03-24 18:06:48.523+00
472aaae9-d51a-437b-8e13-459741448104	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	k6 search 35 dcci1x7g	85000	250000	3	\N	\N	\N	2026-03-24 18:06:48.559+00
548134c2-c9b5-4c36-b128-7ca353b95cbc	682fe188-bad7-45b2-90bb-99a13d0547e9	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-24 18:11:06.859+00
11d857bb-0f8b-4ed0-b03d-f8c4e9b439e4	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:32.989+00
6687646e-b56d-4b26-941a-5ec2a456639c	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:32.987+00
50b51b2c-ed5e-4ca7-a0d2-5ce3aacfc3d2	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:32.994+00
ed5b11e4-481b-4f14-ae65-801345e09d10	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:33.722+00
317fd44e-0a94-4d2f-be38-82e30d17eca2	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:33.747+00
24464ad3-cdd4-4370-9fc3-02099fcefdbc	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:33.75+00
69851177-670a-4e65-8037-a842a667ea22	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:34.753+00
618de237-bfb6-48bb-86ed-45a096223b17	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:34.822+00
69327423-12ed-4f54-a4e1-b6df4277ea93	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:34.845+00
45110a5a-047d-4efa-b39d-c0d6a67704fb	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:35.613+00
1518f6db-50ad-40bc-af6e-2fc6666aea73	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:35.615+00
65ebed52-8e68-48aa-9632-eca84f511c68	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:35.616+00
4303c246-1f85-499a-b0e3-ba2ac54fe0c0	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:36.29+00
a77556a7-cf75-46f6-8f9b-6246f3b2d19a	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:36.292+00
0fb5ffd9-7da7-483a-82d7-df68e19628d8	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:36.294+00
2413065e-dbff-4da5-a1de-25466c9cea55	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:36.956+00
63384eda-0adc-4885-b4dd-70a8ea76dc3d	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:36.958+00
34e73a49-e517-47ab-8476-9642c8e0f2c9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:36.96+00
3602337b-14b5-41de-9c63-5d4a74d3d339	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:37.647+00
2154cb1a-1cb1-4f38-99f9-2b83416810a9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:37.649+00
f7fce33c-73e6-4410-a975-5e47978f0d7b	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:37.651+00
89f2a54f-e32f-4318-a569-b1da81b18b30	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:38.285+00
95715368-82b3-47b7-9ad5-586f4f6380b9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:38.315+00
4f8edda8-96ea-4927-ab16-302794ab426e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:38.322+00
bd8dcddf-1756-4dba-ad81-e5ad80766b64	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:39.424+00
49a39d63-9fb7-416f-9295-9d972e50f440	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:39.427+00
10fd68cf-0518-4fcf-9832-21801b35773d	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:39.429+00
9f0bbac5-fc1e-4670-8ae6-99abee5f1e90	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:40.107+00
7e4dc517-002b-44bc-b85b-91f9691158a1	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:40.11+00
592b3ec5-0ec2-4d93-a2fa-71d0e759f0f5	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:40.144+00
07b6be79-8005-4f1e-b8ec-be760b02e4c0	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:40.786+00
3f8cee1a-c7bd-4955-8f82-38d9658b6979	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:40.793+00
680f7177-dbc8-487a-aa35-dfb1db44bcad	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:40.88+00
d9040540-ce43-4318-972a-3c8df58acb7d	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:41.687+00
cf9c6395-6948-497b-b820-00aec069ffbb	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:41.697+00
2adf5e34-c21b-4918-9c27-23ce832fe556	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:41.776+00
e59c88d8-381f-418c-82a2-fb61b4fd4b54	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:42.302+00
5197a5c0-b406-4cc1-877e-4c8a121c8e37	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:42.312+00
c2ce81fb-8113-41a9-874a-e05e5fd4486e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:42.426+00
37d78e1d-54c4-488b-b32a-c9d9787c76ce	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:42.961+00
19393b3d-8277-489f-af25-dedb3c7b9d89	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:43.019+00
dd04971b-2c49-4784-bf99-62b8f50e92c9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:43.099+00
bf08f02e-31c0-4e7b-8f47-8a5b6120bbd1	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:43.646+00
610a28a6-af0a-41c4-a975-25e3de899ad6	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:43.723+00
db0a01af-4b68-4b5a-a641-a09e447c5ca0	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:43.748+00
7c8c5e59-ee2d-4b9e-8293-4082f45216fe	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:44.58+00
65d72656-f105-4c83-90db-b8f96746a091	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:44.582+00
ef79a4de-149d-4802-bac1-ae747732c2ac	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:44.69+00
0d6a48b4-241e-4534-bc0f-6c617fea5adf	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:45.223+00
cd74356f-e6fe-4b90-b099-f5787ba215fc	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:45.225+00
61ec39a6-1260-4411-8260-50a9ec00cf56	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:45.289+00
86ec885a-98de-4b55-a3cd-0ecab94d23bd	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:45.872+00
b1f218f9-05ab-4e14-aaa1-d3eebf5b7e61	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:45.873+00
39a24339-e385-44dd-9d49-f62bef42a59e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:45.923+00
d023ca5c-b753-490e-9efd-23f0399adadc	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:46.527+00
9089c40a-04c4-461c-a648-89e5db1c013c	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:46.53+00
e6e591cb-8fd5-4e47-9948-c34d47627058	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:46.579+00
b297b02b-fda3-4105-94b8-1d23fc7d8932	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:47.234+00
49bf7506-d48f-4c95-8df0-0089b1622492	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:47.239+00
16f9666d-1ace-4e6d-bab1-acc6a10ffce6	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:47.241+00
bf345ea4-6565-4e8c-95a0-d375f91a0009	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:47.949+00
dd160c6e-5244-4a7f-806c-87bbe0562ca8	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:47.977+00
7613d8b4-1ee0-4a73-bca1-76711fef8360	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:47.979+00
d13ef1b5-7f04-4d6b-a40e-268ab72dcf3b	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:48.649+00
edb4614d-eb5a-44ec-bdc2-ac3846ce0a82	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:48.652+00
df4adc33-0421-4b43-bbb9-693de71ec4f6	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:48.655+00
145fab6d-5fdc-494b-a54e-9c7a44d4ce72	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:49.686+00
fe693980-7802-4a54-a9dc-1d5125f6ccbd	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:49.687+00
b030db21-c2e9-445f-a2be-c466190dbe3a	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:49.689+00
c007350b-313b-4b41-bfd6-b97813e002d7	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:50.342+00
ee584635-a7fe-4850-a9a2-cfbc740aaba9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:50.344+00
8850e7ab-4527-4f7a-a47f-3661c108940a	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:50.346+00
5d0558f9-f4b2-4a8a-ae2b-75e3776a2973	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:51.02+00
92e20c6f-bbe4-46cc-be7d-a2593b0adf01	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:51.714+00
b63bfc82-7615-4f73-bfae-20bd5b1f2fe3	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:52.365+00
b9d43650-e97a-41b4-b35b-958c3ef4531e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:53.729+00
f153e723-fef5-4d48-bcea-858d10ff38be	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:54.66+00
30e4796f-d89d-48c5-96fd-df405ab6279e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:54.667+00
36478baa-0eff-43a6-96dd-fe6b52c15179	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:57.354+00
9a781725-8f2d-4688-9df9-e5a27ac588d3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 0 ks19y7jj	80000	250000	3	\N	\N	\N	2026-03-24 18:37:37.066+00
36e94d77-d734-4d81-b7c5-af9457465266	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 0 na8w1k60	80000	250000	3	\N	\N	\N	2026-03-24 18:37:37.077+00
3e246d69-4c6d-4f52-b231-8837d5501693	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 1 ionshqa0	81000	250000	4	\N	\N	\N	2026-03-24 18:37:37.802+00
1d0f8267-f519-449f-87e6-480f86684d3c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 3 1e13elod	83000	250000	6	\N	\N	\N	2026-03-24 18:37:39.351+00
7b3b448e-f004-4602-9765-7cb8d11cf7e5	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 12 rql5gdme	82000	250000	5	\N	\N	\N	2026-03-25 01:43:31.614+00
45d209b0-8575-4903-b349-70fda60f3cf2	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 16 cgzumcy4	86000	250000	4	\N	\N	\N	2026-03-25 01:43:34.558+00
60eebd60-fe47-43c8-877e-fac5e17cd92a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 15 a7hpcew8	85000	250000	3	\N	\N	\N	2026-03-25 01:43:34.711+00
54b0539f-1e35-4548-9414-020c7f6a8166	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 15 mylg2eag	85000	250000	3	\N	\N	\N	2026-03-25 01:43:34.719+00
c74b7d3e-05ec-46b9-a5f6-1c796dceac67	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 16 fpudd056	86000	250000	4	\N	\N	\N	2026-03-25 01:43:34.874+00
6ee47933-0976-4b95-ba4b-424b40700859	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 17 er32nnma	87000	250000	5	\N	\N	\N	2026-03-25 01:43:35.017+00
7c5f018c-7b52-4d0c-83fa-d03649eed98a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 16 nvargx5l	86000	250000	4	\N	\N	\N	2026-03-25 01:43:35.192+00
7d2532af-ef45-4bf7-aafd-726949b78950	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 16 2uxsngsg	86000	250000	4	\N	\N	\N	2026-03-25 01:43:35.205+00
6dac4e85-6709-4286-bc00-c611e9f0aab0	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 17 l0ksumcp	87000	250000	5	\N	\N	\N	2026-03-25 01:43:35.333+00
1c6820fd-e2db-4901-b02e-9d43b18c93f4	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 18 ane4ynyg	88000	250000	6	\N	\N	\N	2026-03-25 01:43:36.005+00
d8e51840-3e61-4a29-8296-cf675ec25ea1	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 18 hxaas5jh	88000	250000	6	\N	\N	\N	2026-03-25 01:43:36.418+00
a1f68738-f439-4b33-95e8-8045b6f52d42	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 18 jldt0aes	88000	250000	6	\N	\N	\N	2026-03-25 01:43:36.552+00
6fb2c18b-d196-46c8-8c1c-ae20c459c73e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 19 h580km86	89000	250000	7	\N	\N	\N	2026-03-25 01:43:37.118+00
3f244ccd-129d-475d-b783-20e902aaca91	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 20 u0vpqpx2	80000	250000	3	\N	\N	\N	2026-03-25 01:43:37.126+00
77da865a-1c7e-4645-9cbd-8bd9dc4e8845	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 20 zr84mic0	80000	250000	3	\N	\N	\N	2026-03-25 01:43:37.832+00
462fe8fd-77a9-4ac5-a20c-2250098467d7	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 21 scv9lmw6	81000	250000	4	\N	\N	\N	2026-03-25 01:43:37.905+00
883b215c-3d17-4ceb-887a-b1cd27c533df	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 21 04co4w4i	81000	250000	4	\N	\N	\N	2026-03-25 01:43:37.976+00
a0f5a279-4695-451a-91e3-211c397ea439	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 22 3w9evcd7	82000	250000	5	\N	\N	\N	2026-03-25 01:43:38.53+00
eb8dc38d-583b-45d7-9184-52da4501c4cf	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 21 el7uo2lg	81000	250000	4	\N	\N	\N	2026-03-25 01:43:38.618+00
37eb2433-5367-47e7-a90e-f62889005110	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 21 pvco7egb	81000	250000	4	\N	\N	\N	2026-03-25 01:43:38.625+00
853b87d2-868e-4222-a6e5-310e2bc55025	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 22 inj7j0ga	82000	250000	5	\N	\N	\N	2026-03-25 01:43:39.227+00
ab9af010-a930-4099-a94b-a34b65f85958	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 23 eiyd4mmb	83000	250000	6	\N	\N	\N	2026-03-25 01:43:39.286+00
f41ad63d-a4f6-44e6-8901-c5b18ed19af1	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 24 5b1af155	84000	250000	7	\N	\N	\N	2026-03-25 01:43:39.945+00
a1273078-c110-458d-8126-1d3990062dcb	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 24 nvclum1x	84000	250000	7	\N	\N	\N	2026-03-25 01:43:40.281+00
80729c84-2fee-4970-971b-29658a731e4f	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 24 lk481ljk	84000	250000	7	\N	\N	\N	2026-03-25 01:43:40.332+00
781ea9ac-f963-4515-85fd-e26ec2bff463	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 25 tvknvlr7	85000	250000	3	\N	\N	\N	2026-03-25 01:43:40.58+00
7aacf2cd-db24-435e-87d5-b27d4e149d73	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 25 q2g6ii2a	85000	250000	3	\N	\N	\N	2026-03-25 01:43:40.881+00
27b43f6c-867b-439d-b6c7-68ff40f06015	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 28 5x5vw4he	88000	250000	6	\N	\N	\N	2026-03-25 01:43:42.57+00
6d86d9bd-ccde-40c4-bae7-9f1976d1b4f0	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 27 kny2k49b	87000	250000	5	\N	\N	\N	2026-03-25 01:43:42.971+00
761b0ffc-f12f-4a81-b7ae-bf2ad2683a19	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 29 v8x4rrai	89000	250000	7	\N	\N	\N	2026-03-25 01:43:43.069+00
e8446e22-0e78-45fe-a486-80469ab2b37c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 29 oxbtqkci	89000	250000	7	\N	\N	\N	2026-03-25 01:43:43.175+00
6108e5e5-d57a-408f-8d45-83b89c91ffb5	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 29 9cz78i1y	89000	250000	7	\N	\N	\N	2026-03-25 01:43:45.381+00
8b41fe21-850f-443b-8d1f-b77c29ff0fb1	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 31 8q00eutu	81000	250000	4	\N	\N	\N	2026-03-25 01:43:45.473+00
9ed83de1-47b1-4131-915a-5db443a3fc72	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 31 gagy6sjw	81000	250000	4	\N	\N	\N	2026-03-25 01:43:46.483+00
3700f89f-c390-40ae-bb0b-d7863eef859b	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 32 5vju1oxf	82000	250000	5	\N	\N	\N	2026-03-25 01:43:46.571+00
f1e22140-45ed-4f6f-986e-5d723c9d2c12	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 33 ue0y3okr	83000	250000	6	\N	\N	\N	2026-03-25 01:43:47.493+00
ab2bbdd0-04c8-4add-89f9-2a36d6a91369	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 32 tpl5b1nm	82000	250000	5	\N	\N	\N	2026-03-25 01:43:47.543+00
24c20833-8824-4e17-a1d4-447033e2042d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 31 t3j4dkpz	81000	250000	4	\N	\N	\N	2026-03-25 01:43:47.648+00
0bf49172-2efb-4e2b-82f2-3b1d8d38590e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 33 729e81ey	83000	250000	6	\N	\N	\N	2026-03-25 01:43:47.668+00
c9ad0508-ce7b-4c6e-b79c-8bb3033b7589	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 5 2mfr5uuc	85000	250000	3	\N	\N	\N	2026-03-25 16:40:06.473+00
5a9d2f39-9da1-4553-86ad-db00247bd571	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 6 ytrnifxz	86000	250000	4	\N	\N	\N	2026-03-25 16:40:06.651+00
40a54c7e-e2db-477c-a63c-00d4bf6d2483	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 6 14fanywm	86000	250000	4	\N	\N	\N	2026-03-25 16:40:06.712+00
f0ddf14d-6b91-4592-838f-097c45620248	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 7 y6sayhei	87000	250000	5	\N	\N	\N	2026-03-25 16:40:09.251+00
eb5afc0e-9686-4d4e-95da-a6974b69c2f5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 8 qhwwvvzl	88000	250000	6	\N	\N	\N	2026-03-25 16:40:11.249+00
9bc04dac-8858-447d-9df2-93afc58df21d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 8 qthyc0z7	88000	250000	6	\N	\N	\N	2026-03-25 16:40:11.258+00
3ce377b0-f8b8-4ec2-b3fd-fd3a0b2a38da	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 8 dwp7q7c6	88000	250000	6	\N	\N	\N	2026-03-25 16:40:11.263+00
7e5f8c55-306c-4bd9-8b42-06cac5bc009d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 10 capsh111	80000	250000	3	\N	\N	\N	2026-03-25 16:40:13.25+00
04156b7b-b7dc-452f-ac64-753b9cfb8ecc	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 10 hj988m43	80000	250000	3	\N	\N	\N	2026-03-25 16:40:13.446+00
c759b849-ccfd-468a-a9bc-3a1b9e63df78	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 10 swa87txq	80000	250000	3	\N	\N	\N	2026-03-25 16:40:13.646+00
5b2708c9-1e00-42ab-b8a1-c3ef17da30f0	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 10 y9q9g3kq	80000	250000	3	\N	\N	\N	2026-03-25 16:40:13.843+00
39c2b967-7e9e-4a8d-9830-2c7e9b00025e	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 11 wttb5hq7	81000	250000	4	\N	\N	\N	2026-03-25 16:40:14.298+00
46c2ba06-5e55-4e75-ab8e-c4d0d44c92c1	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 11 2rb1ycw2	81000	250000	4	\N	\N	\N	2026-03-25 16:40:14.421+00
e2c629d6-adbe-4ee4-838a-b61da59db130	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 12 5k4ttwac	82000	250000	5	\N	\N	\N	2026-03-25 16:40:14.652+00
d51baa68-c595-4003-9377-27c2d6ebaf03	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 13 vhs9hsg9	83000	250000	6	\N	\N	\N	2026-03-25 16:40:15.417+00
1fb6d220-f20a-4643-a0ad-ec84568fca5a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 14 xnojwq86	84000	250000	7	\N	\N	\N	2026-03-25 16:40:16.413+00
d19cbd26-96b2-4d7d-adc7-560734d60c15	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 15 ipsouavh	85000	250000	3	\N	\N	\N	2026-03-25 16:40:16.478+00
4a91f16d-a457-4d70-a4a9-e99cf42592d1	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 15 tbgzhas1	85000	250000	3	\N	\N	\N	2026-03-25 16:40:16.526+00
57a29b5c-33c5-4626-ac64-c296640eb8c4	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 15 o7rwnrah	85000	250000	3	\N	\N	\N	2026-03-25 16:40:16.917+00
e57f6edf-8eab-4be2-bb87-58fc19900406	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:51.022+00
e9a47d26-eb6f-44a1-bb0b-7bbf5306bc71	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:51.717+00
05320c2e-3353-4f70-b4be-286bb656b3d1	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:52.363+00
d157fa0c-716a-4ac7-98ef-10ff9c23bd84	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:52.367+00
542a10ec-3886-4594-b111-6d6309962be9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:53.008+00
48315ed6-8486-4daa-b07e-f68a1e5c7ece	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:53.749+00
193e7750-7a43-4538-9a98-3d7f98e49be2	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:55.307+00
70c69b87-0db3-418f-88e4-5eb57e4a74b9	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:55.314+00
d5a2c753-131b-4aec-89c3-a9edeec47da2	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:55.32+00
55526a73-53b0-4216-a76f-9b42f6ff5a78	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:56.722+00
d97b1804-dffb-4a2b-b4b5-49aba84362e5	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 0 3fxi0lcf	80000	250000	3	\N	\N	\N	2026-03-24 18:37:37.074+00
cf241460-0771-41ab-8658-100ab3a46e06	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 0 semg2rs5	80000	250000	3	\N	\N	\N	2026-03-24 18:37:37.078+00
22f5d79b-0fed-4867-b370-03c261383872	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 0 x85vgw5n	80000	250000	3	\N	\N	\N	2026-03-24 18:37:37.089+00
afe9518b-f73c-4115-988f-e9e7d3d074a3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 1 whtpbsad	81000	250000	4	\N	\N	\N	2026-03-24 18:37:37.723+00
64544145-ae9a-46b1-ac66-a011dc26be5b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 1 9ffp2nfx	81000	250000	4	\N	\N	\N	2026-03-24 18:37:37.739+00
f90cf399-d12c-4007-9b7c-1a25b3f1bc3f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 1 8x5kpunn	81000	250000	4	\N	\N	\N	2026-03-24 18:37:37.799+00
46876100-31b7-4eff-9546-e925af0116ca	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 2 bgj5a3r3	82000	250000	5	\N	\N	\N	2026-03-24 18:37:38.381+00
f7133d59-abe5-4828-8641-74b98466ffd3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 2 dfzkld82	82000	250000	5	\N	\N	\N	2026-03-24 18:37:38.447+00
1e46ccbd-4fdb-4ce4-a067-5b818b000b0e	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 3 w8k73o2a	83000	250000	6	\N	\N	\N	2026-03-24 18:37:38.949+00
c1653c66-7fd5-43c5-b7bf-fdd74372cb47	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 3 78ihmbcc	83000	250000	6	\N	\N	\N	2026-03-24 18:37:39.145+00
00a6a48f-c8a7-402c-86f0-b931eb2705be	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 3 misd19wz	83000	250000	6	\N	\N	\N	2026-03-24 18:37:39.259+00
31ef82f9-3d6d-464b-b769-259727f37ffe	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 3 0blylo2u	83000	250000	6	\N	\N	\N	2026-03-24 18:37:39.349+00
60f477ef-33db-4cea-9211-6c1c08bb9e0b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 3 3ekp1fos	83000	250000	6	\N	\N	\N	2026-03-24 18:37:39.39+00
d2543ce5-c168-4039-9ac4-75c87a8a5a82	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 4 wuox5hls	84000	250000	7	\N	\N	\N	2026-03-24 18:37:39.948+00
4148f022-78dc-4c04-84e6-1870542d9811	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 4 q33y5nzm	84000	250000	7	\N	\N	\N	2026-03-24 18:37:39.961+00
bdcd672f-088f-4e39-b8e6-afefdd1606e9	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 4 9w52iqzk	84000	250000	7	\N	\N	\N	2026-03-24 18:37:39.988+00
e64ca48b-a230-4208-876f-9ba60922b86f	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 28 yvdkedlp	88000	250000	6	\N	\N	\N	2026-03-25 01:43:42.376+00
7f4bb8d0-d74a-4f69-bc9f-00c43a8964c6	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 28 lyig6r41	88000	250000	6	\N	\N	\N	2026-03-25 01:43:42.973+00
004927ae-5223-40c5-8297-ac262b7c0f2c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 28 quj384la	88000	250000	6	\N	\N	\N	2026-03-25 01:43:43.068+00
5f121cd5-83aa-4b47-b25a-217409466b2c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 28 rniptqii	88000	250000	6	\N	\N	\N	2026-03-25 01:43:44.34+00
e18f4cce-8db8-4d86-8872-0cd7e7bedb46	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 29 w7kzj6go	89000	250000	7	\N	\N	\N	2026-03-25 01:43:44.441+00
8059ac96-2c15-4b07-add8-bd36109232a9	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 30 r754ydmo	80000	250000	3	\N	\N	\N	2026-03-25 01:43:44.467+00
edea30f9-7fba-4e11-a783-c9de64d3156d	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 30 2u4o1wqp	80000	250000	3	\N	\N	\N	2026-03-25 01:43:44.681+00
e06932ac-f509-46fd-bfb3-c811856f3f8a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 31 gmraux5g	81000	250000	4	\N	\N	\N	2026-03-25 01:43:45.375+00
91917f12-03ca-4951-a2a9-aaefcd82df8b	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 32 7gbkska7	82000	250000	5	\N	\N	\N	2026-03-25 01:43:46.48+00
67c7d9d2-cc7d-4d6d-a2b9-58317782721c	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 32 z2u8o3zt	82000	250000	5	\N	\N	\N	2026-03-25 01:43:47.673+00
26bf4f84-16d9-49b3-9a97-9e859ec646f6	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 34 00emzt6o	84000	250000	7	\N	\N	\N	2026-03-25 01:43:48.328+00
10999a23-621c-4645-baf0-46e78b4323bf	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 33 earj666l	83000	250000	6	\N	\N	\N	2026-03-25 01:43:48.467+00
4cdd3555-7feb-413a-8ee8-684c698fe029	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 32 9m1fpxuf	82000	250000	5	\N	\N	\N	2026-03-25 01:43:48.518+00
2aae095c-8665-4ac1-860b-048f992a7c3c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 9 hjrko959	89000	250000	7	\N	\N	\N	2026-03-25 16:40:12.661+00
771c6c0d-2bbd-4c66-ad87-46883b75066f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 10 nm6jez5q	80000	250000	3	\N	\N	\N	2026-03-25 16:40:13.448+00
5ed0ec87-9bb6-4a06-8460-230296c176d2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 11 jdqeo01x	81000	250000	4	\N	\N	\N	2026-03-25 16:40:14.296+00
b37280dd-1cc4-44bd-86f8-b57e2b271c6a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 11 ap8wmp4c	81000	250000	4	\N	\N	\N	2026-03-25 16:40:14.442+00
26dfb2d1-5c1d-4cc7-822f-3f82fa563e61	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 12 09piimdu	82000	250000	5	\N	\N	\N	2026-03-25 16:40:14.966+00
c6305dfd-6846-44e7-8e45-f219b8cdcdc8	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 12 sjpf9h44	82000	250000	5	\N	\N	\N	2026-03-25 16:40:14.974+00
36f22cdb-7ef7-480f-ad66-2eebee21fcce	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 12 b7upmxnr	82000	250000	5	\N	\N	\N	2026-03-25 16:40:15.191+00
bbd49e93-068c-4c9a-94a7-c04edb9859f8	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 12 3xyc5y0l	82000	250000	5	\N	\N	\N	2026-03-25 16:40:15.195+00
64edc4f2-4d1e-4e89-a256-a191123faf2b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 13 d5jpit35	83000	250000	6	\N	\N	\N	2026-03-25 16:40:15.235+00
56174776-efaf-4e7c-b77e-2bca2a000390	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 13 rxazdjln	83000	250000	6	\N	\N	\N	2026-03-25 16:40:15.418+00
85d0ea63-822e-44d2-a024-bde0f9150cc5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 14 i5d3l85g	84000	250000	7	\N	\N	\N	2026-03-25 16:40:15.952+00
5e4c5afe-9db1-4292-a459-c54e22a5f305	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 14 uggxhue4	84000	250000	7	\N	\N	\N	2026-03-25 16:40:16.306+00
cf1ac159-bf8b-4f22-a737-4cf973b1d630	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 15 ao8zckai	85000	250000	3	\N	\N	\N	2026-03-25 16:40:16.534+00
4baf5059-2bb2-4fca-b1db-a6b69b04953d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 16 pn64d3e5	86000	250000	4	\N	\N	\N	2026-03-25 16:40:17.19+00
89c510f5-2398-444f-ad92-ed15a9831a53	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 16 k5k5jdrs	86000	250000	4	\N	\N	\N	2026-03-25 16:40:17.192+00
acb38e80-0b25-49c2-8421-8851653fb837	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 17 dmwv2lvm	87000	250000	5	\N	\N	\N	2026-03-25 16:40:18.045+00
3feea3e9-380e-4cfa-8bbe-7463b4c2cd72	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 17 0uo0yi0p	87000	250000	5	\N	\N	\N	2026-03-25 16:40:18.64+00
35dfab80-32a4-4f3a-ba47-20c762d73dee	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 17 h7tyi0wx	87000	250000	5	\N	\N	\N	2026-03-25 16:40:18.934+00
c6703659-bee6-4fb3-b52f-a21187431232	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 18 nq75wecd	88000	250000	6	\N	\N	\N	2026-03-25 16:40:19.371+00
51153c6b-6306-4654-a1f5-e738e2efe1fa	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 18 yq5lorpd	88000	250000	6	\N	\N	\N	2026-03-25 16:40:19.662+00
b035c789-86a1-4e96-8b15-ca2da56b8e31	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 19 urm2ia73	89000	250000	7	\N	\N	\N	2026-03-25 16:40:19.787+00
24c2ebf4-b33d-47d3-823c-33b4d399395c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 20 l991riah	80000	250000	3	\N	\N	\N	2026-03-25 16:40:20.594+00
cb65908c-03bc-4f97-9c6a-64bb1db5ae5d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 20 oxfxo98v	80000	250000	3	\N	\N	\N	2026-03-25 16:40:20.869+00
b847c7f1-8fb1-4c03-adaf-6dd7ae1cd4c7	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 21 27lxac2l	81000	250000	4	\N	\N	\N	2026-03-25 16:40:22.26+00
34a643c8-442b-4e90-a646-965f32259141	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 21 43zmt1hz	81000	250000	4	\N	\N	\N	2026-03-25 16:40:23.052+00
d89e956b-5a22-4280-8a2d-0f7a2e48f0f6	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 22 01f0uhfw	82000	250000	5	\N	\N	\N	2026-03-25 16:40:23.461+00
41237834-2aa7-40c6-9ded-e8658a7106a2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 22 9ycz4ccw	82000	250000	5	\N	\N	\N	2026-03-25 16:40:23.94+00
64ce6155-29f5-4d4b-b7b4-e2949c300359	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 22 hdp42typ	82000	250000	5	\N	\N	\N	2026-03-25 16:40:24.145+00
53b7b56f-9f42-47eb-a14c-6368b9d36c34	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 23 qgb57939	83000	250000	6	\N	\N	\N	2026-03-25 16:40:24.301+00
215fee95-80d1-416b-aa1f-23ce45fb53f2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 23 faldx531	83000	250000	6	\N	\N	\N	2026-03-25 16:40:24.423+00
99ba3d5f-dcc4-4c8e-a1db-bccf94b0b938	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 23 2pclqc45	83000	250000	6	\N	\N	\N	2026-03-25 16:40:24.651+00
26d2213e-524f-4183-aaf2-3be5a3af7f35	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 24 pn1tgjrw	84000	250000	7	\N	\N	\N	2026-03-25 16:40:24.764+00
fcfac305-4e52-4cec-aef1-72d6ca71d28d	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:51.024+00
0c3d7216-c7ef-4707-b609-802d13262fef	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:51.716+00
bd46b0b9-3b9b-4b4b-b194-3e6886a61d02	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:52.994+00
02fcda5d-7a24-4af3-86aa-e55ab37f5e5e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:53.005+00
a84bef6d-aaa8-49f6-913b-6278e9724122	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:53.747+00
2262b6ed-e4cf-4449-b58d-aa09b424013f	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:54.669+00
437ec6cb-0412-42c2-9251-2c063df0995e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:55.932+00
ed81691e-87bd-41dd-8954-9a47b479d16e	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:55.939+00
43e83108-a3a2-41d3-be7a-07a7c73e35f8	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:55.95+00
cda387bd-b55a-4179-b864-c92aeb186cfe	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:56.692+00
2d84bc54-a26e-433e-8e55-462a1f7d1e08	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:56.702+00
ce13c44e-e389-43d3-987a-fb76cfb9c111	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:57.355+00
acffb187-92aa-4793-a9b0-df5a192a9eb4	9da94f17-e9e4-4e73-8834-0c5988008c53	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 18:36:57.374+00
1db78536-196e-44a0-9c93-9c05122708e1	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 0 45cljjhh	80000	250000	3	\N	\N	\N	2026-03-24 18:37:37.07+00
7050ff7f-7638-42c4-9c78-acc1250c4439	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 1 xveplvk3	81000	250000	4	\N	\N	\N	2026-03-24 18:37:37.766+00
f7f22da0-4793-4359-bc0c-92b55c1f94c2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 1 lut8siw8	81000	250000	4	\N	\N	\N	2026-03-24 18:37:37.797+00
0f000e3f-712f-4b2c-a6c4-2e5a0f7584b8	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 2 mce0ahux	82000	250000	5	\N	\N	\N	2026-03-24 18:37:38.286+00
eb8fd54e-34fb-464f-8c69-a3daa47dd026	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 2 l8l3yfb8	82000	250000	5	\N	\N	\N	2026-03-24 18:37:38.379+00
bc7b1b26-2a5b-4a1f-adb4-92fdd979bb53	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 2 11yhxpvc	82000	250000	5	\N	\N	\N	2026-03-24 18:37:38.42+00
3dd67c46-7599-4418-bda6-cb05b3821a9d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 2 wb39i7id	82000	250000	5	\N	\N	\N	2026-03-24 18:37:38.429+00
85d21563-75e7-4e15-997c-2fdd8525d2bf	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 4 6vwxj4c3	84000	250000	7	\N	\N	\N	2026-03-24 18:37:39.893+00
a1f7dc7f-375f-47cf-9b23-fc8c7eed93c2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 4 q46sixxj	84000	250000	7	\N	\N	\N	2026-03-24 18:37:39.936+00
b993e7bd-48de-426e-8e4c-2332b75a6dd8	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 4 b5wpf6fe	84000	250000	7	\N	\N	\N	2026-03-24 18:37:39.947+00
0d00054e-d501-44f3-b28e-3502dd76e17e	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 5 skvld8zl	85000	250000	3	\N	\N	\N	2026-03-24 18:37:40.574+00
50c5c96b-47d8-429b-82d6-55b35eed55b6	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 5 wssbgy4y	85000	250000	3	\N	\N	\N	2026-03-24 18:37:40.584+00
ba8c2272-21a8-4bf0-90d0-6cc853b493d2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 5 31v3mmp5	85000	250000	3	\N	\N	\N	2026-03-24 18:37:40.585+00
df005aeb-5e27-46ce-be8a-d8af4bef172f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 5 259izkzj	85000	250000	3	\N	\N	\N	2026-03-24 18:37:40.629+00
fe5aaa9c-d2ed-4fd6-bc54-138606b6badc	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 5 cva00rjg	85000	250000	3	\N	\N	\N	2026-03-24 18:37:40.631+00
e0d67184-504c-431e-9f06-c7cfbeb7f25b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 5 bl2i3bgp	85000	250000	3	\N	\N	\N	2026-03-24 18:37:40.633+00
a6db9506-f7f3-4871-af8a-63cf58c80136	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 6 ofzkt6sn	86000	250000	4	\N	\N	\N	2026-03-24 18:37:41.156+00
fec71e96-48d1-44bd-9cdc-62c45439ad68	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 6 z5bznt3d	86000	250000	4	\N	\N	\N	2026-03-24 18:37:41.191+00
f81a5f06-6bb9-46b9-b318-28b90ff53433	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 6 yh04k306	86000	250000	4	\N	\N	\N	2026-03-24 18:37:41.253+00
da625f52-49bd-4fe9-b7d7-a7bd3312f63c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 6 warwmebg	86000	250000	4	\N	\N	\N	2026-03-24 18:37:41.256+00
1e10bd87-506d-4405-a4a1-9b477f456ecc	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 6 2r0x014k	86000	250000	4	\N	\N	\N	2026-03-24 18:37:41.259+00
e2679857-67fe-4d24-968c-b3b5556318f2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 6 6vmj21kj	86000	250000	4	\N	\N	\N	2026-03-24 18:37:41.282+00
f9db6905-05f9-417d-9899-6bee5b88e87c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 7 ut5epctr	87000	250000	5	\N	\N	\N	2026-03-24 18:37:41.689+00
7dc31057-4ed2-4855-a457-d6a4a686a375	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 7 hlfu86v2	87000	250000	5	\N	\N	\N	2026-03-24 18:37:41.797+00
bfd2eb96-ba20-4322-84e9-a6d24c1b6f67	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 7 l0fvmzce	87000	250000	5	\N	\N	\N	2026-03-24 18:37:41.894+00
7a0fdae8-bd4d-434c-81b1-63aa6931b683	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 7 vews71wz	87000	250000	5	\N	\N	\N	2026-03-24 18:37:41.896+00
c136f1cc-c9e2-4326-aebc-5323ff8d833a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 7 tbv03x6p	87000	250000	5	\N	\N	\N	2026-03-24 18:37:41.898+00
118eadcf-1f79-4758-b403-c7a9df33ee5f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 7 csjj3joa	87000	250000	5	\N	\N	\N	2026-03-24 18:37:41.9+00
f6dcb0f8-0885-40d4-a8c8-3792e4b075c1	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 8 j5qed5ro	88000	250000	6	\N	\N	\N	2026-03-24 18:37:42.122+00
90dcf57f-e082-4416-b850-f69f810c8ecb	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 8 5fx21d30	88000	250000	6	\N	\N	\N	2026-03-24 18:37:42.246+00
9de27331-5650-415a-a5f7-5d34a298e7c9	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 8 5i19s7oi	88000	250000	6	\N	\N	\N	2026-03-24 18:37:42.389+00
4ca0fc83-b380-4489-b4eb-85df6f8366b1	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 8 gmstz4kg	88000	250000	6	\N	\N	\N	2026-03-24 18:37:42.448+00
360e684e-0477-4386-b229-fe4fffbfcb3d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 8 vf89xjuu	88000	250000	6	\N	\N	\N	2026-03-24 18:37:42.45+00
4a7db53d-32e3-4817-8342-9bf71420c143	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 8 netezija	88000	250000	6	\N	\N	\N	2026-03-24 18:37:42.451+00
87a3125d-1f68-4768-876a-fd62356b6834	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 9 4et7vekg	89000	250000	7	\N	\N	\N	2026-03-24 18:37:42.547+00
917398d2-329c-4027-9c56-2450f96acd04	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 9 l1ebagd2	89000	250000	7	\N	\N	\N	2026-03-24 18:37:42.651+00
e209621e-d71d-4923-9467-6236d73eda94	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 9 ul04ewu1	89000	250000	7	\N	\N	\N	2026-03-24 18:37:42.825+00
7a84e1cb-d175-4a4e-9e05-e568ba199d2e	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 9 l9c4qx73	89000	250000	7	\N	\N	\N	2026-03-24 18:37:42.954+00
eefbcaec-9bbf-43e4-a0a2-cba5d09ac376	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 9 brgod3jz	89000	250000	7	\N	\N	\N	2026-03-24 18:37:42.957+00
000d5eab-9503-4c6f-899b-936e2007b168	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 9 k5w55s9z	89000	250000	7	\N	\N	\N	2026-03-24 18:37:42.959+00
ea045c32-e7a6-4b77-89ee-0ae7720283bc	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 10 c8h41nwf	80000	250000	3	\N	\N	\N	2026-03-24 18:37:43.056+00
553b84b2-e7a4-42ba-87cd-323082c0a095	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 10 lklrw3xa	80000	250000	3	\N	\N	\N	2026-03-24 18:37:43.154+00
178f1b10-579b-466d-9752-d42c19303256	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 10 6xwzomo5	80000	250000	3	\N	\N	\N	2026-03-24 18:37:43.258+00
03eaf154-498b-4ad0-b285-0c4aab0682f7	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 10 zce1yxe0	80000	250000	3	\N	\N	\N	2026-03-24 18:37:43.547+00
c68338ba-830d-48fd-b210-91a2d7e0f180	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 10 p4v4zkrg	80000	250000	3	\N	\N	\N	2026-03-24 18:37:43.646+00
0ab41223-2925-4e7a-9dfa-39de116e5cfd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 10 vqjrgmap	80000	250000	3	\N	\N	\N	2026-03-24 18:37:43.648+00
4bea54cd-bc1c-4707-97cf-c93d72b91525	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 11 aeu1j3mq	81000	250000	4	\N	\N	\N	2026-03-24 18:37:43.752+00
01628239-e9c8-49d8-b948-dfb9c272e56f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 11 ggskkroy	81000	250000	4	\N	\N	\N	2026-03-24 18:37:43.849+00
ba41d032-d1c0-4b2f-af94-90f30df0aa43	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 11 7ow2xgw2	81000	250000	4	\N	\N	\N	2026-03-24 18:37:43.949+00
004b1aa9-fc76-421f-9f70-708169ba5689	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 11 7el1d4kp	81000	250000	4	\N	\N	\N	2026-03-24 18:37:44.352+00
69576cc3-89b4-4b1c-9bf2-3d92dea669a6	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 11 ojp8xcrt	81000	250000	4	\N	\N	\N	2026-03-24 18:37:44.649+00
24343c93-a54d-4f37-bbe0-abdf55c6998b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 11 n1fq6gv6	81000	250000	4	\N	\N	\N	2026-03-24 18:37:44.652+00
48c9ca5e-be59-487b-9a97-c1f150303b8f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 12 m8h18rag	82000	250000	5	\N	\N	\N	2026-03-24 18:37:44.753+00
878eac9d-fea3-402c-b22a-9ee8de8cc0ea	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 12 null8j12	82000	250000	5	\N	\N	\N	2026-03-24 18:37:44.852+00
14f9ebc4-663c-4872-87fb-db75d5471dfc	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 12 mrjwkfbs	82000	250000	5	\N	\N	\N	2026-03-24 18:37:44.858+00
6e17419f-fd73-4391-8183-59ba62b3322b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 12 4dxu7b3a	82000	250000	5	\N	\N	\N	2026-03-24 18:37:45.132+00
988118b0-522c-4507-82ea-0a1ce4dcf60d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 12 g3fzlmx9	82000	250000	5	\N	\N	\N	2026-03-24 18:37:45.311+00
d07db71d-5f63-412a-8f37-72b84bb486a7	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 12 ta73ot65	82000	250000	5	\N	\N	\N	2026-03-24 18:37:45.454+00
14944abf-2b96-47ce-b324-6165d756d650	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 13 8hx0zt4l	83000	250000	6	\N	\N	\N	2026-03-24 18:37:45.534+00
b4209c3a-b7a4-4725-b4d6-860591ec8dff	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 13 8fp4wnf6	83000	250000	6	\N	\N	\N	2026-03-24 18:37:45.538+00
f7a58571-15a3-4ff3-8243-457267216d41	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 13 b9q60xgw	83000	250000	6	\N	\N	\N	2026-03-24 18:37:45.622+00
258e29e5-8b08-4f23-838d-371085a9ba5a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 14 f176rvsx	84000	250000	7	\N	\N	\N	2026-03-24 18:37:46.158+00
d79642ff-127f-4572-b501-6f9f4b68fe1d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 15 k4dyakhf	85000	250000	3	\N	\N	\N	2026-03-24 18:37:46.815+00
b6f6c504-afdf-4db3-b9a2-5eb638f41aa0	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 16 uka5gncf	86000	250000	4	\N	\N	\N	2026-03-24 18:37:47.423+00
e8c2b311-49d5-4e6d-a391-43430e77be72	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 16 0mekbaec	86000	250000	4	\N	\N	\N	2026-03-24 18:37:47.448+00
6de3be2c-8cca-4a37-b796-039f7eb474e9	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 16 se4zp2vq	86000	250000	4	\N	\N	\N	2026-03-24 18:37:47.455+00
3affe8d4-bae8-4966-8d16-33faac36b67b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 17 c55m67kr	87000	250000	5	\N	\N	\N	2026-03-24 18:37:48.17+00
7ec956ec-7705-4c15-a270-6a7b45a760dc	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 17 c8qi5h7k	87000	250000	5	\N	\N	\N	2026-03-24 18:37:48.45+00
d22c93d2-f519-4a27-945d-0c6729a98917	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 18 csyad3ud	88000	250000	6	\N	\N	\N	2026-03-24 18:37:48.955+00
ca653f97-e284-4d65-9501-24bf54845415	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 18 z2tc24hx	88000	250000	6	\N	\N	\N	2026-03-24 18:37:48.959+00
211a9164-b6f0-48af-85f8-5baaedeef817	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 19 m23ffzj3	89000	250000	7	\N	\N	\N	2026-03-24 18:37:49.983+00
554fbd1f-c65a-4213-80cf-ba16098bb7e1	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 19 k92txw2o	89000	250000	7	\N	\N	\N	2026-03-24 18:37:49.988+00
03ca1186-2651-4bfe-b55d-46afa4e9da53	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 19 rim800d5	89000	250000	7	\N	\N	\N	2026-03-24 18:37:50.045+00
f4df4fef-bf4b-4cfd-bf18-8b4f5d1066f3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 19 k5sjlto0	89000	250000	7	\N	\N	\N	2026-03-24 18:37:50.113+00
89e3bc32-b97b-47bc-a209-638ab9ed2238	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 20 0k9w2kdh	80000	250000	3	\N	\N	\N	2026-03-24 18:37:50.625+00
2ffce93f-4502-4b82-95ae-7d3cf5e8a77a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 20 xe0jzeoo	80000	250000	3	\N	\N	\N	2026-03-24 18:37:50.72+00
fcdc4c79-49a8-45df-b827-1967fee5d8a2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 21 8kiqa1b6	81000	250000	4	\N	\N	\N	2026-03-24 18:37:51.203+00
bea1dc63-3ecb-4bbe-8c2f-ce502e48d874	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 21 ni19d628	81000	250000	4	\N	\N	\N	2026-03-24 18:37:51.27+00
295beea9-0e2b-41d8-9e6d-2bc49b5a206a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 21 d0wnpm91	81000	250000	4	\N	\N	\N	2026-03-24 18:37:51.333+00
2c57626f-24f8-40b0-8cc7-c7d5ccf63cc7	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 21 txko0v4c	81000	250000	4	\N	\N	\N	2026-03-24 18:37:51.346+00
48e7f855-6c8c-4354-ba72-31ff43a1d750	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 22 fo7xjlsd	82000	250000	5	\N	\N	\N	2026-03-24 18:37:51.86+00
89f80c5c-b40b-4786-bb40-be639459b6d7	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 22 u59flm5v	82000	250000	5	\N	\N	\N	2026-03-24 18:37:51.868+00
0c0e7c52-c672-46d3-9e13-e719d59e9ed3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 23 c7wefh72	83000	250000	6	\N	\N	\N	2026-03-24 18:37:52.127+00
38c8c8fe-5748-4f3e-899b-da4ffda2fbef	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 23 wkt8v82p	83000	250000	6	\N	\N	\N	2026-03-24 18:37:52.439+00
4d6ba9fe-ab03-403a-9376-51d5bb323cbb	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 24 q73gwgvq	84000	250000	7	\N	\N	\N	2026-03-24 18:37:52.621+00
3ae4a323-a42c-4775-aea3-7a7cf5c6d78f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 25 8nlt27wk	85000	250000	3	\N	\N	\N	2026-03-24 18:37:53.25+00
973b77c4-2d9e-45a9-906a-44366c76a395	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 25 wpxivvc9	85000	250000	3	\N	\N	\N	2026-03-24 18:37:53.525+00
d712e813-26d8-4441-9175-3facc060cc6c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 25 xh7aljky	85000	250000	3	\N	\N	\N	2026-03-24 18:37:53.548+00
d87f855a-16dd-4455-b488-97f014c24767	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 26 zxkg345k	86000	250000	4	\N	\N	\N	2026-03-24 18:37:53.649+00
3ddedf2d-ec5d-4345-ab90-7600bea6765d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 26 2l29q252	86000	250000	4	\N	\N	\N	2026-03-24 18:37:53.747+00
f05ef1a0-94f1-4d85-8922-8c98a49ab9b9	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 26 2n2igh7l	86000	250000	4	\N	\N	\N	2026-03-24 18:37:54.346+00
f63d0292-ac3d-43a0-b61c-45d34abf95d7	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 26 ftfpdi6f	86000	250000	4	\N	\N	\N	2026-03-24 18:37:54.379+00
0d050b9a-4f2e-4bd2-8a3e-867089eaf37c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 26 p890eu1v	86000	250000	4	\N	\N	\N	2026-03-24 18:37:54.447+00
4a201b7d-fa5c-4c13-8721-7271f28fec7d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 28 pc725zqz	88000	250000	6	\N	\N	\N	2026-03-24 18:37:55.261+00
e34dde9e-9096-4bd3-8dd6-7b80b778df26	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 28 4wdevh35	88000	250000	6	\N	\N	\N	2026-03-24 18:37:55.418+00
ea5004d0-6dff-4ef5-8168-e8db1b95e073	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 29 piv9hl0n	89000	250000	7	\N	\N	\N	2026-03-24 18:37:55.474+00
4c633f67-510a-4ad6-8c30-d1fa243700f4	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 29 10gu8dka	89000	250000	7	\N	\N	\N	2026-03-24 18:37:55.548+00
db18946b-548f-4117-bde9-2c9b9cd9538a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 29 p0jn0vnr	89000	250000	7	\N	\N	\N	2026-03-24 18:37:55.68+00
60d9ede7-26bd-4500-a840-1443c09a5699	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 30 qs4mmfe5	80000	250000	3	\N	\N	\N	2026-03-24 18:37:56.189+00
9a60309c-4a0a-4cf3-a526-f5ac3e7bd206	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 31 zsb9117l	81000	250000	4	\N	\N	\N	2026-03-24 18:37:56.551+00
91d7b0b7-d208-474d-af92-99cf477259d2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 31 hesbsj4n	81000	250000	4	\N	\N	\N	2026-03-24 18:37:56.649+00
0fe0d2c7-575d-4ea7-912c-b6d78979afcc	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 31 l1swu84f	81000	250000	4	\N	\N	\N	2026-03-24 18:37:56.825+00
92c45484-429e-4455-bd5b-b9f4521dca24	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 32 t6z5380d	82000	250000	5	\N	\N	\N	2026-03-24 18:37:58.82+00
19269ea1-483f-4d68-bd01-4d6a8411c411	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 32 itrsmymk	82000	250000	5	\N	\N	\N	2026-03-24 18:38:00.206+00
f2d4ca3c-6fd1-4d86-884d-75c6de3c1735	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 32 keyxdkcs	82000	250000	5	\N	\N	\N	2026-03-24 18:38:00.271+00
e2395cb9-73a8-46a2-8365-d7a4e4f22227	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 33 ut5qpr6r	83000	250000	6	\N	\N	\N	2026-03-24 18:38:00.729+00
61e12fbd-f2cb-439b-9e11-9dff751236ef	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 33 ej6srmw4	83000	250000	6	\N	\N	\N	2026-03-24 18:38:00.77+00
c96f92a4-d49b-4f56-921c-b8136be8ac4b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 33 rbe4b3lx	83000	250000	6	\N	\N	\N	2026-03-24 18:38:00.856+00
43b7856c-bd98-4f7d-bb94-b1bfbe119aef	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 34 h34s3spk	84000	250000	7	\N	\N	\N	2026-03-24 18:38:01.385+00
1ab7a72e-2cdd-4ce7-9297-b5e08948c661	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 34 oylhp5ys	84000	250000	7	\N	\N	\N	2026-03-24 18:38:01.486+00
9151efae-ae40-449a-a998-10f03908c3d5	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 35 1ga9atin	85000	250000	3	\N	\N	\N	2026-03-24 18:38:02.026+00
17bbcbb3-9d59-4c44-9467-ce6f59a279bb	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 37 rbfe0c99	87000	250000	5	\N	\N	\N	2026-03-24 18:38:02.857+00
84b043df-f0ef-4c4d-a8d4-8f92e6c8e917	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 38 knsitw15	88000	250000	6	\N	\N	\N	2026-03-24 18:38:03.284+00
004f4f68-ee56-4b06-89f0-18b1e8264036	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 38 rimxveqn	88000	250000	6	\N	\N	\N	2026-03-24 18:38:03.849+00
086461a9-a701-497c-8e86-9ba5d24ef558	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 39 75q2ymjy	89000	250000	7	\N	\N	\N	2026-03-24 18:38:04.455+00
c319eab9-43ac-4912-916a-6fd66dd7ecba	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 39 6sw3olht	89000	250000	7	\N	\N	\N	2026-03-24 18:38:04.548+00
35137bd6-4245-4b43-996d-43a3e5921198	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 29 tcug31v1	89000	250000	7	\N	\N	\N	2026-03-25 01:43:42.968+00
0cadb5bf-0fe8-43b6-8e73-27b7d59bef74	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 30 trzkvddi	80000	250000	3	\N	\N	\N	2026-03-25 01:43:44.174+00
2c685e27-19cd-43eb-b1e8-01d3c9b7acf8	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 29 yhm7hl5m	89000	250000	7	\N	\N	\N	2026-03-25 01:43:44.485+00
dbf6f286-1a18-4034-a68c-ad52b8a5865e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 30 dtd88168	80000	250000	3	\N	\N	\N	2026-03-25 01:43:45.378+00
ca57fa2b-24d8-4c91-a649-6290ed6d3748	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 31 zdcssvu0	81000	250000	4	\N	\N	\N	2026-03-25 01:43:45.383+00
181b7e33-9f22-4279-8712-f0fd3be671fd	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 30 g2vta9zc	80000	250000	3	\N	\N	\N	2026-03-25 01:43:45.395+00
4864d8cb-5f5a-41aa-a8d1-2184aeeb1a9a	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 32 z7dxl1qn	82000	250000	5	\N	\N	\N	2026-03-25 01:43:46.176+00
6893de11-ef8c-4a1b-91d2-81c3224064ad	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 31 74ohcnoq	81000	250000	4	\N	\N	\N	2026-03-25 01:43:46.275+00
50a04921-a15a-45f9-9fb3-c527d8a2f366	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 30 yc9aon7f	80000	250000	3	\N	\N	\N	2026-03-25 01:43:46.477+00
1065ef51-e5f0-4df1-8487-a4bc0500a33e	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 33 bjglb0m9	83000	250000	6	\N	\N	\N	2026-03-25 01:43:47.671+00
d161b3fd-891f-49ef-adea-ad1f22004e51	b7f9b358-690a-4cab-b767-a1b595593f95	k6 search 34 7eax6w1u	84000	250000	7	\N	\N	\N	2026-03-25 01:43:48.521+00
43038033-06b4-4447-a18f-9345967930fe	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 15 q9ahxeib	85000	250000	3	\N	\N	\N	2026-03-25 16:40:17.179+00
db443c3c-3f1c-4655-b62b-bd9e5627eba1	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 13 j3nbyp1f	83000	250000	6	\N	\N	\N	2026-03-24 18:37:45.536+00
2de1e44b-2dfb-4aa7-8aaa-9be506fb5e57	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 14 7sljvptr	84000	250000	7	\N	\N	\N	2026-03-24 18:37:46.157+00
af6c292e-723b-4382-8dbc-1b2d5497950f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 14 akl38mju	84000	250000	7	\N	\N	\N	2026-03-24 18:37:46.201+00
e97b6c52-62e3-492e-a861-1538f2a8e21d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 14 8truqyxb	84000	250000	7	\N	\N	\N	2026-03-24 18:37:46.672+00
37780f78-134c-485b-b2c3-21a74fe2db21	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 15 8v28bxlm	85000	250000	3	\N	\N	\N	2026-03-24 18:37:46.789+00
d6630aad-efe4-4041-bf16-3eb44f926d45	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 15 njzqhjjy	85000	250000	3	\N	\N	\N	2026-03-24 18:37:46.793+00
eff5da09-32d5-40af-8a2f-0e48f22e54a1	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 15 gayg6kwr	85000	250000	3	\N	\N	\N	2026-03-24 18:37:46.879+00
72275b22-13f0-493e-be2f-458498dd631e	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 15 vb3lldyq	85000	250000	3	\N	\N	\N	2026-03-24 18:37:47.148+00
e9ee3a70-4c3d-42d0-8fb2-20cd867af0e5	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 16 8uweejxz	86000	250000	4	\N	\N	\N	2026-03-24 18:37:47.456+00
b9bbbef5-dadc-42c2-9fd2-3e5037d8dc17	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 17 o0712oxg	87000	250000	5	\N	\N	\N	2026-03-24 18:37:48.173+00
3a0de550-6d9a-4d36-8a91-eadd6ed86885	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 18 bsqj1482	88000	250000	6	\N	\N	\N	2026-03-24 18:37:48.953+00
6770384d-7673-422a-84f9-67b26fe1686d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 18 xne4bgv5	88000	250000	6	\N	\N	\N	2026-03-24 18:37:49.163+00
9257ad57-0063-4dfb-8be2-3e0e7f497085	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 19 s7p4k860	89000	250000	7	\N	\N	\N	2026-03-24 18:37:49.985+00
30a45d37-4385-4f64-9651-82054389ee77	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 19 xljmmzi8	89000	250000	7	\N	\N	\N	2026-03-24 18:37:50.047+00
c5402afc-afe5-47f4-869d-78a55a8cb5b8	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 21 9osmyilo	81000	250000	4	\N	\N	\N	2026-03-24 18:37:51.201+00
ecc96555-1ada-4f8b-9663-ca629b82b764	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 21 008itlgj	81000	250000	4	\N	\N	\N	2026-03-24 18:37:51.331+00
83cbda8a-c73e-4431-acef-bfd19489ff47	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 22 2he7e31u	82000	250000	5	\N	\N	\N	2026-03-24 18:37:51.683+00
6cab63f9-af8c-44eb-b2e8-dda6fad3becd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 22 g20mm05a	82000	250000	5	\N	\N	\N	2026-03-24 18:37:51.808+00
fe68ee35-8c63-49e0-add4-d94221b61d87	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 23 c5xavv3v	83000	250000	6	\N	\N	\N	2026-03-24 18:37:52.149+00
0f4e01aa-ee59-4457-938d-0c1c3d7655cd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 23 d8jet4ln	83000	250000	6	\N	\N	\N	2026-03-24 18:37:52.311+00
750cffc8-2837-4fe9-a58b-7d10c1e8877e	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 23 c6rt86zz	83000	250000	6	\N	\N	\N	2026-03-24 18:37:52.429+00
ab86e12d-2401-48b2-bb41-98df36dc8c85	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 23 yzq4q7ke	83000	250000	6	\N	\N	\N	2026-03-24 18:37:52.437+00
d08138ac-2cbb-41fb-84ad-6b7c27cc0ff4	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 24 m1nlpg4l	84000	250000	7	\N	\N	\N	2026-03-24 18:37:52.961+00
29010e8a-e285-45de-825b-809b04dcf0dd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 25 gldjo8vh	85000	250000	3	\N	\N	\N	2026-03-24 18:37:53.101+00
3919b647-00d6-43a5-849a-0da4edddc68a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 25 eeqrhvv2	85000	250000	3	\N	\N	\N	2026-03-24 18:37:53.522+00
7f28287a-fb9d-44e7-86c1-73cf7c902df0	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 26 gtdirgaw	86000	250000	4	\N	\N	\N	2026-03-24 18:37:53.649+00
52744b46-e6ba-4117-818d-c47a60cd8075	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 27 hytcjb4m	87000	250000	5	\N	\N	\N	2026-03-24 18:37:54.548+00
8d204956-16e0-4ef9-a1f8-707023cf823f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 27 k1jck1uc	87000	250000	5	\N	\N	\N	2026-03-24 18:37:54.587+00
9e252aae-ae0b-4331-8b93-17616dcbc20a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 27 15q1kejr	87000	250000	5	\N	\N	\N	2026-03-24 18:37:54.889+00
ae2aca37-d835-4951-9bca-cc5b0bee468b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 27 ezpn0t3k	87000	250000	5	\N	\N	\N	2026-03-24 18:37:54.974+00
5d0b1a76-2797-4ca9-b041-d24157a9df4f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 28 n5h7y0mq	88000	250000	6	\N	\N	\N	2026-03-24 18:37:55.344+00
0c2711d9-1143-4941-9252-4d9194fa5c12	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 29 yypfqwmf	89000	250000	7	\N	\N	\N	2026-03-24 18:37:55.545+00
8598171f-e6c2-4041-a40a-2debc742b5a3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 29 09zxzyk0	89000	250000	7	\N	\N	\N	2026-03-24 18:37:55.748+00
cbea69a5-71cf-4afa-9cbe-e382e23a9610	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 30 gz79uqwt	80000	250000	3	\N	\N	\N	2026-03-24 18:37:56.011+00
1e1b606e-6de5-40e4-823f-9e9965b565fd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 30 qya4ydq9	80000	250000	3	\N	\N	\N	2026-03-24 18:37:56.265+00
ab3a8182-9863-4a10-94a5-43a514640184	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 31 vdozwzat	81000	250000	4	\N	\N	\N	2026-03-24 18:37:56.823+00
4299b69d-eab0-478c-8121-4f2585fd8c65	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 32 glvwni6a	82000	250000	5	\N	\N	\N	2026-03-24 18:38:00.27+00
643ec955-a389-4133-854a-c03e10125f84	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 34 77vz3xl8	84000	250000	7	\N	\N	\N	2026-03-24 18:38:01.293+00
3630e267-3b12-4f8e-9865-79085dbdffbd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 34 z6c85jyu	84000	250000	7	\N	\N	\N	2026-03-24 18:38:01.427+00
18139240-0916-4e7a-b3fb-d28eaf1e9cc2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 34 yhaoxzcl	84000	250000	7	\N	\N	\N	2026-03-24 18:38:01.484+00
99615962-f705-4e77-a863-2662f6a86edf	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 35 bg8raxej	85000	250000	3	\N	\N	\N	2026-03-24 18:38:02.029+00
7618617f-e3fd-4834-b7d3-47b54de049d5	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 36 rwu641hv	86000	250000	4	\N	\N	\N	2026-03-24 18:38:02.127+00
e70539ba-06d7-47d8-9708-9b812687afdf	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 37 2bbcu460	87000	250000	5	\N	\N	\N	2026-03-24 18:38:02.615+00
f0f095a9-85d7-4b89-bb9d-d32e7561ae89	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 37 f3le92j2	87000	250000	5	\N	\N	\N	2026-03-24 18:38:02.721+00
282f9798-aef6-46f3-91da-a1bd4cfc417d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 37 dczhm3kf	87000	250000	5	\N	\N	\N	2026-03-24 18:38:03.176+00
3f6771b1-5ddb-4a99-b112-bc61f9d0ba53	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 38 acqmsx6l	88000	250000	6	\N	\N	\N	2026-03-24 18:38:03.227+00
ea97c8d5-bd46-4351-b8ba-91e8a294943f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 38 86e3ug2j	88000	250000	6	\N	\N	\N	2026-03-24 18:38:03.349+00
b3869a4b-f145-47b4-b044-0672d85d2093	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 38 easf0wm1	88000	250000	6	\N	\N	\N	2026-03-24 18:38:03.471+00
3806f863-e738-4408-82d5-b13af6485622	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 39 59pn3q33	89000	250000	7	\N	\N	\N	2026-03-24 18:38:04.05+00
b8320aae-8be6-4f52-b272-3e845cb65db3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 39 zdjdo8fe	89000	250000	7	\N	\N	\N	2026-03-24 18:38:04.645+00
a2633d37-d10b-4fc9-ad74-ae16d9e5efbf	ae0d0e6d-ec8a-41ae-8669-d49149ad6bd8	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-25 01:52:02.874+00
4fe139e9-c7d3-4c9b-97f0-49501a87820d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 15 k1di61u9	85000	250000	3	\N	\N	\N	2026-03-25 16:40:17.188+00
51fc0ba4-fe02-4a1f-80d4-ae7a58026c38	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 16 s1f1xex3	86000	250000	4	\N	\N	\N	2026-03-25 16:40:17.194+00
fc38e619-fa08-4d9a-9047-578c04f06c18	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 17 b96gu669	87000	250000	5	\N	\N	\N	2026-03-25 16:40:18.049+00
bff9680d-0747-4a64-bc09-df99f85ba9f3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 17 0aae2j6f	87000	250000	5	\N	\N	\N	2026-03-25 16:40:18.851+00
8456be96-2be2-4625-ba21-84bbbdd5568a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 18 u957qqeg	88000	250000	6	\N	\N	\N	2026-03-25 16:40:18.933+00
682c0485-0181-4100-8960-36a14281e107	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 19 0gccn8ug	89000	250000	7	\N	\N	\N	2026-03-25 16:40:19.637+00
2dcb6abd-b681-4cb6-b58f-11ee1ac5d6c4	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 19 zw4ikgbi	89000	250000	7	\N	\N	\N	2026-03-25 16:40:19.657+00
d426c7af-d1a4-43f9-ad28-600a8bcedfce	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 19 ep3cmbb3	89000	250000	7	\N	\N	\N	2026-03-25 16:40:19.697+00
8e746ecd-58f7-4d6c-974b-dd59fd27154f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 19 ziady1kf	89000	250000	7	\N	\N	\N	2026-03-25 16:40:20.039+00
67d0f79a-1eaf-477f-8b48-5e72702bf2ce	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 20 1vmksg8r	80000	250000	3	\N	\N	\N	2026-03-25 16:40:20.687+00
a6f31008-3cc8-472b-81b3-14e243ce4a3c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 20 xoo67jvc	80000	250000	3	\N	\N	\N	2026-03-25 16:40:20.739+00
60e31d7c-d290-49cd-8fe4-0b4ef82488d2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 21 n36u1net	81000	250000	4	\N	\N	\N	2026-03-25 16:40:21.927+00
c7908d23-a6c0-4c36-b60a-f072f595b0dd	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 21 qt0hbuan	81000	250000	4	\N	\N	\N	2026-03-25 16:40:22.257+00
d1ef2d6b-2a0b-41c2-bee3-02b9d32c8d97	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 22 6zf1vjux	82000	250000	5	\N	\N	\N	2026-03-25 16:40:23.469+00
91289c9c-e3ea-4b6e-9015-2bba7531b15e	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 22 4endfei6	82000	250000	5	\N	\N	\N	2026-03-25 16:40:23.823+00
601fafcb-7fe2-4645-b892-d8fd82fe4830	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 23 dqs943pk	83000	250000	6	\N	\N	\N	2026-03-25 16:40:24.184+00
c07f7f47-784d-4f03-b7d3-2f2b4c661434	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 23 xuco2r6m	83000	250000	6	\N	\N	\N	2026-03-25 16:40:24.196+00
d97663e1-f0e6-4080-9bc5-3c6c6e316bea	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 24 y25mnw54	84000	250000	7	\N	\N	\N	2026-03-25 16:40:24.766+00
bab96efc-bea1-4018-b1c9-c3e5a339b4fc	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 25 ls2topa5	85000	250000	3	\N	\N	\N	2026-03-25 16:40:25.374+00
d1120e1d-613f-45f6-b48b-cbf447432a84	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 13 k0rdpvss	83000	250000	6	\N	\N	\N	2026-03-24 18:37:45.962+00
cc477676-dec0-4715-946a-ac1da41cc62e	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 13 2y9jza6p	83000	250000	6	\N	\N	\N	2026-03-24 18:37:46.1+00
e7f96761-997b-4b27-94a1-ccfae4fa4eb2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 14 7y2fb7ht	84000	250000	7	\N	\N	\N	2026-03-24 18:37:46.155+00
cfbf5ca0-0729-4a57-976f-14b8d9536115	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 14 d4ksbl2h	84000	250000	7	\N	\N	\N	2026-03-24 18:37:46.409+00
461424c9-2723-4a41-95b1-47ba303528f4	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 15 woh63aw6	85000	250000	3	\N	\N	\N	2026-03-24 18:37:46.794+00
369c2eae-8e78-42b1-b59e-21fbe285b650	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 16 bek8vq4y	86000	250000	4	\N	\N	\N	2026-03-24 18:37:47.494+00
62b8fd79-c9d9-48d7-a9fe-d83e1029f8b8	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 16 gjjilown	86000	250000	4	\N	\N	\N	2026-03-24 18:37:47.553+00
263e67b4-5385-4632-a4e4-ddc7748b9e09	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 17 sekd6750	87000	250000	5	\N	\N	\N	2026-03-24 18:37:48.167+00
538a86c5-5fd2-4404-b32b-0eeb70ec1a01	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 17 ohzly47g	87000	250000	5	\N	\N	\N	2026-03-24 18:37:48.172+00
9275b2b2-ccda-4c37-a26e-e042e34cf3e3	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 17 nl9h6dqy	87000	250000	5	\N	\N	\N	2026-03-24 18:37:48.174+00
d207150b-68ff-4195-8cc7-d13f54e2ac51	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 18 c1s3c6ul	88000	250000	6	\N	\N	\N	2026-03-24 18:37:48.95+00
aa7c75d9-259e-466e-89c5-434eefef76bd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 18 tlaplvnw	88000	250000	6	\N	\N	\N	2026-03-24 18:37:48.957+00
7a3eb71e-12cb-4a77-a83f-843feec9adc4	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 20 v5uz6nxz	80000	250000	3	\N	\N	\N	2026-03-24 18:37:50.627+00
c6293c5f-03b9-4b9e-a149-f42907f0d455	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 20 h36q9h7h	80000	250000	3	\N	\N	\N	2026-03-24 18:37:50.641+00
12962808-1630-42c7-8ec4-e375e0427b68	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 20 kbotmrmm	80000	250000	3	\N	\N	\N	2026-03-24 18:37:50.646+00
baec5c77-916e-494d-8bff-90f6c0b79038	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 20 hzdof8kl	80000	250000	3	\N	\N	\N	2026-03-24 18:37:50.697+00
ed1d0f4a-e158-455e-b50b-830ede81f50f	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 22 cyjf9k47	82000	250000	5	\N	\N	\N	2026-03-24 18:37:51.681+00
984538ea-92a5-44b3-8be4-b79681168eee	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 22 ohfzorox	82000	250000	5	\N	\N	\N	2026-03-24 18:37:51.858+00
00fa8b8d-2b2f-4ac5-a4da-8af3c99fccb5	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 24 2czs1blp	84000	250000	7	\N	\N	\N	2026-03-24 18:37:52.622+00
1507aabc-19e4-478c-9761-c2e09fe52077	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 24 5mbmic4l	84000	250000	7	\N	\N	\N	2026-03-24 18:37:52.806+00
44d17f15-80ab-48a4-a083-839c9c6787a8	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 24 7265qqi6	84000	250000	7	\N	\N	\N	2026-03-24 18:37:52.954+00
e2a3d3b9-858f-4578-ad4a-781741bce8c0	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 24 x69n07ll	84000	250000	7	\N	\N	\N	2026-03-24 18:37:52.959+00
384cd897-b55f-40e7-afb0-87dd6ebae78d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 25 f9yep8jp	85000	250000	3	\N	\N	\N	2026-03-24 18:37:53.1+00
4236ab9b-65ee-4049-9c7c-fc554f8d9750	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 27 bzrsk6gc	87000	250000	5	\N	\N	\N	2026-03-24 18:37:54.49+00
78ec6e30-25e9-4621-ae4e-218036ca1aa7	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 27 1lm4mr5q	87000	250000	5	\N	\N	\N	2026-03-24 18:37:54.803+00
2bec63ac-9c32-4495-9865-b2cec4caea6d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 28 xrvgiy2l	88000	250000	6	\N	\N	\N	2026-03-24 18:37:55.009+00
95e86acd-7342-49c0-8df9-288055f8cb6a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 28 55i0l9b0	88000	250000	6	\N	\N	\N	2026-03-24 18:37:55.077+00
88c4ae5e-5b6e-4047-b35a-5c3178658552	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 28 1bk4mwhi	88000	250000	6	\N	\N	\N	2026-03-24 18:37:55.08+00
62b2ec06-c422-42a9-8785-0eff28f2071b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 29 8wjvkr7o	89000	250000	7	\N	\N	\N	2026-03-24 18:37:55.82+00
2ac13787-cdc7-45fc-b6b5-b16094c996ed	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 30 i7u2102i	80000	250000	3	\N	\N	\N	2026-03-24 18:37:55.912+00
6cdd76a3-7aaa-4150-8d28-7f6df7bbda08	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 30 jh7kc4yc	80000	250000	3	\N	\N	\N	2026-03-24 18:37:56.013+00
af251d9a-eb2f-4603-b0b0-13a63cfcc71c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 30 uwfos3os	80000	250000	3	\N	\N	\N	2026-03-24 18:37:56.097+00
8e0d1dce-0e73-4c52-a326-014ac9436b02	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 31 pgp03vzc	81000	250000	4	\N	\N	\N	2026-03-24 18:37:56.326+00
137da533-429c-4965-bb73-26e2b85d33a5	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 31 bwwb2osa	81000	250000	4	\N	\N	\N	2026-03-24 18:37:56.721+00
41e09404-25f3-4cb1-b72f-7e0d06cd0740	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 32 v52nlikx	82000	250000	5	\N	\N	\N	2026-03-24 18:38:00.173+00
e59a8e31-afa0-487b-83b4-d522783217a6	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 32 4alju4vs	82000	250000	5	\N	\N	\N	2026-03-24 18:38:00.204+00
52a9b593-1a6a-4b53-944e-6e99c0e7601c	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 33 ncxj6dfn	83000	250000	6	\N	\N	\N	2026-03-24 18:38:00.272+00
a989ac80-f930-4e78-be05-cd97db147ddf	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 33 wz13lu17	83000	250000	6	\N	\N	\N	2026-03-24 18:38:00.795+00
0869000c-9d50-4d86-a165-9fca43db2a78	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 33 vf5i1n6m	83000	250000	6	\N	\N	\N	2026-03-24 18:38:00.847+00
24a36600-31a7-4be6-84e8-ae19692fbcdd	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 34 9lm8cgrw	84000	250000	7	\N	\N	\N	2026-03-24 18:38:00.859+00
fc8a311e-e7fe-49ff-a0e4-42b1550e215a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 35 bb7a2re9	85000	250000	3	\N	\N	\N	2026-03-24 18:38:01.487+00
0acf55fa-c963-485e-8d2c-72947d636469	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 35 5mfsep93	85000	250000	3	\N	\N	\N	2026-03-24 18:38:01.709+00
003bc44a-c7e2-48da-bd5c-95766d274af2	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 35 5zf7nxai	85000	250000	3	\N	\N	\N	2026-03-24 18:38:01.842+00
589f8445-7351-4835-aecd-69d6a35324ed	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 35 rcdkpaem	85000	250000	3	\N	\N	\N	2026-03-24 18:38:01.938+00
8c424883-5582-4e43-a92d-0501b2e0cc9a	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 36 y08bbfl5	86000	250000	4	\N	\N	\N	2026-03-24 18:38:02.031+00
aa712bf0-d8e3-406a-8a92-ee5fa7bd9baa	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 36 3mz4tn4l	86000	250000	4	\N	\N	\N	2026-03-24 18:38:02.268+00
920593bc-ca4a-420f-9fdc-9fbdd5873358	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 36 bnoxh99z	86000	250000	4	\N	\N	\N	2026-03-24 18:38:02.437+00
7fd3d808-3ebc-400c-b0a5-bb8422da932b	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 36 o4mlnt4k	86000	250000	4	\N	\N	\N	2026-03-24 18:38:02.565+00
88a69242-6422-4746-8fe2-ae66edb75974	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 36 6ylynssh	86000	250000	4	\N	\N	\N	2026-03-24 18:38:02.613+00
5dfcf261-0790-4cbe-9607-dec2e396506d	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 37 cgmeaaw1	87000	250000	5	\N	\N	\N	2026-03-24 18:38:02.663+00
b6e9c69f-918c-4bd7-a8c4-1819ac83e028	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 37 1mmo3t2v	87000	250000	5	\N	\N	\N	2026-03-24 18:38:03.282+00
9b106a5f-4440-40e6-baa5-621f9a74d726	b53a715d-e732-4cea-aff3-855d21cb8e6a	k6 search 38 5c32vk4f	88000	250000	6	\N	\N	\N	2026-03-24 18:38:04.323+00
f5c9ccc9-d178-4306-bd06-eb34768d28d7	f8cc850c-d9b7-4b4c-99c2-ccdc478d5ddc	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-24 18:42:22.4+00
8601baeb-f7b5-49c5-b4c8-2afb8580deef	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:57.56+00
17e2c2ab-d683-4955-9dad-32c653c7acbd	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:57.569+00
1b057b47-5b00-4ba2-a8f4-e4b6edcb58a9	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:57.651+00
7740d62a-a59e-4cf2-8468-102dcc7da3b1	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:58.433+00
5041fdcd-cffb-4f70-91b4-5cfd956a77f0	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:58.435+00
2b922abd-0148-462a-834a-5347565f344a	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:58.437+00
b852e1d5-bda5-4f50-b09a-b802fece6744	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:59.132+00
44a92a36-2214-4f53-818f-c4c1b5bfabe6	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:59.134+00
93076e12-412f-4666-8de9-3e68fc53aae0	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:59.138+00
7fd56df6-9f27-4ffc-b5a9-2de2387d8659	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:59.797+00
c499c28d-3d7b-4280-835a-afaaa6cf5d15	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:59.799+00
709a1e52-d560-48b6-b998-82abfd6177ab	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:48:59.8+00
a8f5a678-681d-414e-bc5e-cc17adbfea0a	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:00.475+00
7a0d8390-4770-4718-bc98-960453b09739	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:00.477+00
0b030b9c-6dde-4d42-8100-41d446250a4d	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:00.479+00
0ad6d40d-9545-4649-b477-ded509fe8bf5	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:01.127+00
4778a34b-43e5-4fc6-a428-658b8a01e128	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:01.129+00
43b6e8b8-2c71-4cd4-a8e1-0606d5d500dc	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:01.13+00
67587493-0382-4ed0-a7a8-910f450cfc9d	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:01.798+00
908ed9a9-20d0-4e4e-b6fa-1e3858674bee	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:02.456+00
c2d87f96-c1b8-4da4-a729-915ac1a9219a	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:03.117+00
3cd9939e-3dca-41dc-845e-307f55302917	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:03.846+00
050b9040-341e-44f2-9d22-94567614251d	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:04.882+00
8c5912c1-3068-484c-998e-7d2569ad981b	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:05.522+00
25795efd-585c-42ee-9d14-8f6b2e1500d2	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:06.157+00
6bedd302-90b5-4ac3-bf90-b7f670f40021	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:06.177+00
6bb5722b-44b6-4b82-8ad2-2a00e610ce32	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:06.182+00
34c038ef-9f1f-4540-bc59-c648f8f5eb8b	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:07.413+00
ce3944bc-94b5-40fb-8c97-85e07437b88c	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:07.524+00
5757e212-ce63-4cc4-9ff0-bf8662d43c11	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:09.13+00
1e042384-8eef-4517-9f4a-6ea094c0e637	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:10.413+00
e80c4d88-c547-4db4-ae28-1d80bffc5d0f	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:11.064+00
0a5fcd6c-33f9-45c2-a7cb-cb87ae3f6441	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:11.741+00
bb3e3ea6-83d2-484c-be02-17276cc354ed	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:12.4+00
c5eba2f9-ae52-4813-8a3d-a64f7678dbb2	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:13.099+00
35c02447-6569-44c5-94f8-b1626ec9cd7e	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:13.825+00
10053047-82f4-46a8-be76-8037aebe43d1	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:14.709+00
17f1a70c-0f62-4b82-bed1-47c895d76085	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:15.399+00
e27cc8d4-fa87-49f2-b276-3f0fd49b73f8	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:15.442+00
651fa7a6-ff23-48b5-aaec-c9ffdc3a357f	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:16.016+00
8b173732-57c7-4652-ba9a-08d814553377	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:16.099+00
faa2fe80-c79d-4f18-803e-b897963a0a03	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:16.783+00
3479c1f8-a311-4246-b58c-2bdbb3b81396	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:17.267+00
13c4ab46-d6b9-41bd-9f03-1bce9aad671b	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:17.484+00
6a152511-8759-4f19-8d11-47ea00369773	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:18.151+00
32f777e5-13f5-46f6-ae19-cec8f98ec4e5	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:18.774+00
b56ce3b0-c2fa-425c-9461-a3e8f604286c	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:19.581+00
925cbf26-1870-4614-a2af-3af437da2432	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:20.37+00
f0ea0100-cf3b-46f1-833c-8d03f2c45168	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:20.835+00
90d8ce45-c90a-4d0f-a249-ac37909b9df8	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:21.467+00
97af180b-f78a-4bad-a5fc-dd499b8e4885	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:21.542+00
ba45047f-9f53-454b-9c08-455597fab72c	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:22.085+00
733bc043-da50-4669-a1b3-cf2437ecae0b	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:22.143+00
76948ed9-1ac2-439f-b2ca-ab8ab7bfebd6	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:16.269+00
27fe8551-b599-4988-b34b-0aa779a1cdfc	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:17.23+00
bcbec9b8-728e-4778-ba0a-fa9ed1ad7757	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:26.5+00
882d87b1-7b42-4998-9a57-754e16f9bcd7	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:27.12+00
03af82d5-ae6b-411f-b611-917b7749fea5	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:31.73+00
d443aae1-09f9-4f74-8d98-d98d25c027b3	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:32.409+00
2613db00-dc58-49d7-b7c8-ff47b5c9288d	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:38.81+00
ad65f7e4-6015-4472-aee5-83f3a21b0fee	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:39.644+00
86700fab-47cc-4832-adb3-6149d149130a	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 0 k1d5aph8	80000	250000	3	\N	\N	\N	2026-03-25 05:30:44.562+00
9f4a1f77-0c90-4881-8550-5209cc2481e4	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 0 uvfhoq56	80000	250000	3	\N	\N	\N	2026-03-25 05:30:48.048+00
bcdcc626-4ead-442c-8335-039f5ff5fc5a	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 1 ic9ozoxx	81000	250000	4	\N	\N	\N	2026-03-25 05:31:04.228+00
43b20b8e-50ae-4b99-aee2-4747949b7903	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 2 dd786l7r	82000	250000	5	\N	\N	\N	2026-03-25 05:31:05.069+00
c968e892-af95-4c4e-8837-44773b60003a	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 2 reuat4xc	82000	250000	5	\N	\N	\N	2026-03-25 05:31:05.154+00
b015d879-dd3b-453f-b9dc-26c1a51dbd35	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 2 7830qk8k	82000	250000	5	\N	\N	\N	2026-03-25 05:31:05.328+00
aab697b0-0a3d-4472-a484-403ef0fc1b36	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 3 vrge3w8d	83000	250000	6	\N	\N	\N	2026-03-25 05:31:05.564+00
bb86e69f-664b-476d-8983-90bd2c0b9b84	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 3 7thgnxov	83000	250000	6	\N	\N	\N	2026-03-25 05:31:05.643+00
13318ada-d1da-4039-8610-5b4deaccb4a8	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 3 xy45927d	83000	250000	6	\N	\N	\N	2026-03-25 05:31:05.964+00
eaaa686b-2032-4848-8f47-3ff02abd528f	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 3 y8odib4c	83000	250000	6	\N	\N	\N	2026-03-25 05:31:06.138+00
6cb691b7-a10c-472c-b21d-89dd103e75b5	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 4 4ctrfkf1	84000	250000	7	\N	\N	\N	2026-03-25 05:31:06.332+00
e6a61127-ee8a-4533-93f0-d53613321ad0	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 4 uoxcfmdl	84000	250000	7	\N	\N	\N	2026-03-25 05:31:06.735+00
90bcda19-ef6d-46d7-8a2c-4be40e6fb0a9	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 4 dn98tkp3	84000	250000	7	\N	\N	\N	2026-03-25 05:31:06.831+00
d7b4218c-371c-4db7-a9e4-d69dc1140c02	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 18 h08ohr75	88000	250000	6	\N	\N	\N	2026-03-25 16:40:19.113+00
86ad9067-e11f-4bd8-a265-6354a42a27da	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 19 mpfstot5	89000	250000	7	\N	\N	\N	2026-03-25 16:40:20.596+00
9ebff4e3-90ac-4040-97f4-c3736a9823de	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 20 kh5yymm6	80000	250000	3	\N	\N	\N	2026-03-25 16:40:20.606+00
fa4ca307-51da-4c83-b410-42b2244d42e2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 20 sxy228ck	80000	250000	3	\N	\N	\N	2026-03-25 16:40:21.88+00
ef1e9394-1ad8-4166-863b-5c0a9f190a35	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 21 b1j2m3rf	81000	250000	4	\N	\N	\N	2026-03-25 16:40:21.922+00
e6aa9e30-1173-44c7-a6e1-898363314a28	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 21 jhqgei61	81000	250000	4	\N	\N	\N	2026-03-25 16:40:22.043+00
e14be651-f6cb-4ecf-913b-ef0e644eb07b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 22 3i6wtm1k	82000	250000	5	\N	\N	\N	2026-03-25 16:40:23.464+00
4cba9526-3dfb-4246-8d3f-d98a98eb8ad3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 23 zg75tvba	83000	250000	6	\N	\N	\N	2026-03-25 16:40:24.181+00
801e252a-3b77-4861-a193-792f780b0706	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 24 tm54bm92	84000	250000	7	\N	\N	\N	2026-03-25 16:40:24.902+00
a98323b2-50a3-47b8-ae05-04237edea012	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 24 ai4ygjx6	84000	250000	7	\N	\N	\N	2026-03-25 16:40:25.067+00
c0e92c8d-68a8-499e-8bc7-79c1bac31e12	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 25 kzcu07ka	85000	250000	3	\N	\N	\N	2026-03-25 16:40:25.296+00
3dd25b30-510f-42dc-9561-0563c42c99c5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 25 qcbk5yrc	85000	250000	3	\N	\N	\N	2026-03-25 16:40:25.421+00
acd77850-aeb9-446e-827b-669185d1aa5a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 26 b816v7le	86000	250000	4	\N	\N	\N	2026-03-25 16:40:26.081+00
21d65e03-5873-4a26-bce2-b929db4e9f2b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 27 lmaghnnt	87000	250000	5	\N	\N	\N	2026-03-25 16:40:26.814+00
82243e65-062f-4486-b7c8-e21cff8ab8e7	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 28 pgm6ewol	88000	250000	6	\N	\N	\N	2026-03-25 16:40:27.148+00
ac716718-c43b-4236-8362-6ddf87f76c71	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 28 fz0by08b	88000	250000	6	\N	\N	\N	2026-03-25 16:40:27.852+00
4f5b6f9e-39d2-4dd7-ad64-43f56cd7d280	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 29 vi4xgq22	89000	250000	7	\N	\N	\N	2026-03-25 16:40:28.453+00
8617155b-fbb2-4813-9f72-3f27ad0eb382	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:01.8+00
e8a48645-1265-41a9-a140-48ab8b51bdd0	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:02.453+00
151b8a71-3dc0-4bce-9ffb-ddd0b3bcaaf6	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:03.826+00
0e7f8e9a-4eee-407a-bf78-978d18ba2bd0	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:04.879+00
e695a03a-ea10-4682-a65b-7dee34185a7a	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:04.883+00
7d844db1-efe4-49f5-be12-2cf879b1cb1c	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:05.519+00
2f5c03f5-9b7e-4c4f-8281-1d941d91c123	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:06.787+00
5338fd1e-204b-40d3-a491-41e11fc0d6c4	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:06.808+00
5e335141-85e7-4a8c-90e7-513e8af77743	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:06.813+00
1a365bd5-c861-4efe-b391-6e6ff1f7c75a	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:07.619+00
ccd0e5c5-9950-418c-a23c-3c39c9508221	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:08.534+00
76fb85bf-aa23-468f-a856-ffb57a1131a4	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:08.563+00
71e6e14a-9af5-4448-a529-021851a82122	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:09.779+00
69ddd2bb-531f-4304-bc88-c2debbba70c6	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:09.802+00
a7655449-3120-47a6-8483-2c77e0067060	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:09.832+00
24c38d08-e7a7-4caa-965f-b1c98e6441e6	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:10.412+00
5eff67ae-65ee-4094-96b0-055e6d059762	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:11.109+00
6cd6c790-ea97-426b-9de4-09f0d19fad14	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:11.739+00
5eb0af78-9175-4da3-819a-64e5b63a1134	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:12.403+00
2153daaa-5fe3-48c5-9798-6e35da65fb76	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:13.096+00
5ae5324d-30c6-4cde-a0b3-c88922f743e3	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:13.821+00
cb4cd8d0-df1f-4ffd-b747-99dab5b638c2	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:14.714+00
4859f21a-c4cd-444d-b496-fe46e1baa40d	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:15.47+00
ba4cc46c-7866-483c-8edc-05d792265603	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:16.101+00
f581489b-3252-4e15-a4e5-304b84bcd64f	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:16.669+00
91230c51-ba4b-42ab-91d1-b533335e6e30	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:16.78+00
d67b82ba-915b-444c-876c-602d0673b413	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:17.486+00
220db0cd-5ae1-47d1-a5d9-9bc4236c6f1f	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:17.868+00
b4030e08-fb48-4f26-bd34-f0d78f33b8f7	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:18.141+00
43304dfa-16dd-455d-a247-beeaff0c437e	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:18.471+00
5c7f53b8-560e-4c4b-b637-3637cd131b34	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:18.772+00
fca09678-1a27-46e2-8cd0-c19bfadcbabb	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:19.055+00
4e05bb21-0338-4928-888a-f2b25b6c01be	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:19.579+00
fb4906a8-62eb-45d5-a124-8913b53a5e55	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:19.775+00
27c480b9-1def-4133-b98f-7c473849202e	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:20.199+00
6c923cf0-60db-4bae-a650-51549f57fbc2	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:20.203+00
ac61e820-d801-4af8-80bd-a258cab158fb	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:20.837+00
081ee422-106a-4093-bec8-9796e2a72e98	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:20.961+00
c4dd0b1a-0f37-43d0-a42a-a9df1245f8b1	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:21.465+00
448ab725-3a96-4753-a1ac-7eb05a22edbd	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:22.084+00
58c31724-5365-4102-a50a-8949732e586b	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:16.907+00
2e1ed38f-1926-49f1-a3df-dbc3726baf85	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 1 f6ln8vy8	81000	250000	4	\N	\N	\N	2026-03-25 05:31:03.452+00
59a3e5e4-a8c1-4278-944f-7c73094dda12	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 1 873bw1d1	81000	250000	4	\N	\N	\N	2026-03-25 05:31:04.157+00
f2cd929e-c8bc-438b-ba6c-ef4adc3a9de5	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 1 o6vu3d3d	81000	250000	4	\N	\N	\N	2026-03-25 05:31:04.629+00
e8c5c89d-7f9b-410d-b277-fc80b799705f	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 2 q9ku327r	82000	250000	5	\N	\N	\N	2026-03-25 05:31:05.331+00
04c5c714-2a7a-4b38-888f-efb3caafda26	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 4 uwv05jrv	84000	250000	7	\N	\N	\N	2026-03-25 05:31:06.733+00
bf514e85-0301-4392-b470-6086e79f42f8	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 4 3rnnzrhu	84000	250000	7	\N	\N	\N	2026-03-25 05:31:06.932+00
80677b56-097c-4975-8e1d-91f0e87804ca	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 24 3eyqloop	84000	250000	7	\N	\N	\N	2026-03-25 16:40:24.769+00
7201527d-4dd8-465a-862f-43417dafa2d7	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 24 v1vbcqlz	84000	250000	7	\N	\N	\N	2026-03-25 16:40:24.851+00
5c42d967-74fd-42af-a92c-c579627fb38f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 25 iq3ysy6w	85000	250000	3	\N	\N	\N	2026-03-25 16:40:25.289+00
d7cfd914-695c-4822-9fe0-84aa436a3fca	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 25 cu7p8opg	85000	250000	3	\N	\N	\N	2026-03-25 16:40:25.294+00
0c02d97b-6268-4ae5-899d-e35380715132	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 25 z1vkd8b3	85000	250000	3	\N	\N	\N	2026-03-25 16:40:25.537+00
e416007b-9296-4757-8fc7-7ad10b23db75	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 26 t3b2o0wy	86000	250000	4	\N	\N	\N	2026-03-25 16:40:25.941+00
f3ead683-4ba8-4267-9c0c-04b5e16b833c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 26 kgz8uar5	86000	250000	4	\N	\N	\N	2026-03-25 16:40:26.075+00
d4b1919b-02fd-4b05-a6f5-b484e973cd91	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 27 sfwd0mer	87000	250000	5	\N	\N	\N	2026-03-25 16:40:26.613+00
947371c5-b2d6-43d7-bbd8-deae36bdfc87	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 27 pzl978kw	87000	250000	5	\N	\N	\N	2026-03-25 16:40:26.622+00
8872c59c-472b-40fd-9684-d6b4335f38f3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 27 zvd8ixsi	87000	250000	5	\N	\N	\N	2026-03-25 16:40:26.661+00
2ce76eb0-5000-428b-880d-e7452b7ab82c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 27 2kpe9jay	87000	250000	5	\N	\N	\N	2026-03-25 16:40:26.754+00
6facc640-8eef-4c0e-ad6d-67cc0a417f8b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 27 ebepuwzh	87000	250000	5	\N	\N	\N	2026-03-25 16:40:26.817+00
20f84c15-6f8d-4b27-9a8c-2789c778e18d	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 28 w1lht5hq	88000	250000	6	\N	\N	\N	2026-03-25 16:40:27.225+00
cdc5b833-7313-4acc-bc77-43547219adbe	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 29 gkyzv9f5	89000	250000	7	\N	\N	\N	2026-03-25 16:40:29.454+00
cb5f90aa-91f9-483b-a8b7-c0dd9df4f82f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 30 y4yexohl	80000	250000	3	\N	\N	\N	2026-03-25 16:40:30.044+00
c3928730-0fef-495a-94e7-5ea83ae92bcc	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 30 vvidihm2	80000	250000	3	\N	\N	\N	2026-03-25 16:40:30.213+00
5f652b96-80b2-4e92-9709-7f7c87c68c9a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 30 3c19bcpa	80000	250000	3	\N	\N	\N	2026-03-25 16:40:30.491+00
778c0801-0dbd-4ade-97a1-bbd1655b352f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 30 35mi1hmo	80000	250000	3	\N	\N	\N	2026-03-25 16:40:30.498+00
d158cd17-2d0f-42d8-bed8-999e22b88b44	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 31 ytr7pi87	81000	250000	4	\N	\N	\N	2026-03-25 16:40:30.622+00
d71a85a1-2996-4480-8b0c-ceb7da966ce1	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:24.413+00
04108cff-a97d-401b-8593-9cdc7c1db9c5	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:25.095+00
a33bf912-7845-4a5b-b422-0fe5f50b2da2	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:25.762+00
a5634b4e-4ea3-44b0-9c5f-f4f1be2ff90e	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:26.432+00
ece31a62-78ab-4a10-b018-02bd8a669a35	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:27.24+00
bbbfc767-4c01-45be-9d72-5b4b7dd3ff80	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:29.383+00
a1857cf9-3909-4f9d-97c7-bef8cd1a57e0	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:30.083+00
4c5dda92-4230-40c9-97b8-09ae2bf61884	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:01.802+00
97c1c470-73d5-4a1c-994d-0b8164a03c43	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:02.454+00
51c2ed2e-5986-43f2-8f17-bea517e65fd0	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:03.114+00
8603053c-855e-4322-8d10-2c5712e0e319	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:03.119+00
1797cefb-1261-445e-92a2-be9a9ba19bf7	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:03.848+00
914f6d48-cf16-470c-87e5-7c72bf0751bd	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:05.517+00
e881d828-1caa-4f32-9de5-1bb573329a36	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:08.507+00
938b3fcb-c3c5-4805-9477-362dfb268343	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:09.159+00
0b747b30-109d-4310-a3c2-4fa80f938c1e	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:09.196+00
08525273-74e2-4cb2-8d11-80e5e1525baa	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:10.448+00
8b8a93f9-2259-4ee1-bf61-d3c8056479a5	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:11.062+00
eec3eb10-5cfc-435b-9d21-bf9c80e595d9	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:11.775+00
6077f055-7141-4574-b72c-fa33dfdb24a6	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:12.401+00
39760828-6c1c-4b27-a86c-9cc504a20f82	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:13.093+00
36a7c6ff-73ab-4fb8-afba-e8108538489c	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:13.846+00
6ca58c23-cfec-4ace-b6d4-a667efea7ca2	95f78edd-cd71-4563-8a09-f181f389a4d2	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-24 20:49:14.706+00
0a62ccc3-eb45-47ba-bcb9-931ff8cffef2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 0 obrce5wj	80000	250000	3	\N	\N	\N	2026-03-24 20:50:07.753+00
af97be37-723e-4a0a-9879-d97231ba0994	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 0 3sb83qn2	80000	250000	3	\N	\N	\N	2026-03-24 20:50:07.758+00
f74d4c33-2c41-423b-b027-c811d8a4d046	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 0 ycl6k3ql	80000	250000	3	\N	\N	\N	2026-03-24 20:50:07.761+00
80dd7329-2d1e-44e6-9da4-8311e6a46a8d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 0 ja45pjmw	80000	250000	3	\N	\N	\N	2026-03-24 20:50:07.764+00
a5cd2921-bed4-4894-b862-267e67aaa51c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 0 hbvmifw7	80000	250000	3	\N	\N	\N	2026-03-24 20:50:07.775+00
6c494c1a-7f4e-44d3-9138-9f96b562b64c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 0 2z1m894f	80000	250000	3	\N	\N	\N	2026-03-24 20:50:07.854+00
8def16bb-d5e2-46df-adfe-0f5d7ea609bb	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 1 p3dizv6y	81000	250000	4	\N	\N	\N	2026-03-24 20:50:08.484+00
bc5167cf-6865-42ad-90b2-3a96e874d915	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 1 1dya633v	81000	250000	4	\N	\N	\N	2026-03-24 20:50:08.505+00
dd51fa0d-a036-442c-8927-a8e856a4bb72	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 1 l44ul2rp	81000	250000	4	\N	\N	\N	2026-03-24 20:50:08.507+00
1439c405-3d8a-4422-919c-9ce68a733f92	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 1 dr1tonyi	81000	250000	4	\N	\N	\N	2026-03-24 20:50:08.516+00
5d76a705-e334-4a42-82f5-6c061ac1c9d7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 1 45yllk8j	81000	250000	4	\N	\N	\N	2026-03-24 20:50:08.518+00
f54ae3a7-6bdf-41e9-8d3a-3b95fec8eccb	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 1 nvomb6j5	81000	250000	4	\N	\N	\N	2026-03-24 20:50:08.531+00
b6294c3b-9073-4517-8578-aa7617310f54	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 2 xvam3e38	82000	250000	5	\N	\N	\N	2026-03-24 20:50:09.188+00
d7207b40-010e-41a4-ab6e-dbfd4bf76f41	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 2 61btxgca	82000	250000	5	\N	\N	\N	2026-03-24 20:50:09.215+00
d5ee7c2f-5600-479c-a6c7-8b90424b4ac6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 2 6qya405n	82000	250000	5	\N	\N	\N	2026-03-24 20:50:09.222+00
5ebd7c5f-d9ef-4556-853f-e162957388f7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 2 8ej4ln0c	82000	250000	5	\N	\N	\N	2026-03-24 20:50:09.299+00
58c17eff-4ac1-4dbb-aaf6-845e80acfa3d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 2 7gmdmxbm	82000	250000	5	\N	\N	\N	2026-03-24 20:50:09.3+00
c9819cb4-06ed-435c-b835-eaf79f777ea1	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 2 u595h2eq	82000	250000	5	\N	\N	\N	2026-03-24 20:50:09.301+00
c8744631-cd81-4e87-9dff-e27ca3d3f7f3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 3 om4790dn	83000	250000	6	\N	\N	\N	2026-03-24 20:50:09.755+00
381d11b8-7fec-45fa-946c-d2ffb6735a4d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 3 2oouvpoe	83000	250000	6	\N	\N	\N	2026-03-24 20:50:09.809+00
b1eb2f5b-0dcb-48ce-870c-0c50e357f2ee	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 3 atrhssuw	83000	250000	6	\N	\N	\N	2026-03-24 20:50:09.813+00
c1d695b4-40f5-4856-a6c5-9c16bb06d688	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 3 qeg2zpg3	83000	250000	6	\N	\N	\N	2026-03-24 20:50:09.871+00
10ecee4e-bf1e-4e7c-87f3-14b6efd5dcce	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 3 2548g4ef	83000	250000	6	\N	\N	\N	2026-03-24 20:50:09.873+00
cedb554f-3a8d-4339-9ab5-9f31e06a4502	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 3 6j51zyno	83000	250000	6	\N	\N	\N	2026-03-24 20:50:09.874+00
79f7cd4a-fb3d-4c59-8f46-9b1d83493330	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 4 caxmgku5	84000	250000	7	\N	\N	\N	2026-03-24 20:50:10.269+00
3f3e46c1-35e5-43a7-ba68-d93293f81337	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 4 okhyhoz1	84000	250000	7	\N	\N	\N	2026-03-24 20:50:10.354+00
8c043cc7-e68d-4846-b6b0-f772e3e1f7ff	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 4 00mkfr5f	84000	250000	7	\N	\N	\N	2026-03-24 20:50:10.387+00
9bf2766c-fd2f-4e62-b984-2676020f69f1	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 4 kpmcfixd	84000	250000	7	\N	\N	\N	2026-03-24 20:50:10.447+00
915e1930-cd6e-482c-802b-dfddbee88cff	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 4 bqf3gdpg	84000	250000	7	\N	\N	\N	2026-03-24 20:50:10.448+00
6f1aa4ef-8f0f-4ccf-b828-6f1d6ae4da12	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 4 yuti0uk5	84000	250000	7	\N	\N	\N	2026-03-24 20:50:10.449+00
7b3cf54d-0446-4326-b25a-eafb3c7504cd	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 5 alcpfbjc	85000	250000	3	\N	\N	\N	2026-03-24 20:50:10.967+00
86b223f5-931c-4b55-854c-1418e34ad6eb	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 5 9p0cniov	85000	250000	3	\N	\N	\N	2026-03-24 20:50:11.344+00
593cda0e-e309-41f1-a1e7-b854ba8c50e2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 5 d83jy0gb	85000	250000	3	\N	\N	\N	2026-03-24 20:50:11.446+00
39d06d06-9fd3-4b30-a63e-d3d56fd4150f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 5 ish6zgg4	85000	250000	3	\N	\N	\N	2026-03-24 20:50:11.504+00
4b51e3f2-cdaf-46b8-a5e5-4853841fdc9f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 5 4crqyvk0	85000	250000	3	\N	\N	\N	2026-03-24 20:50:11.544+00
9813f6c0-e0f5-4450-b384-f12e0e964d9d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 5 0k6hzgcx	85000	250000	3	\N	\N	\N	2026-03-24 20:50:11.598+00
bd438ac5-970a-481f-8a57-6c11845af7c6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 6 gobdis2z	86000	250000	4	\N	\N	\N	2026-03-24 20:50:11.655+00
856e6b7f-f4e8-4949-9767-f17a731df4b7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 6 kphbep8j	86000	250000	4	\N	\N	\N	2026-03-24 20:50:11.849+00
d18474a5-d401-43f4-96ce-fe79f067c696	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 6 rqgi2oow	86000	250000	4	\N	\N	\N	2026-03-24 20:50:12.019+00
91647ab0-47f2-4979-9967-1ce9aaf3411d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 6 kofxr67a	86000	250000	4	\N	\N	\N	2026-03-24 20:50:12.289+00
3d0c0a96-4336-423b-8283-c2477053d7a6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 7 ggoo7ws2	87000	250000	5	\N	\N	\N	2026-03-24 20:50:12.29+00
62892a6c-39b5-473b-852a-01ac5058c04c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 6 l5joyexj	86000	250000	4	\N	\N	\N	2026-03-24 20:50:12.291+00
2913682c-9a91-482e-b9c8-b2bee7986cfc	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 6 b1fe0dnu	86000	250000	4	\N	\N	\N	2026-03-24 20:50:12.293+00
2d1881c3-9152-46fc-9b24-411f75c630c4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 7 md3z3l9y	87000	250000	5	\N	\N	\N	2026-03-24 20:50:12.343+00
0cb9a00c-6415-4ff5-8e63-4ab352ceb244	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 7 ahmvj4c0	87000	250000	5	\N	\N	\N	2026-03-24 20:50:12.43+00
ce93b453-5b2b-46c7-ae63-0f7baf5d14ea	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 8 8r031he5	88000	250000	6	\N	\N	\N	2026-03-24 20:50:12.867+00
604174a2-8e6e-4f62-b69a-661cf8925df3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 7 8bwaeduj	87000	250000	5	\N	\N	\N	2026-03-24 20:50:12.868+00
3c145762-c114-4668-ad17-dd94e99e5d11	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 7 hmjfu59t	87000	250000	5	\N	\N	\N	2026-03-24 20:50:12.871+00
dff64f31-28d0-40b2-a2ee-cd6cc5f735a6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 8 gf3lfwvv	88000	250000	6	\N	\N	\N	2026-03-24 20:50:12.876+00
a3faf593-a5b6-439b-9c7a-6c73b970954d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 7 4pmjm9js	87000	250000	5	\N	\N	\N	2026-03-24 20:50:12.879+00
ae5c11d0-f086-426f-a52a-bf69b9bc540f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 8 cogymark	88000	250000	6	\N	\N	\N	2026-03-24 20:50:12.968+00
f989dc5f-936f-4847-837a-c58a4d71486a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 9 3gzmw03i	89000	250000	7	\N	\N	\N	2026-03-24 20:50:13.393+00
04525e26-45ff-4239-8001-103a46730267	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 8 qkymd9x4	88000	250000	6	\N	\N	\N	2026-03-24 20:50:13.524+00
921dc8b8-c3d9-4553-8bdf-357dab67c44b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 9 xnamuhny	89000	250000	7	\N	\N	\N	2026-03-24 20:50:13.546+00
4dcd88bb-c874-4ee0-9a9b-ad3d79a9fb27	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 8 hskofrtv	88000	250000	6	\N	\N	\N	2026-03-24 20:50:13.625+00
82ef45a6-992a-435d-9f99-bc339045b47a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 8 kt04fsy4	88000	250000	6	\N	\N	\N	2026-03-24 20:50:13.653+00
58ccf71b-7b2a-4ac9-a8d5-b0a9c7f31e44	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 10 7471757z	80000	250000	3	\N	\N	\N	2026-03-24 20:50:14.46+00
c0da0c61-8452-4194-b73e-7ff9c19c6be2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 10 s8yr112b	80000	250000	3	\N	\N	\N	2026-03-24 20:50:15.092+00
013011af-44e1-4aa4-948e-84748f80098c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 11 jidun4gi	81000	250000	4	\N	\N	\N	2026-03-24 20:50:15.222+00
dcadf392-9378-451d-b623-f34b00105a2d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 11 5ny4pgf0	81000	250000	4	\N	\N	\N	2026-03-24 20:50:15.642+00
01613380-467d-4f53-a0c5-ac6c009a515f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 12 l39axeov	82000	250000	5	\N	\N	\N	2026-03-24 20:50:15.701+00
10a771ce-568a-4fa8-a533-3e557e7eb915	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 11 5v6i7co4	81000	250000	4	\N	\N	\N	2026-03-24 20:50:15.804+00
43f1291a-3e61-4af5-b5f8-f21812012b8e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 13 fcwx26mw	83000	250000	6	\N	\N	\N	2026-03-24 20:50:15.855+00
8d719515-44c7-47c1-ad2d-c2c0dbece7dd	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 12 7m2fxkzr	82000	250000	5	\N	\N	\N	2026-03-24 20:50:16.077+00
2e6d392a-80a3-4a00-9913-f44daeea51c9	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 13 9mtf4vn4	83000	250000	6	\N	\N	\N	2026-03-24 20:50:16.19+00
2fabd435-be23-40a4-909a-6e9d87bebffa	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 12 ni8282c9	82000	250000	5	\N	\N	\N	2026-03-24 20:50:16.321+00
30d8f8e2-434f-4cb9-9280-8a51f5ea8d97	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 12 ee60frzo	82000	250000	5	\N	\N	\N	2026-03-24 20:50:16.381+00
1dab7bd1-e13c-46ca-9f6c-ca56984c45c4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 13 anypw3fs	83000	250000	6	\N	\N	\N	2026-03-24 20:50:16.497+00
4fbbe9af-331d-4d23-b7f5-42e7bd4523e3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 13 w47k8mxl	83000	250000	6	\N	\N	\N	2026-03-24 20:50:16.815+00
9e8530c0-ded3-495c-a96f-343be58fb8d5	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 13 8qipj9pt	83000	250000	6	\N	\N	\N	2026-03-24 20:50:16.9+00
af3b73cc-7d4f-401b-8627-f2314e558c95	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 14 fqt5sl02	84000	250000	7	\N	\N	\N	2026-03-24 20:50:16.974+00
fafd79f6-b5ed-4dfc-a251-ad7208e0da2f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 15 eot21mus	85000	250000	3	\N	\N	\N	2026-03-24 20:50:17.516+00
2db3339c-58ed-4610-af3e-1e73b21b454b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 16 v6eggqh6	86000	250000	4	\N	\N	\N	2026-03-24 20:50:18.181+00
c3702f81-1deb-43f1-91ef-00be296d53a6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 18 ixs0np5f	88000	250000	6	\N	\N	\N	2026-03-24 20:50:18.864+00
79f8f972-f1fb-48e6-bad6-e12dd6ec9d74	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 17 x2yura19	87000	250000	5	\N	\N	\N	2026-03-24 20:50:18.951+00
8cebce5b-b44e-4e37-8b8d-612f38aecaba	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 17 e2rbumye	87000	250000	5	\N	\N	\N	2026-03-24 20:50:19.749+00
7ec522e2-9b05-4ac2-a039-eb11c9002946	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 19 t6z15qqz	89000	250000	7	\N	\N	\N	2026-03-24 20:50:21.294+00
880a1c15-25ed-4a84-a56d-407931a59d98	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 21 vezfwntl	81000	250000	4	\N	\N	\N	2026-03-24 20:50:21.303+00
a7eafbdb-c9d9-4f53-a276-1e37463110ee	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 20 0bk3tv97	80000	250000	3	\N	\N	\N	2026-03-24 20:50:21.308+00
05a8a574-82c4-4d91-8302-61a0b9275dd4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 21 d8e3udex	81000	250000	4	\N	\N	\N	2026-03-24 20:50:21.381+00
407c72b0-e119-43f7-a664-3389b4aa67a7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 22 wsmv6uoh	82000	250000	5	\N	\N	\N	2026-03-24 20:50:21.904+00
cbcc013b-06fa-4482-bb46-d30590842699	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 21 fpmkeszo	81000	250000	4	\N	\N	\N	2026-03-24 20:50:21.929+00
d1efb466-20d6-470b-be39-4625781dcc15	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 21 73brzw9m	81000	250000	4	\N	\N	\N	2026-03-24 20:50:21.949+00
9ec123f0-8de9-46b6-9507-de7b0610318b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 23 g0lsgqey	83000	250000	6	\N	\N	\N	2026-03-24 20:50:22.529+00
932ab965-8b87-4e69-a220-40d08c7039b1	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 23 frusu8q8	83000	250000	6	\N	\N	\N	2026-03-24 20:50:22.533+00
5a9f3443-8e86-49c4-aed2-9fc201ac6a11	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 22 ol2rpmyj	82000	250000	5	\N	\N	\N	2026-03-24 20:50:22.543+00
81e9f126-16bc-4494-91d9-bfdf02d02720	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 22 o549x3jm	82000	250000	5	\N	\N	\N	2026-03-24 20:50:22.573+00
32fc4834-5a83-49e2-a5dc-af9a810a62e5	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 23 7p40zt8j	83000	250000	6	\N	\N	\N	2026-03-24 20:50:24.046+00
cfed6de8-2262-4172-951d-2ed94e9ecaa3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 24 srox5mu3	84000	250000	7	\N	\N	\N	2026-03-24 20:50:24.051+00
85a3847f-f332-4ca2-80cd-6ea2d3a06542	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 25 9av82p83	85000	250000	3	\N	\N	\N	2026-03-24 20:50:24.866+00
06dc0f13-a0b1-425e-bf69-1d589bcc3877	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 26 md0da0yl	86000	250000	4	\N	\N	\N	2026-03-24 20:50:24.87+00
da159118-83e7-487e-bcec-45bb88b764de	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 25 uci5p2d0	85000	250000	3	\N	\N	\N	2026-03-24 20:50:25.395+00
69cbd45f-5c81-4348-aa33-f5a32b3fc2ed	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 27 bev3k9s5	87000	250000	5	\N	\N	\N	2026-03-24 20:50:25.408+00
7c81b6df-c5e1-41fd-ac01-cd39daca53dc	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 27 zepk84b3	87000	250000	5	\N	\N	\N	2026-03-24 20:50:25.423+00
c8579c2c-b140-4faf-8dad-21bcfd43afdf	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 27 2uv9zouj	87000	250000	5	\N	\N	\N	2026-03-24 20:50:25.432+00
00ab47cf-59af-4865-9bcc-78332f57c340	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 28 56f350tf	88000	250000	6	\N	\N	\N	2026-03-24 20:50:25.997+00
d450b24d-e284-409c-be0d-3531bb066b49	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 28 h063nsz7	88000	250000	6	\N	\N	\N	2026-03-24 20:50:26.017+00
ba1f4d1f-ba05-4b37-aad3-94848a40ac69	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 27 x08qje4h	87000	250000	5	\N	\N	\N	2026-03-24 20:50:26.7+00
06863efe-6ac7-4971-8c39-4267d2922152	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 28 ew7fz0nd	88000	250000	6	\N	\N	\N	2026-03-24 20:50:26.704+00
0db6c381-622e-4d19-bfc5-2f94d59a4a65	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 30 hxqsv17o	80000	250000	3	\N	\N	\N	2026-03-24 20:50:27.348+00
eb3657ec-1835-45b5-8697-567cee4e31ec	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 29 4ktm92z2	89000	250000	7	\N	\N	\N	2026-03-24 20:50:27.421+00
a099de67-e69a-456d-94bf-ace7fc2eee6f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 30 obfclcw7	80000	250000	3	\N	\N	\N	2026-03-24 20:50:27.447+00
d9f9f72b-11c8-4135-bde8-ffa7fbe41dcf	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 31 a0co2ttu	81000	250000	4	\N	\N	\N	2026-03-24 20:50:28.175+00
9a4cb3e2-6e44-4553-8134-52a237267de2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 30 radrycnb	80000	250000	3	\N	\N	\N	2026-03-24 20:50:28.178+00
76303fdd-38ea-450c-a127-0f33aeda4398	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 31 dw2cqj25	81000	250000	4	\N	\N	\N	2026-03-24 20:50:28.18+00
e5c0b021-b762-4bf0-95f1-f2e8c5bfbb5d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 31 anlxebfv	81000	250000	4	\N	\N	\N	2026-03-24 20:50:28.789+00
677e8fa9-541a-4e16-b616-f6fabe80ef9f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 30 dlge84cl	80000	250000	3	\N	\N	\N	2026-03-24 20:50:28.852+00
654b1e50-d096-482a-a8ee-9cec50e761b4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 32 qciieobd	82000	250000	5	\N	\N	\N	2026-03-24 20:50:29.466+00
829338c4-008c-4b9d-af5b-bc7e552976c4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 33 a7dplcr9	83000	250000	6	\N	\N	\N	2026-03-24 20:50:30.493+00
df68345c-fe9e-42d9-96f5-b88fa860675d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 34 ds02h3pe	84000	250000	7	\N	\N	\N	2026-03-24 20:50:30.507+00
c06b6e3b-bc16-4e85-970e-0a494470b4c2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 34 blydhapv	84000	250000	7	\N	\N	\N	2026-03-24 20:50:30.518+00
466ddfd9-0239-403e-b85b-d11db354312b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 32 7l7z8x8c	82000	250000	5	\N	\N	\N	2026-03-24 20:50:30.528+00
88f88513-d69f-44e5-af37-67ab3f66bb8b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 34 bbp3ldzk	84000	250000	7	\N	\N	\N	2026-03-24 20:50:31.087+00
6d35bd42-6527-4a06-b360-04227caa9f6d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 35 mntvaca2	85000	250000	3	\N	\N	\N	2026-03-24 20:50:31.113+00
63168789-5765-41c2-8bba-ab30774783ca	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 35 efkw9lad	85000	250000	3	\N	\N	\N	2026-03-24 20:50:31.695+00
08a7d598-07c8-4333-be97-c2bdbda2d180	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 36 h6vr8q0f	86000	250000	4	\N	\N	\N	2026-03-24 20:50:31.805+00
df2fb20e-b14c-4ee1-b6b4-f9c585fa497e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 35 2avjeecb	85000	250000	3	\N	\N	\N	2026-03-24 20:50:32.358+00
ac1dc139-2dfb-405f-a4e3-c0c8becbe2ed	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:27.248+00
0d3f36ec-5049-40c7-b376-194fed038c51	ae441525-4c02-48a1-9dbe-5a9fabbc4664	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 04:00:31.659+00
b0df47c8-3d6b-47a5-afc8-7d3e46d1441b	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 0 0r87bayg	80000	250000	3	\N	\N	\N	2026-03-25 05:30:44.986+00
5b3f010b-1be2-42a3-bc7c-4673f5f50eed	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 0 o43rmw0u	80000	250000	3	\N	\N	\N	2026-03-25 05:30:45.683+00
72d9f7fd-4666-408f-ba17-bfc75b223d19	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 0 709un57a	80000	250000	3	\N	\N	\N	2026-03-25 05:30:46.354+00
c468dafa-e2ba-4817-a48d-a9ec60f26ec9	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 0 umfdngid	80000	250000	3	\N	\N	\N	2026-03-25 05:30:47.028+00
33cbd309-0e2c-41b0-be36-5812b33722f3	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 1 f0q1weyl	81000	250000	4	\N	\N	\N	2026-03-25 05:31:04.131+00
db4a686d-a1bf-475a-aa7e-c8eea231213c	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 1 845u9a12	81000	250000	4	\N	\N	\N	2026-03-25 05:31:04.16+00
0f1467c8-39b7-4e75-b064-3ddee381fbc0	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 9 z6mapkt6	89000	250000	7	\N	\N	\N	2026-03-24 20:50:13.723+00
54751d9f-b130-4d79-ac69-f2a41aaee885	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 9 kjtahdtn	89000	250000	7	\N	\N	\N	2026-03-24 20:50:14.459+00
47abbda3-0fcc-4320-a6ef-c01088bed6e0	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 11 9nx8auk4	81000	250000	4	\N	\N	\N	2026-03-24 20:50:15.149+00
63780226-0bd3-4a2f-9875-c979efe50e0c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 10 3k5yh2jt	80000	250000	3	\N	\N	\N	2026-03-24 20:50:15.167+00
022c5ddc-b6b4-45de-bc92-aeb083e0cc3c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 12 0hz9grel	82000	250000	5	\N	\N	\N	2026-03-24 20:50:15.808+00
4c7847bf-09f5-4a64-a442-5b8b2639deea	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 14 vtd8gknb	84000	250000	7	\N	\N	\N	2026-03-24 20:50:16.59+00
50b77776-6ed1-40f5-9b97-a2134a00eb61	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 14 i1vebmrt	84000	250000	7	\N	\N	\N	2026-03-24 20:50:16.818+00
b857c48b-0690-45fd-875c-4304126c5c13	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 15 n0e3xnu3	85000	250000	3	\N	\N	\N	2026-03-24 20:50:16.901+00
a4c4e918-85d3-42f5-b61d-143b18b82a8e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 15 4nefl7bp	85000	250000	3	\N	\N	\N	2026-03-24 20:50:17.024+00
23e6599c-f135-4271-b626-27f3a519219d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 14 cxanrhwj	84000	250000	7	\N	\N	\N	2026-03-24 20:50:17.308+00
8b4a92fe-57b7-4901-8827-69f49f59cf9f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 15 v4yfwcbu	85000	250000	3	\N	\N	\N	2026-03-24 20:50:17.32+00
5a127a5a-2c71-4a42-b7ce-51b8036e8de2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 14 i35ms5mv	84000	250000	7	\N	\N	\N	2026-03-24 20:50:17.488+00
d5a73001-a743-4dc2-82c6-53f89b6a378c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 15 yo1l0w9x	85000	250000	3	\N	\N	\N	2026-03-24 20:50:18.179+00
1fee907f-1fa9-45ce-aa71-a13db361b64c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 16 i12ngk9l	86000	250000	4	\N	\N	\N	2026-03-24 20:50:18.496+00
b8dc3fb7-50a1-4a00-9480-37933f79bb9f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 17 z84ypaj4	87000	250000	5	\N	\N	\N	2026-03-24 20:50:18.624+00
33e69a36-0e52-4066-8bb8-c8af0256130c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 18 pvrn25q0	88000	250000	6	\N	\N	\N	2026-03-24 20:50:18.953+00
82527011-1152-42b1-b278-300b1e969b4b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 19 k55ywgvh	89000	250000	7	\N	\N	\N	2026-03-24 20:50:19.75+00
20ee79a8-5cc3-4a23-97dc-e13d3319312d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 18 nfhuy5ev	88000	250000	6	\N	\N	\N	2026-03-24 20:50:20.222+00
2479ff48-1c1c-4313-a69d-44822e5e9a79	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 19 h6ugh2ij	89000	250000	7	\N	\N	\N	2026-03-24 20:50:20.713+00
2c772157-dd8d-4580-a3b0-835d7fa5a5e3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 19 ehoy9qf7	89000	250000	7	\N	\N	\N	2026-03-24 20:50:20.763+00
097d287d-88ae-4f39-8e49-612cbf8dfd2d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 20 8l7pz3ie	80000	250000	3	\N	\N	\N	2026-03-24 20:50:20.842+00
5928088b-267a-469b-8cf2-63f0fa98f270	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 21 env3qa4a	81000	250000	4	\N	\N	\N	2026-03-24 20:50:21.306+00
8f60046f-9c1e-4950-9e5e-8dc21805c96e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 20 6ya97g84	80000	250000	3	\N	\N	\N	2026-03-24 20:50:21.31+00
b6079497-ea8e-46be-9814-9637df308f8d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 20 tp981kcs	80000	250000	3	\N	\N	\N	2026-03-24 20:50:21.901+00
1cc2b225-fc3d-4840-a08e-9f8a103ee1e5	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 21 013mlo3y	81000	250000	4	\N	\N	\N	2026-03-24 20:50:22.531+00
52d11079-17a9-4d7d-a798-c77910ef9a9b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 23 6p3c2ez6	83000	250000	6	\N	\N	\N	2026-03-24 20:50:22.618+00
aa28bad6-f9df-499d-a581-69c22ff5b6b9	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 24 htyj7rni	84000	250000	7	\N	\N	\N	2026-03-24 20:50:23.159+00
d41c25eb-2fd4-4f75-b5dc-86902d3b3ee2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 24 usy49ek8	84000	250000	7	\N	\N	\N	2026-03-24 20:50:23.167+00
15664f0f-febb-4e63-a649-ffc540591dcd	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 22 89lwdlsa	82000	250000	5	\N	\N	\N	2026-03-24 20:50:23.173+00
ea0c2912-dfe1-4c4c-b586-5353a37fd510	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 23 2va8iavb	83000	250000	6	\N	\N	\N	2026-03-24 20:50:23.184+00
59172051-7d7d-41b4-850b-eae8a423ecf8	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 23 z0lkkxw4	83000	250000	6	\N	\N	\N	2026-03-24 20:50:23.195+00
0f66c3cb-67b6-4c91-819b-a2bd7c62f5c2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 24 dwhv962y	84000	250000	7	\N	\N	\N	2026-03-24 20:50:23.218+00
0433355f-0124-493a-9a24-bf33bf9f286f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 24 86s2pn9p	84000	250000	7	\N	\N	\N	2026-03-24 20:50:24.048+00
c0ea8503-e40c-4daf-a1c9-82bf948e0d05	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 26 o8uvzjxq	86000	250000	4	\N	\N	\N	2026-03-24 20:50:25.995+00
669c96c3-5a6e-4899-ad2c-13e67378d7bb	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 27 0qs1w0t1	87000	250000	5	\N	\N	\N	2026-03-24 20:50:26.019+00
f5008d4a-32a6-42e9-b8ff-3f6212c10699	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 27 9s94ng3g	87000	250000	5	\N	\N	\N	2026-03-24 20:50:26.044+00
fad0ae05-3e4c-4573-ab99-05ab9ee24904	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 29 m6igqxlu	89000	250000	7	\N	\N	\N	2026-03-24 20:50:26.702+00
b4a44817-3e7e-4c72-97f7-a3d0ad86e580	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 29 9xm9d27r	89000	250000	7	\N	\N	\N	2026-03-24 20:50:26.709+00
f71097c0-e715-4e1b-a3d8-ba47cbe2705f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 28 lxg96qwi	88000	250000	6	\N	\N	\N	2026-03-24 20:50:27.328+00
c1b42a98-7c14-4564-8987-af6165d7f41a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 29 dw5s8qgo	89000	250000	7	\N	\N	\N	2026-03-24 20:50:27.344+00
d28705e7-9fba-4fe4-87c5-2209f2b1c834	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 30 cqpiyszm	80000	250000	3	\N	\N	\N	2026-03-24 20:50:27.424+00
20a1e400-b0b9-4b46-bf2a-a65abcdd9bbd	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 30 mqxozwsh	80000	250000	3	\N	\N	\N	2026-03-24 20:50:28.173+00
f575b00a-4d67-4fa0-a6e6-b8bdf29ceea0	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 31 39ynpjsa	81000	250000	4	\N	\N	\N	2026-03-24 20:50:28.179+00
a5230cdf-fb61-4f08-b7fe-4071322376ef	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 32 2ka7yg0x	82000	250000	5	\N	\N	\N	2026-03-24 20:50:28.787+00
4d03a289-80bf-411c-aca3-f7eb5fa324e0	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 33 v3u7yqxj	83000	250000	6	\N	\N	\N	2026-03-24 20:50:29.469+00
61f0c22d-5154-4ef6-af5f-3cfcf9f80e3a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 33 3jz5ygzr	83000	250000	6	\N	\N	\N	2026-03-24 20:50:29.476+00
58167e27-8f59-48f5-9ce8-28f236386654	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 31 yd9dksnt	81000	250000	4	\N	\N	\N	2026-03-24 20:50:29.551+00
9aa05bc9-c9f0-4890-a09a-3d6d2e20dc5a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 33 qgj3tny2	83000	250000	6	\N	\N	\N	2026-03-24 20:50:30.495+00
ec2c60be-eb08-4810-8f09-e4e5bcf082a5	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 34 ur5kt52q	84000	250000	7	\N	\N	\N	2026-03-24 20:50:30.506+00
1d609a23-ae19-49c5-bd69-9ace7244ba74	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 35 4mtybrfj	85000	250000	3	\N	\N	\N	2026-03-24 20:50:31.114+00
cac52359-2e73-4ba5-be67-993e423c35ae	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 33 b5g1zkcx	83000	250000	6	\N	\N	\N	2026-03-24 20:50:31.125+00
93e04ae7-0417-47d7-b7d9-ac1f4dcb85d4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 36 tcrjfvx1	86000	250000	4	\N	\N	\N	2026-03-24 20:50:31.752+00
7bb9a286-f042-474c-85f7-a1f8f21de4fd	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 34 zpnwwu5v	84000	250000	7	\N	\N	\N	2026-03-24 20:50:31.801+00
f3d8a572-3633-4751-ac28-50dc3f7b8452	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 36 hllxpf1n	86000	250000	4	\N	\N	\N	2026-03-24 20:50:32.209+00
60283638-cfcf-4bd5-93b3-d67fc638247b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 37 h3u6d8x6	87000	250000	5	\N	\N	\N	2026-03-24 20:50:32.274+00
ef4037f7-42e9-4f65-ba7d-e0bca6af2022	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 37 zy6wudai	87000	250000	5	\N	\N	\N	2026-03-24 20:50:32.636+00
e8aa4e41-2bb1-4e8a-83c9-8bf955f86c70	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 2 2l0gs1qp	82000	250000	5	\N	\N	\N	2026-03-25 05:31:05.327+00
e42e0e03-606a-403a-9122-7b06e65cce84	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 2 qts3r024	82000	250000	5	\N	\N	\N	2026-03-25 05:31:05.423+00
f4983391-4608-4bd1-9732-e64d4910f8a3	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 3 hnku7gxx	83000	250000	6	\N	\N	\N	2026-03-25 05:31:05.968+00
b4bc16b8-9575-43b3-8eab-2da65f15f651	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 3 41vk16vj	83000	250000	6	\N	\N	\N	2026-03-25 05:31:06.041+00
0bd6baf2-c125-4266-afe9-dfdd02add07c	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 4 wbwf17b8	84000	250000	7	\N	\N	\N	2026-03-25 05:31:06.33+00
dd2b4353-25bc-44b2-bb0c-95151e8b0184	82b2d709-4451-44ea-9076-65097bd7963d	k6 search 5 kdmsvsfm	85000	250000	3	\N	\N	\N	2026-03-25 05:31:07.429+00
e9900722-5b0c-402e-a143-6b1c1d6abaf6	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 26 mld3eg7l	86000	250000	4	\N	\N	\N	2026-03-25 16:40:25.924+00
5e9035a1-abef-43ec-99bf-2bcc951976b5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 26 0wra4vhf	86000	250000	4	\N	\N	\N	2026-03-25 16:40:25.936+00
641a256f-85c8-4b5e-ba84-aa723ec0ce6c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 26 jpqsj318	86000	250000	4	\N	\N	\N	2026-03-25 16:40:26.079+00
6ea5e0d4-aa28-4d1d-88d3-9d50783686fe	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 28 ko41v2jp	88000	250000	6	\N	\N	\N	2026-03-25 16:40:27.288+00
ac1d64c2-ef09-4a0e-8a41-5403b5b2f91f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 28 ypawmnsb	88000	250000	6	\N	\N	\N	2026-03-25 16:40:27.654+00
d65d1590-e458-4d83-8625-c44dff08d302	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 28 vgxcu3rl	88000	250000	6	\N	\N	\N	2026-03-25 16:40:27.85+00
fdaf6d0a-9295-494e-8498-02e229277087	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 29 o1pelz5j	89000	250000	7	\N	\N	\N	2026-03-25 16:40:28.448+00
cdedefaf-b867-491a-9b46-deb24ea78dce	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 29 jqlufsyq	89000	250000	7	\N	\N	\N	2026-03-25 16:40:29.455+00
549d6ab1-b3fe-4752-9cf2-9b725fbd0a68	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 10 253db15g	80000	250000	3	\N	\N	\N	2026-03-24 20:50:14.146+00
1fdf36a2-0a69-4cea-91d3-2937dd05f40f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 9 4p1ifo8p	89000	250000	7	\N	\N	\N	2026-03-24 20:50:14.556+00
6cfbae7b-0148-4e90-976d-df1ab36c1391	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 9 amzzykv0	89000	250000	7	\N	\N	\N	2026-03-24 20:50:14.629+00
dbd43aea-bce2-48fc-9d38-4952af3b0a9c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 10 a53e6mrl	80000	250000	3	\N	\N	\N	2026-03-24 20:50:14.656+00
858c862c-ea63-406a-9145-79f42a203c35	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 11 rqjmctmf	81000	250000	4	\N	\N	\N	2026-03-24 20:50:14.857+00
40530d66-86dd-4ecd-8ef1-d403355e513c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 10 w8aci6lw	80000	250000	3	\N	\N	\N	2026-03-24 20:50:15.221+00
883b0b78-e1e0-4638-a01f-0db2739d0bbf	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 12 vanojkal	82000	250000	5	\N	\N	\N	2026-03-24 20:50:15.303+00
d509d9ec-0e66-4280-9809-357ee41c742d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 11 59ooeoi4	81000	250000	4	\N	\N	\N	2026-03-24 20:50:15.809+00
6c836678-b06b-48de-9366-315d544aa3a7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 13 wbn9qwea	83000	250000	6	\N	\N	\N	2026-03-24 20:50:16.323+00
c59ffed7-8000-4e0e-8ec0-e0ab37d9c778	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 14 ruoea0gr	84000	250000	7	\N	\N	\N	2026-03-24 20:50:16.382+00
eaa5e868-a447-449b-b6c9-1e044f2d7d9d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 16 1lpz3uvh	86000	250000	4	\N	\N	\N	2026-03-24 20:50:17.49+00
d192e3b4-6e18-4f94-b453-92d673ebd55a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 16 kewdbjwf	86000	250000	4	\N	\N	\N	2026-03-24 20:50:17.554+00
8e40b165-2d9a-48bf-8ec5-bddd284c0bdf	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 15 jx0wucou	85000	250000	3	\N	\N	\N	2026-03-24 20:50:17.827+00
f6557bc3-3ff6-4324-9f02-b0223cff7de3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 16 97lr5ms3	86000	250000	4	\N	\N	\N	2026-03-24 20:50:17.857+00
72125cc7-bd25-4cb4-8b12-6d7bf2e458c4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 17 vj8osy5o	87000	250000	5	\N	\N	\N	2026-03-24 20:50:18.156+00
8b5dad1b-1c33-4db3-b00c-82b3771f2503	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 17 htwv5upq	87000	250000	5	\N	\N	\N	2026-03-24 20:50:18.185+00
64fad21f-f9f3-4f27-8a79-30c395c5ac2c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 16 7b8qw0xb	86000	250000	4	\N	\N	\N	2026-03-24 20:50:18.954+00
88f3e552-ed13-4020-a9f5-94010af9802c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 17 yoqntwz1	87000	250000	5	\N	\N	\N	2026-03-24 20:50:19.222+00
2c97eab6-5fc6-4328-8c58-0b07190fcd32	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 18 c1krkpuz	88000	250000	6	\N	\N	\N	2026-03-24 20:50:19.45+00
13977fa4-c06f-4c8c-b42c-8a5ec2b95273	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 19 v429tn6a	89000	250000	7	\N	\N	\N	2026-03-24 20:50:19.747+00
022b2241-7448-42b4-9acd-4106683e7020	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 18 5k44qhfo	88000	250000	6	\N	\N	\N	2026-03-24 20:50:19.752+00
626a574f-2717-4d4e-adf7-80014e32008a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 19 vm7qipkz	89000	250000	7	\N	\N	\N	2026-03-24 20:50:20.383+00
114031f2-674c-4ad5-9eb1-1c72c3df8b89	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 18 f647qhh7	88000	250000	6	\N	\N	\N	2026-03-24 20:50:20.696+00
f150aa66-9426-4615-801a-11fc7144794c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 20 d80emiao	80000	250000	3	\N	\N	\N	2026-03-24 20:50:20.703+00
50bb08f7-b6ce-4ae3-bf8f-436253ccbaa2	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 20 y183a67y	80000	250000	3	\N	\N	\N	2026-03-24 20:50:20.711+00
d7a00fbc-31ec-4a34-9e3b-2a26ed3cff38	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 22 muqsqprf	82000	250000	5	\N	\N	\N	2026-03-24 20:50:21.903+00
2c7e6593-e9d4-4a15-9081-6951dbe7d7b1	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 22 1iv4a5il	82000	250000	5	\N	\N	\N	2026-03-24 20:50:21.97+00
61e73b1e-9fb0-4e69-9e08-a9f64536d76c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 25 wdyiz0oi	85000	250000	3	\N	\N	\N	2026-03-24 20:50:23.948+00
1b2f4c8f-e5b6-4dcc-a777-f65b1d21c1ea	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 25 oot9dlyp	85000	250000	3	\N	\N	\N	2026-03-24 20:50:24.021+00
4fc8491c-7a1f-4cd3-9358-0a44d00d54e9	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 25 toj1by2c	85000	250000	3	\N	\N	\N	2026-03-24 20:50:24.05+00
f2f9d2d2-863c-493e-8189-1718cfe88122	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 24 ebbia51q	84000	250000	7	\N	\N	\N	2026-03-24 20:50:24.797+00
69477c1a-2e7a-47aa-bbf7-1bb1e11158b4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 25 i5qborxz	85000	250000	3	\N	\N	\N	2026-03-24 20:50:24.803+00
0e89cc83-e009-4971-b524-773e207cf230	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 26 1tr55fm0	86000	250000	4	\N	\N	\N	2026-03-24 20:50:24.812+00
41e88f1e-da46-4e70-ac07-edc23c1dec41	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 26 uqjcnmaq	86000	250000	4	\N	\N	\N	2026-03-24 20:50:24.818+00
71015434-ccb2-4134-8d69-db62a341e20a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 26 xnb6dxbz	86000	250000	4	\N	\N	\N	2026-03-24 20:50:25.425+00
8aad7fd0-f10e-4886-ada4-a37953da575e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 26 j84mkdls	86000	250000	4	\N	\N	\N	2026-03-24 20:50:25.431+00
c2116e45-f2d9-4c4e-932f-7a223749dc41	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 28 6qvwl3gp	88000	250000	6	\N	\N	\N	2026-03-24 20:50:26.073+00
d409fe9e-c0f9-41b0-8031-ceffabc7b02d	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 29 m52m5te6	89000	250000	7	\N	\N	\N	2026-03-24 20:50:26.703+00
15c40e6b-fdaa-49e8-97b1-894deddb4f42	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 28 hiti75to	88000	250000	6	\N	\N	\N	2026-03-24 20:50:26.707+00
fb894c02-245e-4300-9a56-35ea0bdd7113	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 29 01sqfudy	89000	250000	7	\N	\N	\N	2026-03-24 20:50:28.176+00
e366f5da-ad84-4743-a639-10ee20a87abb	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 31 y7v554ve	81000	250000	4	\N	\N	\N	2026-03-24 20:50:28.79+00
9153aff4-ab5c-4897-ae9c-fffba3157a5f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 32 33ndt810	82000	250000	5	\N	\N	\N	2026-03-24 20:50:28.82+00
b2e39cfd-2749-4ab7-b523-b3cdd8f6ad0a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 32 9dgjwh2h	82000	250000	5	\N	\N	\N	2026-03-24 20:50:28.848+00
e13ebf11-9413-44e3-bcd0-9644df9bf526	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 32 54k34oo5	82000	250000	5	\N	\N	\N	2026-03-24 20:50:29.464+00
adecfa8b-85a4-43a8-825d-d18efed821cf	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 33 i2gz70qz	83000	250000	6	\N	\N	\N	2026-03-24 20:50:29.468+00
12467391-3f3a-44a6-ad52-e4066e586506	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 34 j42tqqpt	84000	250000	7	\N	\N	\N	2026-03-24 20:50:31.089+00
f0cfdca7-7b7d-4abc-b844-52286487a6b6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 35 4bvjmdy2	85000	250000	3	\N	\N	\N	2026-03-24 20:50:31.112+00
e9fbf1c3-a7d5-412b-b634-d69d70a6bd71	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 35 wx54gfev	85000	250000	3	\N	\N	\N	2026-03-24 20:50:31.694+00
f28307f9-fbf5-4222-b053-a375666ef045	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 36 o2jepiyi	86000	250000	4	\N	\N	\N	2026-03-24 20:50:31.698+00
c6de9515-6200-43ac-b645-42a1ca7e5de7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 36 r9qtuknb	86000	250000	4	\N	\N	\N	2026-03-24 20:50:32.275+00
6b067ff6-5b6f-484c-9a04-836cc147a3a4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 37 2z4tsncs	87000	250000	5	\N	\N	\N	2026-03-24 20:50:32.357+00
a9eb2f2a-75cf-41f2-b809-97388a2ae5cf	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	k6 search 37 x44jyq9v	87000	250000	5	\N	\N	\N	2026-03-24 20:50:32.359+00
ac75ec62-d8ac-4b02-88bf-a3c760b4773c	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:26.651+00
0b1a3085-b104-4347-af6b-b85bf2eb4805	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:26.652+00
8269dd36-9530-457e-9f54-3ce28945ff5c	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:26.655+00
fb37e330-98e8-4fc3-b25f-ebcbb5224f12	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:27.44+00
5db57785-69e4-440a-b62b-0798c4ec2624	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:27.443+00
b84a5606-5285-4025-ba86-e633f5317ccc	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:27.445+00
76410c69-557f-4a4f-a3d5-5f571c9ca45a	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:28.185+00
d7f751e0-3a77-4fd7-9c0c-7f1918799a28	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:28.191+00
532b07e5-5e1a-40eb-8ed4-b76c11bb3c8f	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:28.193+00
6a0934fd-fa1b-4a3a-a628-4562bcc0ef1e	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:29.057+00
a8e412b7-524c-404a-b756-82f13bf64f02	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:29.06+00
c09f26e3-47c6-49c0-88aa-f242ace71a6d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:29.067+00
6365452f-f04d-4a74-9d0e-bade9b888d2c	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:29.741+00
0c91b286-053e-4448-8ca3-0b435e6894eb	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:29.744+00
7acf91d1-183d-4c64-ae6c-a60cf0911e2f	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:29.746+00
9155f2b4-91ce-4758-bf17-1c6980c18dba	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:30.43+00
7b8f50eb-046b-4005-9d6e-5f958f0b7882	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:30.471+00
9aa03e12-09f0-49a8-90ff-4a4affcf5beb	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:30.475+00
98beaa78-1090-47b3-8b1a-54fb12a0ee59	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:31.115+00
d438ce74-86d3-43bd-8d92-d20ab9cf9a5a	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:31.137+00
103b4c4a-fe34-429b-9620-a9a3f74128db	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:31.166+00
456b5850-313e-4013-bcb9-d783812109ec	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:31.821+00
bfe0faee-cc16-45fc-85a9-9c9588e845d7	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:33.168+00
f11875ca-1545-4b90-9a33-03008bdf6e05	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:34.708+00
7b243e4a-a81a-422d-9432-f46ebdbc8b50	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:34.743+00
2a903736-3ff7-4860-962f-16415e2dd1f8	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:35.494+00
6b3c664b-f8aa-4367-a5d6-2617621dd659	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:43.768+00
6fa13178-aee7-437b-94da-22c347bf6f61	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:44.141+00
02ec016c-bf92-41de-92f7-3c01813b97fe	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:44.941+00
8cd3bea1-1a59-49e9-9921-03c2e9a44747	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:45.57+00
49a945c1-d804-42ee-8f57-1dd5ad27144d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:46.2+00
0dc5f394-544a-4440-9544-6186447b532d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:46.973+00
9b8dcf04-7a92-4281-9c3c-659912337e52	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:47.619+00
ef15e11b-25e7-4e5b-b0cf-47dbfb25c1a1	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:48.272+00
6a852793-de50-45d4-95ed-7533324880b2	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:48.9+00
52e9d0bd-33fb-4262-b9bd-b84e7813d9ec	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:49.509+00
aebd28ca-95f3-4659-8190-0d60347f0a62	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:50.12+00
ee61b661-e75b-48a2-8913-bb69f322ce99	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:50.209+00
49685dbd-1108-4f52-adc2-1d47d1c64179	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:50.793+00
97bd9cf3-7065-4391-ad68-5f68cef30f85	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:51.441+00
7ddf92ff-168d-46e4-b057-f9707b089de1	38655d4b-7e66-4310-b585-79abfa3c2163	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-25 13:54:21.742+00
65356afa-000c-4643-bbcd-ccfa6353adb0	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 29 4l23io8t	89000	250000	7	\N	\N	\N	2026-03-25 16:40:28.848+00
783853c5-741f-4c97-939b-86a2ae4f328a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 29 dj9obf88	89000	250000	7	\N	\N	\N	2026-03-25 16:40:29.452+00
5d01d1da-c80c-47c1-b08f-d9905f85f69c	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 30 2jgff0u6	80000	250000	3	\N	\N	\N	2026-03-25 16:40:30.044+00
1762b5af-8851-4e83-bcdd-03e8ed21ce3f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 31 prkai31f	81000	250000	4	\N	\N	\N	2026-03-25 16:40:30.74+00
5b252230-856a-4048-9e39-0949e8550b30	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:24.414+00
e5e24076-594d-449a-a88d-8c1576f28d5a	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:25.091+00
8d5a3bfa-fd17-4c2b-a57d-c17cd09a67c6	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:25.097+00
939738aa-18af-4d07-9e02-98f1b3354f46	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:25.758+00
c6a91897-08e4-41e2-9e2b-197c1bc64936	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:26.43+00
71816e26-87eb-4c9d-9e70-b736309a44aa	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:27.229+00
187503cb-139f-4e19-b7bd-adf9824f844c	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:28.243+00
7cb8302d-8d09-4b2d-a511-b914c79777b0	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:29.385+00
5b590ff3-3990-424f-8fc9-c380c4466bf7	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:30.733+00
21b365b1-8e74-45fa-8be5-3d6d1eb91494	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:30.737+00
81947090-8afe-4300-a935-742ffde485a0	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:31.4+00
e5bc12ca-54b1-4a5f-b7d3-646c0c086365	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:32.154+00
f428454c-6565-40a3-8561-3f22d47230ea	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:32.823+00
5077b41f-0895-41dd-a93b-14941ad098ac	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:33.608+00
f5159b0e-0a1b-40ce-902e-ac1c9188328b	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:34.277+00
9072d49e-893f-4a6e-80aa-cb8b42f1c166	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:35.034+00
9ad77366-7fd5-4d3e-b571-ded69e3d0cee	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:36.177+00
b7dc423c-86bb-473e-b633-d5e6a054249c	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:37.021+00
8ad63ff3-884f-4af2-852e-9b1cb344cd74	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:37.711+00
5c67e11a-e2e3-480d-9518-4b2219b0e859	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:37.851+00
58df1e82-8a5e-47a0-a2cf-d22ce9f042b4	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:38.793+00
4289c45f-0fd4-4284-a598-7ce2f04aaa62	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:38.825+00
9b7dcb1c-45f0-49cd-868b-c3ff7272fc8f	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:39.399+00
079144ce-a7ae-402a-863d-5890a1f99b6c	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:39.444+00
f982d67b-c98a-4de4-8458-c5115f858ed4	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:40.034+00
c5f3f3d0-1d2c-49ff-a05b-9c3e88acc0be	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:40.198+00
6453cc50-6160-443e-94e5-2d2709814a58	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:40.914+00
f343add2-2bb4-4282-93bf-2d97f433d66f	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:40.935+00
d3205479-25f6-44ca-a50c-b47840f4ab6b	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:40.944+00
561c771d-dd44-4e5f-ae6a-e211baef7618	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:41.552+00
f069fcba-fd8b-4afd-a9e8-cd5838d02fbc	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:42.197+00
f2d31b3e-d8f6-4040-912e-58670c622f96	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 0 soykbhp3	80000	250000	3	\N	\N	\N	2026-03-25 16:52:11.483+00
53a7a7f8-3b09-4d26-a53e-a0c4edb2c7f0	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 0 9yh73z37	80000	250000	3	\N	\N	\N	2026-03-25 16:52:11.493+00
b6b81380-ea5a-4fec-8896-20614f8a8c96	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 0 g6g8f6i1	80000	250000	3	\N	\N	\N	2026-03-25 16:52:11.641+00
ebb67627-e306-4f4d-946d-2b17ca3786c6	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 0 2v5ua6b5	80000	250000	3	\N	\N	\N	2026-03-25 16:52:11.646+00
ba9e9456-3aa4-4764-adf2-2f2b7c80b8a3	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 1 2ugs0tad	81000	250000	4	\N	\N	\N	2026-03-25 16:52:12.384+00
789fc1f7-9526-4e88-83ad-d42a32547b44	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 1 uqpbq1hs	81000	250000	4	\N	\N	\N	2026-03-25 16:52:12.402+00
6bc2e3c5-6a2a-4a03-b351-37248ad65c15	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 1 rdx0ym14	81000	250000	4	\N	\N	\N	2026-03-25 16:52:12.409+00
5f70eb1c-4ceb-4d1c-818e-c2da113ca4d0	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 1 tu0j5jay	81000	250000	4	\N	\N	\N	2026-03-25 16:52:12.414+00
5652c5ee-54b8-41b0-8a59-7ebd3d78f6a9	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 2 5ve0359j	82000	250000	5	\N	\N	\N	2026-03-25 16:52:13.616+00
8731d47d-4995-49c9-984a-92f6b2fba88e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 2 ufw6x0mx	82000	250000	5	\N	\N	\N	2026-03-25 16:52:13.646+00
3a9e2c85-bf50-4ed2-a621-719640d1b0f9	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 2 3nj11urm	82000	250000	5	\N	\N	\N	2026-03-25 16:52:13.651+00
d5dcdbb2-cdf1-48ab-8a9c-84b56f0ca094	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 3 hj5kvrna	83000	250000	6	\N	\N	\N	2026-03-25 16:52:14.699+00
6afde16a-199f-49e6-b9f3-07b4df5a819d	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 3 08vzm1ox	83000	250000	6	\N	\N	\N	2026-03-25 16:52:14.701+00
0d72238c-e6d3-448f-a18f-4d7e0d2dcc93	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 3 yd0tzvx0	83000	250000	6	\N	\N	\N	2026-03-25 16:52:14.705+00
78e0a7d7-542d-40a2-8fbf-f2bd783b7fc4	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 3 4bfp99x1	83000	250000	6	\N	\N	\N	2026-03-25 16:52:14.708+00
6400a45c-12be-4298-a3e6-ab8d3c159522	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 3 y58ptws9	83000	250000	6	\N	\N	\N	2026-03-25 16:52:14.711+00
6ff16357-6cfb-43db-947b-48115676f203	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 3 o26zkwui	83000	250000	6	\N	\N	\N	2026-03-25 16:52:14.718+00
611b9769-28d4-4fb4-8729-b10bf6d17209	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:31.77+00
7dcb20bc-4703-4982-9731-6d5eaa927c5c	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:31.791+00
e60ada02-177a-405c-854f-6775bc05858a	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:32.448+00
80b1657e-052a-4413-9dba-6e00c5c9fd35	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:32.472+00
071c0837-ebaf-4984-87de-755a19af5c2a	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:33.166+00
6b14b869-1ed3-485f-9c1e-ba67c3154898	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:34.005+00
ef731502-5832-4278-83b3-81e2032f9700	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:35.495+00
0a074546-e10a-4111-be97-c25f260e86e3	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:36.022+00
fdad0977-f2f1-4bdb-9576-f78c7f99b1da	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:36.111+00
12b18017-b6f7-4b87-bd6a-efda017105dd	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:36.688+00
e760c4ac-5ae8-4bed-9d82-d837c3344f98	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:36.744+00
658721dd-4dc4-442f-bae1-3839ea258b4d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:37.346+00
1ef3d735-2b66-4e0f-b5b1-638edd70f1ed	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:38.067+00
fda71526-7c17-47a8-a898-fc6c2cef40f1	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:39.191+00
fc57233f-515d-43d7-a18f-4c70ce9da8ee	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:39.285+00
38846059-65bb-4b30-aa05-38c275250334	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:39.798+00
76f6f432-1555-4d13-b5c9-ff3717e8429f	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:39.894+00
e2412822-153c-46b5-ae05-d58694b3baa1	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:39.899+00
3065a690-2e58-4a5b-9a08-41d1579da0a1	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:40.427+00
a7450d02-ed6e-43b7-b193-ce281376c2f5	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:40.495+00
e7d2aa11-5e34-4d88-a991-ec15792c8973	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:40.519+00
e16a82f7-4181-46f4-b209-9d5cca372d1d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:41.062+00
541c54c1-cbe3-4768-aac2-f0db066141c8	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:41.192+00
ab18c096-561e-4259-94d9-87180d23103d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:41.232+00
8055b62d-bb4c-4203-914b-8737aea8c001	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:41.661+00
3fcaf07d-705a-4d61-8772-b2196708a196	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:41.81+00
3bb5c50a-66fe-4590-8770-78e1ecadd3ba	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:43.07+00
a951f473-8ecc-4a48-bfb8-2a0837e0e1c1	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:44.085+00
53463089-9e12-4e4a-a0af-09c5ae72dc54	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:44.8+00
fed6850e-1e77-42fb-a6e4-ca04808aa0d0	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:44.939+00
e29d6c58-c713-4849-9414-b3265eef5739	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:45.42+00
307aaf68-98eb-4c6c-97a0-3936e63a0652	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:45.569+00
045fa3ce-4b1c-4c49-bb83-fb4a5d62ceae	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:46.008+00
9344e53b-c1f7-4e8b-9a2a-367b5bada710	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:46.197+00
62c2c99b-36f1-45cb-a4a6-3f02bcbb55a8	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:46.609+00
cf7c6289-72ac-4fd5-abf9-6f3449507376	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:46.971+00
d092cb2d-c68a-4be9-be5a-5f82943e75bb	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:47.208+00
1746107d-d883-4c63-a249-526a2cc1f07a	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:47.616+00
8920d38e-6d1f-4b16-b7f6-6d428cf09b63	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:47.848+00
917bfcbc-09d9-4357-a5b6-a104a1899fe6	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:48.27+00
c951046b-7a48-4438-baab-17cd023addd8	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:48.45+00
009be333-9fb1-48a9-8c51-7c4390ba9d47	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:48.898+00
e510d8ca-cc38-4788-8d97-a44738ad9c32	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:49.036+00
02e7f0f4-6e3b-4e3d-acef-deffd0522e0a	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:49.507+00
bee36e6c-54ae-4456-8af8-4a4a1d861d9f	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:49.618+00
0a6534ae-61bc-4518-87eb-86173a23161d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:50.118+00
0bbb9faa-ac16-4b63-b2d6-f4067d34a7d0	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:50.791+00
7fe0e4d5-827f-4a47-a750-5a894d742bd7	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:50.947+00
8238d5ef-cf65-4599-8928-b4f40ea449c5	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:51.435+00
8becc08b-ac33-42eb-8f79-1bc51fba3c71	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:57.076+00
e9b1a294-71ab-43f6-ae28-918740f3889b	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:57.074+00
068af6fb-6fa5-42ba-b120-4b35fd81abab	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:57.075+00
98174b5f-e777-4590-8a90-73491f01556f	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:58.243+00
b04aaf4d-9aeb-40e9-8e64-b3da13722036	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:58.245+00
103c2ea7-cd45-4a76-9071-f1711b2f7fbe	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:58.247+00
273f4a0b-5e08-416b-98a0-a57b680cd152	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:59.608+00
e38805c2-0f55-4914-b623-0c8825578590	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:59.61+00
0fa265a0-4aba-4e8d-9a4a-ec869c307276	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:38:59.613+00
9a1fc0e5-6dd9-46cb-aff4-cd608d775dd6	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:00.426+00
4ed6d23d-662f-4d5b-94b6-da15e74b597b	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:00.431+00
f7634998-072e-4f67-8d68-7380d5d54629	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:00.433+00
9fd3c72b-c28a-4cd2-bda6-217e393f1360	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:01.165+00
ce7f2375-0003-4b48-a38b-569c39f242c7	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:01.167+00
164cc8c9-9ff0-4e30-b45b-ec7574000e1a	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:01.169+00
5d0f3cf1-966b-4851-9e90-b6d178d41726	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:01.901+00
ef2ad520-e6c5-43a7-bdf5-dbc0a891fb23	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:01.906+00
2d3d822d-250e-4b06-bab7-34af0799c6ef	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:01.908+00
6dd8d3d2-b9cc-4f34-86f3-3f81a416f055	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:02.606+00
923e3591-9ce6-48c7-964f-c5201be484d7	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:02.608+00
d1b33930-042c-47c0-84bf-2d8c4ef59416	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:02.61+00
41006d31-3c66-4b51-84b4-cfcce4b7e84b	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:03.393+00
6f7cb643-2194-4d75-b86e-060b61ccbf72	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:03.395+00
e11b2b0e-7892-4bdf-affa-44f408030e45	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:03.397+00
9cb5f903-9ab7-4b65-a122-438f8401dacd	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:04.076+00
7acd42db-da8f-497a-bee2-d3201bdd3040	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:04.082+00
14aa38d5-2f29-4b93-b68c-1b4fc6972896	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:32.446+00
7579d068-442c-4fc1-b7f9-a44949caebde	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:33.152+00
0d764f99-9c75-4c53-b602-dfdf3a4df534	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:33.986+00
8ecffdb8-9f8e-4d1f-99e2-e9b283e4f6aa	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:34.003+00
e245479d-218b-4f8a-9a70-d720703e13cf	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:34.745+00
2f77eaf3-e8e3-447c-9786-327c24e90008	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:35.386+00
68035e66-87dc-4edd-ad81-9459727eae6f	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:36.113+00
1669b405-24eb-494e-a20d-fd8754f763bf	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:36.767+00
9fbd2036-442a-434b-901c-585ab1237d1c	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:37.399+00
07793a8b-6005-4b4c-bd99-c60c8dc2c5b4	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:37.408+00
afe9a954-35ed-40e9-8a23-78f7a20ba7bc	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:37.976+00
bb1cb8c2-f3bb-48bb-8e01-e23e44eae0a3	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:38.026+00
c73060ee-7ec2-494e-8965-15678d719895	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:38.61+00
bb5359cd-953d-4dcd-b3e2-519995127e0d	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:38.658+00
46b260a7-4111-448d-a0c0-f0711b38adde	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:38.688+00
9378959f-a49c-421a-9cc1-f45ef889ae06	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:39.264+00
68b6611c-8a2b-43bf-a7f6-8ea98cc11fe1	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:41.862+00
455b58df-c260-44c6-93e9-cf0fd760cbc6	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:42.249+00
a621eada-3933-4156-a56b-d034b07716c5	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:42.414+00
cf728b28-76fa-489e-9aec-8963ec079f08	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:42.454+00
f6406cf5-5e67-4e06-b421-8a42e1d43544	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:42.868+00
76d929b9-ae51-4c9c-a201-d733b438c128	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:43.065+00
834e0a33-7340-4d65-b0cd-b6c1a1596bd7	5acf92e3-43de-48cd-8e6b-22fa9da89d38	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 01:30:51.544+00
d631a512-6476-4ac0-bd36-8293f0e3c9e4	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:04.098+00
a15fefa0-266e-4011-81ea-44631ff839ef	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:04.852+00
908e3563-6109-4e84-a07c-8471597116ae	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:05.598+00
58f16ca8-48ee-4384-bb2e-90e6d823bce9	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:05.61+00
5cca375a-c1a2-47d5-959d-7830931861b9	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:06.254+00
6fa09e41-68db-4d8e-aba4-23c835a5fe23	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:06.891+00
02569a8c-2f61-4833-b719-8113be3450a3	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:07.641+00
f4c5a70b-7648-41fc-af18-b39b7505be88	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:08.669+00
3431a62a-fee4-44da-8473-f94600977f14	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:09.42+00
b9e7b528-c2df-40b4-bc70-b3761b20a51b	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:10.814+00
177fdb2d-e02f-42fb-b6e6-e0bbc17daf65	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:10.825+00
3feeab34-d79e-4000-ac2c-d981b9f08cdc	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:11.496+00
df07c628-5b36-412f-ae05-242b4bcf329a	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:13.999+00
cd3683ad-8aca-4df3-86ee-55e22a5e0ddd	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:14.669+00
7a52b5b7-e646-43cc-b399-c57143f7ee47	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:15.367+00
79622b93-08d5-4225-9d94-18edeff3510f	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:16.046+00
b2222569-3e04-4d87-aaf2-823be6627d3e	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:16.691+00
28874c75-62a8-44e8-b776-bde4f1bd22ad	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:17.32+00
71787fd3-b968-4631-8407-0129af1b9039	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:18.057+00
dc327b43-be82-4011-bc1f-cf9d3ea23181	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:18.852+00
8a9f2dce-0338-4c39-9bd9-a45fe22ab7f3	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:19.643+00
ab1eb445-5059-4937-be71-944a02c88081	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:20.285+00
165576c1-1f73-499e-903d-167c4a4b3665	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:20.96+00
ef936991-1427-43dd-8ebb-a1415215b69f	0f59c6e6-f518-46b3-9a99-23f870b06ec9	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:39:20.997+00
6b8884c3-c57c-4e4f-91e2-ad0bd0a62a3e	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 30 t3h6z3q2	80000	250000	3	\N	\N	\N	2026-03-25 16:40:30.493+00
fc62ccfc-e8d3-4de2-b7b9-1506c2e2a0ab	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	k6 search 31 xxkqtn3k	81000	250000	4	\N	\N	\N	2026-03-25 16:40:30.624+00
cc9cd34a-90f5-438a-afab-959a60ca2e63	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:30.089+00
46a70f3c-49bb-4542-ae8b-ce918ccf3b54	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:30.093+00
d1835cc7-851d-495e-91f8-ae2e4c3dd054	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:30.734+00
949c4d0b-c60e-436d-8276-abd810bbb199	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:32.159+00
806b59f7-6b59-4e6b-b316-26090888cb30	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:32.825+00
bcd6e578-f4fb-4d90-8c39-26cb17f6c733	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:33.604+00
53a16d70-d657-4d16-b264-04016d0b3b82	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:34.275+00
96f6f2f2-40e5-4771-96a0-128dc355b3aa	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:35.033+00
9184d0d7-208a-47ad-a48a-ef87beea860c	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:36.182+00
e64e07b2-db98-445a-9934-905876fe553b	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:37.025+00
f662da27-ccba-4d51-87f5-a6e7d8abc577	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:38.829+00
d3d1e825-e29a-4fb2-82e0-3b3df85db0d1	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:39.452+00
f0688cef-3e0f-45d2-b0b0-62110686aa84	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:40.204+00
1d5f0305-a1fb-4d13-9825-f4efd35af581	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:41.555+00
de1dd4a8-0c57-45fa-84d1-e792ef7f75ea	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:41.561+00
c1069ce1-77bc-4c21-83ac-9f5605e08d3a	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:42.201+00
1143db0b-23cb-4920-af87-7fca999f7886	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:42.852+00
85e4eac0-de28-4adc-8362-f21373f0505f	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:43.043+00
370efced-6139-4e83-a3a9-882c7cd3db40	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:43.996+00
99ab9601-a16c-4e98-a931-a527d8951866	8ef65d68-30bd-4bbb-9fe4-5851caeca512	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 16:51:44.392+00
eec9e2ac-ffdd-4b2a-89df-cec8c9e85759	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 0 v7rixqyb	80000	250000	3	\N	\N	\N	2026-03-25 16:52:11.473+00
e54f763c-f958-43dd-9bb0-d547b4788c3d	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 1 5wayr393	81000	250000	4	\N	\N	\N	2026-03-25 16:52:12.406+00
c03d2546-7680-48e8-859f-cd2bab16a16b	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 1 vpicdlwf	81000	250000	4	\N	\N	\N	2026-03-25 16:52:12.412+00
a210d84b-57c6-411e-96df-9ac613af90c0	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 2 szzb58ea	82000	250000	5	\N	\N	\N	2026-03-25 16:52:13.613+00
2a3b90c8-d82d-4069-9b1f-7b900e88583a	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 2 27pn5eo2	82000	250000	5	\N	\N	\N	2026-03-25 16:52:13.642+00
ab3cebda-9ca8-493e-99ca-3c458612bf43	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 2 abc9d83k	82000	250000	5	\N	\N	\N	2026-03-25 16:52:13.654+00
da150627-8ea2-4ee6-8fb1-721d7a197b7e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 4 lv6x0la0	84000	250000	7	\N	\N	\N	2026-03-25 16:52:15.494+00
e1cba043-7136-4eae-ae08-38d279ffc570	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 4 54vmmjdq	84000	250000	7	\N	\N	\N	2026-03-25 16:52:15.545+00
42d51260-f0a1-4a1b-83e6-5bf9a6e28dd6	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 5 ennvk4yv	85000	250000	3	\N	\N	\N	2026-03-25 16:52:16.334+00
2734ed28-63e0-41b9-a14c-2c829937b5a3	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 6 j4rc9g6x	86000	250000	4	\N	\N	\N	2026-03-25 16:52:16.852+00
3a1443a1-7a5a-43d8-84b8-5751039bbe09	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 6 3h1049q6	86000	250000	4	\N	\N	\N	2026-03-25 16:52:17.46+00
65c869ed-5067-4705-a16c-b0c0f5c0dcd4	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 6 s1bptb9s	86000	250000	4	\N	\N	\N	2026-03-25 16:52:17.661+00
8e70f78f-8c32-4def-85b4-8909778d12b5	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 7 g7tdr0u8	87000	250000	5	\N	\N	\N	2026-03-25 16:52:18.453+00
8fe42b8e-3833-4fc4-8e50-00cdecefc673	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 7 5cjib85o	87000	250000	5	\N	\N	\N	2026-03-25 16:52:19.042+00
6d85a94a-bd4b-49e4-ad96-a99761580213	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 8 9j5iernl	88000	250000	6	\N	\N	\N	2026-03-25 16:52:19.987+00
c31249a1-eb13-488b-bb43-7934f7d0a04e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 10 fp528648	80000	250000	3	\N	\N	\N	2026-03-25 16:52:21.584+00
9ee91c96-bd0f-444e-be24-5121865a7137	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 10 hhkskpud	80000	250000	3	\N	\N	\N	2026-03-25 16:52:23.107+00
175827ff-0cd3-42ea-863e-024b26aa253e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 10 oq9f74is	80000	250000	3	\N	\N	\N	2026-03-25 16:52:23.284+00
0eaff280-88f9-404a-a217-f9d34ad7e3ba	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 12 plq64azz	82000	250000	5	\N	\N	\N	2026-03-25 16:52:24.449+00
de642160-ad7a-4a19-8161-a1d9d8ca04b7	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 12 jrelh7l5	82000	250000	5	\N	\N	\N	2026-03-25 16:52:25.333+00
d4343469-e09b-4f61-a8a5-9b423431dfff	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 13 osxdpmv2	83000	250000	6	\N	\N	\N	2026-03-25 16:52:25.409+00
e44d5290-9c69-4705-920e-4c2f37440265	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 13 ceqvd64o	83000	250000	6	\N	\N	\N	2026-03-25 16:52:26.584+00
ab0cf9bf-3a02-4193-9d15-a740576032dc	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 13 1f529pdt	83000	250000	6	\N	\N	\N	2026-03-25 16:52:26.597+00
7e0d7ddf-3c93-4e2f-9dd4-2899b3573723	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 14 nfo1t15z	84000	250000	7	\N	\N	\N	2026-03-25 16:52:27.305+00
ad08e3f5-538d-4349-9065-b1c53d0c47e9	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 15 gtgk9fdz	85000	250000	3	\N	\N	\N	2026-03-25 16:52:27.325+00
f5ed29cf-ca86-4d52-8867-1dd037b0fc38	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 16 2ul3q879	86000	250000	4	\N	\N	\N	2026-03-25 16:52:29.856+00
0c562bb6-5628-43c1-9e2d-ce6623cf774a	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 15 babj44hm	85000	250000	3	\N	\N	\N	2026-03-25 16:52:30.059+00
d174a02a-c3d9-4a01-b0fd-105a7ce3cc93	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 16 ln34hf9v	86000	250000	4	\N	\N	\N	2026-03-25 16:52:30.998+00
469bec76-d0d9-4eb7-9a14-7909ea49f6e8	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 17 l83vu7u2	87000	250000	5	\N	\N	\N	2026-03-25 16:52:31.029+00
baa43608-ab7d-4bd8-b658-43cf81212834	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 17 pxu78a0z	87000	250000	5	\N	\N	\N	2026-03-25 16:52:31.046+00
02e56565-eb16-445d-8fd4-75e1797248ab	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 16 s0mvrtve	86000	250000	4	\N	\N	\N	2026-03-25 16:52:31.106+00
2dcdf656-815f-4e63-b109-1637fe502bae	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 17 hrm57z7n	87000	250000	5	\N	\N	\N	2026-03-25 16:52:31.63+00
c35018d4-9160-4448-828e-70a31fdf3b1b	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 17 sn39xdoj	87000	250000	5	\N	\N	\N	2026-03-25 16:52:31.8+00
d5d9315b-c2a4-4310-a4f2-b568f6f700ae	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 18 5xi9gv35	88000	250000	6	\N	\N	\N	2026-03-25 16:52:32.14+00
810d7f9e-0895-49a5-bfd4-2a89a9ab6e1f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 19 l509oshf	89000	250000	7	\N	\N	\N	2026-03-25 16:52:32.39+00
2d40cee6-44c7-4af4-a60c-43a1d712b243	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 19 ha2npmqo	89000	250000	7	\N	\N	\N	2026-03-25 16:52:32.402+00
9003a5b2-9627-4811-9281-a6ee03572c1b	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 19 edx3xanq	89000	250000	7	\N	\N	\N	2026-03-25 16:52:33.015+00
df172433-a408-48ad-b158-f69efa437c50	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 20 dtwba861	80000	250000	3	\N	\N	\N	2026-03-25 16:52:33.047+00
dde83f53-9e02-4810-9cc1-0873e64b4efd	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 20 lsm5h9v4	80000	250000	3	\N	\N	\N	2026-03-25 16:52:33.227+00
dbf3a221-bd5f-4f95-bdaf-c19fcc112ff5	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 20 o328qblt	80000	250000	3	\N	\N	\N	2026-03-25 16:52:33.263+00
e819bd79-0ff9-4f96-8873-4f9f8f916639	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 21 empv2u4k	81000	250000	4	\N	\N	\N	2026-03-25 16:52:33.771+00
a99fad58-83d1-4e34-bace-a7068a795c19	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 23 qh9xm7ei	83000	250000	6	\N	\N	\N	2026-03-25 16:52:35.066+00
6ebe2649-eff4-4b29-bb2a-326800e46fe0	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 22 6pj7exxn	82000	250000	5	\N	\N	\N	2026-03-25 16:52:35.147+00
59dc66e3-ab37-4640-b199-f6967673ff6d	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 23 zfsd51eu	83000	250000	6	\N	\N	\N	2026-03-25 16:52:35.184+00
8a5ed905-81b1-431e-a52f-a277519d6f4c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 23 dwgjyocg	83000	250000	6	\N	\N	\N	2026-03-25 16:52:35.189+00
7aefbbc7-d9a3-4577-98d0-0ff1b46dec6a	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:02:58.263+00
5b19967b-f77a-4baf-8fd5-3214f5e720d6	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:02:59.963+00
827d4e7f-0419-4ee3-80c5-ad39096872fa	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:01.267+00
abb99a84-8f9f-48e7-959d-d7d956a5bba4	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:04.745+00
b44bb63c-786e-4efd-8d8e-39da0c286f9c	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:04.867+00
b9ecc1d2-d5d4-4d4a-8923-f625b989068e	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:05.591+00
3577b3f2-3cf3-4ccb-a8a0-84e0a5797408	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:05.674+00
591861d4-f140-4850-acf1-26d168d78b8c	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:06.575+00
7d69f4f8-d78e-48b3-b153-2ac49ab52a6f	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:09.397+00
e45c7317-d2dd-4173-8636-26622312c350	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:10.013+00
4e4ded51-66d9-4353-965c-f6d9619738c1	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:10.109+00
f458f5ae-0e7c-4d16-a702-1da479630ebd	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:10.874+00
e77bd11b-776f-46aa-8926-3bf230d098a1	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:12.005+00
51b123f9-7cad-4729-9eb9-76ea78ac44ab	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:12.733+00
cc63e113-e8d8-45cf-b71b-dd0473792756	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:13.462+00
6bfabcd8-42ba-4961-8472-13039e21c96a	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:14.784+00
eff5b8a1-4d99-45b8-9996-b70c83bcccab	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:15.78+00
d8b6f3f6-d064-4f87-badd-9512a2cd8bdc	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:16.765+00
227e08f1-1d25-4d0f-a195-7954472cb35d	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:17.693+00
30441351-e821-4b82-be0d-130cf46cfcbe	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:18.474+00
3dbd5b13-df8a-49b9-8824-30e5624f0f54	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:19.243+00
1dda1df4-c68f-456e-8c3b-ebc4a49dc972	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:19.86+00
5e8e69a3-4276-4d3c-8a4a-789b7822b893	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:19.901+00
ccce22ae-00c0-4d8d-8603-b8eec532e033	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:20.563+00
055f4ac4-29b9-42a7-a112-bfb3b465c7f3	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:21.581+00
ca32c41f-ceec-42cf-a064-3f8945e23350	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 0 c5ts3dge	80000	250000	3	\N	\N	\N	2026-03-27 03:03:50.421+00
bce6d06b-07db-4610-b800-dded038cf804	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 0 06yjxj5w	80000	250000	3	\N	\N	\N	2026-03-27 03:03:50.462+00
89745550-ffd2-4648-9590-d0c39cd56dd2	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 0 eozmglsc	80000	250000	3	\N	\N	\N	2026-03-27 03:03:50.484+00
5a3f9759-4e21-4df0-8ba2-5bf408bdb8d0	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 1 yggceci0	81000	250000	4	\N	\N	\N	2026-03-27 03:03:52.361+00
65fd9799-ddbe-4e1c-99ec-b8a3d48fcf96	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 1 6ydp0zju	81000	250000	4	\N	\N	\N	2026-03-27 03:03:52.367+00
b5aa0c54-cda2-4435-97f7-38df6a48e7d8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 2 yxyn6qkm	82000	250000	5	\N	\N	\N	2026-03-27 03:03:53.539+00
8e8369f2-c0a5-461d-b10d-5e950b81ad09	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 2 trr08pyc	82000	250000	5	\N	\N	\N	2026-03-27 03:03:53.663+00
93dd4157-cab9-4524-b7cb-4e78ef4345d6	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 3 pet9i161	83000	250000	6	\N	\N	\N	2026-03-27 03:03:55.624+00
449f9942-a313-440a-b8f2-d9201f34b247	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 4 55tfqixs	84000	250000	7	\N	\N	\N	2026-03-25 16:52:15.496+00
cb2d648f-5216-4603-8351-4219393ff72c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 4 00cwsyae	84000	250000	7	\N	\N	\N	2026-03-25 16:52:15.543+00
12b36789-4956-427e-a0ec-e56fed9bb4e3	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 4 ufibqf4x	84000	250000	7	\N	\N	\N	2026-03-25 16:52:15.569+00
7c883eec-b2d9-4735-aa94-92627ed3472b	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 4 12rrcw2w	84000	250000	7	\N	\N	\N	2026-03-25 16:52:15.595+00
ae07f20e-a499-466d-9dbf-4f112a09d6a0	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 5 lhb0i8w1	85000	250000	3	\N	\N	\N	2026-03-25 16:52:16.019+00
79a0fdbd-9c95-4391-812a-8661d6c7be0d	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 5 vit19u2b	85000	250000	3	\N	\N	\N	2026-03-25 16:52:16.22+00
da5aba7c-7e0c-4296-b888-4e296ca4f9e4	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 5 qyats18e	85000	250000	3	\N	\N	\N	2026-03-25 16:52:16.312+00
e4bae500-b566-4071-8560-348495bc50ed	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 5 jo22f3yc	85000	250000	3	\N	\N	\N	2026-03-25 16:52:16.328+00
adbbb649-8785-41d4-b63b-690a19c05092	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 5 s09da1k0	85000	250000	3	\N	\N	\N	2026-03-25 16:52:16.338+00
34a42ff0-6bd3-448a-aac1-f9a9432bb9a9	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 6 wkd1zjco	86000	250000	4	\N	\N	\N	2026-03-25 16:52:17.465+00
cb8deed1-ffdc-4915-8435-bf5b9572213e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 7 73triqdc	87000	250000	5	\N	\N	\N	2026-03-25 16:52:19.044+00
6b7550cc-7a61-4c9a-932d-5312ec2c8a2e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 8 9z74ykv9	88000	250000	6	\N	\N	\N	2026-03-25 16:52:19.58+00
b2a3087c-f382-4765-9f27-bb4fe1bc4eb6	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 8 06usgnj9	88000	250000	6	\N	\N	\N	2026-03-25 16:52:19.625+00
210c4d80-f89e-4da4-8860-3bcf2ae81a98	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 8 b1837gpr	88000	250000	6	\N	\N	\N	2026-03-25 16:52:19.985+00
a487c70d-0a5d-4d9b-81c1-e8296c4e9566	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 9 dini00w5	89000	250000	7	\N	\N	\N	2026-03-25 16:52:20.183+00
e4a8156a-30ff-4cf1-89b9-d1e68b39771b	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 9 jyglktqg	89000	250000	7	\N	\N	\N	2026-03-25 16:52:21.547+00
6f976a7d-3571-4ab6-a2f1-e7aaaccad255	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 9 y9gh0mzc	89000	250000	7	\N	\N	\N	2026-03-25 16:52:21.581+00
d3e3418c-3c2a-4d36-ac30-a523e6d6a86f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 11 o9vy95kp	81000	250000	4	\N	\N	\N	2026-03-25 16:52:23.286+00
65ba514c-72f7-4046-acf2-ae518e8939ce	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 11 e5535ff5	81000	250000	4	\N	\N	\N	2026-03-25 16:52:23.501+00
239011fb-488c-4083-9c33-e3258fd88ec4	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 11 ex320oe5	81000	250000	4	\N	\N	\N	2026-03-25 16:52:24.226+00
a19f5c81-1fa9-4a31-8299-c256bce1128f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 11 n5b8xyyg	81000	250000	4	\N	\N	\N	2026-03-25 16:52:24.242+00
6c22a219-756f-4353-8d01-881b70d4415f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 11 y097t1i1	81000	250000	4	\N	\N	\N	2026-03-25 16:52:24.447+00
0d208487-089c-4363-b297-bc84d1e4dd7a	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 12 fy747lz1	82000	250000	5	\N	\N	\N	2026-03-25 16:52:25.349+00
80d1f690-fc74-49b3-873b-5ce90058f363	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 12 aroidjgb	82000	250000	5	\N	\N	\N	2026-03-25 16:52:25.401+00
86d94b95-9248-4cde-bcf4-95b7781846c1	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 13 zfoeni2b	83000	250000	6	\N	\N	\N	2026-03-25 16:52:26.576+00
1ba40aae-c0b0-4f15-bd4e-44fc747ad4cf	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 14 2bg004fx	84000	250000	7	\N	\N	\N	2026-03-25 16:52:26.588+00
2cdca792-ffbd-41ce-b1e4-280809691dbb	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 14 m8iwjdoq	84000	250000	7	\N	\N	\N	2026-03-25 16:52:27.308+00
630f1b85-a162-4310-a2d3-2bbc846dd428	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 15 ejn1hswm	85000	250000	3	\N	\N	\N	2026-03-25 16:52:27.323+00
2e017e63-1d2d-4cd7-91e9-38b20a90f2c3	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 15 70nqvdkn	85000	250000	3	\N	\N	\N	2026-03-25 16:52:29.452+00
62eacfba-8834-473a-9c54-80fe92764df8	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 16 dv0p7hjl	86000	250000	4	\N	\N	\N	2026-03-25 16:52:31.061+00
3a7e642a-67b4-4faf-9617-52757097a906	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 17 ui71ahjw	87000	250000	5	\N	\N	\N	2026-03-25 16:52:31.662+00
7676fd09-74ed-49f9-a333-16bb6e54f67e	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 18 hnalc283	88000	250000	6	\N	\N	\N	2026-03-25 16:52:31.767+00
cd54c2f3-5832-4282-8aa9-2d3e0bbe00a2	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 19 8u0vxivl	89000	250000	7	\N	\N	\N	2026-03-25 16:52:32.641+00
4fab6e21-e034-486d-a03f-74292b8e2aad	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 20 zfkb6e8q	80000	250000	3	\N	\N	\N	2026-03-25 16:52:33.018+00
478fd291-4680-441a-8ed2-ec17ed05c2c8	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 19 4ylzwg0o	89000	250000	7	\N	\N	\N	2026-03-25 16:52:33.043+00
1ebc55d5-a227-4f39-840e-6a7d56955b5c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 21 3amtm18b	81000	250000	4	\N	\N	\N	2026-03-25 16:52:33.747+00
7807be22-4572-49c0-9ab4-1ad819baa326	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 20 x4bkwo56	80000	250000	3	\N	\N	\N	2026-03-25 16:52:33.766+00
cfa51c41-b5c6-4a68-a3b6-a67a3dd390f5	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 20 m3vjvs9p	80000	250000	3	\N	\N	\N	2026-03-25 16:52:33.77+00
f4e40697-f293-4d78-b10a-32f00aaf3ee8	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 21 2wrw2m72	81000	250000	4	\N	\N	\N	2026-03-25 16:52:33.852+00
e549d1a9-7742-474e-86b6-a2deb6da64f6	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 22 y3rxtvb8	82000	250000	5	\N	\N	\N	2026-03-25 16:52:34.417+00
e0222324-e9d7-45a0-8096-fb5019c948bf	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 21 yoecqvlv	81000	250000	4	\N	\N	\N	2026-03-25 16:52:34.436+00
192c6a0a-c789-4a3a-869e-413af2c90526	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 21 p92wb3z2	81000	250000	4	\N	\N	\N	2026-03-25 16:52:34.448+00
d3932146-790e-4127-8cf1-7a23d4630b72	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 22 nsia1ebc	82000	250000	5	\N	\N	\N	2026-03-25 16:52:35.15+00
8dcd1685-5a0b-4648-ac63-ce8d709db90c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 23 paz7uwe4	83000	250000	6	\N	\N	\N	2026-03-25 16:52:35.191+00
67c8ded6-08bb-4350-9343-899630d1df2f	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:02:58.472+00
2b1034a1-63a2-464d-ad64-c1731638457d	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:02:59.968+00
33d9660e-2021-4fb4-97c9-c51c1907deeb	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:01.272+00
112a2991-5ab3-46ae-b29b-f100baeb83a2	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:03.341+00
b5559360-167a-424c-858a-4dc3b42d1a95	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:04.114+00
98057ecd-6344-438b-bd11-ad89e03bbf44	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:04.87+00
9664c4c7-bd98-4792-8444-ab4238b5861d	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:05.678+00
2d266ab9-230a-4d29-a51e-b326898c8dc2	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:06.568+00
951a2cd5-1bb7-487b-9f0b-a1d5f2f76b4b	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:07.636+00
77a55fd5-3e4d-444d-a5ba-a940851b1964	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:07.641+00
23b1c374-b911-482e-86b2-f1c6fc43ed2f	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:08.337+00
30ed3f34-c7c6-44ff-87b1-0daa0393895b	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:08.349+00
0291384c-b8ac-49c3-b5c6-7edd6db1f73d	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:09.32+00
7b386062-be59-4be3-95d1-eab6a6ff0cd5	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:09.395+00
75730c20-e494-4e51-af03-d525249c700f	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:10.13+00
fcbc8e8a-7f6e-44da-8685-29b35673e63a	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:12.008+00
5b751030-acbc-43c5-bc92-0b20162e2eb2	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:13.471+00
fda29b73-26bf-40b3-94ef-a19307185a8f	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:14.782+00
943b294d-8027-4cd7-89db-726811f9e7bd	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:15.774+00
e28bde07-b860-463a-9897-76ea97925104	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:16.769+00
e88c27d2-9b2f-4a4b-8a2a-df16ec5ad448	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:17.69+00
2aa5e469-ae49-4571-b1a2-01ade2f82142	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:19.202+00
7b981573-b037-4fd0-beff-603c7d183d59	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:19.247+00
fa6558fc-9416-4d5f-8ae3-51936dd0c09d	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:20.515+00
6c224e57-2b1d-4add-b80c-9f9461d204c7	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:20.561+00
14a6cdb3-84df-47fd-aec2-e6434dec3475	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:21.658+00
2f8c7366-116b-47e1-9d8f-df4c98020705	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:22.431+00
15b7b2ed-c587-4364-a4b7-e570bd9c1f39	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:22.466+00
a1fce5dd-8a49-40a3-84a1-345cf41b426f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 6 ficrh5sq	86000	250000	4	\N	\N	\N	2026-03-25 16:52:17.245+00
5f1d0a4e-6d3c-45df-85e2-05f61733650d	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 6 0pnwbejg	86000	250000	4	\N	\N	\N	2026-03-25 16:52:17.29+00
1007cdc0-42e3-4d15-94d2-f2b2d7fe69b8	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 7 ioophwnh	87000	250000	5	\N	\N	\N	2026-03-25 16:52:18.842+00
b3c4de04-b213-4905-aa7a-97ca1d782c6f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 7 cthkl3wl	87000	250000	5	\N	\N	\N	2026-03-25 16:52:19.044+00
53d0cc8b-9c78-46bf-938b-e586090d1312	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 7 b0fs5awg	87000	250000	5	\N	\N	\N	2026-03-25 16:52:19.047+00
bcc93367-562b-41cd-ba44-bf62acf989a3	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 8 un7he8gh	88000	250000	6	\N	\N	\N	2026-03-25 16:52:19.981+00
c2dabfa1-2178-4c5e-98f3-4e32aeb99464	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 8 07i5o1h7	88000	250000	6	\N	\N	\N	2026-03-25 16:52:19.99+00
f77afc5f-0cf7-4dc0-a21b-1458cc58c02c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 9 9m65qtrh	89000	250000	7	\N	\N	\N	2026-03-25 16:52:20.145+00
fb2bff1a-67f2-4667-9922-be49529a945f	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 9 sd0dmbak	89000	250000	7	\N	\N	\N	2026-03-25 16:52:21.549+00
5c4c9765-a227-462e-b961-90616be34ff5	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 9 owh87w0d	89000	250000	7	\N	\N	\N	2026-03-25 16:52:21.578+00
150d8f94-aa54-46b4-acfc-edd2782b5893	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 10 yelgpkfb	80000	250000	3	\N	\N	\N	2026-03-25 16:52:21.623+00
b774f831-0a1c-4a36-bd06-9a218284d882	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 10 rfo3w30f	80000	250000	3	\N	\N	\N	2026-03-25 16:52:23.231+00
8fd4bfe4-d787-44cf-bcad-a3c4061a8cb0	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 10 lqtc1osg	80000	250000	3	\N	\N	\N	2026-03-25 16:52:23.279+00
649ee386-87f0-4dc2-91ef-4548d78f2201	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 11 yv6kpftm	81000	250000	4	\N	\N	\N	2026-03-25 16:52:24.223+00
4badfa5e-9a0f-4426-9786-c486837fc1e2	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 12 mkrimxl1	82000	250000	5	\N	\N	\N	2026-03-25 16:52:24.453+00
a5c73271-00a0-4922-8833-5aed8473b638	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 12 002k6qho	82000	250000	5	\N	\N	\N	2026-03-25 16:52:25.347+00
4b232a11-b907-49b9-884c-a6cbeb35e81c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 13 oe98sd4p	83000	250000	6	\N	\N	\N	2026-03-25 16:52:25.39+00
365710cc-8bde-4b68-b1cb-fb6713c69e34	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 13 8r6kjony	83000	250000	6	\N	\N	\N	2026-03-25 16:52:26.581+00
13441f4f-bd24-4c37-aead-de285097c42c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 14 icncu4vy	84000	250000	7	\N	\N	\N	2026-03-25 16:52:26.595+00
f759e7b7-4b33-4cee-8f43-453cfa2ea4d2	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 14 f7p11ehq	84000	250000	7	\N	\N	\N	2026-03-25 16:52:27.453+00
1d4b463e-ba15-40e9-9db2-8f64c0720871	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 14 k2gjy3ss	84000	250000	7	\N	\N	\N	2026-03-25 16:52:27.461+00
46e9924f-6d75-4b1d-a26b-d8b5f02da1ed	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 15 75tzwfvu	85000	250000	3	\N	\N	\N	2026-03-25 16:52:29.66+00
7f13ba19-dc37-49f6-a11d-aadcfebd7c4d	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 16 0abfqqkl	86000	250000	4	\N	\N	\N	2026-03-25 16:52:29.858+00
865adc93-fa78-4ae6-b2e9-a61c0a8159e3	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 15 eu7ku5q6	85000	250000	3	\N	\N	\N	2026-03-25 16:52:30.272+00
6951273f-486f-42d7-8b63-5da17904ce09	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 16 tphpwo9s	86000	250000	4	\N	\N	\N	2026-03-25 16:52:30.995+00
38cd25cf-c4a4-4cd0-a3d7-6039b18e58d1	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 18 98kjgywh	88000	250000	6	\N	\N	\N	2026-03-25 16:52:31.802+00
34e1cf27-d2a5-474d-b2d6-002812576d61	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 17 a31wcbdb	87000	250000	5	\N	\N	\N	2026-03-25 16:52:31.818+00
2291f124-e39f-4aab-84f7-65c6f1472a21	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 18 iqg3w420	88000	250000	6	\N	\N	\N	2026-03-25 16:52:32.08+00
20b8713c-b0de-495b-a236-da451386a978	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 18 pgclkkvg	88000	250000	6	\N	\N	\N	2026-03-25 16:52:32.387+00
b151d12e-dabb-4080-8543-a250785e1845	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 18 9bndopga	88000	250000	6	\N	\N	\N	2026-03-25 16:52:32.404+00
a16099e5-8cef-4caa-b4ce-c862b1f3d0df	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 19 mxzpwa3q	89000	250000	7	\N	\N	\N	2026-03-25 16:52:32.65+00
15e8aaa4-a697-431c-b654-6b95cbc6095c	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 21 bcyyybaa	81000	250000	4	\N	\N	\N	2026-03-25 16:52:33.851+00
638dcb9f-d356-48fa-94bc-a679e3e80dc6	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 22 cs7bvsll	82000	250000	5	\N	\N	\N	2026-03-25 16:52:34.45+00
518e9028-c69e-4e57-941f-887020067de2	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 22 vo3fg8pe	82000	250000	5	\N	\N	\N	2026-03-25 16:52:34.459+00
530d5c01-0c31-4c7c-b1dc-d38fb6417275	af124771-e41b-4b01-9efa-33883b06cd3a	k6 search 22 vtrsxnis	82000	250000	5	\N	\N	\N	2026-03-25 16:52:34.483+00
04625765-09c3-4f04-943a-5b56f9277a2c	faa07055-3e8c-42ae-9a3d-4731ea46a316	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-25 17:00:48.858+00
984f39bb-331b-4643-ad2d-f23fae387849	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:56.14+00
32ca70c7-dcb0-4661-9f0f-6360b5eac647	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:56.142+00
b58ca6e3-61b3-4845-a2a5-2bf412c7a2c8	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:56.141+00
be12e227-751e-497c-8a3a-44dc9c84f03b	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:56.896+00
6150d944-bd0f-4da5-8588-ba1aa04eb440	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:56.898+00
ef3a74f9-c5f2-4ecf-981d-b5f495946150	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:56.904+00
dbb36a14-b916-4abe-906c-9af6c4842e1c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:57.654+00
69d46546-f244-4f18-b4f4-4ce7293f2802	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:57.669+00
533182f0-7665-4c7b-a261-bce30d324764	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:57.841+00
35d3602d-2245-4b85-9ebb-f9c635d08006	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:59.001+00
eeb411b2-4341-4e33-b209-ac511fcbd4db	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:59.003+00
293cd162-263f-42d0-a578-53e8e06c6229	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:59.203+00
564213bd-1216-4f9c-9fe8-06f97968114a	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:59.868+00
98cfbe3e-2a36-49eb-814e-910cdcfcc1f3	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:17:59.871+00
f5243e5e-f4d9-4793-a936-ffbb13c587c1	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:00.062+00
2c1b0ffc-d36a-4977-8d3f-813e30de805f	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:00.645+00
3277899e-6bed-41a5-8b7b-1680f2e2c619	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:00.675+00
8e50dca0-df34-4d3e-9fab-3a8208801eaa	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:00.871+00
4dd0bad0-efb6-4fd4-b67a-874ca22385ad	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:01.581+00
2c0387f9-06ea-42ee-8b57-0eeca9b4076d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:01.636+00
ab3b52d5-b2c4-4bf3-98a0-acf60c9a64ec	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:01.657+00
28554988-024e-429f-83ee-e1a4c6807ccd	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:02.321+00
b77703ab-7a36-4ad2-8db2-bd6d776cbf9d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:02.452+00
23ada572-918a-4c80-890a-e58b3eb7dfb1	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:02.645+00
9690522d-04c7-4bdb-9c13-8d3d4f46a0b5	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:03.17+00
e739fe4d-77b2-49f2-b242-8d1429328c02	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:03.2+00
2e7a2b3c-4b14-4c5e-b4c6-0f63384047a5	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:03.285+00
3e500235-1aec-43db-b484-5da8ed0e557d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:03.866+00
b111eff5-de37-4514-88dd-b6a7c4fff212	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:03.9+00
d92253b4-20b9-4b57-a74a-1d016bd13082	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:03.946+00
3d3495c3-7229-4404-acf4-5f61638fb112	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:04.516+00
fc9e1ee2-c4c7-4dd8-abee-0b29ef33af1b	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:04.527+00
d9980603-063c-40a7-b23b-769dbe635a8f	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:04.577+00
0a92e895-ac9c-475d-a720-f386c5417a3e	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:05.223+00
3fd67274-b5ac-4301-a18b-e157c4de54df	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:05.226+00
4096fad3-e16f-4d9a-8a11-ab83c7fe28d7	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:05.319+00
f7794267-6028-4f30-a56e-8f8c534055aa	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:05.932+00
189c70df-0c5c-448a-840c-84c09da61f90	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:05.956+00
2d3952aa-950d-4972-bdc9-ac7ab48a1f01	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:06.608+00
5fafecc0-d396-4a80-801a-94579cdc4e8c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:06.612+00
44015607-78cf-4c72-9f39-838be7c11855	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:07.27+00
6930fa8c-2d46-43de-8e7e-409b28a8f9a6	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:08.304+00
24afed0b-f891-4a8b-9f57-beaa118b5271	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:09.384+00
5c30bd8d-b130-4f5b-888f-2dd271c5da60	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:10.001+00
949989fe-4c27-4f8f-81b5-2f9fd889aa1a	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:10.726+00
d79e51a6-d4fb-486e-8c48-8797931f4bd3	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:11.438+00
05e02981-44f1-458a-a8a7-3fb2647b211d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:12.121+00
d619cb3a-6ffc-405b-916f-604f078edc44	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:12.134+00
0d44f294-7ce5-4780-ac9b-9b5f5893199c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:13.017+00
26609af8-63bd-4091-9f4f-a8da9e310e07	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:13.814+00
8dd39d64-4757-4774-951b-74208dc5ceed	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:13.818+00
c199c5b4-c01e-4349-b61f-2c74d2552c82	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:14.48+00
2a8f328b-e12d-4012-b59c-61a9e73fee99	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:15.249+00
f484decf-579b-42c7-b371-dd32ae0eab3e	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:15.877+00
aa6070f5-68dc-4e1a-bd84-f5cf09af2349	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:18.075+00
4e2e942b-b07b-4234-9e8c-70ca8f52faef	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:18.63+00
ed62df24-79da-468a-9dbb-e7699d906840	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:19.288+00
307781a0-825b-4166-bf8c-ead99672816a	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:20.101+00
5bebadf8-ac1d-46e2-acc5-21bbef33fe6b	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:20.96+00
f2f4206a-cca7-4ee1-a7d0-e1198ca4cb0a	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 0 2a42r6p6	80000	250000	3	\N	\N	\N	2026-03-25 20:19:03.465+00
48e8bef7-4864-402c-9fbf-a8f246e5f6a1	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 0 vdjjitoj	80000	250000	3	\N	\N	\N	2026-03-25 20:19:03.476+00
7a38c58a-24cd-4906-a383-768e3b848289	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 1 2muctxqk	81000	250000	4	\N	\N	\N	2026-03-25 20:19:04.306+00
8a11e302-6cc9-4c3a-81ac-a8fbe136ea12	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 2 s6mhec70	82000	250000	5	\N	\N	\N	2026-03-25 20:19:04.894+00
17855491-a265-457e-9d15-c67c76485ae0	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 2 u32vher0	82000	250000	5	\N	\N	\N	2026-03-25 20:19:04.987+00
a59aa185-2d3d-4f83-9746-58d47c9d1a20	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 2 dx3uzosh	82000	250000	5	\N	\N	\N	2026-03-25 20:19:04.995+00
e4aaabca-1afb-48ef-a41f-32db3fef9b95	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 2 r5a2tczl	82000	250000	5	\N	\N	\N	2026-03-25 20:19:05.079+00
68ba4ab6-6e32-474d-b48e-9d2d00cc3315	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 3 tmno8gh8	83000	250000	6	\N	\N	\N	2026-03-25 20:19:05.498+00
8104948c-ba43-4480-8999-28e3744a1f5f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 3 4puhqohs	83000	250000	6	\N	\N	\N	2026-03-25 20:19:05.815+00
cdb83a44-a1f2-4c12-beef-60f3036de8d9	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 4 6peskdbq	84000	250000	7	\N	\N	\N	2026-03-25 20:19:05.969+00
d6ccb3e6-c68d-491e-8940-ae04dbe3a193	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 4 5i30owje	84000	250000	7	\N	\N	\N	2026-03-25 20:19:06.277+00
84e22758-b476-4bf7-a682-92ff91617885	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 4 iah4nsub	84000	250000	7	\N	\N	\N	2026-03-25 20:19:06.291+00
b0f2a669-0f3e-4429-8305-f0724de16441	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 4 vne943x2	84000	250000	7	\N	\N	\N	2026-03-25 20:19:06.387+00
64c53750-7c9c-4df3-a111-627a140354c8	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 5 pzed4z4s	85000	250000	3	\N	\N	\N	2026-03-25 20:19:06.858+00
b2e5e4bb-7696-463f-ab33-1e885796de93	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 5 cuitc1fy	85000	250000	3	\N	\N	\N	2026-03-25 20:19:06.99+00
f3a93b7e-039b-43d6-bc90-bfcf0f8f27b3	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 5 vc6w173x	85000	250000	3	\N	\N	\N	2026-03-25 20:19:07.01+00
d2140ece-ea38-486f-a2a5-7f0980128dbe	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 6 mylz4aqb	86000	250000	4	\N	\N	\N	2026-03-25 20:19:07.015+00
61d4f4b1-f5e1-4c0e-b96b-e435fec6074c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 6 v8bzften	86000	250000	4	\N	\N	\N	2026-03-25 20:19:07.308+00
93115257-d521-4d27-9742-575da3e237f1	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 6 eyj8d8t0	86000	250000	4	\N	\N	\N	2026-03-25 20:19:07.49+00
ebf3a937-3720-4fc1-9d01-fe63c292892f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 7 lhn5kocs	87000	250000	5	\N	\N	\N	2026-03-25 20:19:08.995+00
f0ac3516-8943-4b17-ad51-18a92622cfa2	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 8 vbcrsxm3	88000	250000	6	\N	\N	\N	2026-03-25 20:19:09.179+00
d11c439d-36fe-4a7b-9b7d-9a96aeb15ae2	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 8 swzi3ajk	88000	250000	6	\N	\N	\N	2026-03-25 20:19:09.219+00
cb640aab-bf5b-4044-9f3a-ab2588177864	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 9 68cugu35	89000	250000	7	\N	\N	\N	2026-03-25 20:19:09.753+00
9dbe6ef9-d021-4f22-90e3-e0bacdbf6e17	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 8 913woqgj	88000	250000	6	\N	\N	\N	2026-03-25 20:19:09.76+00
ca5bcfe4-4634-4065-b3fe-6344d1ead124	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 9 tqdf19cg	89000	250000	7	\N	\N	\N	2026-03-25 20:19:09.768+00
d77131da-0f97-4eaa-bcdf-05cb9e3fc6c4	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 9 1k3tnh9x	89000	250000	7	\N	\N	\N	2026-03-25 20:19:09.778+00
dac4d9e5-f64c-4203-8452-0c5bb9d80204	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 9 g27rcit3	89000	250000	7	\N	\N	\N	2026-03-25 20:19:09.785+00
0d78a1c0-6320-49df-b2fe-95dd1d63df49	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 10 n3ydccte	80000	250000	3	\N	\N	\N	2026-03-25 20:19:10.411+00
ee4ec6b2-0d2f-4ae1-9585-a759eb259b13	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 10 fwsvfdwf	80000	250000	3	\N	\N	\N	2026-03-25 20:19:10.427+00
ee762533-e2cd-488c-ac44-74e1456d918e	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 11 6588tikd	81000	250000	4	\N	\N	\N	2026-03-25 20:19:11.386+00
3896021a-a54a-4ca1-82ee-ef3d4faffdde	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 11 mezz1fee	81000	250000	4	\N	\N	\N	2026-03-25 20:19:11.439+00
26bc7c6a-acea-4577-a1bc-8db87149be22	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 11 rxmy2nv5	81000	250000	4	\N	\N	\N	2026-03-25 20:19:19.417+00
20ead592-8278-4827-b136-ffcdbb8b0e18	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 13 xx68k0jq	83000	250000	6	\N	\N	\N	2026-03-25 20:19:20.442+00
c17ee8eb-5870-4e92-b17a-bb2a98f5f5ee	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 12 mb9fgak1	82000	250000	5	\N	\N	\N	2026-03-25 20:19:20.446+00
4c840821-8a78-4775-b050-2cbd87702567	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 13 sw52tvfm	83000	250000	6	\N	\N	\N	2026-03-25 20:19:20.448+00
a69a3442-c987-4920-9ecd-00380bf09a0f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 14 01rxdqmj	84000	250000	7	\N	\N	\N	2026-03-25 20:19:21.103+00
d4d6cac8-28df-418f-959c-46e7c46855d9	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 14 ys5pdxut	84000	250000	7	\N	\N	\N	2026-03-25 20:19:21.184+00
8bf25133-3317-4787-a8af-a33dd0b1bcd3	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 14 i0ujfirn	84000	250000	7	\N	\N	\N	2026-03-25 20:19:21.205+00
4064619b-988a-40fb-bb4d-591fa9b1ea7f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 13 z8r09n3h	83000	250000	6	\N	\N	\N	2026-03-25 20:19:21.211+00
94fdaa58-a712-432b-95ed-ce8491a38b94	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 15 38n3zbt9	85000	250000	3	\N	\N	\N	2026-03-25 20:19:21.767+00
0be1ed4f-41d2-4147-87e3-f99a02a47426	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 15 yhfiz59p	85000	250000	3	\N	\N	\N	2026-03-25 20:19:21.954+00
ae04abe6-9afa-421f-96ed-047e3662e5c0	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 16 a2teyn8d	86000	250000	4	\N	\N	\N	2026-03-25 20:19:22.238+00
a452cf8c-bbc5-490e-a272-214b1072e71c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 16 m5lytnnu	86000	250000	4	\N	\N	\N	2026-03-25 20:19:22.381+00
6f3faa09-2959-40e1-b62b-ab7688465ccd	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 16 6qilblno	86000	250000	4	\N	\N	\N	2026-03-25 20:19:22.458+00
b5bd87b4-d381-4570-8e5a-959b031e748b	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 16 du38su4l	86000	250000	4	\N	\N	\N	2026-03-25 20:19:22.471+00
2d0584d8-9c81-42be-9f7c-f3dba2c9ea8a	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 15 45mbp33g	85000	250000	3	\N	\N	\N	2026-03-25 20:19:22.475+00
7cb18e23-4e4d-4e97-a0ea-3e41187f3958	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 17 v0tr7g0t	87000	250000	5	\N	\N	\N	2026-03-25 20:19:22.679+00
59b86b3d-e886-4088-8827-da40365a6277	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 17 4q684rde	87000	250000	5	\N	\N	\N	2026-03-25 20:19:22.9+00
581aa7a2-3483-432e-b63e-9b8b1e033960	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 17 9g7ukt3h	87000	250000	5	\N	\N	\N	2026-03-25 20:19:23.049+00
d85fcf82-d5bd-4fe5-8d77-e9c2f72f9e9e	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:05.986+00
badab218-f5c8-4824-aef1-2d4586aae41d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:06.61+00
7f3876bf-75f9-4139-b899-ad6dbd389742	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:07.276+00
45e33d92-8e92-4704-98f8-13820dab055d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:08.312+00
b9a1e109-d1d0-4250-938b-89c5d3dd5d44	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:09.341+00
c3a0e834-afe8-49ca-9d18-f9fbe77f0d4b	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:10.006+00
a393a400-8d9e-4874-b002-d5f0b32712e7	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:10.731+00
fe459502-f75f-4cdd-a0b2-7175203e2ac4	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:11.443+00
bfb46cc9-990a-405e-94de-1ec7f4f4e12a	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:13.039+00
01182675-4793-444f-9c7d-9519fb73a66d	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:14.484+00
797b1fce-9600-47ea-a382-fa3525771516	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:15.209+00
d70db33a-8e9b-4ec6-b596-43bdac54a685	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:15.246+00
350f5bac-e01a-4fae-baf4-d925573088fd	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:15.824+00
0866f1c0-da5d-4da2-bd2e-32b0bfa3003c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:15.873+00
5578ed44-41af-4ddb-86cf-cd127b8fef29	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:16.774+00
f3e38214-9027-4d5a-8719-ee482ab613e2	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:17.023+00
f6070056-ba9f-4514-b664-cbfc87f0cd4c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:17.388+00
c9de4081-e95a-4720-9b69-84ff4aa1aae8	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:17.649+00
5313fb5f-4454-4d4c-b213-656c8fd73977	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:18.626+00
491631c0-b75f-488d-9aae-fac805c3a23b	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:18.839+00
53a164bf-7771-4f3d-95ac-4841dfae08e8	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:19.281+00
4be61c65-d8fb-45d5-9a9f-547837dc9d57	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:19.432+00
8cfea331-7a2c-4130-9215-1ab684916a88	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:20.095+00
c3205b17-9bb8-46f2-8a1f-4b2026e61d80	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:20.958+00
d3422916-eca6-43d7-b5e1-f5f61734124f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 0 u5tf1vwj	80000	250000	3	\N	\N	\N	2026-03-25 20:19:03.445+00
34ee82b8-e012-4eaf-b3c3-835d3f8f8e8c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 0 o4dzyna8	80000	250000	3	\N	\N	\N	2026-03-25 20:19:03.469+00
a598ec4a-42d7-42e1-947e-43afac897674	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 1 pgcm0l4z	81000	250000	4	\N	\N	\N	2026-03-25 20:19:04.272+00
7e221cda-9655-42c6-9bb1-d0a0d9d9c015	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 1 e67zsjnj	81000	250000	4	\N	\N	\N	2026-03-25 20:19:04.304+00
6775b516-9b51-442e-945b-4bad331e1f55	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 2 bmask2n8	82000	250000	5	\N	\N	\N	2026-03-25 20:19:05.109+00
4f05992c-264c-4f32-a710-71191f106fd2	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 4 qpzzxqs0	84000	250000	7	\N	\N	\N	2026-03-25 20:19:06.016+00
c092c9c1-0dc3-4e7d-a60f-74f8a2013508	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 5 d7b66dix	85000	250000	3	\N	\N	\N	2026-03-25 20:19:06.518+00
c744c108-bf9b-4bfd-b4bd-1e7a29ede574	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 5 27pqhqut	85000	250000	3	\N	\N	\N	2026-03-25 20:19:06.856+00
6ed04947-9632-4bde-8a35-4e94536dbc2c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 6 b6z6jx0n	86000	250000	4	\N	\N	\N	2026-03-25 20:19:07.013+00
a456c4cf-7f88-4ffa-a907-cc4190c7a33b	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 6 xfkzcdmv	86000	250000	4	\N	\N	\N	2026-03-25 20:19:07.306+00
10ebd7a2-69b6-41a1-92fb-c05d10ee8f62	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 7 bgp3n5d3	87000	250000	5	\N	\N	\N	2026-03-25 20:19:07.643+00
d4c7c795-30d7-4c47-8f24-5149e5ac147a	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 6 r3gn4usi	86000	250000	4	\N	\N	\N	2026-03-25 20:19:07.654+00
3ddde83a-5930-42b2-b74d-c8b68cc6c0ca	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 7 x94qzyk0	87000	250000	5	\N	\N	\N	2026-03-25 20:19:08.257+00
34c6c09f-785e-4c98-ae52-9f6da866b02b	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 7 nm38zjhf	87000	250000	5	\N	\N	\N	2026-03-25 20:19:09.181+00
f4d1809e-dc8f-463e-b6c8-9221318ac3c9	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 9 gddr4qfr	89000	250000	7	\N	\N	\N	2026-03-25 20:19:09.88+00
1059ec66-ddb5-4ee0-8ce1-f25e09d9e258	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 9 aj82wwb8	89000	250000	7	\N	\N	\N	2026-03-25 20:19:10.409+00
07b75991-7afd-4111-bc9a-98fa2aba9f63	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 10 ldavlg13	80000	250000	3	\N	\N	\N	2026-03-25 20:19:10.414+00
9f863a9b-207c-4b37-b2e1-794666881ab2	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 10 pg0c9e2m	80000	250000	3	\N	\N	\N	2026-03-25 20:19:10.425+00
c076aa01-24a0-4a3b-856f-5073dc634cbf	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 11 x99xe9rk	81000	250000	4	\N	\N	\N	2026-03-25 20:19:11.388+00
6fff9fcb-2c28-4bfa-a5de-cba2a7b2514c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 11 pajywap6	81000	250000	4	\N	\N	\N	2026-03-25 20:19:11.394+00
309a41b5-834e-4c7a-98b0-183bff6c816f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 12 74x910r3	82000	250000	5	\N	\N	\N	2026-03-25 20:19:19.402+00
a8caef0c-cf9f-4d9f-aa4c-21211b11acf5	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 12 7t8ypev7	82000	250000	5	\N	\N	\N	2026-03-25 20:19:19.419+00
715633a9-9585-4fd9-a037-56719b0446a9	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 13 674bk064	83000	250000	6	\N	\N	\N	2026-03-25 20:19:20.444+00
91f80820-bee6-425e-ba76-fb9f72374876	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 14 8a93yd5b	84000	250000	7	\N	\N	\N	2026-03-25 20:19:21.209+00
d2895f02-4291-418a-bbd5-58fd33a0a825	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 15 k276q47b	85000	250000	3	\N	\N	\N	2026-03-25 20:19:21.868+00
8d375677-f251-4ab8-a939-309ad67b02ba	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 14 ge1yyitg	84000	250000	7	\N	\N	\N	2026-03-25 20:19:21.957+00
b1ea562c-cd75-4ab3-8e3e-ca4cf05f2ee9	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 17 bz8te5rf	87000	250000	5	\N	\N	\N	2026-03-25 20:19:23.789+00
572521d7-5297-482c-80be-e4d986c49182	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 19 arcdirjc	89000	250000	7	\N	\N	\N	2026-03-25 20:19:24.34+00
f4885415-6143-4db3-b466-688ba0e221ee	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 19 9um5zzrp	89000	250000	7	\N	\N	\N	2026-03-25 20:19:24.389+00
af314c21-8973-49d1-a4e1-d87b54f8ddc9	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 20 e1qfaf7i	80000	250000	3	\N	\N	\N	2026-03-25 20:19:24.977+00
0e54431c-7ad6-462a-9812-fd1bfa7a4992	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 21 zulk3w2d	81000	250000	4	\N	\N	\N	2026-03-25 20:19:25.67+00
19ae3bd8-d0d4-49d7-a386-300700691f53	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 22 y81c1l8j	82000	250000	5	\N	\N	\N	2026-03-25 20:19:27.187+00
a13afc8e-2b23-4563-ad2d-37650a267b05	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 23 66or1fjy	83000	250000	6	\N	\N	\N	2026-03-25 20:19:27.249+00
f254c002-fe41-4a29-a90f-45f7d75cff1a	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 23 csqqd06k	83000	250000	6	\N	\N	\N	2026-03-25 20:19:27.253+00
9c32b57f-7803-42c2-9115-d9e11f4e8fa8	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 24 uwsjg43i	84000	250000	7	\N	\N	\N	2026-03-25 20:19:28.451+00
58c19060-db19-41df-9710-dd05d7fc4409	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 25 03b18lqv	85000	250000	3	\N	\N	\N	2026-03-25 20:19:28.649+00
d950ce20-57a0-4957-9208-992521a02c48	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 24 mpirh344	84000	250000	7	\N	\N	\N	2026-03-25 20:19:28.651+00
bc604381-a944-41e6-aaeb-864cf5adecd3	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 25 9an5x141	85000	250000	3	\N	\N	\N	2026-03-25 20:19:30.042+00
7b563a78-8de1-4d13-a8f0-83e3a7db7018	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 25 bb5jwfh9	85000	250000	3	\N	\N	\N	2026-03-25 20:19:30.578+00
f7e74b25-9327-4cc7-93ec-d545b36056ff	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 26 vxoz0jks	86000	250000	4	\N	\N	\N	2026-03-25 20:19:30.819+00
e5c4ee96-a330-474d-9e9d-27c846df3228	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:02:58.473+00
3081d53b-5b6e-4d0e-a989-cd047916f36e	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:02:59.971+00
88d80aca-f531-4bfb-916c-f1a72dffa7e8	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:01.076+00
a3d5aeaf-c9ce-4810-a7ea-f8f7c7f6094e	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:03.264+00
bf92e3a3-cc56-4105-bcad-a286627a6d7f	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:03.337+00
0cab2779-3dba-4817-bfd1-44de0216df32	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:03.969+00
4faa8267-acaa-4cc6-88fa-6386db2619d1	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:04.106+00
c99ec31b-2985-495e-8e42-57adb254ada5	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:06.571+00
55df029f-26db-4cf6-b174-569229b5dc84	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:07.273+00
11891ef8-b81a-465c-a77c-843da305d28c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:08.316+00
17b9f326-b778-40f7-865e-458ce4c63cf5	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:09.343+00
00892ed8-79c3-4ed6-9d94-0247a203d38c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:10.004+00
b9575ee5-90f1-4830-aac0-7ca3c6ac0351	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:10.729+00
a3646eff-67fd-4cca-96dc-e48bfcd49de8	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:11.441+00
05590bba-02c3-4866-b298-efd263ec8eda	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:12.139+00
4e22ac9d-0e04-4c65-82dc-53fe1186371c	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:13.042+00
5875feae-2217-4a90-8e50-a88915b857ef	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:13.816+00
a52b8cc6-87f6-40c8-b6eb-219b5e643435	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:14.486+00
ddb9a45b-dc99-46e7-8d5b-c3df2059c7a8	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:17.025+00
ebcd293f-5be8-44a1-896a-11798f179bcf	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:17.651+00
d8f0bac2-c8fd-4858-89b2-b07b1c581dfd	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:20.107+00
75834652-e96d-46f6-a310-26f168a82e85	f4177abc-ef17-4f98-93ce-97d7defd8ea5	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:18:20.954+00
9d2a3c2e-3f1a-4888-b056-0c90444a5120	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 0 g5h12zhg	80000	250000	3	\N	\N	\N	2026-03-25 20:19:03.442+00
4b37e990-4bbf-4e5d-b377-6a663c604f47	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 0 et8nti9c	80000	250000	3	\N	\N	\N	2026-03-25 20:19:03.472+00
498e0aca-39b4-4114-94c0-7569c44daca5	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 1 vtu6zvxf	81000	250000	4	\N	\N	\N	2026-03-25 20:19:04.274+00
c6c04690-7451-4ae9-a5e6-49b0637dd8a1	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 1 mfbu8jd4	81000	250000	4	\N	\N	\N	2026-03-25 20:19:04.298+00
d5a43bee-a98f-4699-98e6-fef36b50b24d	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 1 09luspxc	81000	250000	4	\N	\N	\N	2026-03-25 20:19:04.302+00
0895ff1f-5a4f-4d1d-94cc-cdc9c0f81304	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 2 tze3vlum	82000	250000	5	\N	\N	\N	2026-03-25 20:19:04.9+00
24994c4d-b78b-46e4-8817-9e2b040142ab	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 3 viz4m0rx	83000	250000	6	\N	\N	\N	2026-03-25 20:19:05.5+00
23a22282-f529-45c6-8ece-2c025a57cfdf	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 3 5wwrzjlk	83000	250000	6	\N	\N	\N	2026-03-25 20:19:05.652+00
d9b7e254-e1d9-48d8-b2b2-e2897893b708	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 3 l4jlgocl	83000	250000	6	\N	\N	\N	2026-03-25 20:19:05.676+00
f70d4dcc-c531-4752-a4df-a819c407d6f2	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 3 isoprvw9	83000	250000	6	\N	\N	\N	2026-03-25 20:19:05.698+00
b3ff65a8-f3f6-4228-9900-41feafb0b47f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 4 qgxhted6	84000	250000	7	\N	\N	\N	2026-03-25 20:19:06.483+00
e2e3e271-6ca0-43df-8914-ecec0e3b5452	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 5 wcyqpds5	85000	250000	3	\N	\N	\N	2026-03-25 20:19:06.519+00
5fb08f12-b482-494b-8d43-a3abd22b01ff	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 7 v0s8z9uv	87000	250000	5	\N	\N	\N	2026-03-25 20:19:07.648+00
bb66b5f4-6f29-4cd9-8db9-bb154c3c1244	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 7 3izpuhcn	87000	250000	5	\N	\N	\N	2026-03-25 20:19:08.265+00
4e6f25d3-247c-47d3-9d32-ad4b3e2333fc	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 8 m81t7mp6	88000	250000	6	\N	\N	\N	2026-03-25 20:19:09.183+00
2f9e58ce-eabf-4f97-bc02-935216342324	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 8 fgbbuwio	88000	250000	6	\N	\N	\N	2026-03-25 20:19:09.218+00
8c17e6f3-dd5b-49b5-86b5-2ff15cf30845	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 8 v32tktpw	88000	250000	6	\N	\N	\N	2026-03-25 20:19:09.421+00
e6968d5b-2a02-4435-8a80-c8f40922f302	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 10 fb3uv1ul	80000	250000	3	\N	\N	\N	2026-03-25 20:19:10.431+00
857b4855-cf71-4637-88b9-6440967d69d7	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 11 6zey2m82	81000	250000	4	\N	\N	\N	2026-03-25 20:19:11.378+00
109b6f36-d3e9-4a97-920d-5435c4b68c5f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 10 pydpwsjy	80000	250000	3	\N	\N	\N	2026-03-25 20:19:11.389+00
4c062199-0abd-4256-98fd-19b93dfd2cd5	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 12 zac5spbt	82000	250000	5	\N	\N	\N	2026-03-25 20:19:19.415+00
2bd0ae29-d718-4141-8e76-c56542cbc550	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 12 nhzn22xw	82000	250000	5	\N	\N	\N	2026-03-25 20:19:19.419+00
89a5128a-4fc8-4a2e-98e2-5bfb05b1a477	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 12 z9d5un64	82000	250000	5	\N	\N	\N	2026-03-25 20:19:19.419+00
d56de6bc-e3d4-4bb7-8e7f-252f97a8d303	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 13 md5tgjs6	83000	250000	6	\N	\N	\N	2026-03-25 20:19:20.333+00
738aaefe-17e9-4c8a-841e-399e8ac5570d	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 13 4bplsmju	83000	250000	6	\N	\N	\N	2026-03-25 20:19:20.447+00
8938568e-834a-4b0e-b644-78a60a7198bc	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 14 9gt3te9b	84000	250000	7	\N	\N	\N	2026-03-25 20:19:21.207+00
a58ecc14-ed48-4a87-966b-4ba09ffe9334	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 15 f514t4be	85000	250000	3	\N	\N	\N	2026-03-25 20:19:21.865+00
d2d1f936-5a56-4d06-a871-8654b1887afa	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 15 r0rbqing	85000	250000	3	\N	\N	\N	2026-03-25 20:19:21.956+00
69ed21d5-d016-4f92-8b4f-6c8299be37bb	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 16 7nnoc19h	86000	250000	4	\N	\N	\N	2026-03-25 20:19:22.383+00
8e8b34c0-abe5-42a4-920a-a7f0336b1038	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 17 5xek33ta	87000	250000	5	\N	\N	\N	2026-03-25 20:19:22.895+00
d295185c-9b72-425d-8739-2685cda6003c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 16 9e1uqmwp	86000	250000	4	\N	\N	\N	2026-03-25 20:19:23.052+00
794efa66-cba2-4c33-946a-cf955a0ace9a	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 18 2snr6wfg	88000	250000	6	\N	\N	\N	2026-03-25 20:19:23.788+00
0eb3c4bd-4dbc-4c56-ae0e-5bbe36b26077	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 18 jg1txed2	88000	250000	6	\N	\N	\N	2026-03-25 20:19:23.791+00
59de525a-e90d-45c1-b67e-a50a05d37aa0	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 19 0ob0qz5c	89000	250000	7	\N	\N	\N	2026-03-25 20:19:24.041+00
53953bb6-6cee-42ad-b7c8-2f997fbbd8e4	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 19 f3ga9k9s	89000	250000	7	\N	\N	\N	2026-03-25 20:19:24.338+00
4cf2bef3-f6c5-43db-baed-59a967202366	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 18 aaozdlrw	88000	250000	6	\N	\N	\N	2026-03-25 20:19:24.382+00
eaedbfd1-1203-421f-8656-2c0e149e13bc	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 19 6lcfodwv	89000	250000	7	\N	\N	\N	2026-03-25 20:19:24.386+00
85f16f7a-badd-439e-9018-f5a1da886e6f	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 20 nc7p4bjv	80000	250000	3	\N	\N	\N	2026-03-25 20:19:24.979+00
bba6f847-86b1-4229-a865-f3a4c534dad1	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 19 oxh7at0i	89000	250000	7	\N	\N	\N	2026-03-25 20:19:25.027+00
6365a79d-15d1-4d59-8c35-d0ce1dd9e9fa	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 20 908p04qx	80000	250000	3	\N	\N	\N	2026-03-25 20:19:25.036+00
d3175f84-1d6d-4026-a932-e89c8bd11aab	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 21 ptve7piw	81000	250000	4	\N	\N	\N	2026-03-25 20:19:25.041+00
f6c4502f-d413-40ae-a21d-f74806ed7468	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 21 1r30qiuz	81000	250000	4	\N	\N	\N	2026-03-25 20:19:25.613+00
cf7e3d58-0595-4b4d-9521-e64914e85637	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 20 c9cwpg86	80000	250000	3	\N	\N	\N	2026-03-25 20:19:25.632+00
fdd93144-40fb-4e04-b290-2491e0ebe56d	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 21 7r9y5dsy	81000	250000	4	\N	\N	\N	2026-03-25 20:19:25.647+00
90d4c291-86de-40b0-82b0-17df7fcb19dd	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 21 v4yz65d2	81000	250000	4	\N	\N	\N	2026-03-25 20:19:25.667+00
970bb628-8e38-4d71-a0c6-b96e9333aa7c	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 22 f8x27v9x	82000	250000	5	\N	\N	\N	2026-03-25 20:19:25.679+00
3532d962-9ee4-411a-ac11-a34f1e626908	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 21 o5g433br	81000	250000	4	\N	\N	\N	2026-03-25 20:19:26.356+00
89df8f3b-1c57-415c-bdab-f2bf305fbaa4	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 22 qrtn2eu3	82000	250000	5	\N	\N	\N	2026-03-25 20:19:26.382+00
9471e68c-f37a-47e8-b2b1-8afde8a64155	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 22 iwagqef9	82000	250000	5	\N	\N	\N	2026-03-25 20:19:26.394+00
5eb80194-1b81-4108-b0bf-63d8f4cd4d67	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 23 1a675ya6	83000	250000	6	\N	\N	\N	2026-03-25 20:19:27.19+00
48a19bf4-f459-4729-8179-7ecde2c6b4c8	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 24 rho0ks4p	84000	250000	7	\N	\N	\N	2026-03-25 20:19:27.252+00
c8d4ad17-7af5-4ff0-a48f-e3c19f434977	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 24 dt9gfatt	84000	250000	7	\N	\N	\N	2026-03-25 20:19:28.247+00
c1afc259-3110-4457-b560-0cc6e338222d	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 23 werbnrfu	83000	250000	6	\N	\N	\N	2026-03-25 20:19:28.249+00
b98efcdd-4982-41de-b2bc-822307bc3a54	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 24 bg1qe580	84000	250000	7	\N	\N	\N	2026-03-25 20:19:29.606+00
83bfa19b-282f-42f6-b5e2-4e63c15d2228	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 25 e7277nmf	85000	250000	3	\N	\N	\N	2026-03-25 20:19:30.22+00
d73ef2f6-9293-4ec6-857b-36248fc08df1	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 25 76on2tvp	85000	250000	3	\N	\N	\N	2026-03-25 20:19:30.243+00
2a062269-06c3-44b4-be52-4755005cfde0	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 26 zmzyl2f2	86000	250000	4	\N	\N	\N	2026-03-25 20:19:30.58+00
0c1ccd9f-1168-4c5c-b886-d9432d6d015e	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 17 shzpqq25	87000	250000	5	\N	\N	\N	2026-03-25 20:19:23.055+00
d075b7ca-15dd-4e66-ada9-942870c591b6	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 18 41wxnkb7	88000	250000	6	\N	\N	\N	2026-03-25 20:19:23.582+00
b76cb32b-08a4-4cb7-8dcc-265b0c71a08b	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 18 z3e2xs22	88000	250000	6	\N	\N	\N	2026-03-25 20:19:23.786+00
9ce23696-f3be-4aef-8ad4-144f9edd8b67	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 18 0d72kzh6	88000	250000	6	\N	\N	\N	2026-03-25 20:19:23.792+00
e4082cc7-2f0c-4f6e-8fc7-c35e5ebb1f1d	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 20 p7u3bljj	80000	250000	3	\N	\N	\N	2026-03-25 20:19:24.528+00
bcb04283-4e2f-4061-8733-bcd07738175b	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 20 90hu35vb	80000	250000	3	\N	\N	\N	2026-03-25 20:19:25.039+00
e2e12685-98cb-4280-aac9-1f8da75317d0	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 22 iiiii9ef	82000	250000	5	\N	\N	\N	2026-03-25 20:19:26.354+00
03c298de-f823-4801-b32d-5a2fc23cd0e7	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 23 74fm0mlt	83000	250000	6	\N	\N	\N	2026-03-25 20:19:26.396+00
b2de50e7-1be5-4d1f-a4a4-2437b9082fbe	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 22 zooxew30	82000	250000	5	\N	\N	\N	2026-03-25 20:19:26.41+00
5fa87e7c-68fe-4df6-9281-a3bbbcaf471b	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 23 jcu4szld	83000	250000	6	\N	\N	\N	2026-03-25 20:19:27.248+00
8d3ee4f9-19ac-4272-9ab0-bd800e912447	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 24 vmdxqz3r	84000	250000	7	\N	\N	\N	2026-03-25 20:19:28.452+00
46be9e35-9618-4607-9fca-6b85988ae5ad	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 25 4535nmr8	85000	250000	3	\N	\N	\N	2026-03-25 20:19:29.604+00
b4f138f9-e4c6-4ca1-b600-2cfc9822f4f8	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 26 s87kp9kq	86000	250000	4	\N	\N	\N	2026-03-25 20:19:30.245+00
be4e224c-1017-4ddb-aaec-4ad07902e842	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 27 s91642pr	87000	250000	5	\N	\N	\N	2026-03-25 20:19:30.82+00
fb9f283d-38d8-42c7-b123-85ec21b4b026	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 26 mpeeue8e	86000	250000	4	\N	\N	\N	2026-03-25 20:19:31.022+00
b2db1b79-3c16-42ee-92e7-47251c46a8a7	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 27 iyn1lefe	87000	250000	5	\N	\N	\N	2026-03-25 20:19:31.027+00
8262b8bb-7fda-41b7-a75d-9bdd4d535def	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:07.638+00
a20c173a-5a84-4838-b198-55b76ab0ae27	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:08.344+00
a28ea026-627e-496d-b078-939d5d5c007c	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:10.773+00
219a768a-825d-42fb-bf64-8fcaa0e08f59	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:10.869+00
dfea8ed0-0b3f-4545-9a19-cee32b977af6	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:12.011+00
638f876e-de2b-470e-9f04-11ba3e346370	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:12.729+00
3920a651-ab5b-4b44-8250-4c1a297d7697	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:12.793+00
6b2979f7-493f-402b-99f8-ac037b7d6860	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:13.468+00
45766401-0caf-4b51-8367-c6797e09fdd8	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:14.777+00
bc6f49da-8727-46f2-ab56-c816ce9899df	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:15.784+00
6118fcab-4147-4e41-9046-4599052a18b8	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:16.762+00
e1b68960-24ef-4fd1-b97f-79c33a4f4d85	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:17.686+00
eec348d2-d754-4f84-93aa-80376e1978cd	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:18.47+00
22553462-9302-4c28-affd-1a8c0096d71e	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:18.478+00
3e069e3e-6dab-441f-bb0f-a6284c8fdb47	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:19.902+00
2387f271-4639-4dad-a284-7e94f69836f8	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:21.573+00
dd589986-f080-4da2-ba96-78173eb0ca5a	412aa140-1643-4d11-a11c-305b8ef9e818	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 03:03:22.468+00
8e0844f0-1636-4478-915f-8a0bfe77663a	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 0 gx6tnhj1	80000	250000	3	\N	\N	\N	2026-03-27 03:03:50.424+00
2e4724ff-b901-4930-b099-086ffaaafbe3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 1 ot5e0im5	81000	250000	4	\N	\N	\N	2026-03-27 03:03:52.281+00
02ba26eb-8495-4b43-8475-c9b10a38ea4d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 1 5o9397vm	81000	250000	4	\N	\N	\N	2026-03-27 03:03:52.365+00
7c36bac2-52ce-40e1-b8ec-a8439016989f	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 1 nyshx5cd	81000	250000	4	\N	\N	\N	2026-03-27 03:03:52.37+00
aa448028-bd69-4351-871d-f7217ed982ff	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 3 0ysh076b	83000	250000	6	\N	\N	\N	2026-03-27 03:03:55.626+00
05b908fe-f0e4-4317-ad5a-387e4b3944cf	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 3 7bb4c5ry	83000	250000	6	\N	\N	\N	2026-03-27 03:03:55.776+00
602997d3-95ee-4e70-ac75-b791a44089a6	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 3 3kqfp67q	83000	250000	6	\N	\N	\N	2026-03-27 03:03:55.88+00
8f824ab3-8fe2-4858-956a-580ba5d001eb	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 4 0aqj10ft	84000	250000	7	\N	\N	\N	2026-03-27 03:03:56.763+00
a2eb2508-c34d-49e1-9e78-e80bb47254d8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 4 b1yoyo0u	84000	250000	7	\N	\N	\N	2026-03-27 03:03:56.769+00
43846e79-15f6-4bd7-ac65-b1fe2558fbeb	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 5 w8ly5em5	85000	250000	3	\N	\N	\N	2026-03-27 03:03:57.189+00
1e720c46-9541-44e0-a4d4-c8ab878d8378	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 5 ykavgvvc	85000	250000	3	\N	\N	\N	2026-03-27 03:03:57.299+00
0bad442c-942e-446e-898c-82fe296838ba	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 5 atcg6odh	85000	250000	3	\N	\N	\N	2026-03-27 03:03:57.48+00
7a1e0c15-4e42-459d-a7ca-7f73788132d5	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 5 vt9i5if7	85000	250000	3	\N	\N	\N	2026-03-27 03:03:57.504+00
32ae8dcd-cda4-4a21-ba00-46b62cbdfc04	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 5 himjpb5w	85000	250000	3	\N	\N	\N	2026-03-27 03:03:57.517+00
9ae600e7-d872-4a16-ada7-f9643d193651	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 5 tdtrn84x	85000	250000	3	\N	\N	\N	2026-03-27 03:03:57.523+00
04c52b1f-d173-4c00-b2a6-9734b1b0b57f	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 6 xaobe2xc	86000	250000	4	\N	\N	\N	2026-03-27 03:03:57.768+00
bfe45869-67d2-4748-a847-b2224a23fc83	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 7 zyzvzglf	87000	250000	5	\N	\N	\N	2026-03-27 03:03:58.566+00
e17a2622-c1b7-412f-a058-79b44f3f0e50	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 8 9ugxmbjv	88000	250000	6	\N	\N	\N	2026-03-27 03:03:59.479+00
df9240cb-7581-4e35-9eab-3e84a133ae10	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 9 a41udrqg	89000	250000	7	\N	\N	\N	2026-03-27 03:03:59.892+00
6c93f6f7-a120-4310-a4dd-a05a69b957f5	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 9 za30cwmg	89000	250000	7	\N	\N	\N	2026-03-27 03:04:00.522+00
780bd9dc-b0d1-4521-950d-2c18a9a772f3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 10 8lzb5mty	80000	250000	3	\N	\N	\N	2026-03-27 03:04:01.567+00
b830e5f5-3530-4adc-b274-8f9128b87d96	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 11 n7v10j0m	81000	250000	4	\N	\N	\N	2026-03-27 03:04:02.07+00
067c7816-ea18-4e89-8b45-1afeca68b024	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 11 nzsve3k0	81000	250000	4	\N	\N	\N	2026-03-27 03:04:02.161+00
05cecbab-cbd9-4c79-b6f9-c9d20c6a0df5	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 13 j3fmeqfu	83000	250000	6	\N	\N	\N	2026-03-27 03:04:03.747+00
211f0722-4cb1-4b1d-abf2-c4f470e17072	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 14 py22iqbf	84000	250000	7	\N	\N	\N	2026-03-27 03:04:04.718+00
7e4b769d-2bc4-457b-80c2-2b1093094b35	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 15 ityd6x0d	85000	250000	3	\N	\N	\N	2026-03-27 03:04:05.054+00
e21a98cd-6c96-4eac-9912-53e2c4ad2a67	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 15 plyquifx	85000	250000	3	\N	\N	\N	2026-03-27 03:04:05.3+00
06e1af8f-1d47-400f-8cf2-aa67c135a47f	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 15 n46bfz6u	85000	250000	3	\N	\N	\N	2026-03-27 03:04:05.381+00
c91a455c-4c4b-4d5f-b830-c14abfb56321	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 16 b1f4vwvo	86000	250000	4	\N	\N	\N	2026-03-27 03:04:05.986+00
e7d5d5ce-05c7-4cb2-afc9-f87ba46e5d14	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 16 jvnyhd9t	86000	250000	4	\N	\N	\N	2026-03-27 03:04:06.77+00
51315e1a-a703-44e2-96b8-6d9914350c07	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 18 hejipp7t	88000	250000	6	\N	\N	\N	2026-03-27 03:04:09.096+00
3e72bda7-1777-4522-92fb-38c0430609d8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 18 brhmr4u9	88000	250000	6	\N	\N	\N	2026-03-27 03:04:09.238+00
2088ad53-23b7-412c-a946-bff929b3b279	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 18 6rvo6fj3	88000	250000	6	\N	\N	\N	2026-03-27 03:04:09.519+00
5047652c-420a-4122-b3f5-62ad386de4e5	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 19 k5f2w3j6	89000	250000	7	\N	\N	\N	2026-03-27 03:04:09.723+00
4a9e1470-89d6-45fd-a440-e8582c7019fe	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 19 7t741b0o	89000	250000	7	\N	\N	\N	2026-03-27 03:04:09.979+00
95a46d21-5f8a-4c7f-871a-296c6badb615	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 20 0h9kb0xx	80000	250000	3	\N	\N	\N	2026-03-27 03:04:10.334+00
44781c92-86fd-48f8-836d-48324b812bf3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 20 l6iyp0z8	80000	250000	3	\N	\N	\N	2026-03-27 03:04:10.387+00
1b1a89d0-2d83-4365-8083-f500896673c4	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 20 achpw69a	80000	250000	3	\N	\N	\N	2026-03-27 03:04:10.767+00
62b46841-c8c9-4ca2-8e3f-1ea49e3032aa	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 26 spauvgh1	86000	250000	4	\N	\N	\N	2026-03-25 20:19:30.79+00
8f34294f-747e-40ee-a8fe-45cbe7337e00	b23dee18-605a-4cd3-8d2f-7184c7c77020	k6 search 26 3ci5ijin	86000	250000	4	\N	\N	\N	2026-03-25 20:19:30.817+00
783a03c1-65a4-4909-a9fd-48e28e74c99a	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:04.447+00
8c424f54-5da5-4114-9aba-3fce9456f781	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:04.45+00
e57550e0-fea2-4d25-99ce-18dd985fe422	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:04.446+00
c5fd3c07-26d1-452e-9139-153151360bfa	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:05.283+00
f5a70551-49c0-4988-8c95-b499c18872a2	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:05.286+00
2f2bff1c-52cb-4822-ace4-3dd95ec1f169	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:05.292+00
aa07bdbc-1561-4398-82ad-472dff5fe579	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:06.083+00
bdd28c14-0398-42b0-8848-e5c19c939d94	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:06.087+00
3c02b9d9-1974-4147-9eb1-e1f029dbf693	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:06.089+00
9f6efd86-ea79-41a6-b362-39ca7bd00ed7	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:06.743+00
081be6a4-b1cf-4381-b857-227519ecd5c1	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:06.746+00
47c78fd4-fb8c-47ea-bb2f-b5a340d25a96	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:06.748+00
872562b4-e666-4578-87f5-98fe0f2f3302	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:07.443+00
91989d62-2b78-49ee-9030-2dc5cf29c27e	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:07.446+00
9e000f3e-0a5d-42b9-a479-f900fa5778bc	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:07.46+00
3ec7cd3f-be8b-49bf-87b9-8019fad3c328	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:08.363+00
0ce63ef8-4b65-4a9c-9a48-fc807d71e433	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:08.369+00
fca67564-305e-4e20-a521-8ff6e89df0d4	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:08.403+00
0c68a7b2-6b70-45ea-9aa1-524696a69c61	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:08.975+00
211f2ef1-5ab7-43d7-9881-6818d7bc9d44	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:08.992+00
1f683355-c99a-41c2-b5b7-372ea3281a8b	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:09.019+00
22a8a03f-1175-4ac9-b424-4a5bb9e80fa1	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:09.596+00
f002680b-1e52-44fd-a0d8-dd928c94adad	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:09.616+00
a2abd86e-6a72-4b78-aeaf-9f1f4de20f15	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:09.635+00
5aeae031-84cd-402c-a0ad-5b261d660160	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:10.265+00
95491776-0a46-4db2-96e0-f84730e67629	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:10.268+00
329f00cb-217e-4504-bfdf-9ae6e1309701	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:10.269+00
77b30a75-52b4-4117-b84d-a04b7c9a3531	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:11.017+00
21a1556b-f840-4861-9aaf-bc89f8a22aa0	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:11.019+00
fd00b079-8e97-4875-9206-0ee5646680b3	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:11.02+00
38c6d8b1-2af5-433a-8822-23cee862dfd8	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:11.653+00
d039338c-f6b8-430a-a36c-abeed0b4d987	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:11.655+00
c17c0a2c-caf9-4b29-8b4a-00239a0e5fb1	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:11.657+00
bd93ddb7-2952-420e-8ddc-c85e83acd394	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:12.326+00
6a2a611a-5f2a-434d-ab57-bdc5e5af3add	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:12.331+00
1822da18-6c7f-4ca9-91fa-c7251e3a6651	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:12.338+00
4779e343-4fb2-4ccb-ab09-c6078bda9a9b	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:13.246+00
adc652cc-4e19-4ab2-9eb4-a12058ad1672	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:13.255+00
e5df6bfb-3087-4058-a488-2a36adc96a94	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:13.259+00
4cceddef-aca4-4b0d-8796-46b91de0c08a	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:14.215+00
9ee65100-72a2-4286-b4bd-ca51c5bfd0b3	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:14.217+00
b79a7095-d1a2-428c-bbb1-c4740f2a7b6a	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:14.218+00
9046a074-07b3-4dbb-8244-2b32f0e4f49f	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:14.867+00
4848079f-5424-489c-a027-a171ffcb2e51	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:14.891+00
d68e7769-4501-4090-839e-016e6971f639	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:14.901+00
bd0ae623-02da-48f9-ab7b-3ddccbbcb4a5	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:15.504+00
35bd3518-bcc2-4a44-ba7d-7180d6713033	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:15.517+00
9839462b-18fe-4605-9940-2be4e5399fae	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:15.571+00
be58ce7d-dbe4-437b-9403-b33b0863f8e8	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:16.122+00
01750e49-4071-4786-9fa6-f6ce678533e0	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:16.124+00
b28638e9-c73f-43d2-a0ac-bf40c1ce548c	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:16.175+00
69e64960-b7dd-4715-a927-e9877c407f70	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:16.782+00
4a25d5bc-bcaa-4c2d-8f39-0ef8348e2703	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:16.785+00
d3ad6234-445a-4753-a076-75d4bd4521a1	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:16.822+00
6351cc1f-29b1-400b-9b77-2e5594ea87c0	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:17.45+00
a4409ea4-f378-415d-b63f-af38772c8afb	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:17.457+00
b969b30b-42af-4577-bd61-ef9c97b4559f	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:17.477+00
5044b9e3-d16b-43f3-8d09-9dea8355e6b7	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:18.379+00
6507319b-ac01-41e9-b1bf-0e154e8f7bab	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:18.38+00
6b08d7ff-d0d5-4e42-9005-12c93fb09e51	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:18.396+00
36818ce5-6ea5-4d1e-a1b0-621f413f8523	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:19.05+00
337b319f-a174-4172-bfcd-1162d34aedcb	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:19.052+00
416590bf-702a-4219-a87f-cc2bfbdd4151	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:19.055+00
cdb62776-995b-4231-afb0-97a7df59d827	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:19.725+00
0767cffa-2017-44ff-be4e-868c64575703	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:19.73+00
e4790f18-5331-4d40-84c6-b05a1dee85bb	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:19.731+00
c40c3818-073b-4641-93a0-c7cb663fdf2e	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:20.39+00
0df2f12a-9363-46ef-b35a-87c81ca3c208	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:20.391+00
f079b3e3-5d9b-4f96-bc80-04e89e61986b	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:20.393+00
b1041f8c-ee0e-44f0-aa76-03d6c3d129d9	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:21.154+00
37c0fc20-3b51-477d-afba-e163de73e14b	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:21.157+00
32af9527-95e9-4d13-8dbf-37e5a2efb15c	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:21.159+00
4aef096c-4542-4bdd-93a5-970209048385	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:21.798+00
2a37d498-5612-4df8-94fb-c8f5e61c4b12	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:21.818+00
dd54a0d4-450d-4cef-bb73-6e2dd116519d	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:22.435+00
6ee12b49-080a-4fb0-9f67-5cc8dc1e0929	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:22.459+00
10c87120-e269-4710-b327-83147e0f2fba	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:22.467+00
02cebd08-957d-479e-b571-4597b676e867	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:23.09+00
f874021d-b19a-41f6-b7d2-4eff4af450f1	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:23.779+00
45d94f59-f9f6-414d-b807-210ad6fb685d	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:23.784+00
9cc6b9d0-d406-469e-95a1-f85f445f9a0d	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:24.789+00
5d23b993-934b-400c-a8d2-21a648ea9b33	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:24.793+00
0ea04125-aa1e-4187-807f-274f1a6645ed	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:25.458+00
cd94bd5d-b8a3-48d6-8acb-9a827f44490b	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:26.167+00
cb26d2b0-bc51-4953-9b6f-f04cc64b1834	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:26.825+00
04f046d7-316f-4c53-a0b5-42609d16a164	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:27.856+00
b2f58047-13fa-459b-9095-34e1294f0e96	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:29.015+00
8e61bafe-0f69-4b3b-9327-125998489cd4	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 0 do0wni3u	80000	250000	3	\N	\N	\N	2026-03-25 20:30:56.066+00
4709f30f-3736-4057-929d-32191c746185	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 1 64t0gdk8	81000	250000	4	\N	\N	\N	2026-03-25 20:30:56.775+00
5a03a7ba-cd27-47ef-b965-ba578b49917a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 1 tmny05hz	81000	250000	4	\N	\N	\N	2026-03-25 20:30:56.79+00
e94dcf3d-1e06-4bfa-b8c6-599ca4501c50	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 2 z4r9apnh	82000	250000	5	\N	\N	\N	2026-03-25 20:30:57.37+00
b3ea01bd-f95b-4baf-b2c7-f5fa3ba2df86	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 2 hsg7f1rp	82000	250000	5	\N	\N	\N	2026-03-25 20:30:57.441+00
47841e8e-5a25-442e-b0eb-b68f7562b3e3	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 3 s6mjra4o	83000	250000	6	\N	\N	\N	2026-03-25 20:30:58.85+00
51c1e96d-ba9f-4e04-938a-2546b4370f13	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 3 47uo47wh	83000	250000	6	\N	\N	\N	2026-03-25 20:30:58.856+00
2213bea5-50b1-4a68-9e5a-447bac759233	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 3 mt0qtbmi	83000	250000	6	\N	\N	\N	2026-03-25 20:30:58.862+00
3c8421dc-d058-4618-a127-98ee38a1181d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 4 grai53kt	84000	250000	7	\N	\N	\N	2026-03-25 20:30:59.7+00
52421f8a-b05b-474e-9ea0-6073698f8d23	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 5 mz6b2n76	85000	250000	3	\N	\N	\N	2026-03-25 20:31:00.414+00
1be757fb-8813-42c9-a9eb-363f466cba91	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 7 qgwgxzu3	87000	250000	5	\N	\N	\N	2026-03-25 20:31:01.932+00
c2679e61-6c92-4b65-af14-90c7e6032039	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 8 mkn76mj7	88000	250000	6	\N	\N	\N	2026-03-25 20:31:03.484+00
9ab1ff9b-53ed-449d-94b9-62e980377ba6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 9 2k4jyoz0	89000	250000	7	\N	\N	\N	2026-03-25 20:31:03.971+00
212eaf44-af50-461d-8a2c-8f0d4855a01b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 9 4k2z3mon	89000	250000	7	\N	\N	\N	2026-03-25 20:31:04.038+00
6f9f877b-7c19-4f1c-9647-2314092fbb4d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 9 ohc5aqqc	89000	250000	7	\N	\N	\N	2026-03-25 20:31:04.046+00
36458209-0172-4196-af04-5698139c1eb4	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 9 m9batms5	89000	250000	7	\N	\N	\N	2026-03-25 20:31:04.07+00
d0e468cf-e3ab-455d-b15b-307d4a617497	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 9 xb5w306o	89000	250000	7	\N	\N	\N	2026-03-25 20:31:04.083+00
e85c9c09-1f05-4c57-bbbc-eba35de09c4c	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 11 wjqzjudv	81000	250000	4	\N	\N	\N	2026-03-25 20:31:05.104+00
0feca4bb-ca5a-4ede-a4fa-ea03fe6ec8fb	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 11 5kn1pyvm	81000	250000	4	\N	\N	\N	2026-03-25 20:31:06.216+00
87a98161-df0f-4971-a8b2-d7c32c81b443	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 11 8ys7bm6x	81000	250000	4	\N	\N	\N	2026-03-25 20:31:06.468+00
65207b79-6e9b-4252-8553-9153f5d9c32b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 11 2qvljq5q	81000	250000	4	\N	\N	\N	2026-03-25 20:31:06.477+00
e0d33519-4de9-426f-82e4-2bc31e226602	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 12 nnyd23dn	82000	250000	5	\N	\N	\N	2026-03-25 20:31:07.442+00
81d037d3-75d0-40b1-90ba-2351e9d52ab6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 13 ikz0fko2	83000	250000	6	\N	\N	\N	2026-03-25 20:31:09.179+00
ed3e56ec-7499-48c1-8b17-2d94bb739a56	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 13 m3uwznng	83000	250000	6	\N	\N	\N	2026-03-25 20:31:09.219+00
7c514726-868f-430a-8aa9-3d5d079166ac	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 13 3d8l7y7p	83000	250000	6	\N	\N	\N	2026-03-25 20:31:09.243+00
247a1301-ccce-4e16-8659-b52705a2ce4e	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 14 scpyllsp	84000	250000	7	\N	\N	\N	2026-03-25 20:31:09.643+00
88bdb6ff-0831-47fa-92d2-b4e145beff40	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 14 y77gi81g	84000	250000	7	\N	\N	\N	2026-03-25 20:31:09.772+00
56d3ca91-f921-49fc-afcc-77387901e93f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 15 bq48rzdw	85000	250000	3	\N	\N	\N	2026-03-25 20:31:10.107+00
e06153c4-7d94-46ef-8c87-98fbed9d3383	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 15 bcrri205	85000	250000	3	\N	\N	\N	2026-03-25 20:31:10.246+00
685a963f-3409-4c15-96be-7fe941a3adba	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 16 3yao79kz	86000	250000	4	\N	\N	\N	2026-03-25 20:31:10.797+00
18d74965-a57c-4731-acf5-1bd7f9846adc	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 16 qyabwhle	86000	250000	4	\N	\N	\N	2026-03-25 20:31:10.816+00
141641a7-63ee-41c0-9dbe-ff218b275130	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 16 eu9t9n2p	86000	250000	4	\N	\N	\N	2026-03-25 20:31:10.849+00
75e6f706-a3f4-46ca-aa67-1968c301713b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 18 azhez43l	88000	250000	6	\N	\N	\N	2026-03-25 20:31:11.95+00
5f4ff543-eeb0-493a-8f93-dfaf90b169a0	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 18 dxur2shx	88000	250000	6	\N	\N	\N	2026-03-25 20:31:12.063+00
4cb0f01d-f21f-41f4-bd1b-0e9513cd9cb5	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 19 ku6z1vbr	89000	250000	7	\N	\N	\N	2026-03-25 20:31:12.232+00
0ac7cbe0-8ca8-4afd-9106-366dcdb5ad3a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 19 c358fp37	89000	250000	7	\N	\N	\N	2026-03-25 20:31:12.431+00
10119384-b3fd-4ba4-a45a-0b6eff9e7fe9	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 19 ynvpkmbz	89000	250000	7	\N	\N	\N	2026-03-25 20:31:12.45+00
6d20e205-5576-4e47-8b20-56f951bcd298	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 19 4ih1mitt	89000	250000	7	\N	\N	\N	2026-03-25 20:31:12.646+00
4d3c1b38-2d27-4430-b049-84d86ec480d0	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 20 vds8nlwj	80000	250000	3	\N	\N	\N	2026-03-25 20:31:12.662+00
89cde52d-e64c-413b-8ca7-93fb6c8d5c19	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 20 5qwik8pd	80000	250000	3	\N	\N	\N	2026-03-25 20:31:13.853+00
a387a383-6070-4554-b33c-5ff94044e0d9	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 20 dd81k61x	80000	250000	3	\N	\N	\N	2026-03-25 20:31:14.451+00
20225e48-1828-4619-a641-d4c754f2f1ef	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 21 o0fsti5a	81000	250000	4	\N	\N	\N	2026-03-25 20:31:15.039+00
86e1e263-a568-4485-ae0a-1efc16316cf8	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 21 y9k275qt	81000	250000	4	\N	\N	\N	2026-03-25 20:31:15.215+00
88e7520b-87c6-46e1-a40b-d66b826dc3c4	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 22 fnlaxif3	82000	250000	5	\N	\N	\N	2026-03-25 20:31:15.681+00
ee289b32-0fb5-41f8-9328-5ec7abe5e596	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 23 g2iia9dm	83000	250000	6	\N	\N	\N	2026-03-25 20:31:15.875+00
55767d8c-93d3-4f11-8040-254da1789338	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 23 y9ircizz	83000	250000	6	\N	\N	\N	2026-03-25 20:31:16.188+00
b9fbb94f-a123-4519-8ae7-d80652641467	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 23 icn4usge	83000	250000	6	\N	\N	\N	2026-03-25 20:31:16.199+00
e74cb8a5-17b7-400d-9c42-e579ea2e22cd	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 24 vys3i4is	84000	250000	7	\N	\N	\N	2026-03-25 20:31:17.017+00
ec6c67c6-550e-4037-8c8b-33ee2d688a7f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 25 xq6v0wpy	85000	250000	3	\N	\N	\N	2026-03-25 20:31:17.439+00
4cabfaa2-8bf5-4f97-8892-fa28237cda53	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 25 7rbco6ew	85000	250000	3	\N	\N	\N	2026-03-25 20:31:17.658+00
61f1ea25-c193-4172-ae4f-a58892c050ec	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 25 ewtkuwqk	85000	250000	3	\N	\N	\N	2026-03-25 20:31:17.813+00
3434fc18-a15e-4999-97ec-ff6d4544e68a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 26 0gyoelqo	86000	250000	4	\N	\N	\N	2026-03-25 20:31:18.217+00
65bdedfd-201a-4fe3-b656-4460b4a26f67	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 26 vpjk9biw	86000	250000	4	\N	\N	\N	2026-03-25 20:31:18.818+00
a7699412-0e1d-462d-8b36-ed50f8d27d2f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 27 blaiylxh	87000	250000	5	\N	\N	\N	2026-03-25 20:31:19.068+00
7e623584-1bf8-49d7-b08b-81633ddbe521	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 27 uwkeegea	87000	250000	5	\N	\N	\N	2026-03-25 20:31:19.416+00
a2f8f5e4-7bd9-4ca6-8a67-29c43c225697	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 27 ojbdlwv9	87000	250000	5	\N	\N	\N	2026-03-25 20:31:19.451+00
8e3ef335-77a0-4cb0-bf95-b4d9ef9ad475	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 27 v3j55ghb	87000	250000	5	\N	\N	\N	2026-03-25 20:31:19.62+00
d0d590fd-3371-4772-a828-982606e1852a	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:21.82+00
f0eee616-9d7c-44c4-b55f-fe545a3d93d0	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:23.093+00
44196d0b-2a20-4b2e-94cf-7c06fc5957a9	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:23.781+00
ee5081be-dc74-4154-b4c8-e4b4fdbfb5d1	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:25.43+00
15f28cc2-2237-4881-919d-c8ddc3e91790	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:25.455+00
9a00f8c8-3333-440a-8f39-a64b14af3e73	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:26.102+00
5b8623f9-50f9-4e4d-bb7a-aef2df82f790	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:26.165+00
f7349b83-6cf2-419d-a40a-5a69750b9095	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:26.815+00
abc53418-8bc6-4a4b-bf15-af8ea197c3f9	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:27.666+00
15346259-05a5-456d-bd79-875feac4b684	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:27.853+00
a6d27c46-acaf-4339-907e-a3d123889e43	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:29.017+00
608e7795-084b-46a9-bb74-4a5639b60da9	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 0 tnx8o8iu	80000	250000	3	\N	\N	\N	2026-03-25 20:30:56.064+00
dab14d9e-70d8-4843-9d35-4ec3cd39b74b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 0 r5nfa6og	80000	250000	3	\N	\N	\N	2026-03-25 20:30:56.078+00
4cd0fe38-cf86-45ab-a5b1-0ad32935d384	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 0 2gi92mrp	80000	250000	3	\N	\N	\N	2026-03-25 20:30:56.087+00
328cbc9a-6a93-4f1d-a38b-0253eab7945c	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 1 zl35eex6	81000	250000	4	\N	\N	\N	2026-03-25 20:30:56.841+00
7ad82849-03b5-48db-90c5-f02c05de7193	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 1 of7kwhgl	81000	250000	4	\N	\N	\N	2026-03-25 20:30:56.844+00
117954ed-43a5-409e-91d9-6b4c6ad1d200	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 2 lfz61ec1	82000	250000	5	\N	\N	\N	2026-03-25 20:30:57.448+00
5c04c7f8-fb06-4c38-bd12-26cfeb1b9d4a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 2 zhjdwa7e	82000	250000	5	\N	\N	\N	2026-03-25 20:30:57.47+00
e053aeb5-b8af-4c4f-ac46-cf22232e76ee	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 3 frqihnuc	83000	250000	6	\N	\N	\N	2026-03-25 20:30:58.651+00
f8b131ad-1482-48f9-bb0b-48e7ca499068	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 3 ywbhdzsp	83000	250000	6	\N	\N	\N	2026-03-25 20:30:58.864+00
fd036d53-bbab-4196-bc16-fd49ab8484f6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 4 k991lg3a	84000	250000	7	\N	\N	\N	2026-03-25 20:30:59.606+00
0698e190-b685-4d6d-bdd0-5a9872fc8fd7	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 4 d6h9uumf	84000	250000	7	\N	\N	\N	2026-03-25 20:30:59.657+00
6f2fba17-96e0-4958-a8c3-b857a937de9a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 4 rfco37so	84000	250000	7	\N	\N	\N	2026-03-25 20:30:59.698+00
8aa8b7ec-5688-4590-8422-041520bb9720	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 4 af411i8u	84000	250000	7	\N	\N	\N	2026-03-25 20:30:59.78+00
19e90996-1385-4ad4-8762-e1e3143e029f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 5 foeebbhl	85000	250000	3	\N	\N	\N	2026-03-25 20:31:00.412+00
b079ec77-985f-4d3a-8d5e-eaab4483ccf0	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 5 r0hri8cq	85000	250000	3	\N	\N	\N	2026-03-25 20:31:00.415+00
ab077448-f8c9-47d1-bd8e-05ba86fb96db	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 5 mz92wcqi	85000	250000	3	\N	\N	\N	2026-03-25 20:31:00.434+00
fd0bc9a2-e142-4382-ab9a-5fddaaa147cb	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 6 gfhb1rm4	86000	250000	4	\N	\N	\N	2026-03-25 20:31:01.015+00
7a491452-11c2-4e5d-8fe9-516fdb045b19	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 6 pfgqk2xf	86000	250000	4	\N	\N	\N	2026-03-25 20:31:01.069+00
4f47d8c0-2649-4d6b-80a7-3996ebdcfe4a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 6 bsp4cpgm	86000	250000	4	\N	\N	\N	2026-03-25 20:31:01.097+00
20386315-d10b-4281-a19f-52c741f69a50	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 7 2c9bwpk2	87000	250000	5	\N	\N	\N	2026-03-25 20:31:01.247+00
e5760c5d-a2b2-4346-b5a9-66f7ea01f587	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 7 fnfrrq7y	87000	250000	5	\N	\N	\N	2026-03-25 20:31:01.87+00
05067465-abed-42f2-9308-bd8092551628	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 7 qt6nlvbn	87000	250000	5	\N	\N	\N	2026-03-25 20:31:01.901+00
63bc0830-eaa4-4424-9e69-2307e3e9ac1a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 7 v8d884mk	87000	250000	5	\N	\N	\N	2026-03-25 20:31:02.046+00
89103dbe-9248-4ea2-9c53-447081920ce1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 8 clo2mcra	88000	250000	6	\N	\N	\N	2026-03-25 20:31:02.093+00
a44f44c1-9c85-4127-a32e-1ec91362a694	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 8 unplkiqp	88000	250000	6	\N	\N	\N	2026-03-25 20:31:03.416+00
ffdaae75-fb89-4e2d-ae0f-385b88926e66	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 8 gk02lr69	88000	250000	6	\N	\N	\N	2026-03-25 20:31:03.482+00
733b554d-022b-472f-b998-e22f6d1ff2ee	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 8 kx1yqiru	88000	250000	6	\N	\N	\N	2026-03-25 20:31:03.486+00
33a6da1b-3687-46a0-85cd-79e08cdfc57e	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 9 qkypkklj	89000	250000	7	\N	\N	\N	2026-03-25 20:31:03.489+00
0502e48d-fc04-43b3-92b6-b02560a2c8cf	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 10 3wcv2mo1	80000	250000	3	\N	\N	\N	2026-03-25 20:31:04.086+00
30bf97a2-0cf8-483a-8f72-a37e69fa79b1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 10 gbf5n69e	80000	250000	3	\N	\N	\N	2026-03-25 20:31:04.947+00
85bd3c00-c4b4-4873-97b4-cb77ee797883	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 10 5u0e2hra	80000	250000	3	\N	\N	\N	2026-03-25 20:31:04.978+00
7b71b564-93b8-46ca-8311-979c2d58b48e	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 10 51bk5xw9	80000	250000	3	\N	\N	\N	2026-03-25 20:31:05.007+00
5ed535f0-3696-49ec-a233-7fb5fd28d0a0	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 11 i97zt2n5	81000	250000	4	\N	\N	\N	2026-03-25 20:31:05.035+00
5c6a57de-b5ed-4e80-b2b8-31a9bfb22b44	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 12 s1x3rogn	82000	250000	5	\N	\N	\N	2026-03-25 20:31:06.473+00
59122f33-7ef9-40ef-a415-ffdbcfab3aa5	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 12 no8l33by	82000	250000	5	\N	\N	\N	2026-03-25 20:31:06.721+00
2608a26c-497c-4c48-ba14-3d584555dde7	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 12 bevadhb0	82000	250000	5	\N	\N	\N	2026-03-25 20:31:07.137+00
249ee33a-3f18-4857-96de-3a41c8f59fc7	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 12 548oxy7y	82000	250000	5	\N	\N	\N	2026-03-25 20:31:07.438+00
f8c78398-c4ee-4d85-a9ff-74ac04680077	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 13 7elly3gg	83000	250000	6	\N	\N	\N	2026-03-25 20:31:07.445+00
50b4ec53-a6ab-49fa-bf2e-3c5ca6b1ce28	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 14 l3z9liun	84000	250000	7	\N	\N	\N	2026-03-25 20:31:09.441+00
cfc09eca-39aa-4300-a703-3c1af008a75a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 14 qygfr887	84000	250000	7	\N	\N	\N	2026-03-25 20:31:09.774+00
5b5534b5-afb7-4d91-b8e4-633f5f78722b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 15 d1e25d0x	85000	250000	3	\N	\N	\N	2026-03-25 20:31:09.978+00
e5f1d47e-feb0-4e66-a29a-e5329f63dd36	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 15 21wsijpo	85000	250000	3	\N	\N	\N	2026-03-25 20:31:10.021+00
ac198465-d2b6-418f-9fc5-603d8f670bfd	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 15 rmb02ymi	85000	250000	3	\N	\N	\N	2026-03-25 20:31:10.036+00
b52d76c0-14c5-4b97-9839-f7b3c675e745	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 15 e7nrjf8r	85000	250000	3	\N	\N	\N	2026-03-25 20:31:10.243+00
9af612f6-49c0-4526-a9a4-2dcb38e4981e	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 16 dmb71dny	86000	250000	4	\N	\N	\N	2026-03-25 20:31:11.015+00
b89d94b5-33a7-47cd-b185-7079bf365720	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 17 fbtc4tdj	87000	250000	5	\N	\N	\N	2026-03-25 20:31:11.34+00
3c8abf7f-99a5-463b-b5c5-b37858c4c9e1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 17 nz8i5gw0	87000	250000	5	\N	\N	\N	2026-03-25 20:31:11.383+00
6b6baeaf-dd09-449c-91d9-9ac1735faf6d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 17 fi22dqoc	87000	250000	5	\N	\N	\N	2026-03-25 20:31:11.387+00
bbb84cd1-cfce-4595-9d14-696092c59b52	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 18 4xmfyml4	88000	250000	6	\N	\N	\N	2026-03-25 20:31:11.951+00
6b9adf73-122b-4381-aa67-05a7d4054768	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 18 h7hk5nz7	88000	250000	6	\N	\N	\N	2026-03-25 20:31:12.06+00
7f6fff63-76e9-4cd6-b6ac-865e5348bb84	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 19 syhdwghb	89000	250000	7	\N	\N	\N	2026-03-25 20:31:12.454+00
b536b53a-260a-4d71-a0e3-03a8dec88297	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 20 7rsxixer	80000	250000	3	\N	\N	\N	2026-03-25 20:31:13.817+00
71632204-236d-4d63-8aec-3bd22d76dbc8	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 21 of5dtrbu	81000	250000	4	\N	\N	\N	2026-03-25 20:31:14.459+00
b8f1d7aa-a170-4cd7-91c8-aadd5b3c6699	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 21 xwsao282	81000	250000	4	\N	\N	\N	2026-03-25 20:31:15.041+00
2b7a3863-1265-47af-a325-97e5c5d79ad1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 21 bq703xwv	81000	250000	4	\N	\N	\N	2026-03-25 20:31:15.178+00
e2460ea4-5356-4432-b7c5-54fcd1607079	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 22 0b9qtojt	82000	250000	5	\N	\N	\N	2026-03-25 20:31:15.873+00
61725949-ba5c-4b4a-9866-26eea09ec36f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 23 erfg2snf	83000	250000	6	\N	\N	\N	2026-03-25 20:31:16.186+00
103420d5-fdf7-478e-8780-deea6d72ed12	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 23 1tsq0ljd	83000	250000	6	\N	\N	\N	2026-03-25 20:31:16.419+00
3cb89c63-a34d-44d0-848c-216897c1a454	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 24 v502cwpm	84000	250000	7	\N	\N	\N	2026-03-25 20:31:16.423+00
2f2cd4b6-acdc-4013-bdd4-280b64902702	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 24 ndlsxp20	84000	250000	7	\N	\N	\N	2026-03-25 20:31:16.683+00
475d7dec-1081-4954-b507-08031264153e	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:23.095+00
4aa67308-9172-4ce2-877b-80f58e23dc2e	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:24.791+00
4270aeea-1872-4f66-885e-c2040e845d0a	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:26.842+00
9b821c8e-ae8a-4beb-8d7d-aad5d8699d21	96b4b689-7052-45aa-913e-29e88b7026c1	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-25 20:30:29.012+00
193f333f-7314-412e-83f2-0f27ae89c13f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 0 kjaczw7a	80000	250000	3	\N	\N	\N	2026-03-25 20:30:56.062+00
0a050450-c414-4450-853b-161843bf5f89	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 0 pli6czj1	80000	250000	3	\N	\N	\N	2026-03-25 20:30:56.068+00
bead085b-1af4-4f4b-a487-3768f76c7299	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 1 2xkefkgu	81000	250000	4	\N	\N	\N	2026-03-25 20:30:56.791+00
66aa337c-c5a8-4786-b014-e89f26f82995	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 1 9u5116iy	81000	250000	4	\N	\N	\N	2026-03-25 20:30:56.842+00
5d772fe7-3b5a-4662-8532-3d211e2e0dc6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 2 x9zelo1k	82000	250000	5	\N	\N	\N	2026-03-25 20:30:57.445+00
1bbc6d78-78ad-415e-bbda-1b7ff9e79e93	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 2 j1b4go2a	82000	250000	5	\N	\N	\N	2026-03-25 20:30:57.64+00
7a913194-521f-49cb-be3b-8e95ac491224	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 3 9o6tb72a	83000	250000	6	\N	\N	\N	2026-03-25 20:30:59.053+00
85e33ed4-3fef-47bf-80f7-fb2aa35ec3eb	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 4 xnhsl9rq	84000	250000	7	\N	\N	\N	2026-03-25 20:30:59.695+00
238e99a3-3eb9-4e15-8993-fa032f49af53	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 5 596vfe72	85000	250000	3	\N	\N	\N	2026-03-25 20:31:00.214+00
787a92a3-4bde-4b97-bece-0720df9b7c43	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 5 n871mvgt	85000	250000	3	\N	\N	\N	2026-03-25 20:31:00.41+00
793db3fa-eb36-45b6-8937-4430525ce724	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 6 ou54zut6	86000	250000	4	\N	\N	\N	2026-03-25 20:31:00.645+00
45a506c7-a42b-406c-8499-9473c6981138	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 6 q563jksd	86000	250000	4	\N	\N	\N	2026-03-25 20:31:01.017+00
aca69a36-723f-46a7-86b5-1d9c33c23253	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 6 qfivntah	86000	250000	4	\N	\N	\N	2026-03-25 20:31:01.065+00
5d9f6687-30e2-4092-bf11-e85967bc1b25	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 7 vl9obpq8	87000	250000	5	\N	\N	\N	2026-03-25 20:31:01.938+00
bf16b81f-cbfd-45d4-8c63-984828c15e2b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 8 0lxet4ma	88000	250000	6	\N	\N	\N	2026-03-25 20:31:03.487+00
5c1380df-dbbb-43eb-9157-fa4f2097a572	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 10 z0p0f4a5	80000	250000	3	\N	\N	\N	2026-03-25 20:31:04.642+00
17274b2b-66db-4a6c-a511-038c85abf3c2	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 10 xf75gubd	80000	250000	3	\N	\N	\N	2026-03-25 20:31:04.944+00
50cbc348-35b1-42b2-998d-40c3a31af00d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 11 oaiu1y3a	81000	250000	4	\N	\N	\N	2026-03-25 20:31:06.465+00
7ba3d761-894f-403a-b38f-cfdb89337c32	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 12 jqo7rphd	82000	250000	5	\N	\N	\N	2026-03-25 20:31:07.44+00
3ebd0884-8970-4940-bb83-7ea28f8ab650	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 13 mudsvazh	83000	250000	6	\N	\N	\N	2026-03-25 20:31:07.444+00
903f9a9c-3009-4833-8b65-45ac44053f0b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 13 kd3vbx91	83000	250000	6	\N	\N	\N	2026-03-25 20:31:07.643+00
0616bdda-7471-45dc-9bcc-d1bdf7e293fe	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 14 uvkas8qe	84000	250000	7	\N	\N	\N	2026-03-25 20:31:09.416+00
a544b969-281a-41f8-ad5f-101bfc30eb73	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 14 2qtqtnbd	84000	250000	7	\N	\N	\N	2026-03-25 20:31:09.45+00
a24819c4-1ff8-4a1c-8643-394248a452bf	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 16 9kv5whmg	86000	250000	4	\N	\N	\N	2026-03-25 20:31:10.795+00
7c1a3741-23d9-4f3f-b610-e47f2ba8c75b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 16 qvbdp231	86000	250000	4	\N	\N	\N	2026-03-25 20:31:10.958+00
b8e3c261-f6d3-4944-8f4f-5ef2a10671e7	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 17 a17hhvp4	87000	250000	5	\N	\N	\N	2026-03-25 20:31:11.385+00
3ae493ba-3629-4352-8138-98b3da8668f4	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 17 qnp7m78j	87000	250000	5	\N	\N	\N	2026-03-25 20:31:11.477+00
e002b9ce-5873-4578-9823-a6de961f96c2	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 17 bl915w6d	87000	250000	5	\N	\N	\N	2026-03-25 20:31:11.489+00
8f3d9641-9b65-41ae-8df3-eee9ef18ead6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 18 h38uz39c	88000	250000	6	\N	\N	\N	2026-03-25 20:31:11.825+00
be9cd680-8448-4bf3-8d99-427b13bb7e3a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 18 tbfq6r1q	88000	250000	6	\N	\N	\N	2026-03-25 20:31:11.948+00
2ed7771c-4ac0-4158-91aa-e72230d35178	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 19 xdcoacib	89000	250000	7	\N	\N	\N	2026-03-25 20:31:12.644+00
d56e9802-9b8c-4fab-8f73-03dbfab0ace1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 20 zz5ob1fk	80000	250000	3	\N	\N	\N	2026-03-25 20:31:13.867+00
60edfaa2-8c0a-4977-93df-24bfe2dd7928	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 20 ndzqr2vk	80000	250000	3	\N	\N	\N	2026-03-25 20:31:14.455+00
c47676d6-783b-48bd-b9c5-f20a06e9dab3	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 21 q0lyfu75	81000	250000	4	\N	\N	\N	2026-03-25 20:31:15.038+00
0e774e34-daf9-4c7c-b049-577d951758b8	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 22 h61v7pdr	82000	250000	5	\N	\N	\N	2026-03-25 20:31:15.213+00
9a088332-2169-4544-bdd3-d51e0017179d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 22 ze2cc41t	82000	250000	5	\N	\N	\N	2026-03-25 20:31:15.679+00
a644cc71-ebca-4254-8208-fc556e2e7973	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 22 q1zmwnae	82000	250000	5	\N	\N	\N	2026-03-25 20:31:15.684+00
61918826-505f-4a12-80c1-493052b40202	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 22 i7mzv917	82000	250000	5	\N	\N	\N	2026-03-25 20:31:15.854+00
83b8cdd3-f00e-4e21-8e20-9c54e6a6fba3	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 23 nv9ho7gt	83000	250000	6	\N	\N	\N	2026-03-25 20:31:16.421+00
da47d8ba-df58-4566-be0b-e9d198661f93	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 24 df9ewc4g	84000	250000	7	\N	\N	\N	2026-03-25 20:31:16.739+00
6e45cbff-6428-440a-92d0-0a7dc26875c6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 24 92dfwb4w	84000	250000	7	\N	\N	\N	2026-03-25 20:31:16.813+00
0052ff4b-3baa-48f5-932c-fc9be8a77840	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 24 nwu7bpor	84000	250000	7	\N	\N	\N	2026-03-25 20:31:16.974+00
a82cb436-4861-4c85-9246-7cab7de70bc1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 25 g9xbg0bf	85000	250000	3	\N	\N	\N	2026-03-25 20:31:17.02+00
f4453479-9259-4af2-a2de-00d613fa05ed	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 25 bx11kxgn	85000	250000	3	\N	\N	\N	2026-03-25 20:31:18.215+00
5ecac0fb-56b4-4731-840d-2be29d3f9718	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 25 yc871xnk	85000	250000	3	\N	\N	\N	2026-03-25 20:31:18.218+00
208333ea-8d86-44b8-9efa-aa6a2b0d4800	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 26 a0s0efy6	86000	250000	4	\N	\N	\N	2026-03-25 20:31:18.815+00
597054dc-3012-49ce-b23f-7cbe850160cf	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 26 dht9x2wd	86000	250000	4	\N	\N	\N	2026-03-25 20:31:18.821+00
91a08a58-8960-4454-8c7d-c22bb6aac7a9	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 26 bj91g8dk	86000	250000	4	\N	\N	\N	2026-03-25 20:31:19.07+00
8fbe98b1-01a9-4799-87ca-391be44fb61b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 26 jlsufou5	86000	250000	4	\N	\N	\N	2026-03-25 20:31:19.073+00
7ae381e8-6aa9-427b-84e9-2e002bb4ca16	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 27 ifsp7vpt	87000	250000	5	\N	\N	\N	2026-03-25 20:31:19.414+00
28e0cde6-6f99-4da0-8382-ca5dc98dd0a5	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 27 5lpc8sab	87000	250000	5	\N	\N	\N	2026-03-25 20:31:19.622+00
390d358f-0cc6-4332-8486-f5f2fb9fa296	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 28 eo7jgnyx	88000	250000	6	\N	\N	\N	2026-03-25 20:31:19.625+00
a3a7d41c-c932-4e71-a9dd-c584bb3385c2	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 28 vnak9uxn	88000	250000	6	\N	\N	\N	2026-03-25 20:31:19.865+00
e34f0a7e-1175-4203-89b7-d10a9ad03503	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 28 npi5pwci	88000	250000	6	\N	\N	\N	2026-03-25 20:31:19.877+00
2de438a5-28aa-4c1a-91ba-35acbdfa7c36	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 28 j4jugmin	88000	250000	6	\N	\N	\N	2026-03-25 20:31:19.912+00
9ad69347-203d-4712-a53b-bd4f2bed477d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 28 nfw0z7ls	88000	250000	6	\N	\N	\N	2026-03-25 20:31:20.088+00
39f44039-51b5-4eb3-89bf-e59889e5b11c	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 28 0v7k35mu	88000	250000	6	\N	\N	\N	2026-03-25 20:31:20.175+00
98caafb1-c604-42b1-8c0a-d5792521d6e2	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 29 wwwsq3dr	89000	250000	7	\N	\N	\N	2026-03-25 20:31:20.177+00
a996719d-8ddd-49cf-878c-752e30c3b820	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 29 cxq7oxbg	89000	250000	7	\N	\N	\N	2026-03-25 20:31:20.412+00
45e46e63-706e-40cf-8229-f97222f017d0	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 29 m4wrr1fl	89000	250000	7	\N	\N	\N	2026-03-25 20:31:20.473+00
442240f2-587c-4bc4-9f42-9abf784b2639	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 29 b77t2580	89000	250000	7	\N	\N	\N	2026-03-25 20:31:20.48+00
2c7b5e94-a0d8-4170-8b93-81220fc4fee6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 29 ojyf5oth	89000	250000	7	\N	\N	\N	2026-03-25 20:31:20.639+00
6d16a1f1-1acd-4c42-b3f9-39701e9181b5	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 29 h7l6l1du	89000	250000	7	\N	\N	\N	2026-03-25 20:31:20.65+00
cd6c8dda-ad40-4957-8b56-324acb70a8c6	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 30 s1hg0hkd	80000	250000	3	\N	\N	\N	2026-03-25 20:31:20.668+00
8975a54b-ac56-4c76-8694-9d750722e785	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 30 54lhdij0	80000	250000	3	\N	\N	\N	2026-03-25 20:31:20.843+00
72328734-3fb7-4941-9908-6ded8fb1b83c	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 30 s6u6uwlx	80000	250000	3	\N	\N	\N	2026-03-25 20:31:20.892+00
06b9a111-e130-410f-a7aa-f516788caa20	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	k6 search 30 g5r4xsh2	80000	250000	3	\N	\N	\N	2026-03-25 20:31:20.895+00
20d2c882-c1ea-406e-8049-b6d2cd38c0cb	154b021e-3a01-4ecf-a919-30d65233b635	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-25 20:39:29.855+00
ffa27438-7fac-4252-9418-2829104baa2a	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:42.06+00
8cd5e771-6e5a-4386-ba7d-5706a09f036e	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:42.088+00
03538941-df5f-4ca3-9572-ece81e4fc371	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:42.088+00
11d9abe1-342e-4946-8314-dd2597e37d2d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:43.132+00
2739f584-bde6-4ab8-8ca4-a5283dcae699	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:43.141+00
70fad6b6-c491-4209-90e5-4a96853cf780	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:43.15+00
b1ba860b-2679-44e4-8c75-19553bfa7c2b	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:43.966+00
e7ddadd8-fcde-4b0d-b6e0-e9f3c00b677f	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:43.975+00
bcfcf574-f1c6-4a7b-940f-a4d22f6c32d7	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:43.979+00
0f83f114-cc2e-42aa-a182-1b2a76782002	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:44.836+00
d55e07dc-ed55-46d7-b034-16d1ba3342e5	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:44.841+00
ff87ad5f-a728-4eac-b954-d5edd8ea35f6	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:44.843+00
35764adf-8a79-476b-b159-03003a42cb21	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:45.506+00
a60f4f56-3049-402c-b575-cfb74ca0cd47	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:45.515+00
03111b76-d26c-4c22-ab27-4d4b50a4e86d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:45.538+00
bee20d6c-ca3a-43b4-aae8-f55fa46ffcaf	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:46.226+00
5e8c53ef-dd51-4821-82c4-25f899ee2f24	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:46.26+00
ff090386-295f-43ae-bd57-01467f8769d2	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:46.264+00
485ccc80-44a1-4d8c-9eaf-4acb5aa93b7d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:47.169+00
0d223bb0-7c13-4126-858e-e9d59d33b178	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:47.172+00
063c2960-c49c-45ae-b174-caedc7c16eee	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:47.474+00
3112c51b-f148-48dd-b41f-5b9d2b403797	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:48.212+00
f41defa0-db57-4d80-b9b2-73013a42edf8	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:48.227+00
2a71eba7-36ce-470a-9def-3bb66689c303	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:48.229+00
467e3479-3de6-4dfd-9841-526d4c8ef48d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:48.907+00
904c7002-a286-437f-8c53-bf03838c92c8	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:48.909+00
c6401ff5-c42b-40d7-af1d-d2c2476ff979	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:48.912+00
2f1ee9a8-5d4a-4b70-a8b7-2672cb31fcbb	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:49.544+00
e441c9a7-0fed-4a97-be3b-a144ddf2331e	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:49.553+00
23a9bd69-143f-4399-816a-3fafb83e2a95	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:49.581+00
35953494-cdc2-4195-8ad9-761e30b07192	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:50.204+00
d9f7976f-0067-48b5-9ddc-9a2ef7d68d94	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:50.207+00
c198e79d-4d6c-42c0-81e5-567aec19e0e1	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:50.211+00
2dae9dd1-9f06-42a8-97d2-85c00e8b0e1f	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:50.963+00
dfaa260d-be38-4d54-9645-6693f87112f7	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:50.966+00
cc31a180-f8f2-4192-af71-1dd955becb10	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:50.968+00
15502450-318b-4541-960d-ae54ad416f2b	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:52.007+00
7b42cfe4-4b62-434a-97a0-a8f3a842db9f	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:52.012+00
897fe80c-5a01-46f1-bb3f-08ecd2d59665	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:52.017+00
f7363193-c960-4cf2-8336-2a8e4d5eaa74	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:52.721+00
0fa7c6b7-3c9e-4188-8674-52d08c75a6f1	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:52.724+00
d25362f6-1705-4cbb-80b2-1de603b5d2cb	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:52.726+00
3f053c9d-86cb-4cf0-b2e0-47419d825a42	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:53.411+00
9bb3dd93-2cb5-49e8-8100-3887313084af	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:53.415+00
e01e7b51-2fd8-4810-8e45-e9a10bf6da6b	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:53.44+00
95b5683b-d99d-4532-b0b8-fd1335a76fde	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:54.12+00
e135a5fb-cea9-4972-a675-357405838382	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:54.126+00
0d01efbc-1117-4017-8469-156db10267fe	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:54.138+00
62304fca-60af-481c-8286-615912f998e7	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:54.908+00
e27c8dbd-edbf-4ddc-b093-a4aca96edfbb	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:54.91+00
dd2386f9-9805-4b0a-9f82-9bd4e20bcfc6	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:54.919+00
bd48ae9e-6c3b-4655-a69e-4b7da2882bd3	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:55.555+00
482c9267-68ae-40c0-8230-27323c390c36	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:55.562+00
0ad9881f-6a35-420e-a5e1-3e4bb93c4683	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:55.564+00
61f4fdc3-0461-4a7f-820f-d2d294bfa674	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:56.247+00
ff215ea5-41f9-4ab2-8b84-89e7ed546e5f	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:56.25+00
fbab55ff-8b77-4bdc-9da6-a579ce1a5082	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:56.252+00
b2594b6f-7967-49a5-8232-1f476d28c0dc	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:57.214+00
f9c26e8a-be68-4924-9d16-d8f46e76fd35	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:57.217+00
fcea3809-e3e6-4c72-8551-08711771d1c5	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:57.219+00
422c520a-2c95-4b48-8c8e-935cb20862dc	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:57.871+00
fb27007e-92f6-4e03-8028-3e84a6d818c0	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:57.873+00
980bdc02-32cb-4361-8b46-12d8468f548d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:57.875+00
6b2f7419-cf41-4638-b5b6-83563831cc5e	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:58.675+00
5eb3c570-b920-46dc-921b-70bb130eccf1	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:58.679+00
f9089c9c-826d-4816-8941-5089ad9ee470	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:58.76+00
b181ffe7-aa48-4b94-9d78-4916d0f2b7b2	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:59.6+00
abdaac25-3d2c-46f9-bc08-45f26ae22efb	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:59.68+00
c69b871c-18e9-4546-b78b-91036b1e6306	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:50:59.707+00
e6e01417-0391-4118-801d-f0e99d4742d6	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:00.219+00
51caedec-9c56-495e-ac33-1ceb7cffb6c6	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:00.328+00
45ebbe46-1eab-47fa-8d11-187e830478e5	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:00.344+00
4a07ad35-e069-4c69-9429-386f3548394a	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:00.981+00
74d5a0ff-050a-45d7-8c07-acb67338226e	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:01.064+00
a3ff778e-569b-46f3-8873-c37b3b2dbc5a	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:02.477+00
030e3307-0f9d-4736-8686-9d653b4a88df	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:03.256+00
4958032d-b2a2-4568-adef-ec5d5e0c35bf	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:04.73+00
74dab9c1-7ab6-4d6b-a688-02b493134818	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:04.806+00
5a535ccb-ebae-4188-a54d-283937b30a6d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:05.376+00
d8342e42-9434-4c04-894b-5f00982bc299	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:06.093+00
efa67658-ca99-4d75-bf25-d015d24f031e	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:06.729+00
a20b1bec-361d-4f9c-b282-6807f42519e8	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 0 xkyox3me	80000	250000	3	\N	\N	\N	2026-03-27 02:51:48.665+00
5687f20c-e900-4066-ac8b-46eaef9d5641	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 1 qos2kcsm	81000	250000	4	\N	\N	\N	2026-03-27 02:51:49.93+00
8a5d6d93-1e6f-4ee7-a4fa-e5ed90797afb	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 1 7io1bf3q	81000	250000	4	\N	\N	\N	2026-03-27 02:51:49.936+00
1c99cc73-9779-4120-8aea-f39c42f5761c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 1 hknsflbp	81000	250000	4	\N	\N	\N	2026-03-27 02:51:50.063+00
59ff25ed-c014-440b-b680-a3e409843132	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 2 rlpjr6c2	82000	250000	5	\N	\N	\N	2026-03-27 02:51:51.571+00
6902246a-ac70-47d3-9481-75a7e93a20e4	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 2 hast9q6v	82000	250000	5	\N	\N	\N	2026-03-27 02:51:51.577+00
b01fbb14-f989-4089-bdd0-6abb66806724	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 2 m263t4l0	82000	250000	5	\N	\N	\N	2026-03-27 02:51:51.664+00
eb22a4a6-f07c-43fb-bddf-74f4b45d68b2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 3 h64okcpa	83000	250000	6	\N	\N	\N	2026-03-27 02:51:52.779+00
9eedd3da-0c62-49b2-aa6e-177aa25b276c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 3 221l39mn	83000	250000	6	\N	\N	\N	2026-03-27 02:51:53.19+00
1a6286c7-2a70-488c-8d8b-b06bbb9da825	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 3 nmn1mh2c	83000	250000	6	\N	\N	\N	2026-03-27 02:51:53.216+00
b77816e6-26f5-4d1c-a803-b97020128890	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 3 ti9uqrbt	83000	250000	6	\N	\N	\N	2026-03-27 02:51:53.308+00
b478d481-c481-45b5-88ea-55706a8a8c59	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 4 uu8z9tpw	84000	250000	7	\N	\N	\N	2026-03-27 02:51:53.664+00
02667f8f-993c-4486-bd59-3722392bdea5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 4 s12e4r5c	84000	250000	7	\N	\N	\N	2026-03-27 02:51:54.093+00
832c1361-3b86-4d0f-b1dd-98e2037f6b60	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 5 cqannpjk	85000	250000	3	\N	\N	\N	2026-03-27 02:51:54.208+00
2daf37d3-25b9-43be-9e58-ce8d3887f8fd	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 6 636dt93n	86000	250000	4	\N	\N	\N	2026-03-27 02:51:55.062+00
c3e4b9d8-e629-42bc-9d17-5670bacf7038	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 6 97thqk0t	86000	250000	4	\N	\N	\N	2026-03-27 02:51:55.153+00
38feb159-6f28-449a-a580-c71d86d342d4	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 7 u8xplzir	87000	250000	5	\N	\N	\N	2026-03-27 02:51:55.342+00
3d8f9f44-f7a7-4e92-bf82-566c1c128a23	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 8 fg9uy2ba	88000	250000	6	\N	\N	\N	2026-03-27 02:51:55.839+00
59d3eecc-4d16-4d55-8bd3-569f3fb7bcf8	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 8 jbl7e5wv	88000	250000	6	\N	\N	\N	2026-03-27 02:51:55.884+00
88bd11e5-39cc-4025-8c10-96d7c9005710	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 8 kyzw2xni	88000	250000	6	\N	\N	\N	2026-03-27 02:51:56.022+00
94dfd66f-a11f-4f34-b12d-c28baf706b8c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 8 w9zr7wb9	88000	250000	6	\N	\N	\N	2026-03-27 02:51:56.031+00
28d3c383-97b9-474a-a3c4-203ebea0767f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 9 xyckde2p	89000	250000	7	\N	\N	\N	2026-03-27 02:51:56.604+00
5b272124-1dc5-44e3-a490-5588b86412cd	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 9 oyqilqsd	89000	250000	7	\N	\N	\N	2026-03-27 02:51:56.7+00
27d7eded-71d7-461e-9b5a-b58aeb956be0	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 10 xqdluvf9	80000	250000	3	\N	\N	\N	2026-03-27 02:51:56.86+00
b7a00d4a-9ace-479a-b870-f646ef57341f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 10 uq3dqu3p	80000	250000	3	\N	\N	\N	2026-03-27 02:51:57.09+00
f3bbc01e-a531-42a7-a11c-1212c16b5fa9	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 11 0tmr4wd9	81000	250000	4	\N	\N	\N	2026-03-27 02:51:57.367+00
c4b44216-ac6a-4419-aeb0-1ae3deca84f5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 13 vvigmyoe	83000	250000	6	\N	\N	\N	2026-03-27 02:51:59.174+00
948e98e1-8f7f-48f9-8094-f17b21d12730	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 14 rdj0daho	84000	250000	7	\N	\N	\N	2026-03-27 02:51:59.466+00
8ef1dd44-40ae-4695-b217-873c5154134d	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 14 0k8khu6g	84000	250000	7	\N	\N	\N	2026-03-27 02:51:59.62+00
96d95f0f-94a7-4e24-bac3-ce6e47fcacb0	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 14 qnoq5b03	84000	250000	7	\N	\N	\N	2026-03-27 02:51:59.913+00
0b7fbba5-f624-4718-8afc-c6207d850871	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 15 kol74sty	85000	250000	3	\N	\N	\N	2026-03-27 02:52:00.228+00
a84ac6bf-79a3-462c-b8de-9fb273a761dc	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 15 2gyr6e8k	85000	250000	3	\N	\N	\N	2026-03-27 02:52:00.301+00
dcf9ca7d-7572-493e-bf80-ba4eb7591f17	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 16 jhm1auum	86000	250000	4	\N	\N	\N	2026-03-27 02:52:02.063+00
0c5c68da-25e0-4ebd-9a22-fa3db3a7b0cc	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 16 p4wtr7h6	86000	250000	4	\N	\N	\N	2026-03-27 02:52:02.262+00
1b220a3f-bea4-48dd-a90f-d06fdffb864c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 16 kae1cvx9	86000	250000	4	\N	\N	\N	2026-03-27 02:52:02.268+00
b2cc104b-0c34-4f20-b95e-89b476600479	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 17 bxk3zy5b	87000	250000	5	\N	\N	\N	2026-03-27 02:52:02.359+00
1e182215-4c0d-4e30-bcb7-1ad09ca3f5e4	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 17 9qv32503	87000	250000	5	\N	\N	\N	2026-03-27 02:52:04.045+00
cfceb509-f59a-468c-8ce6-ed37a10565dd	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 18 ryiqm4e8	88000	250000	6	\N	\N	\N	2026-03-27 02:52:04.17+00
417e80fa-2202-4cfc-8fd5-cdc689203d64	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 20 p3ncsj4y	80000	250000	3	\N	\N	\N	2026-03-27 02:52:05.596+00
8d5eebe3-c4a9-4f10-836b-cfb9003aa1d8	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 20 qt9cqrhy	80000	250000	3	\N	\N	\N	2026-03-27 02:52:05.795+00
dae25a10-1e7b-45c1-82ee-156f131ce77d	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 21 xxurap66	81000	250000	4	\N	\N	\N	2026-03-27 02:52:06.312+00
b8ee0fc7-0a42-4e64-a729-ce806a1fbdbd	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 21 cs0avykp	81000	250000	4	\N	\N	\N	2026-03-27 02:52:06.363+00
3b8a14ff-373f-4411-9e60-e431fb5bbb99	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 21 bc73r9c3	81000	250000	4	\N	\N	\N	2026-03-27 02:52:06.516+00
4c8ff4ec-172a-4187-a8c2-4394cdaca614	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 21 tqugagjt	81000	250000	4	\N	\N	\N	2026-03-27 02:52:06.694+00
a00fad88-02c2-4b9c-a3cd-ab38287e0477	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 22 2qtuccux	82000	250000	5	\N	\N	\N	2026-03-27 02:52:06.868+00
847deb4c-4eaf-41b3-b3f5-56eabb85ce8b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 22 3ixlkezd	82000	250000	5	\N	\N	\N	2026-03-27 02:52:06.963+00
0273cbf5-7cfc-4324-9298-abc4c14be992	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 22 36dlrblq	82000	250000	5	\N	\N	\N	2026-03-27 02:52:07.198+00
e796c54e-a88a-4a62-8be5-5975dfd41e75	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 23 frxgommf	83000	250000	6	\N	\N	\N	2026-03-27 02:52:07.201+00
d49d7808-cc86-43fd-86dc-498ae77ea412	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 24 e2jdq6zu	84000	250000	7	\N	\N	\N	2026-03-27 02:52:07.702+00
082327ba-cebd-4af4-b7b9-a4a439d4842b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 23 cydoypno	83000	250000	6	\N	\N	\N	2026-03-27 02:52:07.705+00
81ab0955-29c3-4c20-99bc-b52f08258ad5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 24 34zhtpwk	84000	250000	7	\N	\N	\N	2026-03-27 02:52:08.022+00
8046f85d-3218-4621-9f28-68215596fd8e	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 24 kgxofyk0	84000	250000	7	\N	\N	\N	2026-03-27 02:52:08.164+00
3634f694-caf8-4099-bc91-678edad5dcd0	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 25 jxtw8rk6	85000	250000	3	\N	\N	\N	2026-03-27 02:52:08.186+00
b8ab39de-11fb-432b-8ae6-cd74e2e3f9a7	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 26 xkop0qbg	86000	250000	4	\N	\N	\N	2026-03-27 02:52:08.878+00
07659775-4247-4735-a07b-c6d490f10b75	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 26 zx9o1nl9	86000	250000	4	\N	\N	\N	2026-03-27 02:52:09.191+00
efe8fe4f-a8b8-4ccf-808a-235108b3526f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 26 pj4dwvd3	86000	250000	4	\N	\N	\N	2026-03-27 02:52:09.41+00
21be2f66-3cec-4ecb-a422-edb090dbc98f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 27 aybi3xdx	87000	250000	5	\N	\N	\N	2026-03-27 02:52:09.448+00
32bdfdce-202c-4164-8f18-3c68b1ac42f7	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 27 6e2adqd2	87000	250000	5	\N	\N	\N	2026-03-27 02:52:09.899+00
1046df0e-c2fb-4364-804c-da93c455daf1	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 29 n1cu1njg	89000	250000	7	\N	\N	\N	2026-03-27 02:52:11.759+00
51767f77-ec60-47bd-8d3e-8efed0634d01	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 30 gqiewrfy	80000	250000	3	\N	\N	\N	2026-03-27 02:52:12.46+00
1adfbb96-ef47-4dbd-9b41-6a82f4983187	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 31 0cgjfoeu	81000	250000	4	\N	\N	\N	2026-03-27 02:52:12.666+00
047d6fe0-ef0e-4bbb-8e7a-73104ae04479	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 31 ad7fugmt	81000	250000	4	\N	\N	\N	2026-03-27 02:52:12.671+00
5fc71a5d-a0b7-4c72-8a56-cd8d00dbe634	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:01.066+00
29fa793b-74ea-4c3f-92d8-b9a6a615e50b	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:02.474+00
2472b2b7-6de4-4698-aaf1-d805179c5bac	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:05.453+00
42c7c1cc-265b-455b-a3a0-a6495162f122	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:06.694+00
2c87002b-c247-49c2-8afc-313f075ec0d4	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:06.732+00
a03c5d74-4c8d-4a3b-bbf4-8a1dc2d307f7	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 0 q10zexqj	80000	250000	3	\N	\N	\N	2026-03-27 02:51:48.612+00
eb5f4a31-9b9e-43b0-bf51-e26a65ffb62d	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 0 nhzeotd2	80000	250000	3	\N	\N	\N	2026-03-27 02:51:48.676+00
d59e9156-930e-4386-a4bf-803f884f0312	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 0 awss8y0c	80000	250000	3	\N	\N	\N	2026-03-27 02:51:48.876+00
f4c80bfa-b2a8-41e5-ace4-6e0df889e8df	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 1 e3zgy4eu	81000	250000	4	\N	\N	\N	2026-03-27 02:51:49.932+00
16bbf463-b9c5-4c05-aa9b-3cde84be0a5f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 4 66wqe5d7	84000	250000	7	\N	\N	\N	2026-03-27 02:51:53.47+00
fae8b41c-a6bb-49a1-86b8-02c4f4787716	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 4 6gd6ngha	84000	250000	7	\N	\N	\N	2026-03-27 02:51:54.095+00
1058151c-0941-4971-bb72-a37f146c2fd1	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 5 al0p8mf5	85000	250000	3	\N	\N	\N	2026-03-27 02:51:54.261+00
4b5c5d75-662c-45e5-9d7b-35ab468a2c56	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 5 sxeztilg	85000	250000	3	\N	\N	\N	2026-03-27 02:51:54.36+00
0698d1ea-04ce-4e3b-b7a9-54406b6ad233	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 6 v6n5772s	86000	250000	4	\N	\N	\N	2026-03-27 02:51:54.81+00
de78efb7-a761-4c94-9109-08df2dbeba45	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 6 842bm7za	86000	250000	4	\N	\N	\N	2026-03-27 02:51:54.898+00
7c4897a1-6bfc-4354-9e26-cc75835e8001	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 7 la05yqto	87000	250000	5	\N	\N	\N	2026-03-27 02:51:55.563+00
9a6fe640-4bac-4c15-badc-f72ec4d88423	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 7 iulh6yad	87000	250000	5	\N	\N	\N	2026-03-27 02:51:55.582+00
45ebbb6d-bbd3-4a4f-a690-278988c7abf8	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 9 dq9i6v51	89000	250000	7	\N	\N	\N	2026-03-27 02:51:56.425+00
6b583674-01f5-468b-86b6-64394260f32f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 9 gfo4lh64	89000	250000	7	\N	\N	\N	2026-03-27 02:51:56.601+00
2606fd9a-2e2c-4b02-b9d1-91fd23cf6b45	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 9 5qhtr1h6	89000	250000	7	\N	\N	\N	2026-03-27 02:51:56.705+00
8119460e-d9ed-432e-9363-dede4518434b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 11 2mcahrij	81000	250000	4	\N	\N	\N	2026-03-27 02:51:57.371+00
63082d57-6f69-46d7-b2e3-f3d65e2f9316	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 11 tfehjkxa	81000	250000	4	\N	\N	\N	2026-03-27 02:51:57.568+00
1f4d251b-4aae-4f48-8c98-0f6cfd8a8df7	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 11 zsduxsrw	81000	250000	4	\N	\N	\N	2026-03-27 02:51:57.799+00
5a631e34-8b97-4bbe-b4fb-5c05ccae3579	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 11 ombiq0yu	81000	250000	4	\N	\N	\N	2026-03-27 02:51:57.88+00
78368fd8-040a-4d2e-994f-014e4fca8516	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 12 qbj8zl07	82000	250000	5	\N	\N	\N	2026-03-27 02:51:57.989+00
94c504c5-efcc-4747-8154-f67a160a8ab2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 12 87gepfc6	82000	250000	5	\N	\N	\N	2026-03-27 02:51:58.365+00
b21efe4a-bf42-446a-94a1-7c8fa84a91e1	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 13 hvc5u1eu	83000	250000	6	\N	\N	\N	2026-03-27 02:51:58.566+00
4e93ac4c-fa10-413f-bb7a-1d3136d203d2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 13 baqlv8iz	83000	250000	6	\N	\N	\N	2026-03-27 02:51:58.57+00
ff734b49-e181-4268-824d-8492bf610452	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 13 hc34v93r	83000	250000	6	\N	\N	\N	2026-03-27 02:51:58.668+00
3adcade7-b673-4c87-bc85-df6071cec68d	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 14 22sihjqo	84000	250000	7	\N	\N	\N	2026-03-27 02:51:59.626+00
b6299ed4-dccd-4a08-939a-e8a2f715cb81	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 14 c7lna9nd	84000	250000	7	\N	\N	\N	2026-03-27 02:51:59.658+00
693eea92-70c9-4629-9bdd-1d2dd7f688d5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 14 gnjxl5a9	84000	250000	7	\N	\N	\N	2026-03-27 02:51:59.764+00
45145c9f-0d3d-4395-93c4-8992d6213ca6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 15 1zxve0sk	85000	250000	3	\N	\N	\N	2026-03-27 02:52:00.038+00
28b62b60-796e-4729-be62-ec616d731534	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 15 sfa6t5mi	85000	250000	3	\N	\N	\N	2026-03-27 02:52:00.307+00
b2681df4-6e53-4547-a83d-4bf2a0197196	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 15 cvrgicia	85000	250000	3	\N	\N	\N	2026-03-27 02:52:00.37+00
60c01b80-7242-4eca-b9c2-0f8ea923c1ca	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 16 vkuy3k94	86000	250000	4	\N	\N	\N	2026-03-27 02:52:01.768+00
a87333f4-4452-4d92-9733-b2012bb06525	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 16 942z4hjv	86000	250000	4	\N	\N	\N	2026-03-27 02:52:02.067+00
c4ed51b9-d5ce-449e-a0cf-50011dd0971c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 17 0966936y	87000	250000	5	\N	\N	\N	2026-03-27 02:52:03.078+00
97b94d6e-8d44-403e-8e70-2621f553d5e1	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 17 br2kmcyy	87000	250000	5	\N	\N	\N	2026-03-27 02:52:04.043+00
310f0ac8-f7a3-4742-8ef5-d055a2e0854f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 17 0bik257r	87000	250000	5	\N	\N	\N	2026-03-27 02:52:04.048+00
4460961d-b7bc-42ab-b1ff-78642488c9ea	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 17 1h2mrcxj	87000	250000	5	\N	\N	\N	2026-03-27 02:52:04.165+00
2830e412-b7e8-45f1-bb18-547ecb3c9c3a	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 18 ibam8ejl	88000	250000	6	\N	\N	\N	2026-03-27 02:52:04.269+00
373138a3-a320-45be-9a19-e60ac4f8a66d	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 18 fygd6crk	88000	250000	6	\N	\N	\N	2026-03-27 02:52:04.742+00
96a541c2-0a07-4507-bb28-4326f568dadc	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 18 lzmed3yi	88000	250000	6	\N	\N	\N	2026-03-27 02:52:04.802+00
436485f8-75f5-435e-9af6-241d25a9408b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 19 p75kq6yv	89000	250000	7	\N	\N	\N	2026-03-27 02:52:04.913+00
701ba643-7e54-46b5-befb-541a1ce5219e	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 19 ngqwhyvz	89000	250000	7	\N	\N	\N	2026-03-27 02:52:04.971+00
939db3fa-d988-4954-a440-53d8c78272f0	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 19 r9wg93h6	89000	250000	7	\N	\N	\N	2026-03-27 02:52:05.565+00
17405cd8-c5a4-482f-beba-95e0b6aaba16	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 20 1vfcid1x	80000	250000	3	\N	\N	\N	2026-03-27 02:52:05.864+00
bdf5498b-5812-41a3-a4a1-a3c07ca29e20	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 21 w4egbawc	81000	250000	4	\N	\N	\N	2026-03-27 02:52:06.092+00
8a0f6c41-f86c-4325-a199-6e21b87bb48f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 21 ak6jxvvw	81000	250000	4	\N	\N	\N	2026-03-27 02:52:06.104+00
a33fdcc6-31e1-4979-b388-55b2fcc49c4a	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 23 sw3mwxt5	83000	250000	6	\N	\N	\N	2026-03-27 02:52:07.2+00
02e1e345-c729-4733-a47d-ea47b759df12	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 23 sfipkkp3	83000	250000	6	\N	\N	\N	2026-03-27 02:52:07.364+00
5e8ee66d-1079-4411-a5c7-e7a6d49548c6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 24 mam75t9b	84000	250000	7	\N	\N	\N	2026-03-27 02:52:07.703+00
d98874aa-6026-4a63-b2c0-eed1cd29e914	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 24 9rwiinhu	84000	250000	7	\N	\N	\N	2026-03-27 02:52:07.893+00
a6ccb3f4-3e03-4d74-b490-42a8ed26bfac	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 25 46o13ihl	85000	250000	3	\N	\N	\N	2026-03-27 02:52:08.188+00
8cef47db-30a7-46e0-bd41-bdc9f7be2aac	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 25 gh3f23d2	85000	250000	3	\N	\N	\N	2026-03-27 02:52:08.371+00
7b641fc4-c5fa-4302-8840-b7d1f7ca8e66	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 25 sou1bzet	85000	250000	3	\N	\N	\N	2026-03-27 02:52:08.474+00
0c0f2b15-b49a-43fe-ae93-36a8c15feed6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 25 6qu50sxm	85000	250000	3	\N	\N	\N	2026-03-27 02:52:08.763+00
498bd055-fce7-44da-85eb-2640b2bb8511	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 26 k6h2p9wb	86000	250000	4	\N	\N	\N	2026-03-27 02:52:09.194+00
a5002a3e-53a3-4131-a190-cbf116c5357e	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 26 wtzw1uzb	86000	250000	4	\N	\N	\N	2026-03-27 02:52:09.296+00
f2618cae-2423-4822-9175-e69749fe9d4d	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 27 r233sxvs	87000	250000	5	\N	\N	\N	2026-03-27 02:52:09.45+00
0a6547e6-9926-4b69-9a42-978b63220c12	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 27 srn8ozj8	87000	250000	5	\N	\N	\N	2026-03-27 02:52:09.674+00
04470852-aa36-4218-9b7a-eddd8bea9cd4	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 27 4j9cjz9r	87000	250000	5	\N	\N	\N	2026-03-27 02:52:09.689+00
8afa2bc5-aebf-417d-8bd0-e1ecd070a3f1	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 28 vo2y9sl6	88000	250000	6	\N	\N	\N	2026-03-27 02:52:10.318+00
b142b099-f17c-4818-944a-3e581f0ac674	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 29 iww38f0z	89000	250000	7	\N	\N	\N	2026-03-27 02:52:10.867+00
7732e4ae-d456-467e-9dc1-296fc10185ec	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 29 inegc4tc	89000	250000	7	\N	\N	\N	2026-03-27 02:52:10.872+00
cb32f0ad-c987-45d8-ae8e-6feb8967a11c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 29 xctj0bx6	89000	250000	7	\N	\N	\N	2026-03-27 02:52:11.063+00
4f7996d6-fd57-4ef7-b471-2d2f1cfab784	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 29 hp55vs3f	89000	250000	7	\N	\N	\N	2026-03-27 02:52:11.066+00
f8a56880-7bd4-4069-93da-35ac246c0693	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 29 l51gb3yv	89000	250000	7	\N	\N	\N	2026-03-27 02:52:11.272+00
b7bbb313-33e0-4665-8eae-66cfe909e803	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 30 z3vky2uy	80000	250000	3	\N	\N	\N	2026-03-27 02:52:11.762+00
bcc93d22-ee5b-4cec-a059-f2cd198bebc8	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:02.479+00
0ceda1ec-5695-4c0b-8880-f0ed3f9e14ed	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:03.252+00
c70b5370-cf73-4747-92f0-cfb4635c8d8c	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:03.297+00
c191f1de-6969-4ef9-942b-2d232a9cfb5b	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:03.95+00
f0f6f4bc-3180-47df-9792-aeefb0818aba	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:04.013+00
83a1be70-171c-48ca-9720-d787d780715c	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:04.092+00
ba157fcf-67d8-4bf7-a979-c1ce643ff80d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:04.811+00
e3418ff7-49d5-4feb-ad42-47fe8884f725	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:05.451+00
3620aedf-a133-4939-9856-5e2b74f3191d	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:06.041+00
ec8ae1f4-bfc4-4964-b74a-529018f22082	8d510357-3cb0-4aaa-a263-3a09a582496c	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-27 02:51:06.091+00
7f804b17-7ee2-4907-b5d2-bbe2707e05a1	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 0 b365tf6e	80000	250000	3	\N	\N	\N	2026-03-27 02:51:48.666+00
abbcbcac-9921-4f03-a591-8e1561c163a3	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 0 vi6o36aq	80000	250000	3	\N	\N	\N	2026-03-27 02:51:48.682+00
1656eb45-fa3a-4350-9047-2bc1ebe854a6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 1 ifvhlmpn	81000	250000	4	\N	\N	\N	2026-03-27 02:51:49.935+00
cdf55e1a-38de-443b-a9ae-9449423ee091	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 1 a6hm9ftj	81000	250000	4	\N	\N	\N	2026-03-27 02:51:50.066+00
874c66d4-98ef-421f-9cba-ec518d4629b0	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 2 5veig1bd	82000	250000	5	\N	\N	\N	2026-03-27 02:51:51.297+00
1011cf3d-d066-4270-ac42-e24f99b6fab2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 2 zdx0meib	82000	250000	5	\N	\N	\N	2026-03-27 02:51:51.38+00
69b24b7f-bb60-496a-a630-eba5f482ca57	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 2 wknkycwl	82000	250000	5	\N	\N	\N	2026-03-27 02:51:51.574+00
c90de82d-af4b-4f6e-aad6-e3851c118652	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 3 4mlz3q79	83000	250000	6	\N	\N	\N	2026-03-27 02:51:52.775+00
850713fc-05ec-4876-b394-08bb5ff1c56f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 3 v2y9mkre	83000	250000	6	\N	\N	\N	2026-03-27 02:51:53.311+00
7c842055-f12c-4b80-a359-89e820ae9812	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 4 n4oo4fqe	84000	250000	7	\N	\N	\N	2026-03-27 02:51:53.468+00
871930f4-7128-4ab7-8542-cb9811435272	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 4 2ivo3443	84000	250000	7	\N	\N	\N	2026-03-27 02:51:53.765+00
53f3d169-78b1-42f1-8925-d977f92ba3c9	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 5 6bt786qc	85000	250000	3	\N	\N	\N	2026-03-27 02:51:54.307+00
865ec97b-fd6f-4aa1-91d9-8d72420a3697	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 5 vx2ay5i2	85000	250000	3	\N	\N	\N	2026-03-27 02:51:54.613+00
25b54a2d-1293-4fda-816c-a359dbcb4953	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 5 fu05lgot	85000	250000	3	\N	\N	\N	2026-03-27 02:51:54.69+00
1be4a9d6-1163-4423-966f-1051f02c7ba7	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 6 p80pfla7	86000	250000	4	\N	\N	\N	2026-03-27 02:51:54.84+00
f38ab4fa-dd90-435a-b6d5-0a6a25ed4128	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 6 lbh254hq	86000	250000	4	\N	\N	\N	2026-03-27 02:51:54.896+00
41a81dd7-d34a-4d66-8e14-4ead9bb1fe4f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 7 e90ourwn	87000	250000	5	\N	\N	\N	2026-03-27 02:51:55.344+00
77fda691-53a8-4aac-a6ca-b0ad221e5fdd	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 7 tzq0lhe2	87000	250000	5	\N	\N	\N	2026-03-27 02:51:55.424+00
368d4bbe-3a08-4e5b-881b-6f9eb9ad1c92	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 7 rouzqhkl	87000	250000	5	\N	\N	\N	2026-03-27 02:51:55.428+00
4b9ff24a-88b4-4c4a-89ec-6b8aea033ac3	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 8 3fbd3ixs	88000	250000	6	\N	\N	\N	2026-03-27 02:51:56.108+00
67b8b455-a657-4f2a-a8d5-ef02042dbb8c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 8 3v420k3l	88000	250000	6	\N	\N	\N	2026-03-27 02:51:56.166+00
65272d8e-a9b9-444f-89b6-6d9d0611e635	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 9 obh8zkv2	89000	250000	7	\N	\N	\N	2026-03-27 02:51:56.345+00
ad897831-4edd-436c-8543-911beb7dbbf0	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 10 dzub8c05	80000	250000	3	\N	\N	\N	2026-03-27 02:51:56.803+00
dddee993-bf18-4efe-8b57-87c101842fb6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 10 r8768alm	80000	250000	3	\N	\N	\N	2026-03-27 02:51:57.092+00
e0690ff8-8c1e-46cf-8bbf-0442c3c2a791	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 10 wo61s6b6	80000	250000	3	\N	\N	\N	2026-03-27 02:51:57.25+00
6c3a452d-3ebe-4efe-b742-dbc16d4c15e2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 10 98vh59w8	80000	250000	3	\N	\N	\N	2026-03-27 02:51:57.289+00
6b5ace34-f8ed-46dc-a117-01e1fef9e239	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 11 krsmk8sp	81000	250000	4	\N	\N	\N	2026-03-27 02:51:57.565+00
83981e45-f52e-43de-9d2b-ef8ffe3f724b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 12 a33wyk3l	82000	250000	5	\N	\N	\N	2026-03-27 02:51:57.992+00
38eed578-fdb6-4d5f-943a-0f6c7bc8ab28	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 12 0k5j56jr	82000	250000	5	\N	\N	\N	2026-03-27 02:51:58.04+00
44827ec1-ed2d-40d9-aa97-fa4f1a990512	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 12 u1zdhmum	82000	250000	5	\N	\N	\N	2026-03-27 02:51:58.052+00
9cc44731-2ae7-41a9-a5cc-9571924d15c6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 12 507dja22	82000	250000	5	\N	\N	\N	2026-03-27 02:51:58.225+00
a3ac4a03-3d3e-482e-aa34-ca103414bb1a	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 13 w6n998mz	83000	250000	6	\N	\N	\N	2026-03-27 02:51:58.564+00
ec016a24-906a-46c6-ac49-5b5ec0764653	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 13 f140cszl	83000	250000	6	\N	\N	\N	2026-03-27 02:51:58.771+00
9c0f8d8c-2a20-49ff-984c-50ab8b791e87	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 15 z5l53dvg	85000	250000	3	\N	\N	\N	2026-03-27 02:52:00.474+00
20790bf8-c0f3-4113-9222-0ae5d27577f5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 16 k0hyfdrc	86000	250000	4	\N	\N	\N	2026-03-27 02:52:00.772+00
f5966861-cbf2-4032-9d11-46ad212b20a2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 18 qcsyxmal	88000	250000	6	\N	\N	\N	2026-03-27 02:52:04.747+00
c81d6e4e-6240-4be6-ba4e-71a153557f90	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 18 5ml5wzm1	88000	250000	6	\N	\N	\N	2026-03-27 02:52:04.915+00
11134a35-49b0-44f4-8a87-8827a6bee32f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 19 84h99rp0	89000	250000	7	\N	\N	\N	2026-03-27 02:52:05.292+00
d4851d2e-f915-4844-8a31-d69e08493fc2	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 19 p9mp2sem	89000	250000	7	\N	\N	\N	2026-03-27 02:52:05.331+00
cc6b0f91-0fbd-4a61-94a3-43591796653c	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 19 ier3kw2m	89000	250000	7	\N	\N	\N	2026-03-27 02:52:05.427+00
2b035f41-bd7f-4a30-9111-4a46f173ef43	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 20 xakt4kcz	80000	250000	3	\N	\N	\N	2026-03-27 02:52:05.564+00
0ea4574b-2e3b-4cb6-8996-b5ab2ea8d48e	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 20 6aj8vlaz	80000	250000	3	\N	\N	\N	2026-03-27 02:52:05.73+00
069a6736-0260-4102-a7d0-837e2799327b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 20 todc0xbx	80000	250000	3	\N	\N	\N	2026-03-27 02:52:06.062+00
4e7e2c93-f840-47df-a2e9-810ecfe5a9cc	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 22 fbijzihc	82000	250000	5	\N	\N	\N	2026-03-27 02:52:06.697+00
fcdf7401-f8ea-4bcc-ab05-9871b9444c7b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 22 aubsd91e	82000	250000	5	\N	\N	\N	2026-03-27 02:52:06.704+00
e1063108-5778-47b2-b93f-11e37d55672e	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 22 w5kwjt9h	82000	250000	5	\N	\N	\N	2026-03-27 02:52:06.86+00
b7ca33fb-7769-448f-b5a9-300ce001a7ce	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 23 f9vy9ywr	83000	250000	6	\N	\N	\N	2026-03-27 02:52:07.386+00
629e28c3-8802-4a84-9d52-da0a519f43ec	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 23 omffv138	83000	250000	6	\N	\N	\N	2026-03-27 02:52:07.461+00
5ebb6b2e-136c-4e0c-b346-9327eee3dd93	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 24 o3ojq6mi	84000	250000	7	\N	\N	\N	2026-03-27 02:52:07.895+00
cc4cb9ca-9d74-484a-9bd3-af86d1199e10	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 25 o6j0qwiq	85000	250000	3	\N	\N	\N	2026-03-27 02:52:08.369+00
4c4b37ce-1f89-4f18-8932-3c1679a07bc4	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 26 mo1g64rz	86000	250000	4	\N	\N	\N	2026-03-27 02:52:08.88+00
522a8d2f-e7dc-43b4-a12e-2903bc187378	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 27 sxa5arto	87000	250000	5	\N	\N	\N	2026-03-27 02:52:10.145+00
e5ca4f4c-48b9-4eec-8f3c-dd18c076f794	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 28 xopgfyss	88000	250000	6	\N	\N	\N	2026-03-27 02:52:10.151+00
e9c119a2-27c1-43dd-8f8b-1c4ce36f66f6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 28 18vr2q8y	88000	250000	6	\N	\N	\N	2026-03-27 02:52:10.261+00
34facfe9-10c8-40d9-a84f-02cb0204c8f6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 28 s7jjgly4	88000	250000	6	\N	\N	\N	2026-03-27 02:52:10.32+00
454636ec-e6ac-4468-a1d3-0b6a2b2dcd04	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 28 exhygnx4	88000	250000	6	\N	\N	\N	2026-03-27 02:52:10.465+00
5899abe1-af02-45fc-bc39-c36def8f430a	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 28 kmug5f54	88000	250000	6	\N	\N	\N	2026-03-27 02:52:10.87+00
146f87d4-2e12-431b-a503-4959d3250030	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 30 4mo46dv7	80000	250000	3	\N	\N	\N	2026-03-27 02:52:11.668+00
8accc565-f039-466a-a6c8-e42993a8addd	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 30 ymu57vzg	80000	250000	3	\N	\N	\N	2026-03-27 02:52:11.915+00
aee32d7e-3156-4da5-93c2-d68fd4bc700b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 30 4dmt4w41	80000	250000	3	\N	\N	\N	2026-03-27 02:52:11.918+00
f0c43719-c874-4b2b-acd4-6debf717e56b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 30 srssbhyr	80000	250000	3	\N	\N	\N	2026-03-27 02:52:11.995+00
4c959831-e483-42bc-b7a3-921f8cbbcef5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 31 ysnl2a2b	81000	250000	4	\N	\N	\N	2026-03-27 02:52:12.229+00
c8f63b2f-c6cf-4473-a09c-6537f8ccd8ca	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 31 vlnvn7ux	81000	250000	4	\N	\N	\N	2026-03-27 02:52:12.364+00
8a235228-3d95-483e-a5bb-18d173813f64	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 31 q9sd1dsl	81000	250000	4	\N	\N	\N	2026-03-27 02:52:12.677+00
e524cff3-5e02-4898-8783-0da5dedde93b	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 32 meiojpwq	82000	250000	5	\N	\N	\N	2026-03-27 02:52:13.232+00
cba5f40f-88ff-4d78-a949-77232d73b9ae	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 32 rjbjxkbo	82000	250000	5	\N	\N	\N	2026-03-27 02:52:13.467+00
a1926084-898c-487d-9a12-50bcc6674346	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 33 gw6z9y7e	83000	250000	6	\N	\N	\N	2026-03-27 02:52:13.77+00
b4a33241-5165-4148-9365-ab2da3e18a7e	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 32 vb1vlix3	82000	250000	5	\N	\N	\N	2026-03-27 02:52:14.471+00
0beeb596-198f-4208-8fc1-5a0fd6fe58c8	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 34 2vgg1uig	84000	250000	7	\N	\N	\N	2026-03-27 02:52:15.215+00
b89bd6ad-f035-46ae-9a37-e01378799302	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 34 rbv8nttr	84000	250000	7	\N	\N	\N	2026-03-27 02:52:15.316+00
14eec228-7b5f-4443-b4f2-f61736a80611	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 0 kg0o82u6	80000	250000	3	\N	\N	\N	2026-03-27 03:03:50.458+00
c937281f-4e32-4982-8bd7-d1cce13c76c4	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 0 zyuzp41w	80000	250000	3	\N	\N	\N	2026-03-27 03:03:50.48+00
b43eb377-1b3f-416e-b996-320874dd011f	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 1 wyeracr3	81000	250000	4	\N	\N	\N	2026-03-27 03:03:52.358+00
0f34ba0a-13da-4794-8e09-e4b24226fa66	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 2 vnqowqol	82000	250000	5	\N	\N	\N	2026-03-27 03:03:53.535+00
afb72fc4-2a38-4d9f-8259-72b845466ab4	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 2 pdurgvcr	82000	250000	5	\N	\N	\N	2026-03-27 03:03:53.619+00
a958388f-8c94-4210-a741-24b4ee69a5e8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 2 yf9mp4q1	82000	250000	5	\N	\N	\N	2026-03-27 03:03:53.659+00
9dc1b48e-0be6-48b0-9af9-241229144641	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 2 ego3nu8y	82000	250000	5	\N	\N	\N	2026-03-27 03:03:53.666+00
114a1ae8-b38b-403f-8a5d-f2b950b66dc6	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 3 jhpzmgzk	83000	250000	6	\N	\N	\N	2026-03-27 03:03:55.882+00
cdcf2a6f-a806-4f3e-b27d-480925764e49	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 4 3fe5tqlh	84000	250000	7	\N	\N	\N	2026-03-27 03:03:56.395+00
f2456010-ee1c-4bdd-977e-09ea7262d0e7	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 4 5wzmsj6t	84000	250000	7	\N	\N	\N	2026-03-27 03:03:56.766+00
66108da6-305e-4672-8816-5b4097279524	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 6 3cm3350s	86000	250000	4	\N	\N	\N	2026-03-27 03:03:57.676+00
e00f46f8-b586-4b14-818d-891f722896b3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 6 jjo64pc0	86000	250000	4	\N	\N	\N	2026-03-27 03:03:58.18+00
e47ede9e-9fe4-4940-bed3-ad0f4dd2aa25	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 6 zvlqrxas	86000	250000	4	\N	\N	\N	2026-03-27 03:03:58.228+00
91774a71-3a5b-4ce0-b228-8921af611cdc	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 6 szfhaiut	86000	250000	4	\N	\N	\N	2026-03-27 03:03:58.233+00
98f621e3-caa8-4f1d-baae-ee5c0e41b7e9	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 7 ij2dzjmg	87000	250000	5	\N	\N	\N	2026-03-27 03:03:59.004+00
5fd9c5cb-f0e7-484d-a4c1-f46c2803cbe2	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 7 lsha148u	87000	250000	5	\N	\N	\N	2026-03-27 03:03:59.09+00
160e1adb-fbba-4a3a-9e5c-2d14768d0e3b	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 7 lps9rxdx	87000	250000	5	\N	\N	\N	2026-03-27 03:03:59.1+00
e3b3ac27-d908-4dc5-bcb2-b1bfc1c06f46	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 7 ej9t6d87	87000	250000	5	\N	\N	\N	2026-03-27 03:03:59.105+00
fbed7fa2-9575-434a-b632-0e5a4a946588	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 8 l1oagdv7	88000	250000	6	\N	\N	\N	2026-03-27 03:03:59.26+00
e4417999-33fa-4d64-bb23-9436f0683106	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 9 aup86zk4	89000	250000	7	\N	\N	\N	2026-03-27 03:04:00.668+00
1332d418-bafc-4e90-8016-958239e87249	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 10 bk74a4sn	80000	250000	3	\N	\N	\N	2026-03-27 03:04:00.768+00
a303a2cb-2798-47b0-b740-7d9750b3ed2d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 10 6jf7bjw0	80000	250000	3	\N	\N	\N	2026-03-27 03:04:01.569+00
760d3272-ea0d-4ac7-8290-dc832120bf2c	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 10 m1q8ejdn	80000	250000	3	\N	\N	\N	2026-03-27 03:04:01.964+00
dccd4a32-2d58-49b5-89e5-6a2ec57cf016	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 11 tqq87q0f	81000	250000	4	\N	\N	\N	2026-03-27 03:04:02.159+00
7b2c4820-bb5a-49e5-83c8-e0b1ccc1a2d5	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 11 8ha9xzan	81000	250000	4	\N	\N	\N	2026-03-27 03:04:02.667+00
288723f9-5291-40be-a6c2-dbf23cb500a9	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 11 t1wkd1wv	81000	250000	4	\N	\N	\N	2026-03-27 03:04:03.006+00
80d9bba4-8789-41d3-9bfc-c146feb4f661	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 12 pjo7m6l3	82000	250000	5	\N	\N	\N	2026-03-27 03:04:03.124+00
e11ee33e-1ecb-48d2-83cc-aed814cdfd98	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 12 wzbz53kn	82000	250000	5	\N	\N	\N	2026-03-27 03:04:03.265+00
ecb21e14-0feb-4b48-8aa2-103d90a8c984	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 13 gai3e93o	83000	250000	6	\N	\N	\N	2026-03-27 03:04:03.744+00
9cb90a63-bce0-4188-8f65-0bf89cf7b3d1	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 13 zyraaiue	83000	250000	6	\N	\N	\N	2026-03-27 03:04:03.869+00
077b7afa-6e20-4253-8b7a-4fabadef20c4	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 13 sk9xf484	83000	250000	6	\N	\N	\N	2026-03-27 03:04:04.131+00
3f2cbb3f-8a63-46ae-b30f-c3465909759d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 14 suo91lxp	84000	250000	7	\N	\N	\N	2026-03-27 03:04:04.485+00
4a2f98bd-4961-4784-9953-a79b694c4736	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 14 74cec22d	84000	250000	7	\N	\N	\N	2026-03-27 03:04:04.505+00
b1662e94-0e73-41f1-8879-f9ceb52b318a	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 14 u2oodi5x	84000	250000	7	\N	\N	\N	2026-03-27 03:04:04.601+00
865ff2d7-69aa-4f98-96d0-f61f2336596a	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 15 0kezsaru	85000	250000	3	\N	\N	\N	2026-03-27 03:04:05.051+00
7084dbbe-0b3b-463b-ae07-b7e70ae4e484	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 16 148ww87o	86000	250000	4	\N	\N	\N	2026-03-27 03:04:05.772+00
128ee598-c74c-4b93-9adb-cbb57d4bdb96	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 16 4leli5sg	86000	250000	4	\N	\N	\N	2026-03-27 03:04:05.991+00
1ca3148c-1210-4f60-a3d1-72851dd54f7d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 16 4psify80	86000	250000	4	\N	\N	\N	2026-03-27 03:04:06.772+00
f39e35bb-60ee-4dd2-9406-7edb19b5fc5a	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 17 zefrrxna	87000	250000	5	\N	\N	\N	2026-03-27 03:04:08.722+00
2ccf711b-01cf-44d5-b356-7e82341b622e	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 17 ug6wktsn	87000	250000	5	\N	\N	\N	2026-03-27 03:04:08.905+00
9f733eff-20b5-4c23-aaad-77e94af86644	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 17 4jvwc8jo	87000	250000	5	\N	\N	\N	2026-03-27 03:04:08.911+00
00755b0d-5556-4940-ba2a-0c2d19048e61	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 18 k2iz0em5	88000	250000	6	\N	\N	\N	2026-03-27 03:04:09.091+00
ae4e8115-5540-424e-a30f-fc98ab4de243	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 19 30pimgn5	89000	250000	7	\N	\N	\N	2026-03-27 03:04:09.769+00
010baeb9-e826-4023-a3c5-12275d7c1a6a	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 20 vv6kq85r	80000	250000	3	\N	\N	\N	2026-03-27 03:04:10.288+00
a816ba82-6af0-456b-a2c8-e34c6a1a9850	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 21 kazwbj67	81000	250000	4	\N	\N	\N	2026-03-27 03:04:11.27+00
28695712-9a9e-4e83-a7e1-1b28e014e673	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 22 al5wz0kt	82000	250000	5	\N	\N	\N	2026-03-27 03:04:13.174+00
49f82ad5-8585-4eb2-a9ed-9a53cc4a0ac0	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 23 r455aoyl	83000	250000	6	\N	\N	\N	2026-03-27 03:04:13.261+00
f10fa501-8f11-45f8-9eb9-141dce9b184d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 23 vb9tgyji	83000	250000	6	\N	\N	\N	2026-03-27 03:04:14.162+00
55a27e88-690c-48e6-b37e-ae3b1cac47ae	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 24 gp8j559o	84000	250000	7	\N	\N	\N	2026-03-27 03:04:15.164+00
5ae95caf-b4b0-4e8e-8adf-f4da54fbdd70	ef99fff9-f1d0-4a77-be7d-681e81d15332	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-27 03:12:40.711+00
f81be54f-98f6-41e0-8af9-fa2d88bd04ca	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 32 1gkjt2q1	82000	250000	5	\N	\N	\N	2026-03-27 02:52:13.31+00
8b8e58da-2d98-4cb5-a0f1-0393fe13f724	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 32 606lcdjm	82000	250000	5	\N	\N	\N	2026-03-27 02:52:13.471+00
ca567828-b04f-4805-8cba-83c49303c6d6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 33 37ok4zen	83000	250000	6	\N	\N	\N	2026-03-27 02:52:14.608+00
e2558a27-20da-4abc-bf21-1cb54f09c9e6	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 33 9lajyguj	83000	250000	6	\N	\N	\N	2026-03-27 02:52:14.662+00
85512836-ccff-44ed-b3dd-acbe18735044	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 33 0otum77p	83000	250000	6	\N	\N	\N	2026-03-27 02:52:15.217+00
46520273-9403-42ea-8ac2-edd2c5a3f136	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 35 3pbg9xdu	85000	250000	3	\N	\N	\N	2026-03-27 02:52:16.094+00
d1ec8e05-062d-47ea-acb0-78f871355759	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 36 1ck3cnzp	86000	250000	4	\N	\N	\N	2026-03-27 02:52:16.164+00
4b120962-cffa-46b8-acbc-938e5d6251f5	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 35 5uiw5uv8	85000	250000	3	\N	\N	\N	2026-03-27 02:52:16.169+00
3ddc74c1-ea9d-47b5-b0a2-4f353864a332	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 3 gxlbeqim	83000	250000	6	\N	\N	\N	2026-03-27 03:03:55.877+00
f3136b55-f380-4689-864e-63d61bf1eb48	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 4 6zzj5xuo	84000	250000	7	\N	\N	\N	2026-03-27 03:03:56.397+00
6c54ad7a-84d7-47ca-9b49-f91c96ebb4d8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 4 fz8r1fer	84000	250000	7	\N	\N	\N	2026-03-27 03:03:56.689+00
0f865c01-4b65-4aaf-85a0-3e99b57a8d88	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 6 g3bv5ao0	86000	250000	4	\N	\N	\N	2026-03-27 03:03:58.23+00
f93d08dc-d0d8-4b35-a8a4-6fa358768608	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 7 ztk98pp0	87000	250000	5	\N	\N	\N	2026-03-27 03:03:58.564+00
13985c56-2d45-461c-afa8-7a6483da6cf2	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 8 ez7wdeuz	88000	250000	6	\N	\N	\N	2026-03-27 03:03:59.261+00
fdb48ecf-b0f1-49fa-a9f2-2031b6483e98	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 8 fr1vijs4	88000	250000	6	\N	\N	\N	2026-03-27 03:03:59.605+00
2c0428ac-f97b-4568-81b5-4603bdda2aa9	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 8 ggkj8q3m	88000	250000	6	\N	\N	\N	2026-03-27 03:03:59.695+00
7d889dd3-c0dc-4d5e-9321-0ea3e33e28b0	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 8 254ejdvb	88000	250000	6	\N	\N	\N	2026-03-27 03:03:59.706+00
3be81978-6ce9-4889-8f3e-5349b8f72f72	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 9 qtkexkpu	89000	250000	7	\N	\N	\N	2026-03-27 03:03:59.9+00
8f42a63c-2314-4e06-bd61-f3e76c3c0b9c	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 9 5zhauib5	89000	250000	7	\N	\N	\N	2026-03-27 03:04:00.079+00
dc2fb05a-78c8-4289-befa-91f7b600602d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 9 4cso1gb0	89000	250000	7	\N	\N	\N	2026-03-27 03:04:00.525+00
264575fe-6fae-43a3-a928-013577fae3c8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 10 s8u458yr	80000	250000	3	\N	\N	\N	2026-03-27 03:04:00.671+00
becdcaea-5d5e-42d7-a46b-eeab25c90836	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 10 w2wm70am	80000	250000	3	\N	\N	\N	2026-03-27 03:04:00.86+00
fcfdc6c2-cb59-424a-a7d6-f7f824fdd53f	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 11 9u0hcv0r	81000	250000	4	\N	\N	\N	2026-03-27 03:04:02.669+00
805397c9-1eb5-4ccb-9476-41d81803a3bc	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 12 uj80j5y8	82000	250000	5	\N	\N	\N	2026-03-27 03:04:03.114+00
9d969216-8962-4b98-9295-b0bb6ca420af	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 12 3n46iaxl	82000	250000	5	\N	\N	\N	2026-03-27 03:04:03.122+00
0540e415-26d8-4b68-b726-843f7b967d01	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 12 cg1jbh93	82000	250000	5	\N	\N	\N	2026-03-27 03:04:03.264+00
5e9452d8-860c-4fbf-a9d9-f7c03f034447	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 12 xa6ezxa0	82000	250000	5	\N	\N	\N	2026-03-27 03:04:03.508+00
93d839ab-a74a-46a8-b2a7-3f744de0c0e2	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 13 5tl0sr8f	83000	250000	6	\N	\N	\N	2026-03-27 03:04:03.741+00
885ef87d-fa90-479b-b4fc-e09937f1b407	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 13 qluru9l4	83000	250000	6	\N	\N	\N	2026-03-27 03:04:03.944+00
a5fb46cc-eaf0-4400-b25c-90f870f7af2e	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 14 k2rhenim	84000	250000	7	\N	\N	\N	2026-03-27 03:04:04.507+00
8df9a779-250a-4599-91e8-ebfbf6526734	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 14 nq2b93r6	84000	250000	7	\N	\N	\N	2026-03-27 03:04:04.645+00
124b12fc-2c2d-4b09-8854-8a9695881b32	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 15 9rmanuok	85000	250000	3	\N	\N	\N	2026-03-27 03:04:04.967+00
9eb82742-f9e6-435c-85eb-c98de141d907	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 15 lscqohzi	85000	250000	3	\N	\N	\N	2026-03-27 03:04:05.314+00
13606597-71e4-49c8-bd5d-8d1bf872ec5e	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 16 pl8dgwmv	86000	250000	4	\N	\N	\N	2026-03-27 03:04:06.82+00
5ffcbf36-29ed-411c-94df-cca76b5cf5fd	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 17 vwyk9a7w	87000	250000	5	\N	\N	\N	2026-03-27 03:04:06.905+00
79135c70-5632-48c1-9185-a1259c4a4765	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 17 lb662i7f	87000	250000	5	\N	\N	\N	2026-03-27 03:04:06.921+00
4ad93e32-9671-4d35-a591-8cdbbf7d0de0	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 17 gjjruxmf	87000	250000	5	\N	\N	\N	2026-03-27 03:04:07.262+00
b674825f-a7c8-4118-b918-3fbeb831d8c3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 18 sog53eiu	88000	250000	6	\N	\N	\N	2026-03-27 03:04:09.094+00
a6e8aa70-ae80-49cb-8e3c-d7d9ef970852	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 18 i11fk95l	88000	250000	6	\N	\N	\N	2026-03-27 03:04:09.521+00
18da5504-8d4b-4102-a5d8-215bace80dc1	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 19 9b8wsihl	89000	250000	7	\N	\N	\N	2026-03-27 03:04:09.645+00
643c3fed-0883-45c2-90b2-b20eda73f37d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 19 2upd8spr	89000	250000	7	\N	\N	\N	2026-03-27 03:04:09.702+00
27a50e45-f769-4206-84e3-acd99968a01b	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 19 sufdtthn	89000	250000	7	\N	\N	\N	2026-03-27 03:04:09.985+00
c148f384-dbcf-4d07-aa40-e7d5e66672d3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 20 d169vb44	80000	250000	3	\N	\N	\N	2026-03-27 03:04:10.108+00
ed3d3f6c-ac51-4fdc-87d6-c4f359c9205c	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 21 zqdfnxeq	81000	250000	4	\N	\N	\N	2026-03-27 03:04:12.056+00
f2e977de-a957-4b57-8120-da4f231868d4	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 22 rbru5yst	82000	250000	5	\N	\N	\N	2026-03-27 03:04:13.172+00
28b09354-6a6d-489f-b25b-c5434f3e1b19	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 23 4cabbayz	83000	250000	6	\N	\N	\N	2026-03-27 03:04:13.465+00
fdc720f2-bd7a-43b0-b698-6373c26e4665	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 24 710j2gca	84000	250000	7	\N	\N	\N	2026-03-27 03:04:14.368+00
ca529565-9610-4546-acd0-3b2a9e5cabf8	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 24 gs9x2u22	84000	250000	7	\N	\N	\N	2026-03-27 03:04:14.484+00
ead127cb-87ca-4a80-a053-00882a6c0d66	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 31 sx9283zn	81000	250000	4	\N	\N	\N	2026-03-27 02:52:13.312+00
b76c6beb-14d3-4aaa-9d23-4890be963c53	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 32 p324j1lb	82000	250000	5	\N	\N	\N	2026-03-27 02:52:13.463+00
a4669e54-434d-4118-9472-ea722d1a0894	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 33 6rjwszsm	83000	250000	6	\N	\N	\N	2026-03-27 02:52:14.469+00
b3848e99-9938-4a13-a01a-26857f2d76a3	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 33 fugsr6rc	83000	250000	6	\N	\N	\N	2026-03-27 02:52:14.57+00
d16d1545-3390-42b6-b6a5-3005d5e5cb8f	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 34 leuk737u	84000	250000	7	\N	\N	\N	2026-03-27 02:52:14.733+00
f971d765-a16f-485e-b596-b10270ed5497	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 34 4ve7t2yg	84000	250000	7	\N	\N	\N	2026-03-27 02:52:15.302+00
deb00f15-40c0-467f-8511-eab65a4ee23a	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 34 rb4h6o7m	84000	250000	7	\N	\N	\N	2026-03-27 02:52:15.461+00
bf519284-2814-4184-ae1b-3668134a3423	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 35 rmrdykb8	85000	250000	3	\N	\N	\N	2026-03-27 02:52:15.466+00
a93d9c43-f29e-449f-a194-868e1df45c27	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 34 6nw9di4a	84000	250000	7	\N	\N	\N	2026-03-27 02:52:16.003+00
ca5b2852-68f5-4ffa-905b-98d27ac92dd3	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 35 cufracuh	85000	250000	3	\N	\N	\N	2026-03-27 02:52:16.02+00
f1006035-7997-419e-ba91-3cda89f19377	f0cbd21e-f352-4890-8b93-c69e8344d22f	k6 search 35 1fk728dy	85000	250000	3	\N	\N	\N	2026-03-27 02:52:16.027+00
575cece4-97ea-4528-a01b-5fa2f8f76521	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 20 pf1w4xdt	80000	250000	3	\N	\N	\N	2026-03-27 03:04:10.86+00
2189a743-88d6-4b8d-b8a1-0d96980d6758	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 21 ayprls6c	81000	250000	4	\N	\N	\N	2026-03-27 03:04:11.561+00
90887bf5-7183-4252-8b8b-a6c181989f2d	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 21 v62bl3y0	81000	250000	4	\N	\N	\N	2026-03-27 03:04:11.777+00
2e4c5f8d-2888-4b4e-b242-af6554317213	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 21 286w3our	81000	250000	4	\N	\N	\N	2026-03-27 03:04:11.778+00
53786a6c-84d3-42c8-83e2-3f6871653eed	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 21 xnedeo4x	81000	250000	4	\N	\N	\N	2026-03-27 03:04:12.064+00
cf094f21-df73-4c9d-bd00-784144ccc1ff	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 22 f71e1alz	82000	250000	5	\N	\N	\N	2026-03-27 03:04:12.268+00
fe93cde9-e0e4-402b-aafb-18b1550f5cc3	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 22 mvwzg27h	82000	250000	5	\N	\N	\N	2026-03-27 03:04:12.762+00
0049e413-d9e5-4ec2-9871-49f949f9ed02	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 22 s9y5xf4i	82000	250000	5	\N	\N	\N	2026-03-27 03:04:13.074+00
a6b99e60-13cc-4e4f-b468-75af0941b491	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 22 n9wurgdo	82000	250000	5	\N	\N	\N	2026-03-27 03:04:13.103+00
ebcf08bb-e41a-416b-994b-07e1fdfdd573	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 23 p41ff2re	83000	250000	6	\N	\N	\N	2026-03-27 03:04:13.981+00
2ac83869-7496-42ef-ab94-e08ca80c0ea2	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 23 tmrcxf7j	83000	250000	6	\N	\N	\N	2026-03-27 03:04:14.16+00
50e41484-0302-403d-8c92-2f299a2c5a1a	6082b8c3-ea19-4184-a121-b42039f8e52a	k6 search 23 6v2kuxd3	83000	250000	6	\N	\N	\N	2026-03-27 03:04:14.165+00
\.


--
-- Data for Name: watchlist_items; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.watchlist_items (id, user_id, listing_id, source, added_at, removed_at, is_active) FROM stdin;
36eb6068-3772-46f1-a908-ec974297f668	c2ac34e6-ba60-4ccf-b9d5-dbb06aa31785	11111111-1111-1111-1111-111111111111	search	2026-03-20 16:37:21.244+00	\N	t
1c83378d-43d7-47e2-ba91-35d143b18d4d	f872a417-3409-4bd0-bf41-c7129108554e	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-22 19:25:11.572+00	2026-03-22 19:25:12.127+00	f
6a5e9566-7a76-4508-b7ba-f3c49ec9923b	ed711d1f-2108-4fbc-bf9c-f915dc2d4c36	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 15:12:41.331+00	2026-03-23 15:12:41.548+00	f
cf927202-145e-4f1a-8194-6c9558f02885	958e471b-aa70-4374-a38d-8544ee85b5fc	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-22 20:20:57.263+00	2026-03-22 20:20:58.182+00	f
44233e3d-9808-4cce-b163-04ee8705c317	a4a667b1-c43a-4092-a0d1-a437172faa7a	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-22 23:18:12.469+00	\N	t
f0d04c62-be38-4576-bcb7-0ac63872d93a	9e72c822-2ee5-46aa-89cc-3f982efa2929	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 17:22:48.23+00	2026-03-23 17:22:48.556+00	f
6b0351ba-19da-48c4-9521-763602ab1fa9	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-23 19:19:29.602+00	2026-03-23 19:19:31.221+00	f
3b555d3b-8761-43dd-9847-889dd94abdda	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 19:19:23.985+00	2026-03-23 19:19:24.419+00	f
ceef0f6f-8d3b-4025-886d-4342ed8859a6	1e25e645-6ec0-4975-b099-de6b5d40e7d4	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 00:33:09.926+00	2026-03-23 00:33:10.266+00	f
c5ab23c3-b3dd-4913-bd2d-42d3cd405949	1e25e645-6ec0-4975-b099-de6b5d40e7d4	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-23 00:33:11.86+00	2026-03-23 00:33:12.46+00	f
e058bc77-b44c-46a5-972e-e8d2eb8eb5b1	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-23 19:19:24.935+00	2026-03-23 19:19:25.246+00	f
82e54085-f1c0-4efe-a309-fffe322151ce	1e25e645-6ec0-4975-b099-de6b5d40e7d4	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-23 00:33:13.057+00	\N	t
7ea2f755-c85f-4787-91ad-8b5a7a13dcba	d9c4b3a1-4517-459b-8e71-416b6f3a0df7	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 00:34:09.131+00	2026-03-23 00:34:09.717+00	f
64b35e6d-7f43-42d6-999a-cba8d232dd25	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-23 19:19:25.58+00	2026-03-23 19:19:26.003+00	f
fa1fba26-3381-48a9-957b-e4b7b0abc4c9	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-23 19:19:31.519+00	2026-03-23 19:19:33.108+00	f
f150b19c-c7ad-4d5b-93a3-10961b6e7088	322c881d-0e5b-4c58-a8d9-131b5358b8fb	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 03:34:51.986+00	2026-03-23 03:34:52.357+00	f
b95a1142-fdcd-421e-843f-7927553f2a72	322c881d-0e5b-4c58-a8d9-131b5358b8fb	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-23 03:34:53.058+00	\N	t
1e2ba602-0086-4e36-bf44-c268d15a2947	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-23 19:19:35.387+00	2026-03-23 19:19:36.607+00	f
2fc5580d-3f70-4093-b5bb-b22f5b0214c0	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-23 19:19:26.407+00	2026-03-23 19:19:27.509+00	f
b4f8cb78-043f-4516-802f-ed5d00ddfe29	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-23 19:19:27.723+00	2026-03-23 19:19:29.507+00	f
7b18599b-cee6-48f1-9586-de7a922fd34a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-23 19:19:33.218+00	2026-03-23 19:19:34.309+00	f
739e1162-6e74-4a6a-96e7-136d0bf49c31	893699ca-346f-4aab-bf83-f51809169543	11111111-1111-1111-1111-111111111111	k6	2026-03-20 16:42:36.072+00	2026-03-20 16:42:54.468+00	f
62c3e505-b1aa-4d88-bd1a-36c1c4243c51	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-23 19:19:36.309+00	2026-03-23 19:19:37.607+00	f
3fc78955-a69e-4540-9d70-07b33720bf0a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-23 19:19:40.804+00	2026-03-23 19:19:41.62+00	f
c3572da0-dda8-424d-a894-2d5c221dd39d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-23 19:19:34.218+00	2026-03-23 19:19:35.491+00	f
925f3b8f-8037-4488-af17-02e5bf05fcfc	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-23 19:19:37.509+00	2026-03-23 19:19:38.307+00	f
c02e6da7-efe0-4235-8011-027d1f05491c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-23 19:19:39.586+00	2026-03-23 19:19:39.993+00	f
87bf34e5-81f0-405e-86cf-2a29b86e7f06	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	11111111-1111-1111-1111-111111111111	k6	2026-03-23 17:21:30.623+00	2026-03-23 17:21:54.619+00	f
169d1ded-fbd6-42ae-8b51-60cfc47ac3ed	74f8a205-4f43-4666-b5de-9d6c5da4edac	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 17:21:56.412+00	\N	t
8923c06b-4da2-438b-8e30-41c65f7d8cd8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	11111111-1111-1111-1111-111111111111	k6	2026-03-20 16:40:43.448+00	2026-03-20 16:40:50.29+00	f
7f2d217f-2c0f-4a75-aa3a-ad56d4fb91b0	74f8a205-4f43-4666-b5de-9d6c5da4edac	11111111-1111-1111-1111-100000000076	k6-search-watchlist	2026-03-23 17:22:23.414+00	2026-03-23 17:22:24.128+00	f
67c1b880-7806-4151-8149-c9e42aa028c9	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-23 19:19:38.405+00	2026-03-23 19:19:39.401+00	f
7e0338e3-738d-4d7c-90d1-a004f88d6975	74f8a205-4f43-4666-b5de-9d6c5da4edac	11111111-1111-1111-1111-100000000077	k6-search-watchlist	2026-03-23 17:22:24.397+00	2026-03-23 17:22:24.796+00	f
9b37e44f-a71e-4a63-937f-129c948d4d18	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 19:24:48.918+00	2026-03-23 19:24:49.206+00	f
f2847a42-9af7-42d0-9d62-f50f578baa4f	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-23 19:19:40.14+00	2026-03-23 19:19:40.849+00	f
d4b87226-e56c-4cf2-ad3b-151d222b3ddb	54394bda-0a5e-47ec-9565-d2b43297c616	11111111-1111-1111-1111-111111111111	k6	2026-03-23 19:24:23.358+00	2026-03-23 19:24:47.506+00	f
e906c986-df23-451b-a372-90a3e6685bc9	d54193dc-859b-4720-838e-4d1e3040216a	11111111-1111-1111-1111-111111111111	k6	2026-03-23 19:18:59.01+00	2026-03-23 19:19:22.39+00	f
87f241bb-4891-43d5-ae8d-3affa8be2f23	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-23 19:24:50.21+00	2026-03-23 19:24:50.654+00	f
eb479fcd-f1fe-4ef1-a0c3-59fb511fe8bd	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-23 19:19:41.62+00	2026-03-23 19:19:42.508+00	f
2c6bbbcb-0b14-4392-852e-bc472063be6e	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-23 19:24:50.816+00	2026-03-23 19:24:51.248+00	f
92739cd3-66cc-46cf-a433-d1e6882831ff	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-23 19:24:51.407+00	2026-03-23 19:24:52.009+00	f
00e13823-de48-4091-a385-bb5a49ea22bb	09635deb-f21d-4d0a-a4af-bb41cd10b405	11111111-1111-1111-1111-111111111111	k6	2026-03-23 13:31:02.812+00	2026-03-23 13:31:21.626+00	f
dc1b08ae-e90c-445f-a951-0f6e19c55e4d	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-23 19:19:42.324+00	2026-03-23 19:19:43.685+00	f
0f6da4c6-9df7-460a-a466-e2d441cc0b0c	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-23 19:19:43.284+00	2026-03-23 19:19:45.308+00	f
85803e1b-ba09-469f-9a39-4d9c0ca6fd93	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-23 19:24:52.259+00	2026-03-23 19:24:53.665+00	f
970d8cf1-b6ae-4515-aa14-2c5221e986d4	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-23 19:24:53.723+00	2026-03-23 19:24:54.387+00	f
4e53cf9c-354d-4304-a15f-b38152f7645b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-23 19:19:44.702+00	2026-03-23 19:19:47.226+00	f
21cefd55-a67f-4633-b5a7-4e67c724abec	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-23 19:24:54.468+00	2026-03-23 19:24:55.801+00	f
ca3fa984-ac51-49da-91ea-f368b54c5099	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-23 19:19:46.072+00	2026-03-23 19:19:48.413+00	f
1c3d61fb-73c5-425a-8949-1aacd7548613	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-23 19:24:55.714+00	2026-03-23 19:24:56.907+00	f
868b2a0b-9200-4bd1-ab5f-2c683439d6ad	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-23 19:19:47.624+00	2026-03-23 19:19:49.21+00	f
ac85df09-41d0-4efe-a09b-dc55cc852d9a	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-23 19:19:48.554+00	2026-03-23 19:19:49.753+00	f
e586e554-7553-4ac6-a91e-18dbb433f7cd	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-23 19:24:56.81+00	2026-03-23 19:24:58.405+00	f
eecde200-1dc5-41c1-904d-988487c06474	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-23 19:24:58.204+00	2026-03-23 19:24:59.523+00	f
00996f15-cfc7-4ea8-9d7f-7322f8787d9b	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-23 19:19:49.287+00	2026-03-23 19:19:50.312+00	f
da15ac84-ee19-4afa-be23-c49c2428a514	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-23 19:24:59.33+00	2026-03-23 19:25:00.206+00	f
0891bd01-82d6-410a-95a8-3ff323bc70e0	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-23 19:25:00.121+00	2026-03-23 19:25:01.52+00	f
a011ba73-158c-40b7-8e38-43da31049eb3	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-23 19:19:49.964+00	2026-03-23 19:19:51.021+00	f
e393b274-9222-4c3a-bb41-216655874c43	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-23 19:19:51.209+00	2026-03-23 19:19:52.029+00	f
d3803027-137a-4851-b3b1-483d5a8ffa25	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-23 19:25:01.204+00	2026-03-23 19:25:02.989+00	f
48c851c8-09e4-4917-ac21-145c7ae3e6ce	9e6056ea-5be4-43e3-bb28-1a7c46ba8269	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-23 19:19:50.527+00	2026-03-23 19:19:52.033+00	f
7ad08ab0-2593-4d21-bb6c-bb2288b0471d	3f6a5abf-3ca2-4f3c-936a-be3826420ec7	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 19:20:04.501+00	2026-03-23 19:20:04.829+00	f
d337c58e-ad7c-4b91-b8fb-e71ff7549829	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-23 19:25:02.8+00	2026-03-23 19:25:04.123+00	f
6594cba6-7dcb-4614-a365-bdb5cd8b9cd3	b96c6ed5-209f-40dd-b1ed-80343789e241	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-24 00:48:16.962+00	2026-03-24 00:48:17.091+00	f
c17c09e5-e71e-4686-a861-c21727046279	748c3744-ce7a-4b25-ba3b-9d8d585853e7	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-24 03:45:22.098+00	2026-03-24 03:45:22.215+00	f
447d2088-c4ce-4c26-9161-b314fc299191	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-24 03:42:01.107+00	2026-03-24 03:42:01.638+00	f
b8f43699-5625-485d-8789-3022f340ead6	682fe188-bad7-45b2-90bb-99a13d0547e9	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-24 18:11:09.159+00	2026-03-24 18:11:09.907+00	f
2bcaa93c-3588-43ae-bd8a-b6a1b5989a57	f8cc850c-d9b7-4b4c-99c2-ccdc478d5ddc	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-24 18:42:22.702+00	2026-03-24 18:42:23.128+00	f
1e47a649-6cd7-48e4-88f2-49852c6acc5f	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-24 18:37:40.651+00	2026-03-24 18:37:40.821+00	f
957c76a3-8021-4a8f-8e5e-31238a64e82c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-24 20:50:07.924+00	2026-03-24 20:50:08.117+00	f
d4c8cde9-9466-46c1-b19d-902f2b7a54f9	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-24 00:47:07.923+00	2026-03-24 00:47:09.429+00	f
b6693f8c-5ce1-40df-8571-526c078407c5	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-23 19:25:03.821+00	2026-03-23 19:25:08.011+00	f
e1d9fc06-fede-4214-9d81-69193ff1d9ce	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-24 03:41:45.935+00	2026-03-24 03:41:46.181+00	f
8116af81-103d-4f08-a7c9-2fed2db3b91a	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-24 18:37:41.223+00	2026-03-24 18:37:41.418+00	f
11e35be8-59d2-475b-a242-9d10dee15eae	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-24 18:06:39.746+00	2026-03-24 18:06:40.823+00	f
7248a27a-7073-430c-aa6c-d5b9166c97bb	a9346f8b-998c-45e1-99ca-339aa10b78be	11111111-1111-1111-1111-111111111111	k6	2026-03-24 18:05:17.053+00	2026-03-24 18:05:41.223+00	f
56425480-8ffa-4627-a065-7231880d76a6	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-23 19:25:07.317+00	2026-03-23 19:25:09.047+00	f
c238fbc6-525b-4b8e-b054-34929a7c32fd	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-24 00:47:15.481+00	2026-03-24 00:47:16.518+00	f
b7bc7349-cd2a-4507-a33c-52b38a6ab711	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-24 18:37:46.253+00	2026-03-24 18:37:46.79+00	f
4110874b-b028-444b-a898-f2cbadcd70f1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-24 03:41:46.908+00	2026-03-24 03:41:47.611+00	f
62846b56-3db6-4806-8c5f-573900a07b3c	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-24 18:06:25.388+00	2026-03-24 18:06:25.946+00	f
72e0495b-6cb1-495f-a313-079bf4cdbd93	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-24 18:06:23.128+00	2026-03-24 18:06:23.326+00	f
4cb62ae8-d80e-4caa-adaa-cad22d0faaa7	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-23 19:25:08.811+00	2026-03-23 19:25:09.764+00	f
4aab8f40-d949-4fe6-8b1a-bf4aa816eb95	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-24 00:47:18.938+00	2026-03-24 00:47:19.883+00	f
f62a7155-b9e4-4931-a6b3-7636bf2dcbad	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-24 03:41:52.699+00	2026-03-24 03:41:53.256+00	f
46c04ed6-b724-4ba9-b1f0-4558604624f7	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-24 18:37:48.297+00	2026-03-24 18:37:48.745+00	f
ff216a01-3d9a-4401-be96-194339577482	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-23 19:25:09.651+00	2026-03-23 19:25:10.342+00	f
5e8c32e7-2760-4460-817f-ea1cf825710d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-24 03:41:47.684+00	2026-03-24 03:41:48.207+00	f
8d915da7-8838-4a52-a72e-0f3fb42a9a7b	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-24 18:37:50.121+00	2026-03-24 18:37:50.282+00	f
6c7e6e8d-0eae-4215-af04-7ded23a4263f	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-24 00:47:22.407+00	2026-03-24 00:47:28.034+00	f
bb113929-a92e-45b7-9fbd-d62fe6d78a56	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-24 18:37:50.725+00	2026-03-24 18:37:50.858+00	f
6954766b-d8df-481b-a3ae-52009f6e599d	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-24 18:06:23.821+00	2026-03-24 18:06:24.535+00	f
ea5cc1cb-98e0-4ecb-9946-2eae54827ffd	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-23 19:25:12.121+00	2026-03-23 19:25:13.906+00	f
2751d869-1ad5-4501-b168-5e5c0db376f8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-24 03:41:49.689+00	2026-03-24 03:41:50.912+00	f
335f4979-e23c-47f6-9a58-1c85a63028ea	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-24 00:47:28.235+00	2026-03-24 00:47:29.625+00	f
c6fd5202-8b3e-424f-9236-c29675deff2c	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-24 18:06:42.534+00	2026-03-24 18:06:44.15+00	f
225bd9f8-2f3e-4e74-815e-a1069e5f262c	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-24 18:37:51.732+00	2026-03-24 18:37:52.086+00	f
671f8df7-8e49-47d4-9598-c40f3cb94520	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-24 18:06:26.559+00	2026-03-24 18:06:27.273+00	f
47e5368b-bca4-4a36-afed-d4d7ec50c923	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-24 18:06:43.848+00	2026-03-24 18:06:45.949+00	f
0b42c925-a2af-4609-bac2-d50b4853f147	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-24 18:06:27.153+00	2026-03-24 18:06:28.047+00	f
f8f032ec-8349-4b3c-a1a3-b67092da393c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-24 03:41:52.179+00	2026-03-24 03:41:52.785+00	f
34d3b5cf-bd3f-4e40-b4f1-e7ac000fe84b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-24 18:06:43.098+00	2026-03-24 18:06:45.329+00	f
34a35a5a-5349-47ed-b18b-e35ce2cbc36c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-24 03:41:53.199+00	2026-03-24 03:41:53.729+00	f
1caeb5dc-204c-485f-ae4e-b85d9320b90d	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-24 18:37:59.628+00	2026-03-24 18:38:00.405+00	f
c19e9037-e8da-4688-ab5f-33d7996913ca	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-24 18:06:28.55+00	2026-03-24 18:06:29.362+00	f
892f4e17-a6fb-42a2-bdd4-874182d22eac	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-24 03:41:55.278+00	2026-03-24 03:41:56.109+00	f
f9dd2628-6258-42d6-b1ca-f223d31d68cd	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000037	k6-search-watchlist	2026-03-24 18:38:02.757+00	2026-03-24 18:38:03.755+00	f
fd8a706b-5795-49d1-9051-a3b90044908b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-24 18:06:45.82+00	2026-03-24 18:06:47.392+00	f
4e2fadee-e5cf-4ba5-b5cf-96e4883f74c2	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-24 18:06:31.086+00	2026-03-24 18:06:32.02+00	f
e5d2c826-93ca-4626-9ea4-724fb8d0b8c2	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-24 03:41:59.075+00	2026-03-24 03:41:59.733+00	f
82d5aed2-1220-45f5-9e6e-6577b5c67901	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-24 18:06:46.953+00	2026-03-24 18:06:47.821+00	f
097a2e13-dbdd-4896-b1ab-7c8acf737d41	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-24 18:06:31.849+00	2026-03-24 18:06:32.684+00	f
fd571176-08c0-400f-844b-528d2d9708ba	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-24 18:06:32.46+00	2026-03-24 18:06:33.394+00	f
bac263f9-522b-4dd7-8932-a4bc2fb615a5	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-24 03:42:01.593+00	2026-03-24 03:42:02.15+00	f
9b323ca8-e639-49bc-86c4-f2eedda097fc	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-24 18:06:47.445+00	2026-03-24 18:06:49.223+00	f
a2310a07-8869-4f3b-b23b-b9006f4d644c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-24 03:42:02.08+00	2026-03-24 03:42:02.595+00	f
6ade6208-896f-41ae-bb20-4d71d64cec6b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-24 18:06:34.947+00	2026-03-24 18:06:36.626+00	f
a626a960-d011-4e71-959a-0f0f89a4e62c	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-24 18:06:36.098+00	2026-03-24 18:06:37.367+00	f
6ff2fc2a-186d-4bba-a241-f9a7f4562b7d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-24 03:42:02.536+00	2026-03-24 03:42:03.063+00	f
d0b70a5e-a9ca-4cd9-af1a-9175be6b7f9f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-24 03:42:02.998+00	2026-03-24 03:42:03.643+00	f
56bf16c1-6cc1-46d9-ba47-b941ff0dd468	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-24 18:06:37.523+00	2026-03-24 18:06:39.15+00	f
7f612eb8-1e08-4fea-82ff-6573d58f098f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000040	k6-search-watchlist	2026-03-24 03:42:08.147+00	2026-03-24 03:42:08.743+00	f
8f7f5fde-7f1b-4070-883d-9f709536c108	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000038	k6-search-watchlist	2026-03-24 03:42:07.241+00	2026-03-24 03:42:07.855+00	f
2344d24e-ee75-4636-91de-1165df4fbf14	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000039	k6-search-watchlist	2026-03-24 03:42:07.702+00	2026-03-24 03:42:08.282+00	f
44d55c17-dbb8-4bdd-bee8-08b72b4671b8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000041	k6-search-watchlist	2026-03-24 03:42:08.611+00	2026-03-24 03:42:09.222+00	f
07d7b48d-af9b-495c-b10f-a97e3c4759f8	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000043	k6-search-watchlist	2026-03-24 03:42:09.563+00	2026-03-24 03:42:10.309+00	f
e92bac7a-f157-483a-b5be-c835f60840bb	ae0d0e6d-ec8a-41ae-8669-d49149ad6bd8	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-25 01:52:04.18+00	2026-03-25 01:52:04.978+00	f
1dd018df-3176-449e-ad59-203a581c97ee	c1b4fd1d-e276-4b96-a40b-3c686e9c37e8	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-24 03:56:14.423+00	2026-03-24 03:56:14.562+00	f
19770171-8eda-4273-bf51-0f749736486c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-24 03:41:45.314+00	2026-03-24 03:41:45.515+00	f
b2ed8e32-85f8-4737-be3e-0d5ac61f086a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-24 18:06:38.078+00	2026-03-24 18:06:39.748+00	f
7194f168-eeba-4277-838e-64336fac0e82	38655d4b-7e66-4310-b585-79abfa3c2163	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-25 13:54:24.074+00	2026-03-25 13:54:24.741+00	f
3de27144-fc78-4556-bb7a-e9fcd9deb338	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-24 18:06:29.75+00	2026-03-24 18:06:30.492+00	f
2690c915-d4cb-40a1-bb7d-ea64217a0f82	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-23 19:25:10.222+00	2026-03-23 19:25:11.054+00	f
6d9845ef-1e66-47fe-bd37-7e2cef46a099	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-24 18:06:39.069+00	2026-03-24 18:06:40.286+00	f
52cbd359-5cad-4caa-b87c-e481c24d08ca	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-24 18:06:24.824+00	2026-03-24 18:06:25.388+00	f
9a329f40-539e-4666-ab1d-8d92b77f7f5c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-24 03:41:46.425+00	2026-03-24 03:41:46.743+00	f
d3d1cce6-6e33-4031-92d8-a334c364eea5	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-24 03:41:54.781+00	2026-03-24 03:41:55.329+00	f
ca609430-1fef-4797-baa3-1548d5157c9e	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-24 18:37:41.73+00	2026-03-24 18:37:42.052+00	f
c3d89e4f-b226-4842-ba7d-5ce118277a40	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-24 03:41:48.21+00	2026-03-24 03:41:48.738+00	f
137c5052-ec9d-4dd6-b6c9-4a74c8f0dbbc	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-24 18:37:42.17+00	2026-03-24 18:37:42.61+00	f
2f4295de-2b2f-41c5-a4d0-917e6b5f5eb9	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-24 03:41:59.611+00	2026-03-24 03:42:00.409+00	f
8385124b-c4f0-406b-956b-a77c5df9a62b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-24 18:06:29.147+00	2026-03-24 18:06:29.979+00	f
4d930dcc-ddc7-4c24-82b0-0c74d69ccaa7	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-24 18:06:40.291+00	2026-03-24 18:06:41.335+00	f
5093a2f5-2cd2-4d60-a059-80fb527f8e0d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-24 03:41:48.684+00	2026-03-24 03:41:49.281+00	f
3ab79d36-3577-4143-840c-71529f3fb408	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-24 18:37:47.547+00	2026-03-24 18:37:47.722+00	f
ef6e0da5-fd4e-4fe5-ac4e-3183487fca59	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-24 18:06:40.921+00	2026-03-24 18:06:41.788+00	f
ba310017-d0eb-4cee-965a-08df5f69be33	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-24 18:37:43.249+00	2026-03-24 18:37:44.222+00	f
b3500583-ed52-4734-b818-ab037fe47513	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-24 03:41:50.512+00	2026-03-24 03:41:51.759+00	f
e0c2efc9-65f3-4095-b536-7e8fed5bcb98	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-24 18:06:33.029+00	2026-03-24 18:06:34.654+00	f
a414df90-a77b-42ca-9975-c56210c191ba	21fb5ed4-2a99-499a-9fae-4a705f894836	11111111-1111-1111-1111-111111111111	k6	2026-03-24 00:46:18.534+00	2026-03-24 00:46:44.034+00	f
77327475-15b3-4712-9943-bc153bc236ef	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-24 18:06:41.995+00	2026-03-24 18:06:43.054+00	f
953fab4b-50f7-4ea0-996e-d12f5f3b8481	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-24 03:41:56.511+00	2026-03-24 03:41:57.178+00	f
509eee92-adb6-4108-9708-13c4acedfd1b	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-24 18:37:44.951+00	2026-03-24 18:37:45.624+00	f
0506d4ff-40fe-44e3-b181-d5bcf0d1733e	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-24 00:47:19.625+00	2026-03-24 00:47:26.011+00	f
8dc44d27-caee-4916-aa11-8635682b55ce	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-24 18:37:46.935+00	2026-03-24 18:37:47.225+00	f
88f9df17-169d-480a-bff2-56e7a75d97ad	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-24 03:41:57.575+00	2026-03-24 03:41:58.127+00	f
1c7844f3-c5e3-4ccb-a213-63dd0bad8d93	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-24 18:37:51.255+00	2026-03-24 18:37:51.476+00	f
77db5c2d-3a6f-44b2-9344-2f55c0c440eb	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-24 00:47:07+00	2026-03-24 00:47:07.718+00	f
2c33b9d5-bc91-45be-af66-1e7d62d486ba	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-24 03:41:58.11+00	2026-03-24 03:41:58.535+00	f
a7501430-f960-4245-a18f-a31c2b92e4cb	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-24 18:37:52.677+00	2026-03-24 18:37:53.147+00	f
319dec67-307a-4816-a4fb-856cf063bbde	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-24 18:37:53.182+00	2026-03-24 18:37:53.945+00	f
32af59c4-df60-497d-9f72-b36b4370249f	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-24 03:42:04.154+00	2026-03-24 03:42:04.681+00	f
ba0f5617-2dc3-4276-a11c-992adc9f5904	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-24 00:47:10.867+00	2026-03-24 00:47:14.09+00	f
4bdd4025-08b7-41cc-9f92-3ba71d57be4e	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-24 00:47:26.829+00	2026-03-24 00:47:28.867+00	f
4a60678c-d991-4f60-947c-0455d0137b74	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-24 18:37:54.596+00	2026-03-24 18:37:55.083+00	f
a10e49d3-42a2-40c9-afcd-82265fca114c	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-24 00:47:13.828+00	2026-03-24 00:47:14.843+00	f
f90fd5f1-39a3-4d2f-b99b-95385c46cae6	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000035	k6-search-watchlist	2026-03-24 03:42:05.206+00	2026-03-24 03:42:06.282+00	f
bec6a371-cd57-42a8-9ac0-7e07df180351	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-24 18:37:55.074+00	2026-03-24 18:37:55.492+00	f
fdd3cf15-81ec-4da2-a35b-7c31c59903fc	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000037	k6-search-watchlist	2026-03-24 03:42:06.712+00	2026-03-24 03:42:07.411+00	f
11d1855b-8258-4801-a95f-816feb2f7d02	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-24 00:47:14.674+00	2026-03-24 00:47:15.608+00	f
898cf950-c546-4892-8b73-abe2cfab12f3	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000036	k6-search-watchlist	2026-03-24 03:42:06.117+00	2026-03-24 03:42:06.851+00	f
be39c240-fb89-491d-8cb2-0c454fb0da8a	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-24 18:37:55.955+00	2026-03-24 18:37:56.349+00	f
6e31607f-c963-4790-94ef-86d0a71d8135	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-24 00:47:16.306+00	2026-03-24 00:47:17.207+00	f
15c4fc0d-4770-491e-9df5-86df89abb998	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-24 00:47:28.885+00	2026-03-24 00:47:30.87+00	f
ec74ab80-4674-4b65-aca9-c2b693588550	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-24 18:38:00.421+00	2026-03-24 18:38:01.022+00	f
a6baab4c-78d1-4f3c-82cd-82c3adf43529	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000042	k6-search-watchlist	2026-03-24 03:42:09.116+00	2026-03-24 03:42:09.687+00	f
af342bb4-a200-4fa6-a7ba-d2929faa91b1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000048	k6-search-watchlist	2026-03-24 03:42:12.636+00	2026-03-24 03:42:12.972+00	f
dab5fb90-ec39-4b9b-bbcb-3409a53985d0	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-24 18:37:37.819+00	2026-03-24 18:37:37.948+00	f
da5a9b71-f6e0-4f37-8150-97a9fcf718be	9da94f17-e9e4-4e73-8834-0c5988008c53	11111111-1111-1111-1111-111111111111	k6	2026-03-24 18:36:33.107+00	2026-03-24 18:36:57.491+00	f
737a06e2-a416-4272-ac58-8e10be7cdbd6	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000044	k6-search-watchlist	2026-03-24 03:42:10.03+00	2026-03-24 03:42:11.179+00	f
54eb4c01-bb67-44dc-bd47-a47319599f8f	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-24 18:38:01.049+00	2026-03-24 18:38:01.683+00	f
b8ceaed5-0f94-486d-833f-05ea6194f46d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000045	k6-search-watchlist	2026-03-24 03:42:10.882+00	2026-03-24 03:42:11.781+00	f
8708a107-5958-4911-8faf-dc42b449fc8c	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-24 18:37:39.425+00	2026-03-24 18:37:39.522+00	f
4113cd44-4a25-4e28-b7ed-5ff6d8f7d012	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-24 18:37:37.221+00	2026-03-24 18:37:37.38+00	f
c03f2cee-d129-4cdf-9313-97941c9bf905	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-24 18:37:38.349+00	2026-03-24 18:37:38.653+00	f
57cf787c-f826-4f19-ac75-9280ba7eee3c	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000035	k6-search-watchlist	2026-03-24 18:38:01.592+00	2026-03-24 18:38:02.22+00	f
8772fd26-d58e-4745-9eed-0c54d324df21	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-24 18:37:40.078+00	2026-03-24 18:37:40.2+00	f
e0ccae89-07d1-405f-a9ad-51675b3d5d9d	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000039	k6-search-watchlist	2026-03-24 18:38:04.546+00	2026-03-24 18:38:05.222+00	f
445db5ca-e09b-44b8-9e6e-452950f62fe2	698187d0-a03d-4e91-bc59-fafd35e4741b	11111111-1111-1111-1111-111111111111	k6	2026-03-24 03:40:45.006+00	2026-03-24 03:41:09.594+00	f
786c5ac8-7e58-489d-913e-d9961ece829a	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 01:31:31.55+00	2026-03-25 01:31:31.725+00	f
3c97bf3e-a90d-406d-a0e5-395c48cf30ca	902bb881-e1d7-4fff-b5c6-a9b2bac3001d	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-24 05:12:29.23+00	2026-03-24 05:12:29.771+00	f
2cb9aa03-377a-46d1-af58-19175bd6349f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-24 20:50:09.296+00	2026-03-24 20:50:09.464+00	f
e31b24fd-3d2a-4ca6-a2a4-b5a07c98b7e3	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-24 00:47:04.287+00	2026-03-24 00:47:04.689+00	f
de26936f-3e62-478d-a7a5-a1820c66148f	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-23 19:25:10.838+00	2026-03-23 19:25:12.207+00	f
7c955748-7c0d-4d33-8c5d-6a8a88260d94	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-24 20:50:08.662+00	2026-03-24 20:50:08.851+00	f
9c5d7717-87b7-48fb-8bed-d8c87ed88b9a	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-24 18:37:45.673+00	2026-03-24 18:37:46.298+00	f
deda5af2-197b-4872-be5b-31b64e58269b	bf0ca156-d0ce-4c63-b02c-bc0081755d44	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-23 19:25:13.719+00	2026-03-23 19:25:13.934+00	f
8363cf3a-17bb-4b99-b121-0d899c993606	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-24 03:41:49.209+00	2026-03-24 03:41:49.81+00	f
72ee9922-d760-480d-b38a-ff3df2964ab5	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-24 18:37:42.62+00	2026-03-24 18:37:43.198+00	f
30c2dcfa-3567-4ac1-80c4-7d502888ee1c	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-24 03:41:57.084+00	2026-03-24 03:41:57.639+00	f
064448ca-fb49-4da6-9bd8-876d973d06b0	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-24 00:47:05.471+00	2026-03-24 00:47:06.629+00	f
5fc017de-c25f-42e3-8a19-bbbf75bc920b	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-24 18:06:25.924+00	2026-03-24 18:06:26.725+00	f
d4fd1251-b4b8-4679-bdcf-7a973d27fde0	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-24 18:06:41.471+00	2026-03-24 18:06:42.42+00	f
14cd74f2-55e0-4f0d-a0e0-ba2a54c225f4	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-24 18:06:33.651+00	2026-03-24 18:06:35.961+00	f
d197a3ae-7a99-4879-b51e-b27ca8348dc9	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-24 03:41:51.61+00	2026-03-24 03:41:52.287+00	f
67ad10fb-c4a2-4dab-8631-30783b202d49	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-24 18:37:53.855+00	2026-03-24 18:37:54.522+00	f
7a524bb5-ec9f-4b7d-bb1d-dca9414c6554	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-24 00:47:09.438+00	2026-03-24 00:47:11.643+00	f
2bb744f6-884b-482e-b6c5-363719fb1692	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-24 20:50:09.811+00	2026-03-24 20:50:10.02+00	f
ed1ed85d-4963-46b2-8392-4882d3ef6a81	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-24 18:06:27.65+00	2026-03-24 18:06:28.811+00	f
44dcecef-7089-4fa2-a13b-03af2410f284	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000035	k6-search-watchlist	2026-03-24 18:06:47.936+00	2026-03-24 18:06:49.928+00	f
c812ca8b-9dd4-4960-a911-8ab737289c71	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-24 20:50:10.311+00	2026-03-24 20:50:11.025+00	f
453919ff-8c84-47bf-8e39-3c09218fce85	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-24 18:06:45.158+00	2026-03-24 18:06:46.958+00	f
7f0be372-c646-4216-b904-6668006b9563	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-24 18:37:44.06+00	2026-03-24 18:37:44.978+00	f
56d11d7b-3d2c-4a4c-8f51-eaca2538e884	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-24 03:41:53.652+00	2026-03-24 03:41:54.312+00	f
39e29f4e-1b81-46b6-86db-845ab1de3aeb	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-24 18:37:49.164+00	2026-03-24 18:37:49.554+00	f
624a781a-d924-4193-87ca-b310f92af30a	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-24 00:47:17.1+00	2026-03-24 00:47:18.516+00	f
52cb1bb8-a3e3-45d4-b5df-8ba97df5ca09	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-24 18:06:30.423+00	2026-03-24 18:06:31.322+00	f
64209b8b-28b7-4521-b0d3-49334815d86d	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-24 03:41:54.188+00	2026-03-24 03:41:54.883+00	f
f571d5a4-b78f-4fa9-b089-f460a04583ad	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-24 00:47:18.178+00	2026-03-24 00:47:19.096+00	f
168f1fee-fb12-4805-a02b-d497218683b5	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-24 18:37:56.423+00	2026-03-24 18:37:59.751+00	f
391d73cb-14be-4697-b088-7c4a1a10fda1	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-24 03:41:58.581+00	2026-03-24 03:41:59.065+00	f
732e9d86-7867-46ef-b68b-c1608c59ade3	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-24 00:47:29.502+00	2026-03-24 00:47:30.752+00	f
5269b64d-b34c-42f3-a18f-488048b0a1d0	2089d278-bdf5-4cbf-871d-74c319bc81f1	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-24 00:47:30.638+00	2026-03-24 00:47:30.962+00	f
e409d94b-fbee-495c-8242-2835a8a78f58	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-24 20:50:11.189+00	2026-03-24 20:50:11.906+00	f
aaaccef8-4edc-4484-aa75-2edcdbe230b7	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-24 03:41:56.014+00	2026-03-24 03:41:56.597+00	f
6cbb25ad-d7eb-49c3-8e9a-94d3097d3835	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-24 18:06:36.859+00	2026-03-24 18:06:37.904+00	f
98ff7b8b-bd9c-4400-a0a4-e4c2e6e4b5a5	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-24 18:37:52.213+00	2026-03-24 18:37:52.596+00	f
f538c138-f58f-4162-9b47-2472c0483416	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-24 20:50:12.365+00	2026-03-24 20:50:13.153+00	f
e2ce4e9f-31ef-424f-ae3b-47a5c03e2292	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000036	k6-search-watchlist	2026-03-24 18:06:49.053+00	2026-03-24 18:06:50.746+00	f
2bb6bddf-dfad-4c45-aec9-22d469ae1fc3	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-24 20:50:11.752+00	2026-03-24 20:50:12.52+00	f
99184203-2e5e-42c0-81ac-d9de14dc8c3b	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-24 03:42:00.284+00	2026-03-24 03:42:01.207+00	f
e228c427-56d1-476a-bc6f-f40bc12c022c	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-24 18:37:55.514+00	2026-03-24 18:37:55.912+00	f
79d4e10e-1590-4525-8603-90990b2a75ee	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000037	k6-search-watchlist	2026-03-24 18:06:49.95+00	2026-03-24 18:06:50.91+00	f
d8ea114d-a954-4c21-b481-3fdbc347dc1a	4c829cd9-1bea-4f51-b2f2-c6e4ff4c69b4	11111111-1111-1111-1111-100000000038	k6-search-watchlist	2026-03-24 18:06:50.647+00	2026-03-24 18:06:51.021+00	f
a761996f-4e60-4909-b88a-883e586d9acf	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000046	k6-search-watchlist	2026-03-24 03:42:11.715+00	2026-03-24 03:42:12.238+00	f
3fe676fd-64d3-4ba4-bbc6-aeaeb2f227d7	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-24 03:42:03.613+00	2026-03-24 03:42:04.184+00	f
01a6ea58-7b6a-466c-96e6-6c3effb2f85c	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-24 20:50:12.955+00	2026-03-24 20:50:14.02+00	f
f426f063-108a-409e-a502-603dc627f0d4	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000038	k6-search-watchlist	2026-03-24 18:38:03.319+00	2026-03-24 18:38:05.062+00	f
6fd945d9-b191-4075-af88-3aada62bcf30	b53a715d-e732-4cea-aff3-855d21cb8e6a	11111111-1111-1111-1111-100000000036	k6-search-watchlist	2026-03-24 18:38:02.139+00	2026-03-24 18:38:02.81+00	f
479fbaa2-92b9-47a3-ab81-967e08f32808	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-24 03:42:04.68+00	2026-03-24 03:42:05.407+00	f
ebf7efda-515f-4187-86d8-b8e6663cefdd	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-24 20:50:13.447+00	2026-03-24 20:50:14.749+00	f
77f38c73-1f8f-4df8-8bf7-419d545e5cee	84f3e0e3-a50e-432d-b3d3-1bd9f210c89f	11111111-1111-1111-1111-100000000047	k6-search-watchlist	2026-03-24 03:42:12.181+00	2026-03-24 03:42:12.756+00	f
bc0eadd6-e880-4326-bdb0-899bd590c4b4	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-24 20:50:14.323+00	2026-03-24 20:50:15.421+00	f
f7e6090f-3633-4548-b57a-63dfd9033959	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-24 20:50:14.913+00	2026-03-24 20:50:15.984+00	f
380db17e-d0ae-481b-ae46-6d9dd28bae36	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-24 20:50:15.421+00	2026-03-24 20:50:16.474+00	f
d910809a-1f35-4082-acea-f2da4158ef7b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-24 20:50:15.956+00	2026-03-24 20:50:17.093+00	f
bf57caa0-fee1-479a-b00f-b3e8c7f3b9fc	95f78edd-cd71-4563-8a09-f181f389a4d2	11111111-1111-1111-1111-111111111111	k6	2026-03-24 20:48:57.847+00	2026-03-24 20:49:22.208+00	f
cc35573b-d947-44a1-87a4-c2970300225b	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-24 20:50:16.458+00	2026-03-24 20:50:17.701+00	f
09f7af2e-4884-465e-ab39-17fe4b78c124	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-24 20:50:17.011+00	2026-03-24 20:50:18.521+00	f
3e925b9a-bd16-4957-b1a3-8fd3c23fe89a	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-24 20:50:17.593+00	2026-03-24 20:50:19.347+00	f
adb47420-1901-410c-8b99-b559af72cac5	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-24 20:50:20.252+00	2026-03-24 20:50:21.545+00	f
4eda0035-4997-4bc4-abb5-6515acb0d966	faa07055-3e8c-42ae-9a3d-4731ea46a316	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-25 17:00:51.731+00	2026-03-25 17:00:53.07+00	f
a8ee68aa-def3-4295-a9f8-a8fdb2ddf458	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-24 20:50:28.272+00	2026-03-24 20:50:30.186+00	f
197f5870-7740-4504-b613-ee716a4cf950	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 16:40:03.088+00	2026-03-25 16:40:03.359+00	f
b37c43dd-efaf-4fd6-8e7d-1c614758b0db	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-25 01:43:27.671+00	2026-03-25 01:43:28.565+00	f
75750a03-ca5b-47fc-9ffa-3b5af107f0a6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-24 20:50:18.352+00	2026-03-24 20:50:20.323+00	f
f8ba1f7c-65a4-42d5-a52d-7b71d5d1aca7	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 01:31:32.193+00	2026-03-25 01:31:32.371+00	f
072c9732-ffa3-4f6b-b9e4-2f5a61b04dc0	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 16:40:03.892+00	2026-03-25 16:40:04.273+00	f
ba045a53-66ce-457e-9fc8-096afdec9bff	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000040	k6-search-watchlist	2026-03-25 01:31:58.071+00	2026-03-25 01:31:59.368+00	f
9b9ac9ac-fd05-40df-8a6c-ff29eede358e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-24 20:50:19.154+00	2026-03-24 20:50:20.924+00	f
032652a7-1777-4c78-ad3f-003477649723	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 16:52:14.043+00	2026-03-25 16:52:14.288+00	f
50e1853f-0a43-4203-b08a-227ac5a0d514	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-24 20:50:28.95+00	2026-03-24 20:50:30.774+00	f
3f76508d-e14b-4b3f-a16a-50080687114b	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-25 01:31:39.379+00	2026-03-25 01:31:40.003+00	f
43fcc62b-ba95-48a8-b62e-37fd7809f657	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000041	k6-search-watchlist	2026-03-25 01:31:59.041+00	2026-03-25 01:31:59.512+00	f
33051d0d-32b1-47db-9408-84657cd80607	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 01:43:23.774+00	2026-03-25 01:43:23.968+00	f
9f056fc6-973f-4751-b8f2-0038eefa6e31	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 01:31:33.142+00	2026-03-25 01:31:33.446+00	f
7f5efb0b-1fe1-441b-b7e7-95055a7c3898	ae441525-4c02-48a1-9dbe-5a9fabbc4664	11111111-1111-1111-1111-111111111111	k6	2026-03-25 04:00:21.92+00	2026-03-25 04:00:42.04+00	f
8173fa87-0a5b-4e02-ad0e-0501390fcf58	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-25 01:31:42.309+00	2026-03-25 01:31:44.567+00	f
5cbc421b-b2d8-4a79-a374-35c5d3b9bfa3	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-25 16:40:19.977+00	2026-03-25 16:40:21.269+00	f
e8508ac8-b319-479d-9c86-9e26ee3fd44c	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 01:31:34.672+00	2026-03-25 01:31:35.354+00	f
f4d251e9-6289-4a96-b14f-91d22db02cd7	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 01:43:25.769+00	2026-03-25 01:43:26.439+00	f
a9c653cc-3063-4b74-95bb-0d71396d5f28	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-24 20:50:24.951+00	2026-03-24 20:50:26.314+00	f
1fa53395-690f-484c-ac0a-b68621c1b962	82b2d709-4451-44ea-9076-65097bd7963d	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 05:31:04.328+00	2026-03-25 05:31:05.07+00	f
1b042e62-4490-4404-81e2-38799a473bb8	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-25 01:31:39.865+00	2026-03-25 01:31:40.572+00	f
a145bc15-c764-44d9-9b4a-084e8148f87d	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 01:31:35.354+00	2026-03-25 01:31:35.973+00	f
d5311893-9e20-4ea6-adc5-d1803c673002	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-24 20:50:25.524+00	2026-03-24 20:50:26.991+00	f
a845a85e-f04c-4ac8-be4c-f8e4e6731e19	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-25 16:40:20.84+00	2026-03-25 16:40:22.511+00	f
930c50ec-2dd7-4fd7-9f91-47c6b30fb0a1	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000036	k6-search-watchlist	2026-03-24 20:50:31.803+00	2026-03-24 20:50:32.418+00	f
33509163-e186-4c7f-93e9-34f47468d1b1	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-24 20:50:26.149+00	2026-03-24 20:50:27.79+00	f
321872a7-7f63-46db-9b1e-c29a27025815	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-25 01:43:29.746+00	2026-03-25 01:43:30.652+00	f
5f7df257-738a-45bc-b7ff-0c5865cc0a3b	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-25 01:31:36.586+00	2026-03-25 01:31:37.342+00	f
883a60e1-46dd-417f-996c-516e6d78aad7	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-25 16:40:24.265+00	2026-03-25 16:40:24.731+00	f
00126ad8-4e9f-4c69-86c3-a29a29eb0573	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-25 01:31:37.218+00	2026-03-25 01:31:37.887+00	f
52333fcb-5933-4eec-be8f-502e0bf5c70e	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-25 16:40:25.407+00	2026-03-25 16:40:25.736+00	f
baeb2e39-081c-41f5-8bb9-22785d792e60	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-25 01:43:31.913+00	2026-03-25 01:43:33.665+00	f
d9338416-2632-4195-960b-55a2b1d4ce19	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-24 20:50:27.553+00	2026-03-24 20:50:29.147+00	f
68031e8b-ff6d-426d-939d-0ff97faa3790	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-25 16:40:29.045+00	2026-03-25 16:40:30.138+00	f
83b43039-060c-48f9-b031-0fbcac4288f2	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-25 01:43:35.075+00	2026-03-25 01:43:36.138+00	f
2fe300c7-22d9-48a8-8720-c8552335c954	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-25 01:31:40.402+00	2026-03-25 01:31:41.233+00	f
15587107-4771-4da2-8e53-0e5e8937890f	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-25 01:43:34.628+00	2026-03-25 01:43:35.368+00	f
0c360ce9-cb03-4f5e-9768-fd4ab47d3182	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-25 16:40:30.158+00	2026-03-25 16:40:30.688+00	f
bb67a620-bc84-4728-a42d-93b13de520f1	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-25 16:40:30.813+00	2026-03-25 16:40:31.039+00	f
e92e0f30-d4d4-458c-bf9d-966c9438b270	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-25 01:31:41.708+00	2026-03-25 01:31:42.53+00	f
758322aa-1d45-4203-846d-160ae838fb6b	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-25 01:31:45.146+00	2026-03-25 01:31:45.978+00	f
a7bfe153-558b-467c-a18d-8d4ea0157734	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-25 01:43:37.274+00	2026-03-25 01:43:38.233+00	f
778c1711-4c8b-423a-9a23-d907f5971603	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-25 01:31:46.475+00	2026-03-25 01:31:47.294+00	f
801cc6cf-0c8d-4f97-b620-1c923b610daa	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-25 01:31:47.153+00	2026-03-25 01:31:47.906+00	f
d25195d6-0f76-49de-a4ca-fe8580677e8e	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-25 01:43:37.967+00	2026-03-25 01:43:38.828+00	f
1fcd26a1-62b4-40cb-a6fa-112406f14a18	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-25 01:31:50.708+00	2026-03-25 01:31:51.369+00	f
ffa7c5fa-5fc0-427b-b9a4-f0385ba01320	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-25 01:31:47.713+00	2026-03-25 01:31:48.362+00	f
e548f693-c180-40b0-9e16-59a10f271e27	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-25 01:43:38.575+00	2026-03-25 01:43:39.44+00	f
69b9ee8c-5ec0-4cb2-9b79-475e6c5e3d4f	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-25 01:31:48.756+00	2026-03-25 01:31:49.277+00	f
ef0f3371-2e99-493b-87d7-99f978fe2bee	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000036	k6-search-watchlist	2026-03-25 01:31:55.498+00	2026-03-25 01:31:56.22+00	f
09ae3218-f379-49d4-9698-3ae8f8d5b8ab	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-25 01:31:51.273+00	2026-03-25 01:31:51.977+00	f
568c9772-3f89-4414-92b3-d458c41af0a4	5acf92e3-43de-48cd-8e6b-22fa9da89d38	11111111-1111-1111-1111-111111111111	k6	2026-03-25 01:30:26.813+00	2026-03-25 01:30:51.66+00	f
9154e4ee-a1ec-4ad6-9448-2e078c3abf14	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-25 01:43:42.373+00	2026-03-25 01:43:44.938+00	f
9dda3e76-98c5-4b56-b249-f60797903384	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-25 01:43:41.674+00	2026-03-25 01:43:43.669+00	f
467db16c-f264-4b88-954a-032df4b241e8	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-25 01:31:52.47+00	2026-03-25 01:31:54.275+00	f
c8da2a1a-265f-4fbe-ada2-a9d42d9ea41a	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000037	k6-search-watchlist	2026-03-25 01:31:55.993+00	2026-03-25 01:31:56.827+00	f
d67af47f-6173-4106-8d04-a4e3cc745147	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-25 01:43:43.269+00	2026-03-25 01:43:45.766+00	f
e70012d8-16f3-442d-8c8d-1dd690687aea	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-25 01:43:44.679+00	2026-03-25 01:43:47.172+00	f
c29019d5-4f12-43c6-b206-c2d5ac0c3ee7	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-25 01:43:46.68+00	2026-03-25 01:43:48.695+00	f
daf8a382-341b-4c6a-a17f-d393f6fbbf82	0f59c6e6-f518-46b3-9a99-23f870b06ec9	11111111-1111-1111-1111-111111111111	k6	2026-03-25 16:38:57.452+00	2026-03-25 16:39:21.904+00	f
4f86e6e9-6c51-4bf7-a392-16e7267a7db4	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-25 01:43:45.477+00	2026-03-25 01:43:48.17+00	f
d2786a44-a034-4b0e-890d-4909f3f27481	154b021e-3a01-4ecf-a919-30d65233b635	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-25 20:39:31.412+00	2026-03-25 20:39:32.019+00	f
1947d16b-490e-45ee-bfe4-524c2e37c1f9	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-25 16:40:11.86+00	2026-03-25 16:40:12.29+00	f
cdbfaa76-2ae9-40e7-94fa-55785ac30bc3	ef99fff9-f1d0-4a77-be7d-681e81d15332	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-27 03:12:42.973+00	2026-03-27 03:12:46.264+00	f
8c8ea468-58e4-4bee-b9b0-55fd79b0f639	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-25 01:31:41.101+00	2026-03-25 01:31:41.927+00	f
64642a09-3e45-4fa9-ab51-74bf2b4841f0	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 01:43:24.397+00	2026-03-25 01:43:24.743+00	f
fc3b8a16-e0fb-4aff-8421-744e43a0ae21	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 01:31:33.894+00	2026-03-25 01:31:34.549+00	f
c322a633-cfb9-4f2f-8324-cf9d1281a9db	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 16:40:06.219+00	2026-03-25 16:40:06.572+00	f
75b202f3-5972-4838-9336-0b925effc373	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-25 01:31:50.171+00	2026-03-25 01:31:50.733+00	f
a2974981-a83c-497e-8872-98db7bd06b4d	82b2d709-4451-44ea-9076-65097bd7963d	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 05:30:51.441+00	2026-03-25 05:30:58.829+00	f
29b1512c-2ca5-4a21-b0e4-539842178f1f	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 16:40:04.541+00	2026-03-25 16:40:04.876+00	f
7e461e86-6a61-4a3c-ad7c-340a7a7db45f	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-25 01:43:29.193+00	2026-03-25 01:43:29.845+00	f
c06da370-161a-44eb-a0fa-a86d2a0a9b82	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-25 01:31:35.976+00	2026-03-25 01:31:36.694+00	f
d937e9e1-8bdf-48ec-9a80-b883dcd1252b	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 01:43:26.722+00	2026-03-25 01:43:26.97+00	f
d94955f9-978b-4c0d-a8c9-bf38f90c2902	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-24 20:50:20.797+00	2026-03-24 20:50:22.192+00	f
423b77b5-b3e6-4789-81ff-4bb193653e78	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-25 16:40:13.644+00	2026-03-25 16:40:14.041+00	f
fa5e0c05-8437-4f43-97db-3c139c5464b1	82b2d709-4451-44ea-9076-65097bd7963d	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 05:31:05.754+00	2026-03-25 05:31:06.431+00	f
fc0bf7b1-b61e-4332-8d73-13d28f250627	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 16:40:05.122+00	2026-03-25 16:40:05.503+00	f
1f5504d5-60a5-4f9b-81f9-1355b8815a89	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-24 20:50:21.421+00	2026-03-24 20:50:22.801+00	f
eba4d8b9-497e-46c7-a39a-1f73130a044a	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 01:43:27.126+00	2026-03-25 01:43:27.606+00	f
1ee0e42f-a918-468c-94be-5c3f738c6951	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-25 01:31:37.824+00	2026-03-25 01:31:38.545+00	f
9f71ffd2-fb5c-42a0-87f7-21a71831af98	82b2d709-4451-44ea-9076-65097bd7963d	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 05:31:06.435+00	2026-03-25 05:31:07.631+00	f
1e4d23be-e88c-490f-b7a1-5caa75a78892	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-25 16:40:08.472+00	2026-03-25 16:40:11.265+00	f
f3dc80c2-c755-4538-8abf-017016d641c0	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-24 20:50:22.049+00	2026-03-24 20:50:23.553+00	f
d7d9b295-ad1e-4ee8-bcc9-fb553a31b095	82b2d709-4451-44ea-9076-65097bd7963d	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 05:31:07.756+00	2026-03-25 06:31:22.024+00	f
b088438b-9628-415a-82b0-5334d73fe0d7	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-25 01:31:38.39+00	2026-03-25 01:31:39.143+00	f
3a0190ff-2059-4e36-adea-200c8a300067	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-25 01:43:28.388+00	2026-03-25 01:43:29.29+00	f
63162859-3ddb-425c-b431-665fa3f6f6df	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-25 01:31:44.066+00	2026-03-25 01:31:45.339+00	f
16616dbe-fb26-49db-a4d4-726d8c9ff65f	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-24 20:50:22.625+00	2026-03-24 20:50:24.452+00	f
50ab1124-426c-418d-b941-6c5c6b1e3703	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-25 16:40:12.498+00	2026-03-25 16:40:13.217+00	f
de349191-4d79-4d5f-b507-24480ca4dfc4	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-25 01:31:38.855+00	2026-03-25 01:31:39.578+00	f
ac59f3d0-2b68-4acd-baed-fe7fdb8bcaf7	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-24 20:50:23.346+00	2026-03-24 20:50:25.051+00	f
e4b17da8-ad66-4c45-82b4-ddcb6fd4345f	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-25 01:43:30.341+00	2026-03-25 01:43:31.14+00	f
1502734c-522b-46be-96c7-e9ff1f720b0e	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-24 20:50:24.263+00	2026-03-24 20:50:25.654+00	f
0604ae9a-b11c-4a5f-bdd7-1b2348565e47	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-24 20:50:30.613+00	2026-03-24 20:50:32.014+00	f
0a6273de-5c4d-4262-876b-2e82ae8e39c9	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000035	k6-search-watchlist	2026-03-24 20:50:31.22+00	2026-03-24 20:50:32.524+00	f
0c461cf4-ee74-4e8f-8392-7be453f59ced	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-24 20:50:26.822+00	2026-03-24 20:50:28.481+00	f
85c88346-1666-4635-9ec6-b034463ce809	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-25 01:31:45.811+00	2026-03-25 01:31:46.646+00	f
5c946ea3-875d-4b54-bd84-d6ad709ae4dc	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-25 01:43:36.001+00	2026-03-25 01:43:36.743+00	f
b2518236-f3d5-4b9e-82e0-3a7a4fa65b86	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-25 01:43:33.97+00	2026-03-25 01:43:34.817+00	f
6c9d33bc-7755-4dc2-bbc0-122cb91c5c93	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-25 16:40:14.865+00	2026-03-25 16:40:15.341+00	f
d980965a-39d2-4739-b261-faa5497fb139	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-25 01:31:48.303+00	2026-03-25 01:31:48.821+00	f
7e20a49b-6386-469a-97f3-422f4c330e34	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-25 01:31:51.871+00	2026-03-25 01:31:52.742+00	f
f3bd096e-cf50-40dc-b865-519956ddbce5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-25 16:40:15.331+00	2026-03-25 16:40:15.953+00	f
744f66ae-e6c9-41cc-b20d-d5c34f9f1b7b	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-25 01:31:49.197+00	2026-03-25 01:31:49.719+00	f
4572690c-e486-40ea-9dff-f86c7b311239	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-25 01:43:36.64+00	2026-03-25 01:43:37.447+00	f
aadb6079-9ead-48a4-91e7-1e2626e23089	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-25 16:40:18.45+00	2026-03-25 16:40:19.243+00	f
1873197c-cd6a-41c3-a928-a38f410c4a34	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-25 16:40:17.292+00	2026-03-25 16:40:18.516+00	f
31240050-ea8c-47c7-9c1d-1a890ad62a63	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-25 01:31:49.64+00	2026-03-25 01:31:50.242+00	f
dde70363-b7c4-4493-a925-577ecb92c409	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-25 01:43:40.178+00	2026-03-25 01:43:41.84+00	f
dcf57868-2bf0-46a6-aedb-603d753677b5	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-25 16:40:23.676+00	2026-03-25 16:40:24.312+00	f
a9319c1c-d814-4f92-bb50-8822ceb9c697	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-25 16:40:22.395+00	2026-03-25 16:40:23.738+00	f
b0256635-71d5-4d2b-9f03-69517bdeeb32	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-25 01:31:53.667+00	2026-03-25 01:31:54.788+00	f
afc01904-504f-46a8-97ed-3d0303e85b12	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-25 01:43:47.641+00	2026-03-25 01:43:48.604+00	f
29608dc9-7f30-44ca-a514-aa5f511831be	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-25 16:40:26.666+00	2026-03-25 16:40:27.281+00	f
e6d7daef-4e60-4562-80fb-d51f61314382	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-25 16:40:27.438+00	2026-03-25 16:40:28.842+00	f
e9723e1f-8a2b-4cc2-839f-ab3bc54c64a9	8ef65d68-30bd-4bbb-9fe4-5851caeca512	11111111-1111-1111-1111-111111111111	k6	2026-03-25 16:51:19.851+00	2026-03-25 16:51:44.473+00	f
4ceab2cf-3dab-4bf0-8957-ed028a06d8b1	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 16:52:14.879+00	2026-03-25 16:52:15.147+00	f
23240702-ff49-46bc-a434-1a991701c767	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-25 16:52:18.879+00	2026-03-25 16:52:19.524+00	f
0d4f289f-a961-4364-a8c4-d2b6e915d414	96b4b689-7052-45aa-913e-29e88b7026c1	11111111-1111-1111-1111-111111111111	k6	2026-03-25 20:30:04.642+00	2026-03-25 20:30:29.149+00	f
53cb337f-3bb0-4323-968c-6d828e8570d1	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-25 16:52:21.832+00	2026-03-25 16:52:23.812+00	f
ca89c1b0-fc00-4e6f-83e2-e1665d1b2b6c	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-25 16:52:25.685+00	2026-03-25 16:52:26.922+00	f
17144b45-82dc-424b-adcf-7bbcf133599a	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-25 16:52:30.263+00	2026-03-25 16:52:31.288+00	f
afb6ea99-19c2-4bde-ae1a-4b88be5061b7	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-25 16:52:32.47+00	2026-03-25 16:52:33.352+00	f
ea1b1856-c1e2-4daf-9714-9be3fecb26ba	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000039	k6-search-watchlist	2026-03-25 01:31:57.325+00	2026-03-25 01:31:58.374+00	f
b7086358-4d12-4413-908c-1bb9108ed61a	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-25 16:40:16.643+00	2026-03-25 16:40:17.446+00	f
c49fe455-1b9e-44e7-ba2e-71c7acc54046	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-25 16:52:27.674+00	2026-03-25 16:52:30.718+00	f
40566556-2d98-4c13-b4cd-1654a64fc984	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-25 16:52:17.238+00	2026-03-25 16:52:18.439+00	f
f111b628-c043-4434-be55-002a72da4d92	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-24 20:50:29.98+00	2026-03-24 20:50:31.423+00	f
f1ffd904-d69d-45b6-b489-e33d83e4a349	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 16:40:05.684+00	2026-03-25 16:40:06.084+00	f
ec9ea633-f49f-4010-9cc8-fecda18f4c77	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 16:52:11.815+00	2026-03-25 16:52:12.026+00	f
366fab9e-d575-4801-bf40-527a5e902d64	82b2d709-4451-44ea-9076-65097bd7963d	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 05:31:05.15+00	2026-03-25 05:31:05.633+00	f
c95cd47c-f0c0-42b9-8e06-8a93c216ca9a	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-25 01:31:54.465+00	2026-03-25 01:31:55.222+00	f
9d9e0c22-f1c8-4a38-b107-513f5ebc91b6	554fdcea-c6c1-4b73-93cd-8091b3abdd4c	11111111-1111-1111-1111-100000000037	k6-search-watchlist	2026-03-24 20:50:32.322+00	2026-03-24 20:50:32.715+00	f
479a6575-912d-457e-8c3d-34654cf2d820	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-25 16:52:23.716+00	2026-03-25 16:52:24.887+00	f
6c756a4c-1273-45cd-b9a2-bf7def03e206	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000035	k6-search-watchlist	2026-03-25 01:31:54.967+00	2026-03-25 01:31:55.734+00	f
fec33907-76e0-4ab6-a199-f6254ec79384	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-25 16:40:06.757+00	2026-03-25 16:40:08.017+00	f
4c11b258-b963-4ab9-b165-1250a8074744	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 16:52:12.495+00	2026-03-25 16:52:13.012+00	f
eb47149c-358f-4761-9c2f-2faf38fc646b	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-25 16:40:19.075+00	2026-03-25 16:40:20.214+00	f
aec697d0-1d3c-4ff2-83dd-cc7c768cb41d	646a708d-9379-48ae-836d-5a5272ab09ba	11111111-1111-1111-1111-100000000038	k6-search-watchlist	2026-03-25 01:31:56.666+00	2026-03-25 01:31:57.379+00	f
d6ef5dff-c1a9-4241-ba6b-9ea846ca4872	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-25 16:40:14.241+00	2026-03-25 16:40:14.847+00	f
cbdb2861-8a24-4946-8ede-52f68554624b	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-25 16:52:19.646+00	2026-03-25 16:52:21.07+00	f
79eb2efa-bb9b-4d6f-bb54-dac1d64bce6c	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 16:52:15.565+00	2026-03-25 16:52:15.816+00	f
6931e189-6fb3-4037-a7aa-8675d78fbbe7	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-25 16:52:24.741+00	2026-03-25 16:52:25.98+00	f
5497651e-ff00-4624-a5e7-143a64076353	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 16:52:16.117+00	2026-03-25 16:52:16.845+00	f
990c49d9-ed46-414c-bb98-78b0411927d2	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-25 16:40:15.897+00	2026-03-25 16:40:16.756+00	f
b64aeee1-eaaf-41f9-b489-50ad37b2dd45	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-25 16:52:20.614+00	2026-03-25 16:52:22.041+00	f
e24c3078-6645-4416-9da3-360a95b39fbb	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-25 16:40:24.845+00	2026-03-25 16:40:25.161+00	f
2add693b-95ec-4862-8a06-2997c9ae40ec	44abbe07-d0fd-48de-a8bc-4e3a3e5038b9	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-25 16:40:26.108+00	2026-03-25 16:40:26.313+00	f
e4fe4ded-4f19-4d17-8b4a-d48b76fbb5e5	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-25 16:52:26.792+00	2026-03-25 16:52:29.442+00	f
59f0df48-fea6-4552-817f-b443f4f05172	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-25 16:52:31.212+00	2026-03-25 16:52:32.041+00	f
2190c62e-9cd5-4600-873d-c36c86d07a41	e578f15c-a49c-455c-8aab-078d1f550d74	11111111-1111-1111-1111-111111111111	k6	2026-03-25 01:42:32.428+00	2026-03-25 01:42:56.715+00	f
1cb41712-d57d-4e54-afa8-e106d49e70a5	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-25 16:52:31.892+00	2026-03-25 16:52:32.617+00	f
84e39fd4-ee1f-4d02-b01e-45ecaa3491b9	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-25 16:52:33.214+00	2026-03-25 16:52:34.074+00	f
23e05e66-9b0c-406e-a25c-8a7e283c6962	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-25 16:52:35.267+00	2026-03-25 16:52:36.074+00	f
a7dcc68d-030b-4e30-a570-f2589f4304f8	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-25 16:52:34.535+00	2026-03-25 16:52:36.088+00	f
fdf7aa61-9fdf-4665-a725-416b4b17c08b	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 01:43:25.042+00	2026-03-25 01:43:25.445+00	f
f7c44c45-d5a9-4b5d-ba44-7d99e5257177	af124771-e41b-4b01-9efa-33883b06cd3a	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-25 16:52:33.887+00	2026-03-25 16:52:34.771+00	f
2a645b36-bec8-4ea1-8b00-8c75a4fecd34	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-25 01:43:39.092+00	2026-03-25 01:43:40.208+00	f
e79b5049-95df-4e8c-ac8a-dcd1147e47ae	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-25 01:43:30.866+00	2026-03-25 01:43:31.68+00	f
fa9a5bcb-649e-4bc7-872b-bd67f9527062	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-25 01:43:31.402+00	2026-03-25 01:43:32.765+00	f
5181a00c-c940-474a-b76f-c3d8282b3978	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 20:19:03.717+00	2026-03-25 20:19:03.926+00	f
e5f74ea2-2b3d-46d7-8c49-12518e01fcbf	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-25 01:43:33.076+00	2026-03-25 01:43:34.367+00	f
c0372eda-a650-44ac-b382-99236e319e1a	f4177abc-ef17-4f98-93ce-97d7defd8ea5	11111111-1111-1111-1111-111111111111	k6	2026-03-25 20:17:56.288+00	2026-03-25 20:18:21.13+00	f
b42a9562-d919-44c4-9c58-83e39a4c1db4	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-25 01:43:39.625+00	2026-03-25 01:43:41.07+00	f
06656167-45e1-4ad9-8805-54b5bc1b2f32	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 20:19:04.99+00	2026-03-25 20:19:05.31+00	f
9cd601f4-c5fc-4db0-b6db-8f74be81b1be	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 20:19:05.554+00	2026-03-25 20:19:06.083+00	f
351ea64d-4d83-49f8-967b-760b3a4facfc	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 20:19:04.442+00	2026-03-25 20:19:04.539+00	f
6cb46abc-e997-4e4e-900a-bed45264e167	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-25 01:43:40.771+00	2026-03-25 01:43:42.514+00	f
b919569b-ce38-4ac3-a23c-919b334c3a17	b7f9b358-690a-4cab-b767-a1b595593f95	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-25 01:43:48.392+00	2026-03-25 01:43:48.697+00	f
bd019f20-4c70-4571-a1a1-fd8ee3c5418b	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 20:19:06.087+00	2026-03-25 20:19:06.65+00	f
55840089-f9eb-4007-859f-5065c64d22e2	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 20:19:06.603+00	2026-03-25 20:19:07.147+00	f
ad5fcc26-7483-46c0-83eb-1146bbd9d7b9	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-25 20:19:07.094+00	2026-03-25 20:19:08.642+00	f
96b1f591-a236-49fb-a771-ab37a17fc347	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-25 20:19:08.428+00	2026-03-25 20:19:09.417+00	f
134a8efb-7a8e-4797-a873-12cf6257cd42	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-25 20:19:09.275+00	2026-03-25 20:19:10.042+00	f
6dc4c6ea-5f3e-4dde-9df1-2a23a9e1d7a5	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-25 20:19:09.875+00	2026-03-25 20:19:10.827+00	f
c6555335-bcba-48c9-8927-39c66b6b2910	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-25 20:19:10.626+00	2026-03-25 20:19:18.705+00	f
79332bff-55b5-466c-84fe-f4c5ac3c0965	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-25 20:19:11.85+00	2026-03-25 20:19:19.815+00	f
a686cf84-b80e-4c0f-b25d-22fae89b9161	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-25 20:19:19.628+00	2026-03-25 20:19:20.849+00	f
ba1a2420-ad0e-4642-a5e8-c44a08a5f475	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-25 20:19:20.641+00	2026-03-25 20:19:21.616+00	f
7fb72b8e-b8ee-4a35-8b17-22ad198d8e48	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-25 20:19:21.223+00	2026-03-25 20:19:22.137+00	f
7c24e2cf-3632-4b8d-8528-1b863091eb6b	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-25 20:19:21.832+00	2026-03-25 20:19:22.711+00	f
eb864efa-c093-474e-a11d-44f3ebe66394	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-25 20:19:22.298+00	2026-03-25 20:19:23.414+00	f
95bf88b4-26a6-4542-a5da-841dae623022	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-25 20:31:06.842+00	2026-03-25 20:31:08.693+00	f
19748207-e3f1-4f23-8b00-9e27a67c620b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-25 20:30:56.241+00	2026-03-25 20:30:56.443+00	f
1ff2e183-c3d9-4a3c-a3dd-7b0aba127902	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-27 02:52:05.065+00	2026-03-27 02:52:05.692+00	f
f5e23e76-4c07-45c6-b8f3-912e3d66f3e2	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-27 02:51:51.564+00	2026-03-27 02:51:52.858+00	f
690feedd-e18f-4df1-b6e3-e54c369273e1	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-25 20:31:08.274+00	2026-03-25 20:31:09.308+00	f
7191ae10-a150-4cd1-a54d-76b87cf7b124	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-25 20:19:22.865+00	2026-03-25 20:19:24.015+00	f
3e774803-ddcf-4f73-bd90-ddb257f98102	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-25 20:30:57.647+00	2026-03-25 20:30:58.439+00	f
a8a69879-0183-49c2-b7d3-ac73ec178a55	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-25 20:19:23.626+00	2026-03-25 20:19:24.675+00	f
6dbde94d-739a-4f3b-b84d-4b0b5554a90c	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-27 02:51:54.91+00	2026-03-27 02:51:55.252+00	f
b88b7970-c4ad-43e6-9a71-edcfcf7e2887	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-25 20:31:19.706+00	2026-03-25 20:31:20.304+00	f
5e1a8d54-5891-4423-8395-f642c719f193	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-25 20:30:59.664+00	2026-03-25 20:31:00.015+00	f
91bfeb88-e813-409d-85c4-ff20b494a20f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-25 20:31:11.865+00	2026-03-25 20:31:12.212+00	f
559ea192-4d5a-4e82-9b4b-3c519a99259f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-25 20:31:00.263+00	2026-03-25 20:31:00.658+00	f
520c2ba9-2ac8-43c2-a41a-75839d0e9307	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-25 20:19:24.657+00	2026-03-25 20:19:25.93+00	f
5c2018e2-bce0-4b89-8383-7065b95cb212	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-27 02:51:58.866+00	2026-03-27 02:51:59.558+00	f
24e8d531-719d-4e06-84d2-8c19754f606b	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-25 20:19:25.214+00	2026-03-25 20:19:26.841+00	f
d3c420c1-d933-44a0-b912-6cd5128b8c1d	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-25 20:31:01.507+00	2026-03-25 20:31:03.049+00	f
00a0570f-e489-47cd-abf5-d880d6665f32	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-25 20:19:25.848+00	2026-03-25 20:19:27.856+00	f
fd05b0aa-740a-4aac-ac1e-23d1e2d9a220	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-27 02:52:01.471+00	2026-03-27 02:52:03.379+00	f
0889595d-5465-43e2-ab44-00a2bbbbe54e	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-25 20:19:27.654+00	2026-03-25 20:19:29.853+00	f
f803b311-26db-4dcb-a71e-bfc2477e4530	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-25 20:31:05.24+00	2026-03-25 20:31:07.013+00	f
8b38320e-f3c5-47e4-8a80-396bbc7c321b	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-27 02:52:06.755+00	2026-03-27 02:52:07.361+00	f
8e8f093b-97c0-4522-85d2-492887f7e609	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-25 20:31:13.06+00	2026-03-25 20:31:14.806+00	f
b07388bb-15f6-4257-b42b-5a961546c51b	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-25 20:31:20.731+00	2026-03-25 20:31:21.092+00	f
96833744-934c-46cf-8f92-a2cec4b7e4c0	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-27 02:52:07.263+00	2026-03-27 02:52:07.831+00	f
d1855cb8-ff6e-4b77-a23e-43fa8ccd0cfa	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-25 20:31:14.719+00	2026-03-25 20:31:15.501+00	f
e4aadc8a-a72e-438f-8b69-323e2fad2fb6	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-27 02:52:07.763+00	2026-03-27 02:52:08.365+00	f
15b87d0b-cae1-436c-837e-e08a695a13b3	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-25 20:31:15.445+00	2026-03-25 20:31:16.06+00	f
5db7b2d3-476d-413c-b775-732eea3645fc	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-27 02:52:09+00	2026-03-27 02:52:09.721+00	f
bdac3094-8df4-4132-a394-191c80300f10	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-27 03:04:08.476+00	2026-03-27 03:04:09.185+00	f
4fe0def6-d0bb-486f-a82a-c95e24b3e11c	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000035	k6-search-watchlist	2026-03-27 02:52:15.665+00	2026-03-27 02:52:16.365+00	f
52b500b4-115d-4ec8-8997-3f54771f6ec0	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-27 03:04:01.17+00	2026-03-27 03:04:02.663+00	f
f8494e1b-477f-4367-9894-be092173cf48	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000030	k6-search-watchlist	2026-03-27 02:52:11.796+00	2026-03-27 02:52:12.963+00	f
ec19f69d-963b-470d-9743-7f99002072e0	412aa140-1643-4d11-a11c-305b8ef9e818	11111111-1111-1111-1111-111111111111	k6	2026-03-27 03:02:59.075+00	2026-03-27 03:03:22.663+00	f
06a46289-4a37-406f-b354-787686e8c8e0	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-27 03:04:02.465+00	2026-03-27 03:04:03.147+00	f
c401b7e1-4d27-4eb4-8df4-0c1e76d8e501	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000034	k6-search-watchlist	2026-03-27 02:52:14.932+00	2026-03-27 02:52:16.178+00	f
efcce0ac-c104-419e-92f7-908c4362ed0f	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000013	k6-search-watchlist	2026-03-27 03:04:03.932+00	2026-03-27 03:04:04.342+00	f
c9c636a1-cdac-417a-8f50-46a9bac65f94	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-27 03:04:03.197+00	2026-03-27 03:04:03.71+00	f
82aec12b-1c54-42f1-ae29-deaa273ea4f5	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-27 03:04:10.329+00	2026-03-27 03:04:11.562+00	f
00a37558-90e2-41e7-9ace-a343a86f6e79	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-27 03:04:04.547+00	2026-03-27 03:04:04.833+00	f
4d3dddc1-fe1a-47ec-8faa-e281884a9342	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-27 03:04:09.24+00	2026-03-27 03:04:09.633+00	f
ea2d524e-84ac-4507-9bbe-18bb2ccd2aef	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-27 03:04:11.567+00	2026-03-27 03:04:12.567+00	f
529c75d6-f97c-4807-b518-0e5ee4e6eb37	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-25 20:31:20.267+00	2026-03-25 20:31:20.767+00	f
da493f91-f602-4309-bffe-98c0018e699a	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-25 20:19:24.09+00	2026-03-25 20:19:25.298+00	f
967aed8e-426f-4ab1-969b-a6aac845eb10	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-25 20:30:56.852+00	2026-03-25 20:30:57.054+00	f
07b463dc-d980-4a4b-81db-ca7cca0f6b58	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-27 03:03:50.958+00	2026-03-27 03:03:51.659+00	f
e663995b-4bd4-430b-9ac2-f0fa64b67334	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-25 20:19:26.647+00	2026-03-25 20:19:29.243+00	f
79270ba8-9054-4af4-ad01-e9f5a25aef06	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-25 20:31:00.737+00	2026-03-25 20:31:01.496+00	f
e67388b2-72d3-4e44-b39c-c595841439d1	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-27 03:03:57.233+00	2026-03-27 03:03:57.813+00	f
2d5bde4b-c624-404d-be17-229b0a951f99	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-25 20:19:29.249+00	2026-03-25 20:19:30.688+00	f
4fb244ee-5482-4dff-9423-d52e8f7812f7	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-25 20:31:04.444+00	2026-03-25 20:31:05.445+00	f
fe02b497-ffce-41ca-9ecd-838ffaaa6336	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-27 03:04:00.17+00	2026-03-27 03:04:01.471+00	f
70bff278-7a95-4b38-9103-ccfbacb65eac	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000022	k6-search-watchlist	2026-03-27 03:04:12.664+00	2026-03-27 03:04:13.568+00	f
15f95613-85c5-43d1-b9e2-2552b6c427aa	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-25 20:31:11.402+00	2026-03-25 20:31:11.714+00	f
05aff2bd-a838-4d00-83c8-198c1541610a	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-27 03:04:06.192+00	2026-03-27 03:04:08.162+00	f
dd805c9d-3dcd-4a22-ae19-70647ea8cd04	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-25 20:31:16.536+00	2026-03-25 20:31:17.845+00	f
86eb9911-1ebe-4fe9-a771-5e03512e0530	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-25 20:31:17.112+00	2026-03-25 20:31:18.707+00	f
8c4aade5-ffae-452b-a2e6-737014fd6b31	8d510357-3cb0-4aaa-a263-3a09a582496c	11111111-1111-1111-1111-111111111111	k6	2026-03-27 02:50:42.47+00	2026-03-27 02:51:06.886+00	f
41ff952b-e8ee-44ac-8850-312a81f0a145	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000017	k6-search-watchlist	2026-03-27 02:52:03.056+00	2026-03-27 02:52:04.373+00	f
834d735c-c1cf-4ae0-b66f-846d393a7127	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-27 02:51:56.405+00	2026-03-27 02:51:56.912+00	f
465b6528-2efa-43fc-b90a-97ec5e0212d5	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000010	k6-search-watchlist	2026-03-27 02:51:56.938+00	2026-03-27 02:51:57.458+00	f
763d9e4c-6f1c-4f62-be37-119b7101946a	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000012	k6-search-watchlist	2026-03-27 02:51:58.061+00	2026-03-27 02:51:58.67+00	f
7c58a95e-540d-4b58-8041-e67059daa6d2	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000020	k6-search-watchlist	2026-03-27 02:52:05.639+00	2026-03-27 02:52:06.33+00	f
af44c157-0d38-4049-b07d-1382151974d7	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000028	k6-search-watchlist	2026-03-27 02:52:10.359+00	2026-03-27 02:52:11.362+00	f
1924d406-003b-44c4-bb96-a6d244ebb43d	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000032	k6-search-watchlist	2026-03-27 02:52:13.273+00	2026-03-27 02:52:14.863+00	f
eee499bf-4eee-4133-ae20-be9dfe7b2b65	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000033	k6-search-watchlist	2026-03-27 02:52:14.173+00	2026-03-27 02:52:15.659+00	f
b3c2a904-8a9d-464c-a442-9ba306197043	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-27 02:51:49.164+00	2026-03-27 02:51:49.572+00	f
4d2bec57-e130-4eab-a3b4-0277c0dc340a	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-25 20:30:59.048+00	2026-03-25 20:30:59.316+00	f
cae32d99-190a-4620-bb06-5e8d46f72764	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-27 03:03:52.764+00	2026-03-27 03:03:53.058+00	f
1f10a087-8f5d-4da0-a238-3d95a1662c19	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-25 20:19:30.354+00	2026-03-25 20:19:31.319+00	f
31958e94-e937-4508-b105-d518b3f408a8	b23dee18-605a-4cd3-8d2f-7184c7c77020	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-25 20:19:30.91+00	2026-03-25 20:19:31.325+00	f
1aef2b45-1915-4523-8d04-c2880dd5e965	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000006	k6-search-watchlist	2026-03-27 03:03:57.896+00	2026-03-27 03:03:58.57+00	f
34ae03a6-704b-43cb-b7d6-e8839e500a3e	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-27 02:51:50.069+00	2026-03-27 02:51:51.162+00	f
618bb6dc-b41b-4ece-9f1d-515dae111f63	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-25 20:31:02.896+00	2026-03-25 20:31:03.699+00	f
9cbb8bf3-8522-4a6c-9af6-5ca4f5422ec2	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-27 03:03:53.668+00	2026-03-27 03:03:55.385+00	f
0460b243-8dc6-4ed1-8104-e6fe37fd9f57	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-25 20:31:15.95+00	2026-03-25 20:31:16.621+00	f
a2b42546-f763-4b83-8906-87777fc2ef0e	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-27 02:51:55.894+00	2026-03-27 02:51:56.345+00	f
12b7b7f9-2a26-4371-a7e9-9996c6604fff	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000009	k6-search-watchlist	2026-03-25 20:31:03.645+00	2026-03-25 20:31:04.494+00	f
9a4577c1-13e3-4777-ac30-9e9b4db96348	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-27 02:51:52.964+00	2026-03-27 02:51:53.719+00	f
f0d9ca1b-2209-425c-a62e-f2f1dc9a6fc7	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000003	k6-search-watchlist	2026-03-27 03:03:55.705+00	2026-03-27 03:03:56.264+00	f
72e04350-2abf-4cde-9b93-0eca239914cb	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-25 20:31:09.536+00	2026-03-25 20:31:09.886+00	f
8b708d07-0d60-4f64-a95e-88baeb5ec2e9	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-27 02:51:53.759+00	2026-03-27 02:51:54.264+00	f
1f91d176-331b-4976-b1a8-a8c0c516134b	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000004	k6-search-watchlist	2026-03-27 03:03:56.573+00	2026-03-27 03:03:57.107+00	f
f5e6a272-c3b0-40b5-a12f-bd4f76c75a8f	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-27 03:03:58.815+00	2026-03-27 03:03:59.261+00	f
4b5d4187-239f-4a8a-9b80-ebfc508a399e	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-25 20:31:10.22+00	2026-03-25 20:31:10.508+00	f
4b25ae04-753d-4f23-b457-1dcca79d3133	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-27 03:04:05.094+00	2026-03-27 03:04:06.35+00	f
dd1e6baa-4a3f-44b9-bcdb-c3ecbd40717e	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000026	k6-search-watchlist	2026-03-25 20:31:18.62+00	2026-03-25 20:31:19.28+00	f
8a1c17fa-c2a7-4b2d-b5c7-0d94cf3a7b3d	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000005	k6-search-watchlist	2026-03-27 02:51:54.363+00	2026-03-27 02:51:54.804+00	f
ae81f76d-9dfd-4b96-aeeb-9831cb987810	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000016	k6-search-watchlist	2026-03-25 20:31:10.873+00	2026-03-25 20:31:11.137+00	f
a9e6971a-aa22-4e82-bb39-2b2eb9a1ccc9	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000008	k6-search-watchlist	2026-03-27 03:03:59.362+00	2026-03-27 03:04:00.162+00	f
f846a5c5-9fdf-443c-9ae2-bb50eedad0db	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000023	k6-search-watchlist	2026-03-27 03:04:13.572+00	2026-03-27 03:04:14.986+00	f
9d33dcb8-0833-4094-a015-97869e0a3e43	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000007	k6-search-watchlist	2026-03-27 02:51:55.405+00	2026-03-27 02:51:55.765+00	f
b839773d-54e0-4f89-bfe5-1f622096889f	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-25 20:31:12.279+00	2026-03-25 20:31:13.848+00	f
bb01cca4-8e7f-40a2-b373-bf70e52ec19f	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000011	k6-search-watchlist	2026-03-27 02:51:57.509+00	2026-03-27 02:51:57.992+00	f
f251038b-21ea-4956-b36c-979ad80c5d35	39a3ba6f-6195-41cc-ae9a-0b7a78f422ee	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-25 20:31:19.143+00	2026-03-25 20:31:19.751+00	f
b76ad9bb-82e4-4c88-a1b6-20a918f837fb	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000019	k6-search-watchlist	2026-03-27 03:04:09.689+00	2026-03-27 03:04:10.359+00	f
01877f65-3f8c-4d8b-b9c7-a13deecec223	6082b8c3-ea19-4184-a121-b42039f8e52a	11111111-1111-1111-1111-100000000024	k6-search-watchlist	2026-03-27 03:04:14.862+00	2026-03-27 03:04:15.563+00	f
98ba8cef-3613-4448-8f62-728f2137739d	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000014	k6-search-watchlist	2026-03-27 02:51:59.564+00	2026-03-27 02:52:00.076+00	f
9585ebd9-71d0-4fa3-8067-374ca1f7b507	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000018	k6-search-watchlist	2026-03-27 02:52:04.379+00	2026-03-27 02:52:05.078+00	f
8c76d907-070e-48b6-9c51-a586a9a449fa	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000015	k6-search-watchlist	2026-03-27 02:52:00.087+00	2026-03-27 02:52:01.573+00	f
7baa58e5-4c79-4d37-b7bf-d2df36c6c288	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000021	k6-search-watchlist	2026-03-27 02:52:06.225+00	2026-03-27 02:52:06.838+00	f
1592db76-15dd-467d-9682-88796674c725	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000025	k6-search-watchlist	2026-03-27 02:52:08.297+00	2026-03-27 02:52:09.026+00	f
1a145651-d276-4018-af98-f1f5c9d27aa7	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000027	k6-search-watchlist	2026-03-27 02:52:09.658+00	2026-03-27 02:52:10.462+00	f
7fa83064-d26a-4492-8516-5e7086435835	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000029	k6-search-watchlist	2026-03-27 02:52:11.06+00	2026-03-27 02:52:11.975+00	f
d96a2476-9780-4808-b958-1b8056b7715c	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000031	k6-search-watchlist	2026-03-27 02:52:12.675+00	2026-03-27 02:52:13.968+00	f
8a8937a2-134b-43d7-a1a2-6567493dcf64	f0cbd21e-f352-4890-8b93-c69e8344d22f	11111111-1111-1111-1111-100000000036	k6-search-watchlist	2026-03-27 02:52:16.286+00	2026-03-27 02:52:16.406+00	f
\.


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: bookings no_overlapping_bookings; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.bookings
    ADD CONSTRAINT no_overlapping_bookings EXCLUDE USING gist (listing_id WITH =, daterange(start_date, end_date, '[]'::text) WITH &&) WHERE ((status = ANY (ARRAY['confirmed'::booking.booking_status, 'pending_confirmation'::booking.booking_status])));


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- Name: watchlist_items watchlist_items_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.watchlist_items
    ADD CONSTRAINT watchlist_items_pkey PRIMARY KEY (id);


--
-- Name: idx_booking_landlord; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_landlord ON booking.bookings USING btree (landlord_id, created_at DESC);


--
-- Name: idx_booking_listing_status; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_listing_status ON booking.bookings USING btree (listing_id, status);


--
-- Name: idx_booking_outbox_unpublished; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_outbox_unpublished ON booking.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_booking_status_dates; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_status_dates ON booking.bookings USING btree (status, start_date);


--
-- Name: idx_booking_tenant; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_tenant ON booking.bookings USING btree (tenant_id, created_at DESC);


--
-- Name: idx_bookings_listing_id; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_bookings_listing_id ON booking.bookings USING btree (listing_id);


--
-- Name: idx_bookings_status; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_bookings_status ON booking.bookings USING btree (status);


--
-- Name: idx_bookings_tenant_id; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_bookings_tenant_id ON booking.bookings USING btree (tenant_id);


--
-- Name: idx_search_history_user_created; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_search_history_user_created ON booking.search_history USING btree (user_id, created_at DESC);


--
-- Name: idx_watchlist_user_active_added; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_watchlist_user_active_added ON booking.watchlist_items USING btree (user_id, is_active, added_at DESC);


--
-- Name: ux_watchlist_user_listing; Type: INDEX; Schema: booking; Owner: -
--

CREATE UNIQUE INDEX ux_watchlist_user_listing ON booking.watchlist_items USING btree (user_id, listing_id);


--
-- Name: bookings tr_booking_state_transition; Type: TRIGGER; Schema: booking; Owner: -
--

CREATE TRIGGER tr_booking_state_transition BEFORE UPDATE ON booking.bookings FOR EACH ROW EXECUTE FUNCTION booking.enforce_booking_transition();


--
-- Name: bookings tr_booking_updated_at; Type: TRIGGER; Schema: booking; Owner: -
--

CREATE TRIGGER tr_booking_updated_at BEFORE UPDATE ON booking.bookings FOR EACH ROW EXECUTE FUNCTION booking.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict rcQF2PjcnH2NVzaTUzM8WDXl6KlNfYPZWngWSYNf26EfZKE8woCY5CuC4wqJWkc

