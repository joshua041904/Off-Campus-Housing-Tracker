--
-- PostgreSQL database dump
--

\restrict U4a3sJaFUD69dLo7CmIrUhLpd1O0bbtUoB3T1IIi9zGlr6LbdT3cfVitwelLLFl

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: listings; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA listings;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: listing_status; Type: TYPE; Schema: listings; Owner: -
--

CREATE TYPE listings.listing_status AS ENUM (
    'active',
    'paused',
    'closed',
    'flagged'
);


--
-- Name: norm_text(text); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.norm_text(t text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  SELECT lower(trim(regexp_replace(coalesce(trim(t), ''), '\s+', ' ', 'g')));
$$;


--
-- Name: search_listings_fuzzy_count(uuid, text, bigint); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.search_listings_fuzzy_count(p_user_id uuid, p_q text, p_lim bigint DEFAULT 50) RETURNS bigint
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  SELECT count(*)::bigint FROM listings.search_listings_fuzzy_ids(p_user_id, p_q, p_lim::integer);
$$;


--
-- Name: FUNCTION search_listings_fuzzy_count(p_user_id uuid, p_q text, p_lim bigint); Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON FUNCTION listings.search_listings_fuzzy_count(p_user_id uuid, p_q text, p_lim bigint) IS 'Returns count of fuzzy search results for pgbench.';


--
-- Name: search_listings_fuzzy_ids(uuid, text, integer); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.search_listings_fuzzy_ids(p_user_id uuid, p_q text, p_lim integer DEFAULT 50) RETURNS TABLE(listing_id uuid)
    LANGUAGE plpgsql STABLE PARALLEL SAFE
    AS $$
DECLARE
  qn text;
BEGIN
  qn := listings.norm_text(coalesce(p_q, ''));
  IF qn = '' THEN
    RETURN QUERY SELECT l.id FROM listings.listings l
      WHERE l.user_id = p_user_id AND l.status = 'active' AND l.deleted_at IS NULL
      ORDER BY l.created_at DESC LIMIT p_lim;
    RETURN;
  END IF;
  RETURN QUERY
  SELECT l.id
  FROM listings.listings l
  WHERE l.user_id = p_user_id
    AND l.status = 'active'
    AND l.deleted_at IS NULL
    AND l.search_norm % qn
  ORDER BY similarity(l.search_norm, qn) DESC
  LIMIT p_lim;
END;
$$;


--
-- Name: FUNCTION search_listings_fuzzy_ids(p_user_id uuid, p_q text, p_lim integer); Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON FUNCTION listings.search_listings_fuzzy_ids(p_user_id uuid, p_q text, p_lim integer) IS 'Trigram fuzzy search on search_norm for pgbench and API.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  ELSIF TG_OP = 'INSERT' AND (NEW.version IS NULL OR NEW.version < 1) THEN
    NEW.version := 1;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: sync_search_norm(); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.sync_search_norm() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.search_norm := lower(trim(coalesce(NEW.title, '') || ' ' || coalesce(NEW.description, '')));
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: listing_media; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.listing_media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    media_type text NOT NULL,
    url_or_path text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT listing_media_media_type_check CHECK ((media_type = ANY (ARRAY['image'::text, 'video'::text])))
);


--
-- Name: listings; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.listings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    username_display text,
    title text,
    listed_at date NOT NULL,
    price_cents integer NOT NULL,
    lease_length_months integer,
    size_sqft integer,
    description text,
    amenities jsonb DEFAULT '[]'::jsonb,
    smoke_free boolean DEFAULT true NOT NULL,
    pet_friendly boolean DEFAULT false NOT NULL,
    furnished boolean,
    effective_from date NOT NULL,
    effective_until date,
    status listings.listing_status DEFAULT 'active'::listings.listing_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    latitude double precision,
    longitude double precision,
    version integer DEFAULT 1 NOT NULL,
    search_norm text,
    listing_code text
);


--
-- Name: TABLE listings; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.listings IS 'Housing listings; user_id references auth.users.id on auth DB (5441). Trust: listing service consumes listing.flagged Kafka event and sets status=flagged (no cross-DB write).';


--
-- Name: COLUMN listings.listed_at; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.listed_at IS 'Listing date (mm-dd-yyyy).';


--
-- Name: COLUMN listings.price_cents; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.price_cents IS 'Rent in cents to avoid float.';


--
-- Name: COLUMN listings.lease_length_months; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.lease_length_months IS 'Lease length in months if fixed.';


--
-- Name: COLUMN listings.effective_from; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.effective_from IS 'When the listing becomes active.';


--
-- Name: COLUMN listings.effective_until; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.effective_until IS 'When the listing stops being effective (NULL = no end).';


--
-- Name: COLUMN listings.deleted_at; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.deleted_at IS 'Soft delete; preserve for analytics. All reads filter deleted_at IS NULL.';


--
-- Name: COLUMN listings.latitude; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.latitude IS 'Location: latitude (distance-from-campus, map).';


--
-- Name: COLUMN listings.longitude; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.longitude IS 'Location: longitude.';


--
-- Name: COLUMN listings.version; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.version IS 'Optimistic lock; increment on update.';


--
-- Name: outbox_events; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.processed_events IS 'Idempotent consumer: before handling event, INSERT event_id; ON CONFLICT DO NOTHING skip; else process then commit offset. Kafka is at-least-once.';


--
-- Data for Name: listing_media; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.listing_media (id, listing_id, media_type, url_or_path, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.listings (id, user_id, username_display, title, listed_at, price_cents, lease_length_months, size_sqft, description, amenities, smoke_free, pet_friendly, furnished, effective_from, effective_until, status, created_at, updated_at, deleted_at, latitude, longitude, version, search_norm, listing_code) FROM stdin;
93366ea6-8920-4749-a571-3f26d21f2b53	19fd3e4a-815f-4a0a-9774-05762066c132	\N	Quiet studio e2e-1774324305029	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	\N	2026-03-24	\N	active	2026-03-24 03:51:45.899+00	2026-03-24 03:51:45.899+00	\N	\N	\N	1	quiet studio e2e-1774324305029 near campus, laundry in unit.	\N
4633b9e4-4af5-4bd4-86c4-832e2d3a8f53	2e74d5f2-a62e-4148-848a-1c2815a2d4fa	\N	Quiet studio e2e-1774324563200	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	\N	2026-03-24	\N	active	2026-03-24 03:56:03.945555+00	2026-03-24 03:56:03.945555+00	\N	\N	\N	1	quiet studio e2e-1774324563200 near campus, laundry in unit.	\N
9e06a9a5-c7e4-46aa-a84c-84cfc3c40b93	23ea79d7-5bac-4ca9-937e-14b1ba417f1e	\N	Quiet studio e2e-1774324572878	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	\N	2026-03-24	\N	active	2026-03-24 03:56:13.737275+00	2026-03-24 03:56:13.737275+00	\N	\N	\N	1	quiet studio e2e-1774324572878 near campus, laundry in unit.	\N
5f8efde9-c057-4580-a810-d7bcbe6fb41f	e0d2bfe5-3205-4056-968a-e7f0e1e09207	\N	Quiet studio e2e-1774325114759	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	\N	2026-03-24	\N	active	2026-03-24 04:05:19.77707+00	2026-03-24 04:05:19.77707+00	\N	\N	\N	1	quiet studio e2e-1774325114759 near campus, laundry in unit.	\N
9c761547-20a7-4002-90e1-2f8216a4b52f	c5eda15f-4756-43b2-8bb7-15109d5b131e	\N	Map test 1774328628019	2026-03-24	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-24	\N	active	2026-03-24 05:03:48.842155+00	2026-03-24 05:03:48.842155+00	\N	42.391	-72.527	1	map test 1774328628019 near campus with parking.	\N
ab8976aa-212d-4514-9dbb-bf70902e90c8	38b2ec19-2164-4361-9b2e-51f44f0801c7	\N	Pet e2e 1774328628857	2026-03-24	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-24	\N	active	2026-03-24 05:03:49.113654+00	2026-03-24 05:03:49.113654+00	\N	\N	\N	1	pet e2e 1774328628857 cats ok.	\N
f425c5d3-6957-4b5b-8fe5-62f5b69fa803	5b8d876c-1559-4607-8c33-7bd360d0927c	\N	Map test 1774328704042	2026-03-24	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-24	\N	active	2026-03-24 05:05:04.401811+00	2026-03-24 05:05:04.401811+00	\N	42.391	-72.527	1	map test 1774328704042 near campus with parking.	\N
3e1dfef1-2727-4e6f-b1f5-20a4f64af7a6	a477dfd8-1efd-4c8a-a7d7-11c9df54de43	\N	Pet e2e 1774328704596	2026-03-24	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-24	\N	active	2026-03-24 05:05:04.744745+00	2026-03-24 05:05:04.744745+00	\N	\N	\N	1	pet e2e 1774328704596 cats ok.	\N
9724a1f7-76c4-4ce1-9a3a-b6c780c80fb0	bc24ad18-e3bb-4318-a557-746d18f8d93e	\N	Quiet studio e2e-1774329139522	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-24	\N	active	2026-03-24 05:12:27.565846+00	2026-03-24 05:12:27.565846+00	\N	\N	\N	1	quiet studio e2e-1774329139522 near campus, laundry in unit.	\N
88644f95-7a3a-4188-af49-4eeae5ca38c4	8ff79cd7-2511-4415-8de6-f7ae817e0f8b	\N	Map test 1774329148706	2026-03-24	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-24	\N	active	2026-03-24 05:12:29.342654+00	2026-03-24 05:12:29.342654+00	\N	42.391	-72.527	1	map test 1774329148706 near campus with parking.	\N
d5304d57-e395-40a8-943c-b4636500f5ed	107cf0db-53db-4feb-aeae-044b3e9a8ab2	\N	Pet e2e 1774329152312	2026-03-24	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-24	\N	active	2026-03-24 05:12:32.688071+00	2026-03-24 05:12:32.688071+00	\N	\N	\N	1	pet e2e 1774329152312 cats ok.	\N
e4edb9f1-0f77-439a-9aed-2715ed4eb5e2	411f3543-4577-4e4f-a838-00373def4e88	\N	Map test 1774375865352	2026-03-24	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-24	\N	active	2026-03-24 18:11:06.022998+00	2026-03-24 18:11:06.022998+00	\N	42.391	-72.527	1	map test 1774375865352 near campus with parking.	\N
5534bcde-ffb6-40d2-b107-e329dc5059e6	cb1666e0-10a7-4b4f-8d1e-336885c3ae2d	\N	Quiet studio e2e-1774375862169	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-24	\N	active	2026-03-24 18:11:06.601064+00	2026-03-24 18:11:06.601064+00	\N	\N	\N	1	quiet studio e2e-1774375862169 near campus, laundry in unit.	\N
3df44279-75d4-4f05-9b63-1c44f0fe0702	09bdcb4a-061d-44ba-a68a-2c37d752910c	\N	Pet e2e 1774375869034	2026-03-24	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-24	\N	active	2026-03-24 18:11:09.881292+00	2026-03-24 18:11:09.881292+00	\N	\N	\N	1	pet e2e 1774375869034 cats ok.	\N
d010e1a3-0fff-477a-ad8d-5fcae61125a3	be5497d1-fdbe-41dd-910e-8f6f0bf47f4f	\N	Quiet studio e2e-1774377737582	2026-03-24	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-24	\N	active	2026-03-24 18:42:21.43292+00	2026-03-24 18:42:21.43292+00	\N	\N	\N	1	quiet studio e2e-1774377737582 near campus, laundry in unit.	\N
099cc879-3fc6-4c2b-ab17-b2e8e74553bd	68b987e2-2dc0-4a23-ab6c-b0fff9202c3f	\N	Map test 1774377741556	2026-03-24	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-24	\N	active	2026-03-24 18:42:21.888263+00	2026-03-24 18:42:21.888263+00	\N	42.391	-72.527	1	map test 1774377741556 near campus with parking.	\N
b478827f-45ad-48d4-af58-515be79a7809	dda4403f-bb72-4527-83e5-a8eecc8cfca5	\N	Pet e2e 1774377743601	2026-03-24	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-24	\N	active	2026-03-24 18:42:23.944306+00	2026-03-24 18:42:23.944306+00	\N	\N	\N	1	pet e2e 1774377743601 cats ok.	\N
82ff4ed0-c090-49f9-bb22-3a12c73d9d7e	1cb388e5-5e05-40c5-bcbb-afabfa47500f	\N	Quiet studio e2e-1774403517867	2026-03-25	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-25	\N	active	2026-03-25 01:52:04.926558+00	2026-03-25 01:52:04.926558+00	\N	\N	\N	1	quiet studio e2e-1774403517867 near campus, laundry in unit.	\N
6507d4d7-3919-410d-90c7-31e67c56acc0	61d6ce19-8d41-498d-804e-9a9302896d57	\N	Map test 1774403522306	2026-03-25	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-25	\N	active	2026-03-25 01:52:08.408262+00	2026-03-25 01:52:08.408262+00	\N	42.391	-72.527	1	map test 1774403522306 near campus with parking.	\N
8328fcf1-1d22-40dd-a2ac-cafdf261b75b	42f17812-0477-477e-a954-15b327686cee	\N	Pet e2e 1774403527763	2026-03-25	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-25	\N	active	2026-03-25 01:52:08.559074+00	2026-03-25 01:52:08.559074+00	\N	\N	\N	1	pet e2e 1774403527763 cats ok.	\N
7c362051-bd2e-4ceb-b3d7-cb215d53cb26	87a18af1-cdec-4c78-89a9-aeaed382e605	\N	Quiet studio e2e-1774446854032	2026-03-25	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-25	\N	active	2026-03-25 13:54:20.626479+00	2026-03-25 13:54:20.626479+00	\N	\N	\N	1	quiet studio e2e-1774446854032 near campus, laundry in unit.	\N
486efe34-1fed-4b63-a545-713b52f9c8bc	dae8c640-345f-436f-a34f-7f186616bbd9	\N	Map test 1774446861669	2026-03-25	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-25	\N	active	2026-03-25 13:54:22.814028+00	2026-03-25 13:54:22.814028+00	\N	42.391	-72.527	1	map test 1774446861669 near campus with parking.	\N
935475c7-7b09-4c8d-b70a-6ade05d9e23d	f2c84026-4467-4014-bdcb-26ea9352d5a7	\N	Pet e2e 1774446866152	2026-03-25	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-25	\N	active	2026-03-25 13:54:26.666756+00	2026-03-25 13:54:26.666756+00	\N	\N	\N	1	pet e2e 1774446866152 cats ok.	\N
5af46a93-001f-4683-a505-f151982dac75	6fd15f70-1ae7-4d57-9ae1-c74e18f086f6	\N	Quiet studio e2e-1774458027845	2026-03-25	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-25	\N	active	2026-03-25 17:00:50.541297+00	2026-03-25 17:00:50.541297+00	\N	\N	\N	1	quiet studio e2e-1774458027845 near campus, laundry in unit.	\N
13b9ab8a-f826-420b-94b1-3638ad52f854	3a557ec0-08d2-4fd7-996e-c530d3e06c91	\N	Pet e2e 1774458065812	2026-03-25	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-25	\N	active	2026-03-25 17:01:12.247452+00	2026-03-25 17:01:12.247452+00	\N	\N	\N	1	pet e2e 1774458065812 cats ok.	\N
5aaee4dd-6777-425d-8f95-54b10ce17bbb	adc5c468-2cdb-4f46-8495-b28f95a248fd	\N	Quiet studio e2e-1774471164859	2026-03-25	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-25	\N	active	2026-03-25 20:39:29.115973+00	2026-03-25 20:39:29.115973+00	\N	\N	\N	1	quiet studio e2e-1774471164859 near campus, laundry in unit.	\N
df2cd329-4af7-4854-a288-a883e7e68131	fd3fabb8-dc7f-4b24-8123-13204b549d8c	\N	Map test 1774471167697	2026-03-25	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-25	\N	active	2026-03-25 20:39:29.301148+00	2026-03-25 20:39:29.301148+00	\N	42.391	-72.527	1	map test 1774471167697 near campus with parking.	\N
f3a78eed-32b8-49f4-a95b-02c12d2e1644	fe59154b-242b-4f95-9d54-d43a1a1b5b58	\N	Pet e2e 1774471171456	2026-03-25	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-25	\N	active	2026-03-25 20:39:31.823414+00	2026-03-25 20:39:31.823414+00	\N	\N	\N	1	pet e2e 1774471171456 cats ok.	\N
b5cd3371-5fc1-4f25-928c-3e2d62b31fae	c3baeddd-c486-486a-88ee-24243eef72b1	\N	Map test 1774581155735	2026-03-27	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-03-27	\N	active	2026-03-27 03:12:44.401356+00	2026-03-27 03:12:44.401356+00	\N	42.391	-72.527	1	map test 1774581155735 near campus with parking.	\N
bf0f3fcb-5386-4e26-8448-99ece3884bcf	20fba4bc-c00e-4fec-8603-8f8fa9729a44	\N	Quiet studio e2e-1774581149147	2026-03-27	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-03-27	\N	active	2026-03-27 03:12:50.486424+00	2026-03-27 03:12:50.486424+00	\N	\N	\N	1	quiet studio e2e-1774581149147 near campus, laundry in unit.	\N
4751f539-c2b8-4e24-8470-4b7bbf426d77	56753e05-4f52-4912-9daa-a4f4434c5d14	\N	Pet e2e 1774581169697	2026-03-27	120000	\N	\N	Cats ok.	[]	t	t	f	2026-03-27	\N	active	2026-03-27 03:12:52.329729+00	2026-03-27 03:12:52.329729+00	\N	\N	\N	1	pet e2e 1774581169697 cats ok.	\N
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.processed_events (event_id, processed_at) FROM stdin;
\.


--
-- Name: listing_media listing_media_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listing_media
    ADD CONSTRAINT listing_media_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: idx_listing_media_listing_id; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listing_media_listing_id ON listings.listing_media USING btree (listing_id);


--
-- Name: idx_listings_active_created_desc; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_active_created_desc ON listings.listings USING btree (created_at DESC) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_active_effective; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_active_effective ON listings.listings USING btree (effective_from, effective_until, price_cents) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_amenities_gin; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_amenities_gin ON listings.listings USING gin (amenities);


--
-- Name: idx_listings_effective_dates; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_effective_dates ON listings.listings USING btree (effective_from, effective_until);


--
-- Name: idx_listings_lat_lon; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_lat_lon ON listings.listings USING btree (latitude, longitude) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_listing_code; Type: INDEX; Schema: listings; Owner: -
--

CREATE UNIQUE INDEX idx_listings_listing_code ON listings.listings USING btree (listing_code) WHERE (listing_code IS NOT NULL);


--
-- Name: idx_listings_listing_code_hash; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_listing_code_hash ON listings.listings USING hash (listing_code) WHERE (listing_code IS NOT NULL);


--
-- Name: idx_listings_outbox_unpublished; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_outbox_unpublished ON listings.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_listings_price_effective; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_price_effective ON listings.listings USING btree (price_cents, effective_from);


--
-- Name: idx_listings_search_norm_gin; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_search_norm_gin ON listings.listings USING gin (search_norm public.gin_trgm_ops);


--
-- Name: idx_listings_smoke_pet; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_smoke_pet ON listings.listings USING btree (smoke_free, pet_friendly) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_status_effective_until; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_status_effective_until ON listings.listings USING btree (status, effective_until) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_user_created; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_user_created ON listings.listings USING btree (user_id, created_at DESC);


--
-- Name: listings tr_listings_sync_search_norm; Type: TRIGGER; Schema: listings; Owner: -
--

CREATE TRIGGER tr_listings_sync_search_norm BEFORE INSERT OR UPDATE OF title, description ON listings.listings FOR EACH ROW EXECUTE FUNCTION listings.sync_search_norm();


--
-- Name: listings tr_listings_updated_at; Type: TRIGGER; Schema: listings; Owner: -
--

CREATE TRIGGER tr_listings_updated_at BEFORE UPDATE ON listings.listings FOR EACH ROW EXECUTE FUNCTION listings.set_updated_at();


--
-- Name: listing_media listing_media_listing_id_fkey; Type: FK CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listing_media
    ADD CONSTRAINT listing_media_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings.listings(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict U4a3sJaFUD69dLo7CmIrUhLpd1O0bbtUoB3T1IIi9zGlr6LbdT3cfVitwelLLFl

