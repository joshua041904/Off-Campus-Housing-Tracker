--
-- PostgreSQL database dump
--

\restrict EzbBIvuxJkSH3eYcQYvXI67B18AQkT8YAcR5mbtRtRkcz54iCc781DeQlMr0sJE

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: listings; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA listings;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: listing_status; Type: TYPE; Schema: listings; Owner: -
--

CREATE TYPE listings.listing_status AS ENUM (
    'active',
    'paused',
    'closed',
    'flagged'
);


--
-- Name: norm_text(text); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.norm_text(t text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  SELECT lower(trim(regexp_replace(coalesce(trim(t), ''), '\s+', ' ', 'g')));
$$;


--
-- Name: search_listings_fuzzy_count(uuid, text, bigint); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.search_listings_fuzzy_count(p_user_id uuid, p_q text, p_lim bigint DEFAULT 50) RETURNS bigint
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  SELECT count(*)::bigint FROM listings.search_listings_fuzzy_ids(p_user_id, p_q, p_lim::integer);
$$;


--
-- Name: FUNCTION search_listings_fuzzy_count(p_user_id uuid, p_q text, p_lim bigint); Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON FUNCTION listings.search_listings_fuzzy_count(p_user_id uuid, p_q text, p_lim bigint) IS 'Returns count of fuzzy search results for pgbench.';


--
-- Name: search_listings_fuzzy_ids(uuid, text, integer); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.search_listings_fuzzy_ids(p_user_id uuid, p_q text, p_lim integer DEFAULT 50) RETURNS TABLE(listing_id uuid)
    LANGUAGE plpgsql STABLE PARALLEL SAFE
    AS $$
DECLARE
  qn text;
BEGIN
  qn := listings.norm_text(coalesce(p_q, ''));
  IF qn = '' THEN
    RETURN QUERY SELECT l.id FROM listings.listings l
      WHERE l.user_id = p_user_id AND l.status = 'active' AND l.deleted_at IS NULL
      ORDER BY l.created_at DESC LIMIT p_lim;
    RETURN;
  END IF;
  RETURN QUERY
  SELECT l.id
  FROM listings.listings l
  WHERE l.user_id = p_user_id
    AND l.status = 'active'
    AND l.deleted_at IS NULL
    AND l.search_norm % qn
  ORDER BY similarity(l.search_norm, qn) DESC
  LIMIT p_lim;
END;
$$;


--
-- Name: FUNCTION search_listings_fuzzy_ids(p_user_id uuid, p_q text, p_lim integer); Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON FUNCTION listings.search_listings_fuzzy_ids(p_user_id uuid, p_q text, p_lim integer) IS 'Trigram fuzzy search on search_norm for pgbench and API.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  ELSIF TG_OP = 'INSERT' AND (NEW.version IS NULL OR NEW.version < 1) THEN
    NEW.version := 1;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: sync_search_norm(); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.sync_search_norm() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.search_norm := lower(trim(coalesce(NEW.title, '') || ' ' || coalesce(NEW.description, '')));
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: listing_media; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.listing_media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    media_type text NOT NULL,
    url_or_path text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT listing_media_media_type_check CHECK ((media_type = ANY (ARRAY['image'::text, 'video'::text])))
);


--
-- Name: listings; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.listings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    username_display text,
    title text,
    listed_at date NOT NULL,
    price_cents integer NOT NULL,
    lease_length_months integer,
    size_sqft integer,
    description text,
    amenities jsonb DEFAULT '[]'::jsonb,
    smoke_free boolean DEFAULT true NOT NULL,
    pet_friendly boolean DEFAULT false NOT NULL,
    furnished boolean,
    effective_from date NOT NULL,
    effective_until date,
    status listings.listing_status DEFAULT 'active'::listings.listing_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    latitude double precision,
    longitude double precision,
    version integer DEFAULT 1 NOT NULL,
    search_norm text,
    listing_code text
);


--
-- Name: TABLE listings; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.listings IS 'Housing listings; user_id references auth.users.id on auth DB (5441). Trust: listing service consumes listing.flagged Kafka event and sets status=flagged (no cross-DB write).';


--
-- Name: COLUMN listings.listed_at; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.listed_at IS 'Listing date (mm-dd-yyyy).';


--
-- Name: COLUMN listings.price_cents; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.price_cents IS 'Rent in cents to avoid float.';


--
-- Name: COLUMN listings.lease_length_months; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.lease_length_months IS 'Lease length in months if fixed.';


--
-- Name: COLUMN listings.effective_from; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.effective_from IS 'When the listing becomes active.';


--
-- Name: COLUMN listings.effective_until; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.effective_until IS 'When the listing stops being effective (NULL = no end).';


--
-- Name: COLUMN listings.deleted_at; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.deleted_at IS 'Soft delete; preserve for analytics. All reads filter deleted_at IS NULL.';


--
-- Name: COLUMN listings.latitude; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.latitude IS 'Location: latitude (distance-from-campus, map).';


--
-- Name: COLUMN listings.longitude; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.longitude IS 'Location: longitude.';


--
-- Name: COLUMN listings.version; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.version IS 'Optimistic lock; increment on update.';


--
-- Name: outbox_events; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.processed_events IS 'Idempotent consumer: before handling event, INSERT event_id; ON CONFLICT DO NOTHING skip; else process then commit offset. Kafka is at-least-once.';


--
-- Data for Name: listing_media; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.listing_media (id, listing_id, media_type, url_or_path, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.listings (id, user_id, username_display, title, listed_at, price_cents, lease_length_months, size_sqft, description, amenities, smoke_free, pet_friendly, furnished, effective_from, effective_until, status, created_at, updated_at, deleted_at, latitude, longitude, version, search_norm, listing_code) FROM stdin;
bb31efc9-d029-48be-93df-fd3d4ec75df4	33333333-3333-4333-8333-333333333333	\N	grpc-it-1774818697468	2026-03-29	199000	\N	\N	grpc integration	["wifi"]	t	f	f	2026-08-01	\N	active	2026-03-29 21:11:37.601517+00	2026-03-29 21:11:37.601517+00	\N	\N	\N	1	grpc-it-1774818697468 grpc integration	\N
afaa46ea-df31-498a-8744-e863654e7d2e	22222222-2222-4222-8222-222222222222	\N	Integration http-it-1774818702095	2026-03-29	250000	\N	\N	supertest + live Postgres	["parking"]	t	f	t	2026-07-01	\N	active	2026-03-29 21:11:42.326798+00	2026-03-29 21:11:42.326798+00	\N	\N	\N	1	integration http-it-1774818702095 supertest + live postgres	\N
571ea9a8-d6b8-4585-998c-6943b2253c7b	a738ea17-952d-4b04-b945-1cf62cd5d870	\N	Quiet studio e2e-1775148616063	2026-04-02	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-04-02	\N	active	2026-04-02 16:50:23.364953+00	2026-04-02 16:50:23.364953+00	\N	\N	\N	1	quiet studio e2e-1775148616063 near campus, laundry in unit.	\N
cb3c69fc-5472-471a-b1a1-adce749dc602	8e571065-a208-49df-a748-0b30dc7109b2	\N	Map test 1775148624961	2026-04-02	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-04-02	\N	active	2026-04-02 16:50:25.300045+00	2026-04-02 16:50:25.300045+00	\N	42.391	-72.527	1	map test 1775148624961 near campus with parking.	\N
8b5575eb-c9b7-4518-9523-336b5a096d43	3d5426a3-26a7-455d-ab4e-e850cb2e2ea3	\N	Pet e2e 1775148639915	2026-04-02	120000	\N	\N	Cats ok.	[]	t	t	f	2026-04-02	\N	active	2026-04-02 16:50:41.886598+00	2026-04-02 16:50:41.886598+00	\N	\N	\N	1	pet e2e 1775148639915 cats ok.	\N
aa9cbaba-87aa-4613-b428-e0b10f2443dd	05b56e24-98c9-42d2-8a38-daa48bc96f45	\N	Integrity suite sysint-1775148656980	2026-04-02	120000	\N	\N	Cross-service E2E path.	[]	t	f	f	2026-04-02	\N	active	2026-04-02 16:51:01.11276+00	2026-04-02 16:51:01.11276+00	\N	\N	\N	1	integrity suite sysint-1775148656980 cross-service e2e path.	\N
0ea3f922-057e-43f2-bb22-d8214af91e27	c727f598-56e9-46b8-8e11-05c44b7e2d3c	\N	Quiet studio e2e-1775159336341	2026-04-02	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-04-02	\N	active	2026-04-02 19:49:00.707312+00	2026-04-02 19:49:00.707312+00	\N	\N	\N	1	quiet studio e2e-1775159336341 near campus, laundry in unit.	\N
6d09d27a-68e9-490a-a504-e233f40d787a	e501fce8-ac79-407c-914b-d298ef4994d8	\N	Map test 1775159341375	2026-04-02	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-04-02	\N	active	2026-04-02 19:49:02.25888+00	2026-04-02 19:49:02.25888+00	\N	42.391	-72.527	1	map test 1775159341375 near campus with parking.	\N
bff25836-d0dd-4504-8437-1295aac5e21f	07b3f0c5-2878-4cf8-a23b-e523bf1a7f04	\N	Pet e2e 1775159351837	2026-04-02	120000	\N	\N	Cats ok.	[]	t	t	f	2026-04-02	\N	active	2026-04-02 19:49:12.753853+00	2026-04-02 19:49:12.753853+00	\N	\N	\N	1	pet e2e 1775159351837 cats ok.	\N
31a82671-d478-4942-8f52-e020cb3217b8	8c008efc-755f-4122-a81e-039ffc40cccf	\N	Integrity suite sysint-1775159360870	2026-04-02	120000	\N	\N	Cross-service E2E path.	[]	t	f	f	2026-04-02	\N	active	2026-04-02 19:49:21.731113+00	2026-04-02 19:49:21.731113+00	\N	\N	\N	1	integrity suite sysint-1775159360870 cross-service e2e path.	\N
fc03fc06-34f0-4087-9c35-dcd515629c06	3307a410-7a66-42a1-9972-911e91151bd1	\N	Quiet studio e2e-1775237757354	2026-04-03	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-04-03	\N	active	2026-04-03 17:36:01.657718+00	2026-04-03 17:36:01.657718+00	\N	\N	\N	1	quiet studio e2e-1775237757354 near campus, laundry in unit.	\N
744cfff8-d3a4-43e1-b169-07fd8ba89cc2	e0ac579c-d748-4241-bddb-3688da4bf353	\N	Map test 1775237760613	2026-04-03	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-04-03	\N	active	2026-04-03 17:36:01.704981+00	2026-04-03 17:36:01.704981+00	\N	42.391	-72.527	1	map test 1775237760613 near campus with parking.	\N
729bc88b-6fcd-492d-8568-bfab8efd75e2	74040b02-8359-4193-ba8a-85a79b84a1bf	\N	Pet e2e 1775237771743	2026-04-03	120000	\N	\N	Cats ok.	[]	t	t	f	2026-04-03	\N	active	2026-04-03 17:36:12.227944+00	2026-04-03 17:36:12.227944+00	\N	\N	\N	1	pet e2e 1775237771743 cats ok.	\N
519866a7-d966-4cbf-bf12-05e0277954c6	dae02d42-2558-4bbe-87d4-04b9dc8e7d08	\N	Integrity suite sysint-1775237781982	2026-04-03	120000	\N	\N	Cross-service E2E path.	[]	t	f	f	2026-04-03	\N	active	2026-04-03 17:36:23.233308+00	2026-04-03 17:36:23.233308+00	\N	\N	\N	1	integrity suite sysint-1775237781982 cross-service e2e path.	\N
f44bcd05-c442-4486-8a58-359f2551f203	1de5af4c-890f-4795-a7cb-2b5381e98012	\N	Quiet studio e2e-1775249733595	2026-04-03	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-04-03	\N	active	2026-04-03 20:55:39.38998+00	2026-04-03 20:55:39.38998+00	\N	\N	\N	1	quiet studio e2e-1775249733595 near campus, laundry in unit.	\N
d0e6317e-3cab-4b92-9965-1973a9c27eca	6e29a3f8-9d8d-4bd8-99b5-1203d02ad2d4	\N	Map test 1775249745813	2026-04-03	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-04-03	\N	active	2026-04-03 20:55:48.022587+00	2026-04-03 20:55:48.022587+00	\N	42.391	-72.527	1	map test 1775249745813 near campus with parking.	\N
70465624-1d7a-470c-bf06-9d4e405f5476	2e6f59e0-5dcb-4aae-9105-f2186a35f5e1	\N	Pet e2e 1775249762048	2026-04-03	120000	\N	\N	Cats ok.	[]	t	t	f	2026-04-03	\N	active	2026-04-03 20:56:03.809939+00	2026-04-03 20:56:03.809939+00	\N	\N	\N	1	pet e2e 1775249762048 cats ok.	\N
92d5f744-785b-4e31-af56-2f83b15b2dd5	18d234a0-521f-44f7-8565-6e90473d875d	\N	Integrity suite sysint-1775249775276	2026-04-03	120000	\N	\N	Cross-service E2E path.	[]	t	f	f	2026-04-03	\N	active	2026-04-03 20:56:17.622267+00	2026-04-03 20:56:17.622267+00	\N	\N	\N	1	integrity suite sysint-1775249775276 cross-service e2e path.	\N
84e80551-435a-4e4e-a882-cc1b730a5057	cf779af3-74c4-412e-8f5d-ff4f57f12ff0	\N	Quiet studio e2e-1775279556434	2026-04-04	110000	\N	\N	Near campus, laundry in unit.	[]	t	f	f	2026-04-04	\N	active	2026-04-04 05:12:40.314338+00	2026-04-04 05:12:40.314338+00	\N	\N	\N	1	quiet studio e2e-1775279556434 near campus, laundry in unit.	\N
804a42d3-7270-4d53-bbdd-cb4e49264f7e	c73b1935-2139-49da-b1dd-6c04e250509c	\N	Map test 1775279561740	2026-04-04	95000	\N	\N	Near campus with parking.	["garage"]	t	f	f	2026-04-04	\N	active	2026-04-04 05:12:42.556488+00	2026-04-04 05:12:42.556488+00	\N	42.391	-72.527	1	map test 1775279561740 near campus with parking.	\N
82bcea10-2054-4bef-bbcc-358a497b77e5	a571eba8-ffdd-469f-b75e-ad29961c5b7e	\N	Pet e2e 1775279571676	2026-04-04	120000	\N	\N	Cats ok.	[]	t	t	f	2026-04-04	\N	active	2026-04-04 05:12:52.812816+00	2026-04-04 05:12:52.812816+00	\N	\N	\N	1	pet e2e 1775279571676 cats ok.	\N
785dd86c-cb7e-4b9f-8c38-657c2f5ff285	53ab663e-eb51-415c-ae22-3d4d35469899	\N	Integrity suite sysint-1775279585497	2026-04-04	120000	\N	\N	Cross-service E2E path.	[]	t	f	f	2026-04-04	\N	active	2026-04-04 05:13:07.987384+00	2026-04-04 05:13:07.987384+00	\N	\N	\N	1	integrity suite sysint-1775279585497 cross-service e2e path.	\N
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.processed_events (event_id, processed_at) FROM stdin;
\.


--
-- Name: listing_media listing_media_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listing_media
    ADD CONSTRAINT listing_media_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: idx_listing_media_listing_id; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listing_media_listing_id ON listings.listing_media USING btree (listing_id);


--
-- Name: idx_listings_active_created_desc; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_active_created_desc ON listings.listings USING btree (created_at DESC) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_active_effective; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_active_effective ON listings.listings USING btree (effective_from, effective_until, price_cents) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_amenities_gin; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_amenities_gin ON listings.listings USING gin (amenities);


--
-- Name: idx_listings_effective_dates; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_effective_dates ON listings.listings USING btree (effective_from, effective_until);


--
-- Name: idx_listings_lat_lon; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_lat_lon ON listings.listings USING btree (latitude, longitude) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_listing_code; Type: INDEX; Schema: listings; Owner: -
--

CREATE UNIQUE INDEX idx_listings_listing_code ON listings.listings USING btree (listing_code) WHERE (listing_code IS NOT NULL);


--
-- Name: idx_listings_listing_code_hash; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_listing_code_hash ON listings.listings USING hash (listing_code) WHERE (listing_code IS NOT NULL);


--
-- Name: idx_listings_outbox_unpublished; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_outbox_unpublished ON listings.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_listings_price_effective; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_price_effective ON listings.listings USING btree (price_cents, effective_from);


--
-- Name: idx_listings_search_norm_gin; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_search_norm_gin ON listings.listings USING gin (search_norm public.gin_trgm_ops);


--
-- Name: idx_listings_smoke_pet; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_smoke_pet ON listings.listings USING btree (smoke_free, pet_friendly) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_status_effective_until; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_status_effective_until ON listings.listings USING btree (status, effective_until) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_user_created; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_user_created ON listings.listings USING btree (user_id, created_at DESC);


--
-- Name: listings tr_listings_sync_search_norm; Type: TRIGGER; Schema: listings; Owner: -
--

CREATE TRIGGER tr_listings_sync_search_norm BEFORE INSERT OR UPDATE OF title, description ON listings.listings FOR EACH ROW EXECUTE FUNCTION listings.sync_search_norm();


--
-- Name: listings tr_listings_updated_at; Type: TRIGGER; Schema: listings; Owner: -
--

CREATE TRIGGER tr_listings_updated_at BEFORE UPDATE ON listings.listings FOR EACH ROW EXECUTE FUNCTION listings.set_updated_at();


--
-- Name: listing_media listing_media_listing_id_fkey; Type: FK CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listing_media
    ADD CONSTRAINT listing_media_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings.listings(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict EzbBIvuxJkSH3eYcQYvXI67B18AQkT8YAcR5mbtRtRkcz54iCc781DeQlMr0sJE

