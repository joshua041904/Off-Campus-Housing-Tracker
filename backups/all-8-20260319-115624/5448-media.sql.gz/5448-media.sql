--
-- PostgreSQL database dump
--

\restrict e4T5I8JUaZueUzi7ObT628SdQKP9pBpXVZJggBLjo2hFmF1K2hLmR9ciXGKUZ1A

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: media; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA media;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: media; Owner: -
--

CREATE FUNCTION media.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: media_files; Type: TABLE; Schema: media; Owner: -
--

CREATE TABLE media.media_files (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    object_key text NOT NULL,
    filename text NOT NULL,
    content_type text NOT NULL,
    size_bytes bigint NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT media_files_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'uploaded'::text, 'failed'::text])))
);


--
-- Name: TABLE media_files; Type: COMMENT; Schema: media; Owner: -
--

COMMENT ON TABLE media.media_files IS 'Metadata only; file bytes in object storage. status: pending (presigned URL issued), uploaded (CompleteUpload verified), failed.';


--
-- Name: outbox_events; Type: TABLE; Schema: media; Owner: -
--

CREATE TABLE media.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: media; Owner: -
--

COMMENT ON TABLE media.outbox_events IS 'Outbox: after upload verified, insert MediaUploadedV1; publisher sends EventEnvelope to ${ENV_PREFIX}.media.events; key = aggregate_id (media_id).';


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: media; Owner: -
--

COPY media.media_files (id, user_id, object_key, filename, content_type, size_bytes, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: media; Owner: -
--

COPY media.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: media; Owner: -
--

ALTER TABLE ONLY media.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: media; Owner: -
--

ALTER TABLE ONLY media.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: idx_media_outbox_unpublished; Type: INDEX; Schema: media; Owner: -
--

CREATE INDEX idx_media_outbox_unpublished ON media.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_media_status; Type: INDEX; Schema: media; Owner: -
--

CREATE INDEX idx_media_status ON media.media_files USING btree (status);


--
-- Name: idx_media_user_id; Type: INDEX; Schema: media; Owner: -
--

CREATE INDEX idx_media_user_id ON media.media_files USING btree (user_id);


--
-- Name: media_files tr_media_files_updated; Type: TRIGGER; Schema: media; Owner: -
--

CREATE TRIGGER tr_media_files_updated BEFORE UPDATE ON media.media_files FOR EACH ROW EXECUTE FUNCTION media.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict e4T5I8JUaZueUzi7ObT628SdQKP9pBpXVZJggBLjo2hFmF1K2hLmR9ciXGKUZ1A

