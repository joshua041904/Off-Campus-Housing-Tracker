--
-- PostgreSQL database dump
--

\restrict r8Y9WVkpipiFDxw3MeEZqAWeSZ0PQWASrM7W7zuMFw4qwXs4wz7hpTXUmdgOjBD

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: forum; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA forum;


--
-- Name: messages; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA messages;


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: forum; Owner: -
--

CREATE FUNCTION forum.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: update_comment_count(); Type: FUNCTION; Schema: forum; Owner: -
--

CREATE FUNCTION forum.update_comment_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum.posts SET comment_count = comment_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum.posts SET comment_count = GREATEST(0, comment_count - 1) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: update_comment_votes(); Type: FUNCTION; Schema: forum; Owner: -
--

CREATE FUNCTION forum.update_comment_votes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.vote_type = 'up' THEN
      UPDATE forum.comments SET upvotes = upvotes + 1 WHERE id = NEW.comment_id;
    ELSE
      UPDATE forum.comments SET downvotes = downvotes + 1 WHERE id = NEW.comment_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.vote_type = 'up' THEN
      UPDATE forum.comments SET upvotes = GREATEST(0, upvotes - 1) WHERE id = OLD.comment_id;
    ELSE
      UPDATE forum.comments SET downvotes = GREATEST(0, downvotes - 1) WHERE id = OLD.comment_id;
    END IF;
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.vote_type = 'up' AND NEW.vote_type = 'down' THEN
      UPDATE forum.comments SET upvotes = GREATEST(0, upvotes - 1), downvotes = downvotes + 1 WHERE id = NEW.comment_id;
    ELSIF OLD.vote_type = 'down' AND NEW.vote_type = 'up' THEN
      UPDATE forum.comments SET downvotes = GREATEST(0, downvotes - 1), upvotes = upvotes + 1 WHERE id = NEW.comment_id;
    END IF;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: update_post_votes(); Type: FUNCTION; Schema: forum; Owner: -
--

CREATE FUNCTION forum.update_post_votes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.vote_type = 'up' THEN
      UPDATE forum.posts SET upvotes = upvotes + 1 WHERE id = NEW.post_id;
    ELSE
      UPDATE forum.posts SET downvotes = downvotes + 1 WHERE id = NEW.post_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.vote_type = 'up' THEN
      UPDATE forum.posts SET upvotes = GREATEST(0, upvotes - 1) WHERE id = OLD.post_id;
    ELSE
      UPDATE forum.posts SET downvotes = GREATEST(0, downvotes - 1) WHERE id = OLD.post_id;
    END IF;
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    -- Handle vote change (up -> down or down -> up)
    IF OLD.vote_type = 'up' AND NEW.vote_type = 'down' THEN
      UPDATE forum.posts SET upvotes = GREATEST(0, upvotes - 1), downvotes = downvotes + 1 WHERE id = NEW.post_id;
    ELSIF OLD.vote_type = 'down' AND NEW.vote_type = 'up' THEN
      UPDATE forum.posts SET downvotes = GREATEST(0, downvotes - 1), upvotes = upvotes + 1 WHERE id = NEW.post_id;
    END IF;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;


--
-- Name: set_thread_id(); Type: FUNCTION; Schema: messages; Owner: -
--

CREATE FUNCTION messages.set_thread_id() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- If this is a reply, set thread_id to the parent's thread_id (or parent's id if parent has no thread_id)
  IF NEW.parent_message_id IS NOT NULL THEN
    SELECT COALESCE(thread_id, id) INTO NEW.thread_id
    FROM messages.messages
    WHERE id = NEW.parent_message_id;
  ELSE
    -- If this is a new message, thread_id is its own id
    NEW.thread_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: messages; Owner: -
--

CREATE FUNCTION messages.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: update_message_read(); Type: FUNCTION; Schema: messages; Owner: -
--

CREATE FUNCTION messages.update_message_read() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE messages.messages
  SET is_read = TRUE
  WHERE id = NEW.message_id AND (recipient_id = NEW.user_id OR group_id IS NOT NULL);
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: comment_attachments; Type: TABLE; Schema: forum; Owner: -
--

CREATE TABLE forum.comment_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    file_url text NOT NULL,
    file_path text,
    thumbnail_url text,
    file_name character varying(512),
    file_size bigint,
    mime_type character varying(128),
    file_type character varying(32) NOT NULL,
    width integer,
    height integer,
    duration integer,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT comment_attachments_file_type_check CHECK (((file_type)::text = ANY (ARRAY[('image'::character varying)::text, ('video'::character varying)::text, ('audio'::character varying)::text, ('document'::character varying)::text, ('other'::character varying)::text])))
);


--
-- Name: comment_votes; Type: TABLE; Schema: forum; Owner: -
--

CREATE TABLE forum.comment_votes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    vote_type character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT comment_votes_vote_type_check CHECK (((vote_type)::text = ANY (ARRAY[('up'::character varying)::text, ('down'::character varying)::text])))
);


--
-- Name: comments; Type: TABLE; Schema: forum; Owner: -
--

CREATE TABLE forum.comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    parent_id uuid,
    content text NOT NULL,
    upvotes integer DEFAULT 0 NOT NULL,
    downvotes integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: post_attachments; Type: TABLE; Schema: forum; Owner: -
--

CREATE TABLE forum.post_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    file_url text NOT NULL,
    file_path text,
    thumbnail_url text,
    file_name character varying(512),
    file_size bigint,
    mime_type character varying(128),
    file_type character varying(32) NOT NULL,
    width integer,
    height integer,
    duration integer,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT post_attachments_file_type_check CHECK (((file_type)::text = ANY (ARRAY[('image'::character varying)::text, ('video'::character varying)::text, ('audio'::character varying)::text, ('document'::character varying)::text, ('other'::character varying)::text])))
);


--
-- Name: post_votes; Type: TABLE; Schema: forum; Owner: -
--

CREATE TABLE forum.post_votes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    vote_type character varying(8) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT post_votes_vote_type_check CHECK (((vote_type)::text = ANY (ARRAY[('up'::character varying)::text, ('down'::character varying)::text])))
);


--
-- Name: posts; Type: TABLE; Schema: forum; Owner: -
--

CREATE TABLE forum.posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title character varying(512) NOT NULL,
    content text NOT NULL,
    flair character varying(64) DEFAULT 'Discussion'::character varying NOT NULL,
    upload_type character varying(32) DEFAULT 'text'::character varying NOT NULL,
    upvotes integer DEFAULT 0 NOT NULL,
    downvotes integer DEFAULT 0 NOT NULL,
    comment_count integer DEFAULT 0 NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    is_locked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT posts_upload_type_check CHECK (((upload_type)::text = ANY (ARRAY[('text'::character varying)::text, ('image'::character varying)::text, ('video'::character varying)::text, ('link'::character varying)::text, ('poll'::character varying)::text])))
)
WITH (autovacuum_vacuum_scale_factor='0.1', autovacuum_analyze_scale_factor='0.05');


--
-- Name: group_bans; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.group_bans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid NOT NULL,
    user_id uuid NOT NULL,
    banned_by uuid NOT NULL,
    reason text,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: group_members; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.group_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(16) DEFAULT 'member'::character varying NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    left_at timestamp with time zone,
    CONSTRAINT group_members_role_check CHECK (((role)::text = ANY (ARRAY[('owner'::character varying)::text, ('admin'::character varying)::text, ('moderator'::character varying)::text, ('contributor'::character varying)::text, ('member'::character varying)::text, ('read_only'::character varying)::text])))
);


--
-- Name: COLUMN group_members.left_at; Type: COMMENT; Schema: messages; Owner: -
--

COMMENT ON COLUMN messages.group_members.left_at IS 'When user left; NULL = still in group. Re-join = new row or left_at cleared per policy';


--
-- Name: groups; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(256) NOT NULL,
    description text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    archived boolean DEFAULT false NOT NULL
);


--
-- Name: message_attachments; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.message_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    file_url text NOT NULL,
    file_path text,
    thumbnail_url text,
    file_name character varying(512),
    file_size bigint,
    mime_type character varying(128),
    file_type character varying(32) NOT NULL,
    width integer,
    height integer,
    duration integer,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT message_attachments_file_type_check CHECK (((file_type)::text = ANY (ARRAY[('image'::character varying)::text, ('video'::character varying)::text, ('audio'::character varying)::text, ('document'::character varying)::text, ('sticker'::character varying)::text, ('other'::character varying)::text])))
);


--
-- Name: message_reads; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.message_reads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    read_at timestamp with time zone DEFAULT now() NOT NULL,
    read_by_sender boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE message_reads; Type: COMMENT; Schema: messages; Owner: -
--

COMMENT ON TABLE messages.message_reads IS 'Per-recipient read receipt; read_by_sender = true when sender sees that recipient read it.';


--
-- Name: messages; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sender_id uuid NOT NULL,
    recipient_id uuid,
    group_id uuid,
    parent_message_id uuid,
    thread_id uuid,
    message_type character varying(32) DEFAULT 'General'::character varying NOT NULL,
    subject character varying(512),
    content text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    sender_display_name character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    recalled_at timestamp with time zone,
    archived boolean DEFAULT false NOT NULL,
    CONSTRAINT messages_check CHECK ((((recipient_id IS NOT NULL) AND (group_id IS NULL)) OR ((recipient_id IS NULL) AND (group_id IS NOT NULL))))
)
WITH (autovacuum_vacuum_scale_factor='0.1', autovacuum_analyze_scale_factor='0.05');


--
-- Name: TABLE messages; Type: COMMENT; Schema: messages; Owner: -
--

COMMENT ON TABLE messages.messages IS 'WhatsApp-style: 1:1 (recipient_id) or group (group_id). content supports emoji; read state in message_reads. sender_display_name from auth.';


--
-- Name: COLUMN messages.sender_display_name; Type: COMMENT; Schema: messages; Owner: -
--

COMMENT ON COLUMN messages.messages.sender_display_name IS 'Denormalized from auth for display; can be synced from auth.users or profile.';


--
-- Name: user_archived_threads; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.user_archived_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    archived_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_deleted_threads; Type: TABLE; Schema: messages; Owner: -
--

CREATE TABLE messages.user_deleted_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    thread_id uuid NOT NULL,
    deleted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: comment_attachments; Type: TABLE DATA; Schema: forum; Owner: -
--

COPY forum.comment_attachments (id, comment_id, file_url, file_path, thumbnail_url, file_name, file_size, mime_type, file_type, width, height, duration, display_order, created_at) FROM stdin;
00a266e3-e2c9-4407-8aa1-820485e130e4	a8b87227-09cb-4667-9ee8-2cb3bb31ce22	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-27 08:39:14.312481+00
695ef191-e3b7-400c-bb1b-7ea116c47efa	09a8e93e-b7b0-4c67-bf6e-a22352598a3b	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-27 09:10:40.18308+00
66caa96d-55c7-4b1c-b206-11b48dbbff37	a3b89c03-6588-44df-ac48-81c9f47aa947	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-27 09:42:49.666064+00
23b8d34c-4a20-428a-8a16-d6d11b478f76	1f503e8f-353f-4814-9954-2aeb6d27031e	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-27 21:15:40.678472+00
72780909-7e03-4c9e-bdf3-98fcc65c9151	22421a7c-f0a6-4969-8eb1-fe4d9710cc66	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 02:02:10.24451+00
82ac6b6a-5273-4e6c-869d-95e06dcad8dc	d32b1fc0-1d4c-47d4-8dfc-195d211b6408	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 02:39:07.56548+00
3995074b-891f-422e-96a2-79f46b62df9e	60dfb432-5475-40f3-8ae1-4807c70afdf4	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 06:02:50.107854+00
fba56edb-4f4f-455f-88e5-12e4301c5376	0ff1cd5b-03b8-4c83-8de1-94e7643da751	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 06:50:16.480223+00
867f3f82-ea25-413d-9fb6-4fb24ebb3204	17fcf234-91fc-4a28-8772-9c146c22ef39	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 07:57:53.154333+00
258f0161-dd8e-4a5c-a4fd-6e19c619ea44	ebc690a3-ee00-4265-9f67-c78f2274329f	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 08:42:26.762176+00
7802aba1-e665-439d-9480-99c12ed4bf5c	43aab0d1-c168-444c-a50f-380d814dc7fa	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 09:12:15.465775+00
5516a5b2-1471-443e-9685-2ce12e9979e8	4d875f85-2ef8-4d1e-8fe8-a549e6ea4c95	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 09:33:47.60289+00
684db468-e7b7-4480-8621-3ab8d17bc870	8baa178b-89e8-4483-b435-57a59b3b62a7	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-02-28 10:18:14.814617+00
752fe185-5de8-4f24-b31f-21bf66a945d6	58653e89-4dc2-4cca-af55-57aa505aea6a	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 02:39:37.10732+00
762eb8c3-a3d9-4b87-882a-e283447044e3	9fa57481-a877-412e-b14f-cd76bf42c224	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 03:20:26.796571+00
fe3651f7-bfd8-4644-91cd-b40cc42a275c	1be7bf1c-e916-4f9d-b324-4061772efbea	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 04:02:48.466477+00
d2f6c6d3-7460-4744-bee2-4b4ba88b3713	182bd719-b681-4cf1-a2d3-26a056a5f81a	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 04:45:01.517795+00
407358c7-db33-4d29-bb87-f392945100c0	f534e814-2dc3-4e91-9d82-64d42169d95a	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 05:49:39.859962+00
bf60a980-aad8-4847-9b85-203cfaa4e6ba	e851fbeb-01df-45bf-8bfa-3b46cfd844f1	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 06:27:40.402161+00
42cc33a8-0a80-4135-b0d1-c27a33075c14	d879b979-c55e-411b-9f50-6c82d8155d76	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 07:10:59.050366+00
b17f3dd1-3dac-4e2c-870a-f0f16b7d0d21	2d0a9130-7bd6-48f6-a07a-9f67fee8ea61	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 08:22:45.589078+00
042b80c8-6e27-4a09-8b8b-e7718bde1e77	06849244-3442-44d0-8d08-f514ec21f77f	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 08:52:26.525899+00
cab6b202-34db-42ee-a742-1aaa3faab54e	47289520-6d6b-4bac-b4ce-db224645bbe6	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 09:25:09.257546+00
80dc830c-7f84-41fc-930e-a2d45c59d505	ca63c976-afd0-4c65-81eb-da76aa44f50a	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 20:43:16.357249+00
259b24ce-5408-43c4-906c-14f56f03aa53	86354cc9-7d14-4840-b76a-dd9bd1dc7cb1	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-01 22:04:14.448711+00
b84c3ced-1fee-4209-b459-406aef5b73ec	0d0cbaa4-b328-4ab9-9ac2-d556c52a87e9	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 00:29:37.417025+00
5b87fc48-64d6-43ea-abb5-d87324883ee5	da8b99a8-0c48-42ef-8dd0-b9283df34b83	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 01:23:33.632902+00
79f2107a-a102-4e66-a1b9-0d142565ef2b	1a27ca42-1639-40c5-a19a-73dc3a8aa10d	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 10:19:12.78841+00
e392193e-86a4-4aed-87f3-950983de6cff	7f852790-78cf-4fe2-b108-b751ac320b31	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 12:43:46.574815+00
51bd2d59-7b6f-4a51-8b88-6d049cba9583	433eb8d5-3b1e-49d8-8837-ad61be5ac94a	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 13:17:14.127851+00
a0308cc5-33b0-48f7-9c0d-d01868e40ef9	a9eaaaf8-b8c2-4139-a42e-734c7b0320f6	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 14:21:09.133933+00
d4ebb7a2-7c35-462f-90d5-24c11137478f	ac4868c0-4298-4411-a229-4eaa3e2dda39	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 15:11:07.217133+00
2100683d-ae31-456a-b96a-28ce41f77ce8	f3fa1ca1-6696-4dec-b227-d2bc1da8fba3	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-02 20:33:21.485033+00
5cc3c66a-ebfd-4941-bf12-71b2a7fbd287	33f46de0-c89b-4388-b7ee-d03f6321232b	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-03 00:16:09.906772+00
f66b3645-ccff-4e9e-9b83-74d396571258	4d3aa0ac-000a-486e-9b80-96c952a619a5	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-03 00:55:05.270144+00
2506ad80-7109-4526-96d9-345686b1a8e8	5b9d197c-e83d-49c1-b1b0-f293579b95b4	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-03 02:09:55.310424+00
a0bc66f4-0bb6-495e-ad49-e216be9d886f	63e5442e-2bbe-45de-a5ab-bf3b2cf17483	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-03 05:11:34.679237+00
5ea82bb0-31b6-4c67-8c20-3ca8f3545d83	d0316676-38c2-49a4-8d0b-631562aa63e6	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-03 06:18:05.333532+00
c119ebff-cf52-49ac-9b2f-6824e2745f9f	736440a9-97c5-404c-8fd2-59e89add5997	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-03 16:13:36.619004+00
d5e2d7db-1b82-4763-a12e-fd0d710a1290	ab47548f-e3a2-4efc-8e17-013663e19373	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-04 09:50:12.932076+00
49645b26-aaf5-4659-9afe-041476e9e7c1	e1341f21-a08a-4368-956c-b5130f73bac3	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-04 16:20:39.722238+00
8b6ad29b-b4a5-43de-b2d7-a2b3446a2f0b	cca0923b-067e-4c46-9b7a-005f11ba7b2f	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-04 23:16:25.778433+00
b9fe0d6c-0089-478b-b147-ad2b721e8dca	525657b8-658c-40d6-9e88-8cf68d8baac5	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 02:05:01.912035+00
af538711-c3dd-487e-be42-0a58fe2cedf9	e807c87b-b9ae-4171-a0f0-f1f59dfeaa1b	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 03:22:26.966686+00
ae397014-576e-4b8e-99fe-470ee9bd402e	fdc096fb-a2d0-4786-86ab-00edf1b29040	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 04:11:56.134656+00
cf12404d-694f-43bf-88c4-f1162ff85822	a5fef55c-951e-444b-9d57-ede75364ba8d	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 05:22:04.719095+00
cf0394fa-d003-4631-ad20-42721f54183a	de455734-9485-436f-ac47-216e8ff50652	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 07:31:40.570282+00
478c053e-6a0e-4a2f-8617-2ef1904e6af2	941ebd45-99ec-4373-9321-6f8dbfdc10c0	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 07:56:21.044589+00
6c3fdcb7-7574-4595-aaed-ad326b320959	a84f691e-cca2-421a-b66b-b3560685269f	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 08:33:33.777872+00
58add6c2-7510-4272-9e8c-e5f655419b52	fc8ab64f-32e9-4fe9-b90b-ec95a3a58274	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 09:02:08.68991+00
f31cc7b6-2c40-4ba8-8b44-b1229d931a56	ace68f25-c8b7-4821-817f-f7d81e17b6f7	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 09:40:22.935962+00
83c88889-e77f-443f-b238-796f80cc4565	aed2ac53-8835-4be9-b693-ce8d57113136	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 11:41:26.049895+00
4deb7d68-776c-4f57-936b-a224ce396049	2e52d18d-f89c-4c11-b4c0-75908b144f0a	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 15:28:50.250207+00
cdcaf850-c8db-4029-9229-6738e3ab2cad	94de8fab-4dcc-4f18-a1dc-4989bdafab83	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-05 22:42:13.303195+00
8b23a787-286f-461f-85bc-62c834088ca8	68abe4f7-390b-4474-b880-ca0cdee8dd35	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-06 03:03:37.583004+00
35c5bbbc-2983-487a-9480-79d80b21b1f2	dccca772-ea6f-4734-8297-0a2d45006a25	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-06 05:24:35.205188+00
fba9dca4-aeab-4c14-93a9-1a95d830ffe6	38554dcb-be05-480b-8a97-a7fe3671b583	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-11 00:31:34.797085+00
d40d1351-662e-4359-ae03-6b2f33c5e226	49c5c2ce-ea7c-439b-84f6-6ccf9424be22	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-11 01:27:57.344409+00
446880a5-a086-4fc6-befe-df16d608340a	43539f56-3e18-4955-8499-6caa4083e33c	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-11 03:01:45.646463+00
a2f23304-1ac8-4836-97f6-a4e28ddf4dad	c69671e6-ce20-43d0-84cf-30cb4c4f3595	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-11 04:53:24.834103+00
cb0f886d-5bbc-4be7-9a70-81f1b2dc99c7	54ccc0a5-55f4-44d0-9117-f0b9fab7733d	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-11 07:25:05.754366+00
debc879b-b7e9-4b5f-a95c-537450f36467	2014e155-7b5c-4188-adfe-a6362fe8ca61	https://example.com/comment-pdf.pdf	\N	\N	document.pdf	54321	application/pdf	document	\N	\N	\N	0	2026-03-11 09:01:26.332083+00
\.


--
-- Data for Name: comment_votes; Type: TABLE DATA; Schema: forum; Owner: -
--

COPY forum.comment_votes (id, comment_id, user_id, vote_type, created_at) FROM stdin;
718ea94f-fc31-4f65-a052-97d512e3ec1c	4bf5af18-6271-42b4-b1f1-a20f5036bb4f	210ea469-1f0b-4e7a-9064-10bc09022f6b	up	2026-02-27 07:58:32.977431+00
340c9217-faf7-446c-8035-5c862069a404	3ab19638-49bc-4f33-b520-8c2f01694f44	3912eb1f-e62d-4f9d-a28c-3f7542e24446	up	2026-02-27 08:39:06.699446+00
b12c647e-ce02-48c9-86f6-cf0f17e1e957	e9e6a2d5-3b35-403c-aea7-28aca25de8ce	021b5560-5b8a-4028-94fd-83c8c102c5e2	up	2026-02-27 09:10:15.987229+00
c387393b-c85c-4467-a3f4-8dc6feeaee77	e5899af0-0ca0-4249-9e70-833a0d40eb48	6ad98c87-3efa-41af-abeb-963cf0c9c96b	up	2026-02-27 09:42:32.344406+00
7198f7e6-28b7-4971-9ab9-0f62e3a06b96	fb53e502-c035-47ef-9865-b5382a665a01	3e9b0531-adbb-4989-9906-144bf69095e8	up	2026-02-27 21:15:30.448986+00
c771f1e9-e3dc-445f-b8c7-7e8a18cb752f	bdca725d-ef96-4930-9bcf-fb2adbb8bb09	c6414dc6-8494-4962-a5a8-9032b76a6a36	up	2026-02-28 02:01:57.005348+00
c48e6c4b-c23d-4557-a313-20018906e9fd	eb1f44e8-4f26-4d28-963b-a4a5dbf6c943	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	up	2026-02-28 02:38:52.929259+00
6d7584f3-78df-4993-8834-a8d4b7672868	431a56c2-c0dd-4871-80c8-82f9474566ed	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	up	2026-02-28 06:02:38.1245+00
bf4252d4-8f1b-40c7-8ff9-b5bc6a1d5195	7364631a-744d-423a-b2b2-7b10d7b1a521	d9640291-3bd0-4af1-ab49-8c2867f1dd74	up	2026-02-28 06:50:07.661168+00
d6b05621-6bb9-48c7-a620-72e07f9a16a7	e4ef8797-462b-45d5-85be-7477caf72834	445e0fc9-051f-4ab6-a6f6-12b334b24cac	up	2026-02-28 07:57:40.59829+00
43f750ac-dd9a-459c-b0e2-bdac01536484	5c106d53-fe1c-4ab6-93b4-80e7faebb19f	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	up	2026-02-28 08:42:15.274137+00
edfd48d8-bf60-4821-8aa2-bf8204fc95e9	f0c05073-caa1-4f41-b202-0ec525c03bf5	a91b9539-b268-439e-b171-53a99f420ea7	up	2026-02-28 09:11:57.602779+00
27bb93b2-a9a3-460d-80de-cd82e4e2bea3	e64b7b73-f2fc-416b-89fe-e2c3ba4dba88	38097e8b-144a-47cf-95fe-002c168192ad	up	2026-02-28 09:33:39.708832+00
f4be0deb-afa8-4ce7-87ce-c3dd1fd48706	6098eeda-0396-4090-a7df-6e85e65cb326	8642494b-070a-4118-9900-9de9ab1c1a15	up	2026-02-28 10:18:06.505801+00
48a70a96-0a90-4e5f-898a-d65c14ec1c54	5493b7eb-749a-4c71-8f2d-99825651735e	41a4377c-8f35-4d62-b76b-e5d1045c9c91	up	2026-03-01 02:39:22.840058+00
a24e1305-50e0-435a-be6f-5ffc1e164391	9e1128e3-9159-4b85-b16b-c6da5a30f26c	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	up	2026-03-01 03:20:02.085671+00
a2bc5d55-3a5c-4701-ab95-933a1b41d224	db7b6372-e16d-4dea-b4ea-f108865bebd3	cc04016a-872b-40c2-b75a-acdb030b759d	up	2026-03-01 04:02:32.221985+00
b9d94bb7-3b3a-47d2-890f-cd747b3844a2	9940a9a9-748f-45ae-8ecd-943fd5fbf38a	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	up	2026-03-01 04:44:46.418946+00
90285847-c8bb-4a5a-b0d4-e5694cab1793	61a53b97-d49a-432f-b605-5aa3918c0cb8	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	up	2026-03-01 05:49:31.671285+00
f2bfc0d1-8365-40c3-afbd-66628a6f27e5	02a0b038-98e6-42ab-b2ce-f9772f267951	e08c76f6-b5b7-4dce-b61d-450c96abedd6	up	2026-03-01 06:27:28.935491+00
62e5e597-2311-4510-8f3e-9bc8d8506252	6ebf8945-8c6e-4f4f-9a85-fea753e16af4	2f2cd581-05ce-4f21-8352-e51f1be40de4	up	2026-03-01 07:10:47.329182+00
307bfbb3-46ba-43f1-bdd2-82f4211ae382	e7c48526-87bf-47bd-8980-ab2709ada9b1	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	up	2026-03-01 08:22:25.729053+00
22099f67-eb52-4662-93bc-09a7671e7aa2	60cb2a99-8931-4e12-b23c-248c1c784aa9	391d8769-702e-4c1a-a44c-29022307c877	up	2026-03-01 08:52:14.119899+00
3f3868b8-0277-4800-94ba-d8788f6a9808	043da337-c8d0-4751-b3f8-bebe7c1d1ce4	ca77bbd7-501b-4cea-88d8-3f62f7e46255	up	2026-03-01 09:24:46.508064+00
eff103b3-3e9e-4cbb-804c-e0d48f2cd1e4	65599501-92b0-450d-ba98-8c64ba59b0aa	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	up	2026-03-01 20:43:03.763905+00
8b179ba9-66a1-47b4-a80b-8ba768b448df	e00591bb-2e53-48b1-911b-df0352fc1c7f	21ff734b-3c75-4574-97c9-c35cc3818bc6	up	2026-03-01 22:03:54.843923+00
38446a0c-62dd-46e8-b4b1-49f311215bac	23228985-f15b-46c6-960c-c848aa470a4e	92a67500-cdac-43d1-8f4b-f27e7f1891ec	up	2026-03-02 00:29:23.168926+00
bcf01c08-3bde-4867-ab64-5ca03bf6876b	b0df5244-ef9e-4fbe-bf9d-4f80a6d07806	6246157a-a93d-4ef5-b943-c9a143f03e2d	up	2026-03-02 01:23:22.148317+00
67c92d78-cfb5-403c-a9f2-a66814f3f1d8	8ad29297-0622-46e5-b14a-f0b5eb104556	56886316-0d84-4556-ba46-56b476dcfffa	up	2026-03-02 10:19:01.549537+00
e5ee430a-3595-42b2-b6d9-35b57d8e3d83	e401ae6d-5816-417a-933d-ca6d3faf1c00	563da29b-6b23-4753-8dba-01fdbb6f905d	up	2026-03-02 12:43:34.804629+00
dcb5f841-1fe9-445c-8445-9e7b13adb6d5	ca1a8725-7ecd-4411-9ecc-2ce4968401cf	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	up	2026-03-02 13:17:05.824011+00
989dac74-235d-41dc-92af-d8116b6824d9	714bebfa-e754-4ae3-9022-ab4a6034a7ca	0d58e6b5-eb5a-4976-bae0-2f459280932a	up	2026-03-02 13:37:21.476752+00
95cf523c-a1d3-4d37-b0ff-0eaa49767eb0	59f3bd9d-d04d-46a2-8a71-e017a0d802f3	24246ea0-c094-4c8c-b167-a83a72bed89b	up	2026-03-02 14:20:57.064676+00
ed032148-8eea-4062-9a9e-9ca74bea1902	038ade32-c07a-430d-accd-4f9bd6e3ef9d	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	up	2026-03-02 15:10:58.654756+00
e2cd0888-c232-4428-a5c1-551eb97b7ee0	9b474e5f-55cd-4275-98e2-593c829651c9	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	up	2026-03-02 20:33:13.690425+00
209adbe2-a14c-4fbf-a052-f931735b07b9	de80e9a3-544a-4956-bdb1-604a63fe9f38	436892ad-1a40-40dd-ad3e-62d59baca3bb	up	2026-03-03 00:15:58.164651+00
0d4d7778-51aa-40e1-ae2f-f5d5a4c49cfe	83cf9412-407e-42eb-b0f7-7d29105bc918	ee231bdc-5265-4443-bf4a-a66f74a3e754	up	2026-03-03 00:54:56.900499+00
5e274f03-a96f-402d-9c18-4a31ef608db2	8effe8f9-661b-4171-8a3d-a9ee32c4c229	245ed62a-4f36-4819-b992-d06509f66369	up	2026-03-03 02:09:39.605664+00
3f9bf68a-5c80-49ef-bd08-43d4131ef97c	a9f75f07-dae4-472c-9a88-db9273712b47	28043028-1578-4221-b470-b43484c8fc7e	up	2026-03-03 05:11:18.834113+00
1816b3e7-7431-46e6-9945-4057fa7b3d48	175d049b-9db4-4ed7-809d-063d747cf5d1	56bdeb68-a57e-497e-95a3-c8eb0f596d61	up	2026-03-03 06:17:51.000557+00
a510a795-a208-49bb-98cd-1cb6806d55e9	efdfe8a3-f42d-484f-9adf-2b2d1aee10b7	cd859d66-dee0-4cb6-9689-bd47cae0be0f	up	2026-03-03 16:13:22.049449+00
4c23290a-2329-40aa-9cae-479512096490	9b866de6-6e4d-4773-b814-abe88356b775	b282ed2d-29af-4fad-a357-02ab89c459fd	up	2026-03-04 09:50:04.669212+00
b3b0df3d-1a7c-4da4-8432-3097301adcd8	184884ec-ab65-48cb-baad-5f8b467ab8dc	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	up	2026-03-04 16:20:31.482179+00
dd099126-8038-45c2-8879-f8c2cc20c384	05a64af2-7f35-4714-924b-3235f0c62d9e	a11c2fb2-b350-416b-9cb4-176c82eaf560	up	2026-03-04 23:16:17.753655+00
e3b765e3-0aeb-4048-9915-40b68bae2fa3	973d1eb6-9803-4fcf-9c86-30a6de04bb4e	b7273deb-f387-46c0-a5d4-712a9784544d	up	2026-03-05 02:04:46.819264+00
7aaf5e19-13eb-4cc6-bdbb-fc768b2b485c	6e35a397-a4d5-41ae-902d-e291b0429db6	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	up	2026-03-05 03:22:17.489716+00
8b6ca38e-f86e-4561-aa37-c476891a8c02	a5726d32-8e96-4550-a989-1796dbb5fc5e	5176ab32-17b3-4f7d-8432-2d93718a0bbf	up	2026-03-05 04:11:46.609754+00
ceaa82ac-0710-47ca-a10a-80116e0abe89	5e0250b7-e5a7-47cd-a540-95aaa4f6ed1c	aa3a21e3-ae58-40a2-946c-2c5e799d0330	up	2026-03-05 05:21:53.072538+00
40e2ce43-4df9-49b0-8bd3-8270ab40c35f	b3486464-cd94-46ce-bbb7-480e3124cc84	cdc85298-8764-4ff7-8acf-74ace40dd1d8	up	2026-03-05 07:31:28.651308+00
11dfd3e6-9c1e-4b47-a4c5-be3105184eea	d9b52e75-ad92-43f7-84a2-b9197d53e52f	d8290673-93c3-421c-8914-4c2a0f83b12b	up	2026-03-05 07:56:11.208441+00
5a197efe-388f-40b8-8dc3-b4d759136bf8	6632b775-e26e-4cfa-a391-aa5b47b5f4b7	8701ce73-3f04-42af-8554-c72cb58a838f	up	2026-03-05 08:33:12.678115+00
2b7bae65-8a44-4ac8-b56a-302ab4bcab1f	6bb6a27f-2968-489e-a79d-ac1716933acb	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	up	2026-03-05 09:01:42.099813+00
fffe42a1-57c6-4e98-a9b1-6e05d66ee3cb	55f861b0-c902-487a-b09a-60c4b4882087	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	up	2026-03-05 09:40:14.52869+00
cc630fa1-30cb-40e6-929d-118a1371e896	53a96745-63bf-4e1f-a8a8-8d23a1854bec	c50a2a26-686c-434a-86bb-828cb62f0ce0	up	2026-03-05 11:41:14.481672+00
8199b2c1-5f7d-4877-87c3-73f8067bbe29	14bdea87-c6ba-474e-b1bc-7fc607a08e0c	3bb235ee-59d6-449b-b5a9-99e70614c7c2	up	2026-03-05 15:28:29.593632+00
fbca69fc-f2ba-4fbf-b695-5983144455d5	604a4483-bd02-4570-ab6e-a436efd4f9ac	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	up	2026-03-05 22:41:51.372304+00
4ce793b4-4a3c-4f7a-86a7-49989046c478	f52d64bf-284c-479b-88cc-c7211b0d5f80	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	up	2026-03-06 03:03:21.553501+00
3b999694-9c52-4e6f-82a9-f6fa13632403	51238d1b-6151-4d1a-b45a-357ff95f1b7d	74fd4160-d207-47b4-87c2-e418ccf0462e	up	2026-03-06 05:24:13.435439+00
84f2c718-8695-407a-971a-8bb308a6f382	ce62ea20-f32d-4b8b-8f49-957149f2b720	ae6839bd-0c8a-4f8b-8785-c1b37880e158	up	2026-03-11 00:31:27.655748+00
70c2b0f7-b757-4fca-bd62-1735d3a31a1f	4a88091f-3c67-4396-94e4-e13b0c6f0190	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	up	2026-03-11 01:27:44.260693+00
54130c1f-4a4e-4526-8189-7790a835097f	a9005ed6-8c23-404d-a460-6a07a018fa09	d52c170c-8356-4666-b7b7-4d0c772ae583	up	2026-03-11 03:01:38.515717+00
6fa0fe44-026f-48e1-a729-4ad3028cbc78	ea491435-36e8-4483-a00d-c02af3dd535f	491c69a3-3681-4da0-beac-053d9351c06a	up	2026-03-11 04:53:06.869975+00
125cb6b5-140d-43e1-abb1-29c243438018	6914092a-0b29-4cd1-99ce-054eb31f021a	d8f6ab86-5b6b-472c-b393-74632a4bc00a	up	2026-03-11 07:24:55.552638+00
994e9529-c7cd-416d-a972-14f182d763b8	dbb8dd08-f199-4c77-8a0a-89e210302ed0	f6e8e0bd-41cb-48eb-9587-43e14005f426	up	2026-03-11 09:01:15.898244+00
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: forum; Owner: -
--

COPY forum.comments (id, post_id, user_id, parent_id, content, upvotes, downvotes, created_at, updated_at) FROM stdin;
4bf5af18-6271-42b4-b1f1-a20f5036bb4f	1f783840-912a-4895-a7c3-340502c8db0a	75d7c735-56b5-4885-8ed0-3739224c38e9	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-27 07:57:38.546951+00	2026-02-27 07:58:29.280886+00
3ab19638-49bc-4f33-b520-8c2f01694f44	f387d943-c6ec-477b-9b7d-13b02e92516c	f898d5aa-370c-42f8-b8d9-2073c009843e	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-27 08:38:02.358812+00	2026-02-27 08:39:06.191673+00
a8b87227-09cb-4667-9ee8-2cb3bb31ce22	f387d943-c6ec-477b-9b7d-13b02e92516c	f898d5aa-370c-42f8-b8d9-2073c009843e	\N	This comment will have an attachment	0	0	2026-02-27 08:39:14.007951+00	2026-02-27 08:39:14.007951+00
e9e6a2d5-3b35-403c-aea7-28aca25de8ce	c177bbef-ed44-4b79-a26c-0e63c8397b92	dfcca53c-b7c6-4c7e-b1f8-5eab18a31803	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-27 09:09:37.962903+00	2026-02-27 09:10:15.513003+00
09a8e93e-b7b0-4c67-bf6e-a22352598a3b	c177bbef-ed44-4b79-a26c-0e63c8397b92	dfcca53c-b7c6-4c7e-b1f8-5eab18a31803	\N	This comment will have an attachment	0	0	2026-02-27 09:10:32.805433+00	2026-02-27 09:10:32.805433+00
e5899af0-0ca0-4249-9e70-833a0d40eb48	edb23991-01e6-43a2-b0df-82585bfbab1e	f2462b92-84ec-468a-a7c0-f3137fe27079	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-27 09:41:27.934613+00	2026-02-27 09:42:31.678921+00
a3b89c03-6588-44df-ac48-81c9f47aa947	edb23991-01e6-43a2-b0df-82585bfbab1e	f2462b92-84ec-468a-a7c0-f3137fe27079	\N	This comment will have an attachment	0	0	2026-02-27 09:42:49.338311+00	2026-02-27 09:42:49.338311+00
fb53e502-c035-47ef-9865-b5382a665a01	a1011270-fad1-4253-82ce-bcb952d60606	8eb88955-4a5a-441e-980d-62032c083d4d	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-27 21:14:22.978742+00	2026-02-27 21:15:26.800896+00
1f503e8f-353f-4814-9954-2aeb6d27031e	a1011270-fad1-4253-82ce-bcb952d60606	8eb88955-4a5a-441e-980d-62032c083d4d	\N	This comment will have an attachment	0	0	2026-02-27 21:15:40.317978+00	2026-02-27 21:15:40.317978+00
bdca725d-ef96-4930-9bcf-fb2adbb8bb09	780a9699-7311-463a-8f51-f701f8fddf76	90e9bcf9-d5cc-491d-8f61-7547398220f6	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 02:01:05.719458+00	2026-02-28 02:01:56.508484+00
22421a7c-f0a6-4969-8eb1-fe4d9710cc66	780a9699-7311-463a-8f51-f701f8fddf76	90e9bcf9-d5cc-491d-8f61-7547398220f6	\N	This comment will have an attachment	0	0	2026-02-28 02:02:06.938992+00	2026-02-28 02:02:06.938992+00
eb1f44e8-4f26-4d28-963b-a4a5dbf6c943	bc03acb5-3ba5-4d27-9bd1-305d464c9977	7cf6ed2f-4d23-430a-bc85-37e738821801	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 02:37:45.738486+00	2026-02-28 02:38:49.403318+00
d32b1fc0-1d4c-47d4-8dfc-195d211b6408	bc03acb5-3ba5-4d27-9bd1-305d464c9977	7cf6ed2f-4d23-430a-bc85-37e738821801	\N	This comment will have an attachment	0	0	2026-02-28 02:39:07.282099+00	2026-02-28 02:39:07.282099+00
431a56c2-c0dd-4871-80c8-82f9474566ed	91a88757-5b8a-4fb9-9b30-a0e6fa7cc270	2d2cb136-6784-4266-a122-d1fb57c0ccf0	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 06:02:33.709816+00	2026-02-28 06:02:34.582944+00
60dfb432-5475-40f3-8ae1-4807c70afdf4	91a88757-5b8a-4fb9-9b30-a0e6fa7cc270	2d2cb136-6784-4266-a122-d1fb57c0ccf0	\N	This comment will have an attachment	0	0	2026-02-28 06:02:49.694159+00	2026-02-28 06:02:49.694159+00
7364631a-744d-423a-b2b2-7b10d7b1a521	e8d449d3-e372-46fd-90b6-8816e216f5fe	f0382884-80a6-47dd-9957-27e5a7d77aef	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 06:49:55.991794+00	2026-02-28 06:50:00.025731+00
0ff1cd5b-03b8-4c83-8de1-94e7643da751	e8d449d3-e372-46fd-90b6-8816e216f5fe	f0382884-80a6-47dd-9957-27e5a7d77aef	\N	This comment will have an attachment	0	0	2026-02-28 06:50:16.104172+00	2026-02-28 06:50:16.104172+00
e4ef8797-462b-45d5-85be-7477caf72834	d5778d74-271e-45ce-bc60-c5318a7f77a3	8f9cd0e7-20ea-4c88-849a-b68cee224dd5	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 07:57:22.362732+00	2026-02-28 07:57:40.076439+00
17fcf234-91fc-4a28-8772-9c146c22ef39	d5778d74-271e-45ce-bc60-c5318a7f77a3	8f9cd0e7-20ea-4c88-849a-b68cee224dd5	\N	This comment will have an attachment	0	0	2026-02-28 07:57:52.815971+00	2026-02-28 07:57:52.815971+00
5c106d53-fe1c-4ab6-93b4-80e7faebb19f	d288744c-3c50-411c-962d-4cb91a721c4a	f3098473-3e59-4ce5-8a2a-b81c816bd940	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 08:42:07.43983+00	2026-02-28 08:42:11.504773+00
ebc690a3-ee00-4265-9f67-c78f2274329f	d288744c-3c50-411c-962d-4cb91a721c4a	f3098473-3e59-4ce5-8a2a-b81c816bd940	\N	This comment will have an attachment	0	0	2026-02-28 08:42:26.399294+00	2026-02-28 08:42:26.399294+00
f0c05073-caa1-4f41-b202-0ec525c03bf5	c64ac5a6-359b-4e13-b895-8af1dd40c08e	5829e9e4-67f7-4102-8612-42299d0313e1	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 09:11:52.989565+00	2026-02-28 09:11:56.998956+00
43aab0d1-c168-444c-a50f-380d814dc7fa	c64ac5a6-359b-4e13-b895-8af1dd40c08e	5829e9e4-67f7-4102-8612-42299d0313e1	\N	This comment will have an attachment	0	0	2026-02-28 09:12:11.987253+00	2026-02-28 09:12:11.987253+00
e64b7b73-f2fc-416b-89fe-e2c3ba4dba88	7441b1ed-e454-445d-81ed-7a8a533a9904	c2406d5f-4d30-4032-94e8-25f4cea037a5	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 09:33:38.21975+00	2026-02-28 09:33:39.009153+00
4d875f85-2ef8-4d1e-8fe8-a549e6ea4c95	7441b1ed-e454-445d-81ed-7a8a533a9904	c2406d5f-4d30-4032-94e8-25f4cea037a5	\N	This comment will have an attachment	0	0	2026-02-28 09:33:47.151003+00	2026-02-28 09:33:47.151003+00
6098eeda-0396-4090-a7df-6e85e65cb326	44d65a0a-2c7b-41a4-bb08-6b581363bf5e	433f76c4-c2f8-4ad7-9a98-c4ddebac9dce	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-02-28 10:18:01.92451+00	2026-02-28 10:18:05.996502+00
8baa178b-89e8-4483-b435-57a59b3b62a7	44d65a0a-2c7b-41a4-bb08-6b581363bf5e	433f76c4-c2f8-4ad7-9a98-c4ddebac9dce	\N	This comment will have an attachment	0	0	2026-02-28 10:18:14.47696+00	2026-02-28 10:18:14.47696+00
58653e89-4dc2-4cca-af55-57aa505aea6a	3c4e1c89-93c4-4abb-8359-07251ede239a	341136ec-c2b1-451e-ac28-b38865090b15	\N	This comment will have an attachment	0	0	2026-03-01 02:39:36.743756+00	2026-03-01 02:39:36.743756+00
5493b7eb-749a-4c71-8f2d-99825651735e	3c4e1c89-93c4-4abb-8359-07251ede239a	341136ec-c2b1-451e-ac28-b38865090b15	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 02:39:14.276181+00	2026-03-01 02:39:15.281935+00
9e1128e3-9159-4b85-b16b-c6da5a30f26c	6f7e45e8-fec2-4370-9544-a5b330add8ff	bc338835-6459-402b-9a49-85712076f449	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 03:19:47.195915+00	2026-03-01 03:19:48.945328+00
9fa57481-a877-412e-b14f-cd76bf42c224	6f7e45e8-fec2-4370-9544-a5b330add8ff	bc338835-6459-402b-9a49-85712076f449	\N	This comment will have an attachment	0	0	2026-03-01 03:20:23.040964+00	2026-03-01 03:20:23.040964+00
db7b6372-e16d-4dea-b4ea-f108865bebd3	e71cd790-6140-4be0-b88d-516b23fb60d8	56f04bfd-6f18-45f4-8946-fee3d4fd4399	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 04:02:30.506573+00	2026-03-01 04:02:31.796863+00
1be7bf1c-e916-4f9d-b324-4061772efbea	e71cd790-6140-4be0-b88d-516b23fb60d8	56f04bfd-6f18-45f4-8946-fee3d4fd4399	\N	This comment will have an attachment	0	0	2026-03-01 04:02:44.743267+00	2026-03-01 04:02:44.743267+00
9940a9a9-748f-45ae-8ecd-943fd5fbf38a	9b1cbad2-5223-4aa1-8d6b-5fe3427c83d9	fbf0bebe-ce4a-4a11-826e-756aa0fafcb2	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 04:44:45.099229+00	2026-03-01 04:44:45.983221+00
182bd719-b681-4cf1-a2d3-26a056a5f81a	9b1cbad2-5223-4aa1-8d6b-5fe3427c83d9	fbf0bebe-ce4a-4a11-826e-756aa0fafcb2	\N	This comment will have an attachment	0	0	2026-03-01 04:44:53.903823+00	2026-03-01 04:44:53.903823+00
e851fbeb-01df-45bf-8bfa-3b46cfd844f1	5160c280-2241-433e-9f62-9ab8f90faf73	0d55aa69-c8e7-417f-abb2-5eb119e59cac	\N	This comment will have an attachment	0	0	2026-03-01 06:27:40.071412+00	2026-03-01 06:27:40.071412+00
61a53b97-d49a-432f-b605-5aa3918c0cb8	f4bb97ac-ce74-41e8-9770-032b7ca63cfc	4cfdea78-eaf5-448b-91b3-6cbf2ecb0c98	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 05:49:29.819846+00	2026-03-01 05:49:30.830635+00
f534e814-2dc3-4e91-9d82-64d42169d95a	f4bb97ac-ce74-41e8-9770-032b7ca63cfc	4cfdea78-eaf5-448b-91b3-6cbf2ecb0c98	\N	This comment will have an attachment	0	0	2026-03-01 05:49:39.514089+00	2026-03-01 05:49:39.514089+00
02a0b038-98e6-42ab-b2ce-f9772f267951	5160c280-2241-433e-9f62-9ab8f90faf73	0d55aa69-c8e7-417f-abb2-5eb119e59cac	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 06:27:27.503437+00	2026-03-01 06:27:28.516189+00
6ebf8945-8c6e-4f4f-9a85-fea753e16af4	1c2461da-06e8-4b5a-a02f-b9c2d9c9ffe6	b3185860-cff6-462e-be65-cfacff59945d	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 07:10:42.936138+00	2026-03-01 07:10:46.783012+00
d879b979-c55e-411b-9f50-6c82d8155d76	1c2461da-06e8-4b5a-a02f-b9c2d9c9ffe6	b3185860-cff6-462e-be65-cfacff59945d	\N	This comment will have an attachment	0	0	2026-03-01 07:10:58.708523+00	2026-03-01 07:10:58.708523+00
e7c48526-87bf-47bd-8980-ab2709ada9b1	9230ec06-3e4e-4f7e-bcbb-7f83919c1388	09a07f48-8194-4865-ad69-a1cbf10233b4	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 08:22:24.08527+00	2026-03-01 08:22:25.131341+00
2d0a9130-7bd6-48f6-a07a-9f67fee8ea61	9230ec06-3e4e-4f7e-bcbb-7f83919c1388	09a07f48-8194-4865-ad69-a1cbf10233b4	\N	This comment will have an attachment	0	0	2026-03-01 08:22:44.987431+00	2026-03-01 08:22:44.987431+00
60cb2a99-8931-4e12-b23c-248c1c784aa9	ecc26c5a-9ada-4713-b5fd-bbf97a2068d0	47670534-24e1-40f2-bff6-753d69b03443	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 08:52:12.15017+00	2026-03-01 08:52:13.52+00
06849244-3442-44d0-8d08-f514ec21f77f	ecc26c5a-9ada-4713-b5fd-bbf97a2068d0	47670534-24e1-40f2-bff6-753d69b03443	\N	This comment will have an attachment	0	0	2026-03-01 08:52:25.940038+00	2026-03-01 08:52:25.940038+00
043da337-c8d0-4751-b3f8-bebe7c1d1ce4	78facf02-8cc6-489a-80c4-d1a463e8007b	07e2d78a-a5a8-416c-acb3-3de5249a0cc3	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 09:24:37.084847+00	2026-03-01 09:24:42.327789+00
47289520-6d6b-4bac-b4ce-db224645bbe6	78facf02-8cc6-489a-80c4-d1a463e8007b	07e2d78a-a5a8-416c-acb3-3de5249a0cc3	\N	This comment will have an attachment	0	0	2026-03-01 09:25:08.818985+00	2026-03-01 09:25:08.818985+00
65599501-92b0-450d-ba98-8c64ba59b0aa	53ed8dca-c521-4231-83e1-ae9ab65d2a11	133b5917-1b22-4465-9878-313102c84d25	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 20:42:59.094061+00	2026-03-01 20:43:00.146089+00
ca63c976-afd0-4c65-81eb-da76aa44f50a	53ed8dca-c521-4231-83e1-ae9ab65d2a11	133b5917-1b22-4465-9878-313102c84d25	\N	This comment will have an attachment	0	0	2026-03-01 20:43:15.856204+00	2026-03-01 20:43:15.856204+00
e00591bb-2e53-48b1-911b-df0352fc1c7f	29dbaf40-7525-4487-9028-a31dc7c4134e	37d17cdf-0a49-474c-b4fb-b9095b1acb7e	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-01 22:03:51.989683+00	2026-03-01 22:03:53.976485+00
86354cc9-7d14-4840-b76a-dd9bd1dc7cb1	29dbaf40-7525-4487-9028-a31dc7c4134e	37d17cdf-0a49-474c-b4fb-b9095b1acb7e	\N	This comment will have an attachment	0	0	2026-03-01 22:04:10.795263+00	2026-03-01 22:04:10.795263+00
de80e9a3-544a-4956-bdb1-604a63fe9f38	22b58c95-6c8a-4452-9085-5e51260c1242	203dba31-03b6-4bad-8239-14a9ab706d6f	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-03 00:15:56.713861+00	2026-03-03 00:15:57.68433+00
33f46de0-c89b-4388-b7ee-d03f6321232b	22b58c95-6c8a-4452-9085-5e51260c1242	203dba31-03b6-4bad-8239-14a9ab706d6f	\N	This comment will have an attachment	0	0	2026-03-03 00:16:09.260668+00	2026-03-03 00:16:09.260668+00
23228985-f15b-46c6-960c-c848aa470a4e	359f62ed-8fc4-498a-962c-a2df71c96ce7	f3df66bc-9014-4c35-9030-4632bf8c2cc1	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 00:29:21.833495+00	2026-03-02 00:29:22.747019+00
0d0cbaa4-b328-4ab9-9ac2-d556c52a87e9	359f62ed-8fc4-498a-962c-a2df71c96ce7	f3df66bc-9014-4c35-9030-4632bf8c2cc1	\N	This comment will have an attachment	0	0	2026-03-02 00:29:37.087104+00	2026-03-02 00:29:37.087104+00
b0df5244-ef9e-4fbe-bf9d-4f80a6d07806	1a60049c-38fa-41de-a15b-121c9d9a6ed8	85da0865-b48b-4ad4-a88b-883d122aa944	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 01:23:17.760816+00	2026-03-02 01:23:18.574573+00
da8b99a8-0c48-42ef-8dd0-b9283df34b83	1a60049c-38fa-41de-a15b-121c9d9a6ed8	85da0865-b48b-4ad4-a88b-883d122aa944	\N	This comment will have an attachment	0	0	2026-03-02 01:23:33.289667+00	2026-03-02 01:23:33.289667+00
83cf9412-407e-42eb-b0f7-7d29105bc918	aba17d5a-4877-4e97-8e8f-cd1513f5ba45	7fb588e1-ea59-44c5-8402-eb8ddd5e7172	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-03 00:54:48.19358+00	2026-03-03 00:54:49.134706+00
8ad29297-0622-46e5-b14a-f0b5eb104556	794ea3d0-299f-4488-81c1-5721d6bd66fe	742bcd22-7377-4911-aaf6-ea1debfe30d7	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 10:18:53.135735+00	2026-03-02 10:18:57.892983+00
1a27ca42-1639-40c5-a19a-73dc3a8aa10d	794ea3d0-299f-4488-81c1-5721d6bd66fe	742bcd22-7377-4911-aaf6-ea1debfe30d7	\N	This comment will have an attachment	0	0	2026-03-02 10:19:09.275742+00	2026-03-02 10:19:09.275742+00
4d3aa0ac-000a-486e-9b80-96c952a619a5	aba17d5a-4877-4e97-8e8f-cd1513f5ba45	7fb588e1-ea59-44c5-8402-eb8ddd5e7172	\N	This comment will have an attachment	0	0	2026-03-03 00:55:04.960041+00	2026-03-03 00:55:04.960041+00
e401ae6d-5816-417a-933d-ca6d3faf1c00	c1ee4ae8-e5e5-449c-802c-95ebcaf77196	b7c0acea-5ac9-45f5-94f1-0c4756736899	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 12:43:32.979089+00	2026-03-02 12:43:33.951286+00
7f852790-78cf-4fe2-b108-b751ac320b31	c1ee4ae8-e5e5-449c-802c-95ebcaf77196	b7c0acea-5ac9-45f5-94f1-0c4756736899	\N	This comment will have an attachment	0	0	2026-03-02 12:43:45.510231+00	2026-03-02 12:43:45.510231+00
ca1a8725-7ecd-4411-9ecc-2ce4968401cf	3b355715-3f13-4ada-ab5a-389e635c17dc	46131b88-f99b-4d7e-97ec-f2b40d70e108	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 13:17:04.108456+00	2026-03-02 13:17:05.414983+00
433eb8d5-3b1e-49d8-8837-ad61be5ac94a	3b355715-3f13-4ada-ab5a-389e635c17dc	46131b88-f99b-4d7e-97ec-f2b40d70e108	\N	This comment will have an attachment	0	0	2026-03-02 13:17:13.767525+00	2026-03-02 13:17:13.767525+00
efdfe8a3-f42d-484f-9adf-2b2d1aee10b7	be2753a7-770c-49b8-9ee8-e2013559eefd	54d941d6-1ea7-49e2-b7a8-e6015ae0032c	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-03 16:13:04.159016+00	2026-03-03 16:13:21.298937+00
714bebfa-e754-4ae3-9022-ab4a6034a7ca	d5ea4396-7d0b-4416-b972-1cb17a10c93c	0d58e6b5-eb5a-4976-bae0-2f459280932a	\N	Updated comment content	1	0	2026-03-02 13:37:21.319489+00	2026-03-02 13:37:21.476752+00
59f3bd9d-d04d-46a2-8a71-e017a0d802f3	11943cac-d9c1-4067-a3d2-eb03f985fb6a	b386fee6-107d-475c-bac6-c29a764bbeb3	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 14:20:51.971776+00	2026-03-02 14:20:52.871913+00
a9eaaaf8-b8c2-4139-a42e-734c7b0320f6	11943cac-d9c1-4067-a3d2-eb03f985fb6a	b386fee6-107d-475c-bac6-c29a764bbeb3	\N	This comment will have an attachment	0	0	2026-03-02 14:21:08.809052+00	2026-03-02 14:21:08.809052+00
736440a9-97c5-404c-8fd2-59e89add5997	be2753a7-770c-49b8-9ee8-e2013559eefd	54d941d6-1ea7-49e2-b7a8-e6015ae0032c	\N	This comment will have an attachment	0	0	2026-03-03 16:13:36.226585+00	2026-03-03 16:13:36.226585+00
038ade32-c07a-430d-accd-4f9bd6e3ef9d	0b5ed87d-0634-4e10-bf4d-5b71530dbc6f	f6e4c03c-c756-4eb4-911b-d1c4060a5ba0	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 15:10:57.238079+00	2026-03-02 15:10:58.188492+00
ac4868c0-4298-4411-a229-4eaa3e2dda39	0b5ed87d-0634-4e10-bf4d-5b71530dbc6f	f6e4c03c-c756-4eb4-911b-d1c4060a5ba0	\N	This comment will have an attachment	0	0	2026-03-02 15:11:06.892029+00	2026-03-02 15:11:06.892029+00
8effe8f9-661b-4171-8a3d-a9ee32c4c229	22e2a3b7-c2cf-4807-a307-fe8b48495e88	e2936688-4233-4586-a72e-a0a83d2e832c	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-03 02:09:37.796097+00	2026-03-03 02:09:38.884136+00
5b9d197c-e83d-49c1-b1b0-f293579b95b4	22e2a3b7-c2cf-4807-a307-fe8b48495e88	e2936688-4233-4586-a72e-a0a83d2e832c	\N	This comment will have an attachment	0	0	2026-03-03 02:09:54.673172+00	2026-03-03 02:09:54.673172+00
9b474e5f-55cd-4275-98e2-593c829651c9	2d5a20d0-5ba5-4b69-8155-c10f433ef19e	c882505f-d91f-46b4-98cf-72907a7f29b3	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-02 20:33:11.833523+00	2026-03-02 20:33:13.191029+00
f3fa1ca1-6696-4dec-b227-d2bc1da8fba3	2d5a20d0-5ba5-4b69-8155-c10f433ef19e	c882505f-d91f-46b4-98cf-72907a7f29b3	\N	This comment will have an attachment	0	0	2026-03-02 20:33:21.163312+00	2026-03-02 20:33:21.163312+00
cca0923b-067e-4c46-9b7a-005f11ba7b2f	7b33e813-91c4-409d-858d-0f76ab58d2c9	b9f7507a-0e78-4770-8594-0e4279f96bff	\N	This comment will have an attachment	0	0	2026-03-04 23:16:25.41104+00	2026-03-04 23:16:25.41104+00
a9f75f07-dae4-472c-9a88-db9273712b47	1d0326ae-951f-4980-a2ef-89fa671402d1	e096959c-006c-4cdc-9944-5cedb6d64b14	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-03 05:11:05.856179+00	2026-03-03 05:11:15.108684+00
63e5442e-2bbe-45de-a5ab-bf3b2cf17483	1d0326ae-951f-4980-a2ef-89fa671402d1	e096959c-006c-4cdc-9944-5cedb6d64b14	\N	This comment will have an attachment	0	0	2026-03-03 05:11:34.313566+00	2026-03-03 05:11:34.313566+00
175d049b-9db4-4ed7-809d-063d747cf5d1	e3d32c46-ecc2-4a8c-99eb-18d09cb2c05b	d323a977-0cd3-4171-a664-9d8f02929081	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-03 06:17:44.909051+00	2026-03-03 06:17:50.380326+00
d0316676-38c2-49a4-8d0b-631562aa63e6	e3d32c46-ecc2-4a8c-99eb-18d09cb2c05b	d323a977-0cd3-4171-a664-9d8f02929081	\N	This comment will have an attachment	0	0	2026-03-03 06:18:04.71751+00	2026-03-03 06:18:04.71751+00
9b866de6-6e4d-4773-b814-abe88356b775	03e587d5-0b2d-4203-bda1-3a60abeba33d	a7965ef1-4594-4506-9fe0-e58f031c6172	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-04 09:50:02.798952+00	2026-03-04 09:50:04.163163+00
ab47548f-e3a2-4efc-8e17-013663e19373	03e587d5-0b2d-4203-bda1-3a60abeba33d	a7965ef1-4594-4506-9fe0-e58f031c6172	\N	This comment will have an attachment	0	0	2026-03-04 09:50:12.59147+00	2026-03-04 09:50:12.59147+00
184884ec-ab65-48cb-baad-5f8b467ab8dc	2cc729b7-0f5e-4fe4-838a-7dc9b8ba99d9	93f1e2db-37ce-46ea-817e-6964a900d6a1	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-04 16:20:27.11404+00	2026-03-04 16:20:27.938147+00
e1341f21-a08a-4368-956c-b5130f73bac3	2cc729b7-0f5e-4fe4-838a-7dc9b8ba99d9	93f1e2db-37ce-46ea-817e-6964a900d6a1	\N	This comment will have an attachment	0	0	2026-03-04 16:20:39.331614+00	2026-03-04 16:20:39.331614+00
6e35a397-a4d5-41ae-902d-e291b0429db6	77788cfa-4b4a-492f-8199-69db8a6e27f7	638535b9-f452-4817-86b3-899c56e3ba49	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 03:22:09.371381+00	2026-03-05 03:22:13.875605+00
e807c87b-b9ae-4171-a0f0-f1f59dfeaa1b	77788cfa-4b4a-492f-8199-69db8a6e27f7	638535b9-f452-4817-86b3-899c56e3ba49	\N	This comment will have an attachment	0	0	2026-03-05 03:22:26.53899+00	2026-03-05 03:22:26.53899+00
05a64af2-7f35-4714-924b-3235f0c62d9e	7b33e813-91c4-409d-858d-0f76ab58d2c9	b9f7507a-0e78-4770-8594-0e4279f96bff	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-04 23:16:09.242029+00	2026-03-04 23:16:10.170711+00
973d1eb6-9803-4fcf-9c86-30a6de04bb4e	184ff4db-a253-43d2-abe1-726c09832976	491c0272-e244-486e-957a-36f366a3a5c6	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 02:04:32.204566+00	2026-03-05 02:04:42.591567+00
525657b8-658c-40d6-9e88-8cf68d8baac5	184ff4db-a253-43d2-abe1-726c09832976	491c0272-e244-486e-957a-36f366a3a5c6	\N	This comment will have an attachment	0	0	2026-03-05 02:05:01.287048+00	2026-03-05 02:05:01.287048+00
a5726d32-8e96-4550-a989-1796dbb5fc5e	6db217e5-0f20-4931-bd2c-3438526a7f0c	be95d56c-09b5-4e0c-90ce-95da0726a1f0	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 04:11:45.156485+00	2026-03-05 04:11:46.056383+00
fdc096fb-a2d0-4786-86ab-00edf1b29040	6db217e5-0f20-4931-bd2c-3438526a7f0c	be95d56c-09b5-4e0c-90ce-95da0726a1f0	\N	This comment will have an attachment	0	0	2026-03-05 04:11:55.818705+00	2026-03-05 04:11:55.818705+00
5e0250b7-e5a7-47cd-a540-95aaa4f6ed1c	c681b4dc-061e-48e6-8044-14e433b3d434	b54272d2-f5dd-46d4-9eb8-827754fe5c05	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 05:21:50.247288+00	2026-03-05 05:21:52.434828+00
a5fef55c-951e-444b-9d57-ede75364ba8d	c681b4dc-061e-48e6-8044-14e433b3d434	b54272d2-f5dd-46d4-9eb8-827754fe5c05	\N	This comment will have an attachment	0	0	2026-03-05 05:22:04.338601+00	2026-03-05 05:22:04.338601+00
b3486464-cd94-46ce-bbb7-480e3124cc84	6160450d-c5a4-4dfc-9dd9-4b0e89def46c	22960ac9-b138-4cbe-9083-0d90802591bb	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 07:31:19.944481+00	2026-03-05 07:31:28.147294+00
de455734-9485-436f-ac47-216e8ff50652	6160450d-c5a4-4dfc-9dd9-4b0e89def46c	22960ac9-b138-4cbe-9083-0d90802591bb	\N	This comment will have an attachment	0	0	2026-03-05 07:31:40.240312+00	2026-03-05 07:31:40.240312+00
d9b52e75-ad92-43f7-84a2-b9197d53e52f	c803a568-8751-445b-a276-da1dba5fd570	40d677cc-0352-4315-b8d8-162c66a9a00d	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 07:56:09.405106+00	2026-03-05 07:56:10.719112+00
941ebd45-99ec-4373-9321-6f8dbfdc10c0	c803a568-8751-445b-a276-da1dba5fd570	40d677cc-0352-4315-b8d8-162c66a9a00d	\N	This comment will have an attachment	0	0	2026-03-05 07:56:20.725856+00	2026-03-05 07:56:20.725856+00
6632b775-e26e-4cfa-a391-aa5b47b5f4b7	f476e310-225e-4860-a4d2-8f109d1cc683	4d16ff25-2bbd-4a06-a3fa-cee29ef9bceb	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 08:33:01.969353+00	2026-03-05 08:33:08.218075+00
a84f691e-cca2-421a-b66b-b3560685269f	f476e310-225e-4860-a4d2-8f109d1cc683	4d16ff25-2bbd-4a06-a3fa-cee29ef9bceb	\N	This comment will have an attachment	0	0	2026-03-05 08:33:33.244795+00	2026-03-05 08:33:33.244795+00
6bb6a27f-2968-489e-a79d-ac1716933acb	29695f06-74db-40a5-a12c-7fd33f869281	d036cfe7-b466-4a84-a850-759c5d6b1de1	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 09:01:32.869531+00	2026-03-05 09:01:34.264909+00
fc8ab64f-32e9-4fe9-b90b-ec95a3a58274	29695f06-74db-40a5-a12c-7fd33f869281	d036cfe7-b466-4a84-a850-759c5d6b1de1	\N	This comment will have an attachment	0	0	2026-03-05 09:02:01.088867+00	2026-03-05 09:02:01.088867+00
55f861b0-c902-487a-b09a-60c4b4882087	7e853104-1a64-43f4-b67e-69baa3b132e3	3cbbf74d-0691-475e-98cc-8e3543607ac4	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 09:40:12.938541+00	2026-03-05 09:40:13.800828+00
ace68f25-c8b7-4821-817f-f7d81e17b6f7	7e853104-1a64-43f4-b67e-69baa3b132e3	3cbbf74d-0691-475e-98cc-8e3543607ac4	\N	This comment will have an attachment	0	0	2026-03-05 09:40:22.52395+00	2026-03-05 09:40:22.52395+00
53a96745-63bf-4e1f-a8a8-8d23a1854bec	15db143a-27ac-48b1-831b-297df09d53e4	da1311fc-11f8-4855-9561-9dabdbac9200	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 11:41:09.944371+00	2026-03-05 11:41:13.967728+00
aed2ac53-8835-4be9-b693-ce8d57113136	15db143a-27ac-48b1-831b-297df09d53e4	da1311fc-11f8-4855-9561-9dabdbac9200	\N	This comment will have an attachment	0	0	2026-03-05 11:41:22.404345+00	2026-03-05 11:41:22.404345+00
14bdea87-c6ba-474e-b1bc-7fc607a08e0c	cc5eeab9-8ac7-4601-999b-8832337b2fdb	421d247a-e0ed-469a-8d29-c77f6aad985b	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 15:28:24.444899+00	2026-03-05 15:28:25.908625+00
2e52d18d-f89c-4c11-b4c0-75908b144f0a	cc5eeab9-8ac7-4601-999b-8832337b2fdb	421d247a-e0ed-469a-8d29-c77f6aad985b	\N	This comment will have an attachment	0	0	2026-03-05 15:28:49.620793+00	2026-03-05 15:28:49.620793+00
604a4483-bd02-4570-ab6e-a436efd4f9ac	870a91bc-7f2b-4505-a38f-fd5a27aa9dae	55e16ca2-05bd-493e-acd1-462f5c03b526	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-05 22:41:49.313411+00	2026-03-05 22:41:50.501588+00
94de8fab-4dcc-4f18-a1dc-4989bdafab83	870a91bc-7f2b-4505-a38f-fd5a27aa9dae	55e16ca2-05bd-493e-acd1-462f5c03b526	\N	This comment will have an attachment	0	0	2026-03-05 22:42:09.808065+00	2026-03-05 22:42:09.808065+00
f52d64bf-284c-479b-88cc-c7211b0d5f80	499d7de8-57a8-4d71-82a7-29114888b028	8ce64101-e018-4d06-badb-5b7f217509da	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-06 03:03:17.358556+00	2026-03-06 03:03:21.008696+00
68abe4f7-390b-4474-b880-ca0cdee8dd35	499d7de8-57a8-4d71-82a7-29114888b028	8ce64101-e018-4d06-badb-5b7f217509da	\N	This comment will have an attachment	0	0	2026-03-06 03:03:37.220175+00	2026-03-06 03:03:37.220175+00
51238d1b-6151-4d1a-b45a-357ff95f1b7d	a933c8c8-29b8-483f-9f0c-70d9e311edf1	569413ba-a1c8-43fc-9f30-a0deafe7875d	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-06 05:23:59.522816+00	2026-03-06 05:24:12.315575+00
dccca772-ea6f-4734-8297-0a2d45006a25	a933c8c8-29b8-483f-9f0c-70d9e311edf1	569413ba-a1c8-43fc-9f30-a0deafe7875d	\N	This comment will have an attachment	0	0	2026-03-06 05:24:27.381834+00	2026-03-06 05:24:27.381834+00
ce62ea20-f32d-4b8b-8f49-957149f2b720	ae9aa93d-a3c1-49bf-b2bb-939622dded53	3370312a-8076-4b39-b08a-d1c0815f45e8	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-11 00:31:23.573107+00	2026-03-11 00:31:24.126916+00
38554dcb-be05-480b-8a97-a7fe3671b583	ae9aa93d-a3c1-49bf-b2bb-939622dded53	3370312a-8076-4b39-b08a-d1c0815f45e8	\N	This comment will have an attachment	0	0	2026-03-11 00:31:34.487974+00	2026-03-11 00:31:34.487974+00
4a88091f-3c67-4396-94e4-e13b0c6f0190	fadaf9e5-cdd4-448a-8412-20e33d8d1a0e	cbe014df-8888-4f19-9d6a-51f3d00e146e	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-11 01:27:33.35986+00	2026-03-11 01:27:36.896168+00
49c5c2ce-ea7c-439b-84f6-6ccf9424be22	fadaf9e5-cdd4-448a-8412-20e33d8d1a0e	cbe014df-8888-4f19-9d6a-51f3d00e146e	\N	This comment will have an attachment	0	0	2026-03-11 01:27:54.022728+00	2026-03-11 01:27:54.022728+00
a9005ed6-8c23-404d-a460-6a07a018fa09	09ec70aa-bbf3-4224-bd9a-628bd13c1570	653ad0f3-d2b0-4a56-941e-256f958beab3	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-11 03:01:34.596267+00	2026-03-11 03:01:38.184961+00
43539f56-3e18-4955-8499-6caa4083e33c	09ec70aa-bbf3-4224-bd9a-628bd13c1570	653ad0f3-d2b0-4a56-941e-256f958beab3	\N	This comment will have an attachment	0	0	2026-03-11 03:01:45.35155+00	2026-03-11 03:01:45.35155+00
ea491435-36e8-4483-a00d-c02af3dd535f	036baece-222a-4403-840c-ebfa09da7d5c	e86ff6b9-ff9e-41f3-a60e-f1f9aa01c77c	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-11 04:53:02.977897+00	2026-03-11 04:53:03.503842+00
c69671e6-ce20-43d0-84cf-30cb4c4f3595	036baece-222a-4403-840c-ebfa09da7d5c	e86ff6b9-ff9e-41f3-a60e-f1f9aa01c77c	\N	This comment will have an attachment	0	0	2026-03-11 04:53:24.450155+00	2026-03-11 04:53:24.450155+00
6914092a-0b29-4cd1-99ce-054eb31f021a	71c5a2c9-a338-4bc9-8643-bfc32964a677	1cdbfbb1-24ca-4be3-b2f0-b16ba448ab50	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-11 07:24:54.425229+00	2026-03-11 07:24:55.122373+00
54ccc0a5-55f4-44d0-9117-f0b9fab7733d	71c5a2c9-a338-4bc9-8643-bfc32964a677	1cdbfbb1-24ca-4be3-b2f0-b16ba448ab50	\N	This comment will have an attachment	0	0	2026-03-11 07:25:04.83309+00	2026-03-11 07:25:04.83309+00
dbb8dd08-f199-4c77-8a0a-89e210302ed0	6dc18105-f0a1-4e9d-bb04-7e9a3cf3c774	40ac61f7-4705-4c54-b839-ab971c2ebdaf	\N	Great post! This is a test comment via HTTP/3 from User 2	1	0	2026-03-11 09:01:15.061695+00	2026-03-11 09:01:15.574867+00
2014e155-7b5c-4188-adfe-a6362fe8ca61	6dc18105-f0a1-4e9d-bb04-7e9a3cf3c774	40ac61f7-4705-4c54-b839-ab971c2ebdaf	\N	This comment will have an attachment	0	0	2026-03-11 09:01:26.023294+00	2026-03-11 09:01:26.023294+00
\.


--
-- Data for Name: post_attachments; Type: TABLE DATA; Schema: forum; Owner: -
--

COPY forum.post_attachments (id, post_id, file_url, file_path, thumbnail_url, file_name, file_size, mime_type, file_type, width, height, duration, display_order, created_at) FROM stdin;
8fb2a100-1061-4511-87e8-b17de7917ce0	bef76a75-2944-466b-8ec6-ed2b20758588	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-27 08:39:13.711697+00
49c46f16-7421-4d30-9b1b-ffa72ad6a3a4	db3e7cd9-fc3a-4973-88bb-2e9635d01c22	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-27 09:10:25.4593+00
a8f7904c-1255-4779-a8d9-e84dc81667de	d52fe75d-f2b6-4fe6-abda-29c695a4ffc3	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-27 09:42:46.010367+00
beb3a91d-a6c3-4f47-bb07-43cffa58c3ff	21ce7a33-9249-4a38-b08a-68fce9c3ccad	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-27 21:15:36.972021+00
6b428b81-c157-46c7-86ec-84031b175c8c	3ee5d2f7-8ca6-45a1-80b9-a74bba54e77f	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 02:02:06.641035+00
5bdd3dd1-0037-4731-bb12-cd0dee559ba7	06babf43-8bd2-4999-ae06-09a8f65bc3ad	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 02:39:06.963509+00
cd088a01-3c87-4dbe-8c5b-cdfbfa583466	5f68aa7d-0b2f-4b02-8f2a-d45207be3dbd	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 06:02:49.331604+00
193d931d-9bc2-464e-a675-05a162224ab8	464ea321-52d3-4740-a991-2b997de5fb66	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 06:50:15.723522+00
0766692b-4a04-4d15-9381-d01b7497dc4d	d2df751c-0c65-4720-9938-d8b91b9a7b40	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 07:57:52.421809+00
91b83370-b6c9-4e45-af74-11158c2d7ea6	5145de65-bddb-4336-aee5-88599ef27fb1	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 08:42:26.068689+00
fb4a2e17-638e-4f60-8415-d815ebb87207	216445cf-cdcf-46b6-a305-d4942ca34e07	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 09:12:08.58438+00
d3bf8969-2c38-4ea5-ac3d-a646673765cd	18a28a12-aef2-48f8-be48-5081e4390a06	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 09:33:46.835743+00
1450e257-8daa-462b-bfdf-1b723004c5be	b25c5ae4-b03d-450b-95f2-6cb279fed81e	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-02-28 10:18:14.167149+00
db67a86d-8fbf-4523-ae42-92755064d78e	82810739-e7ae-4670-9363-662c1c2061e2	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 02:39:33.364647+00
75fabaf7-5447-472e-b177-ea61335b1684	946f07e3-cfde-40cd-aec3-a98f4dc6ad79	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 03:20:09.888428+00
da63e8cd-1797-47e2-862d-c69678322b13	1a2053c8-a4d1-4b47-8e73-63670c2ce8f6	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 04:02:44.193846+00
d433189c-2a42-444d-8563-fc1bcba6d636	6c360c4a-26ca-4cab-a9cc-316d5c98f2f1	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 04:44:53.581885+00
cabf4b68-4bdf-4642-8d6e-0c1becbb2cd6	000d534d-faf3-4bc9-9754-8c0218efc30a	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 05:49:39.189592+00
ef7e34b0-3039-45ed-970b-dc0fc097cb43	0e59b962-436c-4114-ae5a-63c00ed0de86	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 06:27:39.661476+00
b29b8b14-74cb-41df-8a83-dc25dc92734e	060ab966-3826-4b54-b8bb-215fa03b49f8	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 07:10:58.317555+00
4aa91d82-a106-42c8-af5d-8518e52c378c	6c7257d0-b9e4-4e8a-93cc-3e304128890f	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 08:22:41.496413+00
44fd5c68-f9e5-41bc-890e-4e04712183bc	afab8800-4d97-4d6d-8f8f-f5599f373f1f	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 08:52:22.178612+00
2eca0d86-5f42-4ef9-92d5-74448114bc4d	a474cc4c-2fd0-4fb7-995c-6148d896e80c	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 09:25:05.371855+00
cd60035e-ce43-4b19-af31-4b60f5a0a986	12e6faf8-f66a-49b4-8a75-c88d8ea4f0f9	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 20:43:15.415792+00
051d68d0-96d9-4525-b467-125d0257e736	61fcfe96-2bf8-4258-8535-e7b103c063b4	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-01 22:04:10.249328+00
cf8ec797-873e-4696-adf9-4ae0e7ec9fe7	f98344ff-5d99-45df-83b3-dccd72b464ba	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 00:29:36.750608+00
e365bc06-3c85-41bd-b9a1-9919933e06d4	e461ab95-563b-4606-a2ba-850b57924ed1	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 01:23:32.908901+00
3aef86f3-61f2-4ad0-8bd3-d8e5fb95896f	861902f4-8af0-4c61-b48b-bf2087dba5b1	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 10:19:08.964362+00
723c1420-63db-4c5d-ac1c-448bba82fe31	f86dfa57-6734-4ee6-8eaa-d2515a220b1e	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 12:43:44.8185+00
69f14367-39b3-4d5a-b99e-ac1e7820c9b4	0b3f7a47-472a-41be-adb7-de7299728aa2	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 13:17:13.385127+00
1c4afea0-0b8b-4d02-901a-56acec410369	0061ea59-ccf0-48de-8f4f-9512d245f02d	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 14:21:08.463576+00
415a100f-184a-4a87-b2b4-e04792b23df7	f14cf564-246a-4e5a-a853-fac169374800	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 15:11:06.573089+00
a1895ccd-4287-4643-b8bd-2fbb68a3e9f1	d362008e-e841-48bd-845c-10fe19ba9bff	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-02 20:33:20.841844+00
07f7feb0-ec79-4712-8cec-ee0a95c52b72	def5e823-9852-4474-a129-7d0500ebd4f6	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-03 00:16:05.734472+00
ce4a207f-5a3f-4080-8a5e-b5b2d54a5891	a0130d14-1e84-4844-ae29-c02a47013c83	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-03 00:55:04.576626+00
38c89b95-ed86-4cd0-b9a2-505074f161a1	b319592d-0470-43e4-91f1-43e1c01da65b	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-03 02:09:51.302572+00
e9841fdd-2191-4c61-bf71-e82ce786fb94	c8d76388-1f14-4af9-b7a1-34c7ca3b0615	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-03 05:11:30.643001+00
ac805a46-a82a-4279-9c68-7bd28d6f64b5	d0612acf-7be2-4794-bf90-33e024943c11	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-03 06:18:04.09869+00
8d836a33-07fa-4d96-8d73-ea8801b93453	ee8e9bde-2033-45f7-81ef-29a3ec17fadb	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-03 16:13:35.786429+00
fc0dda78-5c1e-46ea-a6dc-df2f7e7eb1ea	f05a2a0d-2180-4b50-8e4c-332a08935e70	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-04 09:50:12.255877+00
08f0d96c-14cb-46df-93ca-0f860ecef49b	9f8e95d6-7fb1-4081-ac6c-ba5704eb93b5	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-04 16:20:38.996273+00
21b70b86-ec87-4da7-8fea-183835907c2a	f2cd9503-6c01-47d3-a3ae-f7a09bd20684	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-04 23:16:25.06597+00
3946b5d2-64e2-43b4-96e7-bdf2c1f7c30e	78cb1b85-318d-4624-84e3-fa50ba32431d	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 02:05:00.628945+00
4adabe39-4ce4-4a8b-a9fc-91b661197dca	e5ee9e18-7d14-42da-a64c-0dc228061218	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 03:22:26.09516+00
b705c4b1-7182-415c-a8a9-ddb287636c21	da73a18d-b774-4e95-9439-14452454a14b	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 04:11:55.513065+00
77096515-7f3a-4df5-a828-77804f61908f	2092ef40-01b0-413d-ad0a-2e5b7e37a55c	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 05:22:03.923983+00
83565d55-e6d1-49a9-89d3-2afe6c346a44	dd93acdf-b80c-4be8-b4cf-24b4d0c12042	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 07:31:39.850259+00
f15edd60-02a2-4746-b6d4-2777d6440e16	2f0e6e81-12a1-40e9-afd6-ecdcb3f5f917	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 07:56:20.228268+00
fdf42eac-6a92-4a29-8b2a-3530d89b4f80	4a92804d-deb4-41b2-9ed1-5ade6c946595	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 08:33:32.748045+00
ae23bf60-cd1a-4a42-8cda-e75b3541cce7	6561f049-351f-4f32-b7c1-8583d16e167d	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 09:01:53.448707+00
b438d242-8a3a-420c-8bb9-fa31a817042b	085bcc9e-29fb-48b2-b369-40e78683e60c	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 09:40:22.163493+00
716d4e75-d67f-46a9-bb2e-a076e4c3de14	a559266b-7b2e-42c4-8668-a6f1b108e686	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 11:41:22.082097+00
4a2cd6d6-e560-409b-8eb7-b441de60f688	c6692d11-79ff-4cfa-9edf-aad58b882bab	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 15:28:42.176533+00
dd354381-1783-414d-a4fe-976058993d5e	b7d7b7c5-cff8-4472-a2ff-56d40d95ee20	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-05 22:42:06.181671+00
30d142a9-924a-4559-81dc-a032dab9777f	69151f35-3114-4ea7-9445-e707e8c3548d	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-06 03:03:33.516721+00
53e9c92b-3945-4294-962d-ab2138c2886d	f6e285b1-f0da-4a80-ac2f-e1edce0d2c4b	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-06 05:24:26.841228+00
48d70e72-4bf4-4267-b340-1306320e802e	c639d68c-58f3-4119-a9b8-958c9970939a	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-11 00:31:34.186554+00
1f3602ee-1a6a-4498-a904-47859bdbd367	71988e31-2c9b-4e0c-aecc-b752cbaeae5c	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-11 01:27:50.695604+00
4351dbb5-804d-4611-8d8e-b272189b1bee	f6ae284f-6d48-4c42-9c83-51efe7868b52	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-11 03:01:45.065143+00
458fc6cd-f2c5-4936-afac-47c87e10f352	671c8d7c-4a5b-40e9-8dd8-2b8d1b2c8029	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-11 04:53:21.087334+00
3e24bfbb-d4c8-4afc-bf1c-93e1744da3c0	da8e81ef-7f5f-4279-a7eb-976ed8a125a9	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-11 07:25:04.303197+00
cabb4757-1581-4d09-aa1e-c35585f7b39b	5781cd50-202a-4219-ac12-199696f758b5	https://example.com/test-image.jpg	\N	\N	test-image.jpg	12345	image/jpeg	image	1920	1080	\N	0	2026-03-11 09:01:25.736711+00
\.


--
-- Data for Name: post_votes; Type: TABLE DATA; Schema: forum; Owner: -
--

COPY forum.post_votes (id, post_id, user_id, vote_type, created_at) FROM stdin;
c1e0e333-e17a-430b-8c06-a82847896a8e	eff5e8eb-bd62-4dce-8bc4-7191ffa21181	21c55ea6-7f60-427f-990d-8511ff7ff421	up	2026-02-28 03:02:16.232441+00
12e573d0-6f4d-4f45-8825-3c3b1e765368	91a88757-5b8a-4fb9-9b30-a0e6fa7cc270	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	up	2026-02-28 06:02:34.398698+00
2586ed55-e2b5-44d2-bfb2-031ac54d5c0e	e8d449d3-e372-46fd-90b6-8816e216f5fe	d9640291-3bd0-4af1-ab49-8c2867f1dd74	up	2026-02-28 06:49:59.717271+00
6ce62037-b467-412c-8bae-0bd5bc9ba85b	d5778d74-271e-45ce-bc60-c5318a7f77a3	445e0fc9-051f-4ab6-a6f6-12b334b24cac	up	2026-02-28 07:57:39.810617+00
27d86f72-1d71-430f-97c2-4031a82be459	d288744c-3c50-411c-962d-4cb91a721c4a	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	up	2026-02-28 08:42:11.221614+00
e7f512c1-062c-4839-8471-b19c0f1e0a55	c64ac5a6-359b-4e13-b895-8af1dd40c08e	a91b9539-b268-439e-b171-53a99f420ea7	up	2026-02-28 09:11:56.72951+00
61ee4838-c4a4-418e-851d-f6c14609fda2	7441b1ed-e454-445d-81ed-7a8a533a9904	38097e8b-144a-47cf-95fe-002c168192ad	up	2026-02-28 09:33:38.844954+00
67fcfe44-e5c0-4a4c-9599-88d1d42b5012	44d65a0a-2c7b-41a4-bb08-6b581363bf5e	8642494b-070a-4118-9900-9de9ab1c1a15	up	2026-02-28 10:18:05.770376+00
c67403a8-fdf2-429b-b43e-e13028d8c8c6	3c4e1c89-93c4-4abb-8359-07251ede239a	41a4377c-8f35-4d62-b76b-e5d1045c9c91	up	2026-03-01 02:39:15.069902+00
2307770e-e6ec-467e-bd3b-dd37a271b12d	6f7e45e8-fec2-4370-9544-a5b330add8ff	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	up	2026-03-01 03:19:48.657539+00
e34d7e90-eb1a-4bac-955f-27ea71c2275e	e71cd790-6140-4be0-b88d-516b23fb60d8	cc04016a-872b-40c2-b75a-acdb030b759d	up	2026-03-01 04:02:31.518644+00
e12dee07-ad87-4192-b54c-b7b7a4bdead8	9b1cbad2-5223-4aa1-8d6b-5fe3427c83d9	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	up	2026-03-01 04:44:45.778094+00
c3368b50-d45e-4cc1-b2ae-5650b1d7381a	f4bb97ac-ce74-41e8-9770-032b7ca63cfc	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	up	2026-03-01 05:49:30.606574+00
bfec8ceb-23dc-4f2f-bea3-4019226c8b64	5160c280-2241-433e-9f62-9ab8f90faf73	e08c76f6-b5b7-4dce-b61d-450c96abedd6	up	2026-03-01 06:27:28.324694+00
34809420-3eac-4e21-b30c-0702b0aba2f9	1c2461da-06e8-4b5a-a02f-b9c2d9c9ffe6	2f2cd581-05ce-4f21-8352-e51f1be40de4	up	2026-03-01 07:10:46.564689+00
6cd7347b-089b-456a-ab31-f7e371e03954	9230ec06-3e4e-4f7e-bcbb-7f83919c1388	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	up	2026-03-01 08:22:24.927805+00
efeadc02-1dba-4e79-9635-2abc935ea21a	ecc26c5a-9ada-4713-b5fd-bbf97a2068d0	391d8769-702e-4c1a-a44c-29022307c877	up	2026-03-01 08:52:13.190642+00
66ebc68f-d7c4-45a3-ad7c-4480afe43d3b	78facf02-8cc6-489a-80c4-d1a463e8007b	ca77bbd7-501b-4cea-88d8-3f62f7e46255	up	2026-03-01 09:24:41.636463+00
2e8f69a4-848f-441b-8ea8-93ff8a7b8bfa	53ed8dca-c521-4231-83e1-ae9ab65d2a11	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	up	2026-03-01 20:42:59.902059+00
09900a03-dd81-4118-b426-c7d71ac4c5ad	29dbaf40-7525-4487-9028-a31dc7c4134e	21ff734b-3c75-4574-97c9-c35cc3818bc6	up	2026-03-01 22:03:53.428835+00
5a1bc836-4e5c-4466-8f88-00359ec9d552	359f62ed-8fc4-498a-962c-a2df71c96ce7	92a67500-cdac-43d1-8f4b-f27e7f1891ec	up	2026-03-02 00:29:22.54688+00
094cfc6d-d21e-4465-b07b-6f603969cf04	1a60049c-38fa-41de-a15b-121c9d9a6ed8	6246157a-a93d-4ef5-b943-c9a143f03e2d	up	2026-03-02 01:23:18.403443+00
0d6e6a57-677d-4110-a9a8-7f339549abbc	794ea3d0-299f-4488-81c1-5721d6bd66fe	56886316-0d84-4556-ba46-56b476dcfffa	up	2026-03-02 10:18:57.668022+00
ffff3d72-2b1f-4054-ae8a-a14b13107f03	c1ee4ae8-e5e5-449c-802c-95ebcaf77196	563da29b-6b23-4753-8dba-01fdbb6f905d	up	2026-03-02 12:43:33.744605+00
cb28864d-9374-4cad-9304-1f8fd43e2df7	3b355715-3f13-4ada-ab5a-389e635c17dc	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	up	2026-03-02 13:17:05.214196+00
2f00e72f-94dc-49bd-9fb1-5eb18c07a8bb	d5ea4396-7d0b-4416-b972-1cb17a10c93c	0d58e6b5-eb5a-4976-bae0-2f459280932a	up	2026-03-02 13:37:21.101946+00
3b67367e-7495-49c3-831d-e75f71c2d759	11943cac-d9c1-4067-a3d2-eb03f985fb6a	24246ea0-c094-4c8c-b167-a83a72bed89b	up	2026-03-02 14:20:52.662033+00
80f57e32-48f8-4781-a24d-e37a5e3ceb08	0b5ed87d-0634-4e10-bf4d-5b71530dbc6f	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	up	2026-03-02 15:10:57.928696+00
acfb37c2-955c-412e-98c5-6997d6fbcda0	2d5a20d0-5ba5-4b69-8155-c10f433ef19e	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	up	2026-03-02 20:33:12.984927+00
5c7965e7-8af1-44bc-ae98-47ccabf154af	22b58c95-6c8a-4452-9085-5e51260c1242	436892ad-1a40-40dd-ad3e-62d59baca3bb	up	2026-03-03 00:15:57.441657+00
6931310b-401f-43ae-80d7-40d3fb325098	aba17d5a-4877-4e97-8e8f-cd1513f5ba45	ee231bdc-5265-4443-bf4a-a66f74a3e754	up	2026-03-03 00:54:48.948648+00
c3aa9674-ceef-46a9-86bc-3bc4b0c89c85	22e2a3b7-c2cf-4807-a307-fe8b48495e88	245ed62a-4f36-4819-b992-d06509f66369	up	2026-03-03 02:09:38.64856+00
a48fd90f-8191-43b5-80f1-50b409be937b	1d0326ae-951f-4980-a2ef-89fa671402d1	28043028-1578-4221-b470-b43484c8fc7e	up	2026-03-03 05:11:14.647857+00
48e1b0e2-d5b2-40d6-a4cf-22875832c391	e3d32c46-ecc2-4a8c-99eb-18d09cb2c05b	56bdeb68-a57e-497e-95a3-c8eb0f596d61	up	2026-03-03 06:17:50.014728+00
77f3760e-aa3e-4fb0-a4c5-35c206d96bf3	be2753a7-770c-49b8-9ee8-e2013559eefd	cd859d66-dee0-4cb6-9689-bd47cae0be0f	up	2026-03-03 16:13:20.218997+00
640c6284-93b3-45ce-b2e3-de99842b0f9d	03e587d5-0b2d-4203-bda1-3a60abeba33d	b282ed2d-29af-4fad-a357-02ab89c459fd	up	2026-03-04 09:50:03.836632+00
b3018445-8595-40dd-bc0b-bd098d8eb48e	2cc729b7-0f5e-4fe4-838a-7dc9b8ba99d9	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	up	2026-03-04 16:20:27.759098+00
c9408b63-f3e1-4944-b7ed-06d099d711c8	7b33e813-91c4-409d-858d-0f76ab58d2c9	a11c2fb2-b350-416b-9cb4-176c82eaf560	up	2026-03-04 23:16:10.003151+00
0ae21d4f-3ab5-4da3-8e8d-c2af22179c13	184ff4db-a253-43d2-abe1-726c09832976	b7273deb-f387-46c0-a5d4-712a9784544d	up	2026-03-05 02:04:41.784746+00
d062b21c-7f11-49ca-9255-eef3f394653c	77788cfa-4b4a-492f-8199-69db8a6e27f7	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	up	2026-03-05 03:22:13.508974+00
864665c1-05db-4682-a1e9-bd27c576041b	6db217e5-0f20-4931-bd2c-3438526a7f0c	5176ab32-17b3-4f7d-8432-2d93718a0bbf	up	2026-03-05 04:11:45.870461+00
3d74e0e0-9e50-4564-9a9a-81bb57904d8b	c681b4dc-061e-48e6-8044-14e433b3d434	aa3a21e3-ae58-40a2-946c-2c5e799d0330	up	2026-03-05 05:21:51.944272+00
8c854eca-8c0f-4eab-8681-a0f9c0aa64a5	6160450d-c5a4-4dfc-9dd9-4b0e89def46c	cdc85298-8764-4ff7-8acf-74ace40dd1d8	up	2026-03-05 07:31:27.888419+00
938ac8e0-c333-40d8-9641-f170599085b9	c803a568-8751-445b-a276-da1dba5fd570	d8290673-93c3-421c-8914-4c2a0f83b12b	up	2026-03-05 07:56:10.48496+00
d98541a7-e3b4-48f4-a66c-bf0dcebdf8f6	f476e310-225e-4860-a4d2-8f109d1cc683	8701ce73-3f04-42af-8554-c72cb58a838f	up	2026-03-05 08:33:06.895958+00
ac956225-3362-4723-b07a-db7077124a30	29695f06-74db-40a5-a12c-7fd33f869281	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	up	2026-03-05 09:01:33.820342+00
52916f7a-45f0-4bf3-860e-71c5aed90461	7e853104-1a64-43f4-b67e-69baa3b132e3	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	up	2026-03-05 09:40:13.598181+00
448fd247-7af0-47fb-901b-6ab0bcac034f	15db143a-27ac-48b1-831b-297df09d53e4	c50a2a26-686c-434a-86bb-828cb62f0ce0	up	2026-03-05 11:41:13.709178+00
8e503f44-25cf-4a6e-825b-e51d1f37a5cc	cc5eeab9-8ac7-4601-999b-8832337b2fdb	3bb235ee-59d6-449b-b5a9-99e70614c7c2	up	2026-03-05 15:28:25.646349+00
47617766-ab1a-4999-b886-8569e8a117a2	870a91bc-7f2b-4505-a38f-fd5a27aa9dae	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	up	2026-03-05 22:41:50.223349+00
e4004478-0932-4079-a545-ee4ae910a688	499d7de8-57a8-4d71-82a7-29114888b028	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	up	2026-03-06 03:03:20.659814+00
01bb263b-a0c5-4f6e-9a8c-4c64a56017f7	a933c8c8-29b8-483f-9f0c-70d9e311edf1	74fd4160-d207-47b4-87c2-e418ccf0462e	up	2026-03-06 05:24:11.700836+00
1a14cbda-1f96-4adb-8978-92ade643214e	ae9aa93d-a3c1-49bf-b2bb-939622dded53	ae6839bd-0c8a-4f8b-8785-c1b37880e158	up	2026-03-11 00:31:24.010646+00
70409c22-f921-4c4a-b0e6-62e72082982b	fadaf9e5-cdd4-448a-8412-20e33d8d1a0e	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	up	2026-03-11 01:27:36.792448+00
9d20cc5b-efe4-4ac7-8d1a-46a7857d88ec	09ec70aa-bbf3-4224-bd9a-628bd13c1570	d52c170c-8356-4666-b7b7-4d0c772ae583	up	2026-03-11 03:01:38.078293+00
2ff186da-9776-4ebc-8252-885489787723	036baece-222a-4403-840c-ebfa09da7d5c	491c69a3-3681-4da0-beac-053d9351c06a	up	2026-03-11 04:53:03.418834+00
a6cbe7df-edec-4844-9018-3c3fdc8fa5fe	71c5a2c9-a338-4bc9-8643-bfc32964a677	d8f6ab86-5b6b-472c-b393-74632a4bc00a	up	2026-03-11 07:24:54.994036+00
c34a2256-ccff-4fef-b15d-d33755d47230	6dc18105-f0a1-4e9d-bb04-7e9a3cf3c774	f6e8e0bd-41cb-48eb-9587-43e14005f426	up	2026-03-11 09:01:15.498659+00
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: forum; Owner: -
--

COPY forum.posts (id, user_id, title, content, flair, upload_type, upvotes, downvotes, comment_count, is_pinned, is_locked, created_at, updated_at) FROM stdin;
e1e07f89-224d-4fee-8b7a-204ac9a391c1	210ea469-1f0b-4e7a-9064-10bc09022f6b	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-27 07:57:38.087115+00	2026-02-27 07:57:38.087115+00
1f783840-912a-4895-a7c3-340502c8db0a	210ea469-1f0b-4e7a-9064-10bc09022f6b	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	1	f	f	2026-02-27 07:57:32.584025+00	2026-02-27 07:57:38.546951+00
3fd89ef1-1f37-4c68-b3c4-6775bd8fd9d4	3912eb1f-e62d-4f9d-a28c-3f7542e24446	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-27 08:38:01.792865+00	2026-02-27 08:38:01.792865+00
464ea321-52d3-4740-a991-2b997de5fb66	d9640291-3bd0-4af1-ab49-8c2867f1dd74	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 06:50:15.643207+00	2026-02-28 06:50:15.643207+00
bef76a75-2944-466b-8ec6-ed2b20758588	3912eb1f-e62d-4f9d-a28c-3f7542e24446	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-27 08:39:13.664972+00	2026-02-27 08:39:13.664972+00
f387d943-c6ec-477b-9b7d-13b02e92516c	3912eb1f-e62d-4f9d-a28c-3f7542e24446	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	2	f	f	2026-02-27 08:37:56.296772+00	2026-02-27 08:39:14.007951+00
5123e7d9-a02d-443e-affe-f312ee29769e	021b5560-5b8a-4028-94fd-83c8c102c5e2	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-27 09:09:34.469548+00	2026-02-27 09:09:34.469548+00
e8d449d3-e372-46fd-90b6-8816e216f5fe	d9640291-3bd0-4af1-ab49-8c2867f1dd74	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 06:49:48.098252+00	2026-02-28 06:50:16.104172+00
db3e7cd9-fc3a-4973-88bb-2e9635d01c22	021b5560-5b8a-4028-94fd-83c8c102c5e2	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-27 09:10:25.412607+00	2026-02-27 09:10:25.412607+00
c177bbef-ed44-4b79-a26c-0e63c8397b92	021b5560-5b8a-4028-94fd-83c8c102c5e2	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	2	f	f	2026-02-27 09:09:28.979019+00	2026-02-27 09:10:32.805433+00
adcd67ec-2a76-430f-82ea-f1d7d83044c0	6ad98c87-3efa-41af-abeb-963cf0c9c96b	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-27 09:41:27.42086+00	2026-02-27 09:41:27.42086+00
d52fe75d-f2b6-4fe6-abda-29c695a4ffc3	6ad98c87-3efa-41af-abeb-963cf0c9c96b	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-27 09:42:45.961198+00	2026-02-27 09:42:45.961198+00
edb23991-01e6-43a2-b0df-82585bfbab1e	6ad98c87-3efa-41af-abeb-963cf0c9c96b	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	2	f	f	2026-02-27 09:41:21.916942+00	2026-02-27 09:42:49.338311+00
48f6509d-78a2-4490-a5f1-2255eb3b6128	3e9b0531-adbb-4989-9906-144bf69095e8	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-27 21:14:19.450577+00	2026-02-27 21:14:19.450577+00
acc71d52-7dbf-4212-9adf-0048fcd49cc4	445e0fc9-051f-4ab6-a6f6-12b334b24cac	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 07:57:17.472995+00	2026-02-28 07:57:17.472995+00
21ce7a33-9249-4a38-b08a-68fce9c3ccad	3e9b0531-adbb-4989-9906-144bf69095e8	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-27 21:15:36.926716+00	2026-02-27 21:15:36.926716+00
a1011270-fad1-4253-82ce-bcb952d60606	3e9b0531-adbb-4989-9906-144bf69095e8	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	2	f	f	2026-02-27 21:14:13.849242+00	2026-02-27 21:15:40.317978+00
500a39a9-7aa4-4c81-ac0f-b048b385a7c0	c6414dc6-8494-4962-a5a8-9032b76a6a36	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 02:01:05.126005+00	2026-02-28 02:01:05.126005+00
216445cf-cdcf-46b6-a305-d4942ca34e07	a91b9539-b268-439e-b171-53a99f420ea7	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 09:12:08.4818+00	2026-02-28 09:12:08.4818+00
3ee5d2f7-8ca6-45a1-80b9-a74bba54e77f	c6414dc6-8494-4962-a5a8-9032b76a6a36	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 02:02:06.585603+00	2026-02-28 02:02:06.585603+00
780a9699-7311-463a-8f51-f701f8fddf76	c6414dc6-8494-4962-a5a8-9032b76a6a36	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	2	f	f	2026-02-28 02:00:52.506681+00	2026-02-28 02:02:06.938992+00
3a8c8fb4-422a-4cd0-97ce-e5859334614a	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 02:37:45.205212+00	2026-02-28 02:37:45.205212+00
06babf43-8bd2-4999-ae06-09a8f65bc3ad	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 02:39:06.919231+00	2026-02-28 02:39:06.919231+00
bc03acb5-3ba5-4d27-9bd1-305d464c9977	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	Test Forum Post	This is a test post via HTTP/2	general	text	0	0	2	f	f	2026-02-28 02:37:39.582996+00	2026-02-28 02:39:07.282099+00
50528a50-cad0-4193-b874-c81417051344	fb864704-8a2e-480f-8a19-9cbb30f20c09	Vote repro	502 repro	general	text	0	0	0	f	f	2026-02-28 02:59:08.470494+00	2026-02-28 02:59:08.470494+00
d33ddbd6-f58e-4f79-b0c9-34e9f6ebba3e	624651ef-684e-4664-9dea-0e11ef220337	Vote repro	502 repro	general	text	0	0	0	f	f	2026-02-28 03:00:45.257806+00	2026-02-28 03:00:45.257806+00
eff5e8eb-bd62-4dce-8bc4-7191ffa21181	21c55ea6-7f60-427f-990d-8511ff7ff421	Vote repro	502 repro	general	text	1	0	0	f	f	2026-02-28 03:01:44.749156+00	2026-02-28 03:02:16.232441+00
df124806-4f5a-4bf4-b156-1825d4746da1	d1be53a0-aa0b-4c71-838a-8af2edcbfdd9	Vote repro	502 repro	general	text	0	0	0	f	f	2026-02-28 03:03:01.252+00	2026-02-28 03:03:01.252+00
8f3aeccd-5453-41e0-a68d-2a88d0dce265	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 06:02:32.025275+00	2026-02-28 06:02:32.025275+00
d2df751c-0c65-4720-9938-d8b91b9a7b40	445e0fc9-051f-4ab6-a6f6-12b334b24cac	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 07:57:52.245183+00	2026-02-28 07:57:52.245183+00
5f68aa7d-0b2f-4b02-8f2a-d45207be3dbd	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 06:02:49.253513+00	2026-02-28 06:02:49.253513+00
91a88757-5b8a-4fb9-9b30-a0e6fa7cc270	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 06:02:25.994449+00	2026-02-28 06:02:49.694159+00
754636d1-bcd1-4355-8aeb-2c9af5976d1c	d9640291-3bd0-4af1-ab49-8c2867f1dd74	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 06:49:53.998825+00	2026-02-28 06:49:53.998825+00
d5778d74-271e-45ce-bc60-c5318a7f77a3	445e0fc9-051f-4ab6-a6f6-12b334b24cac	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 07:57:08.262017+00	2026-02-28 07:57:52.815971+00
bfa05315-909a-4c00-9592-e2069df4c979	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 08:42:06.039825+00	2026-02-28 08:42:06.039825+00
c64ac5a6-359b-4e13-b895-8af1dd40c08e	a91b9539-b268-439e-b171-53a99f420ea7	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 09:11:46.282552+00	2026-02-28 09:12:11.987253+00
5145de65-bddb-4336-aee5-88599ef27fb1	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 08:42:25.993172+00	2026-02-28 08:42:25.993172+00
d288744c-3c50-411c-962d-4cb91a721c4a	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 08:41:57.086969+00	2026-02-28 08:42:26.399294+00
c43ec0f7-2283-4d20-b8ca-457f0c2c7fec	a91b9539-b268-439e-b171-53a99f420ea7	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 09:11:51.972429+00	2026-02-28 09:11:51.972429+00
e29aba7d-9847-4db0-b3d1-97162eb85354	38097e8b-144a-47cf-95fe-002c168192ad	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 09:33:37.17058+00	2026-02-28 09:33:37.17058+00
acd99e42-d708-4be1-ad69-be0ffde3f12a	8642494b-070a-4118-9900-9de9ab1c1a15	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-02-28 10:18:00.570146+00	2026-02-28 10:18:00.570146+00
18a28a12-aef2-48f8-be48-5081e4390a06	38097e8b-144a-47cf-95fe-002c168192ad	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 09:33:46.758517+00	2026-02-28 09:33:46.758517+00
7441b1ed-e454-445d-81ed-7a8a533a9904	38097e8b-144a-47cf-95fe-002c168192ad	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 09:33:31.45695+00	2026-02-28 09:33:47.151003+00
b25c5ae4-b03d-450b-95f2-6cb279fed81e	8642494b-070a-4118-9900-9de9ab1c1a15	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-02-28 10:18:14.051961+00	2026-02-28 10:18:14.051961+00
44d65a0a-2c7b-41a4-bb08-6b581363bf5e	8642494b-070a-4118-9900-9de9ab1c1a15	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-02-28 10:17:51.781258+00	2026-02-28 10:18:14.47696+00
280079ec-9202-4938-823f-e217217ae747	41a4377c-8f35-4d62-b76b-e5d1045c9c91	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 02:39:12.578843+00	2026-03-01 02:39:12.578843+00
82810739-e7ae-4670-9363-662c1c2061e2	41a4377c-8f35-4d62-b76b-e5d1045c9c91	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 02:39:33.238669+00	2026-03-01 02:39:33.238669+00
3c4e1c89-93c4-4abb-8359-07251ede239a	41a4377c-8f35-4d62-b76b-e5d1045c9c91	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 02:39:03.84995+00	2026-03-01 02:39:36.743756+00
132f4652-e480-4d81-99e9-75d57b07a6c2	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 03:19:43.129905+00	2026-03-01 03:19:43.129905+00
62988543-5e1e-4634-9bae-e3ba856119a2	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 20:33:09.708192+00	2026-03-02 20:33:09.708192+00
946f07e3-cfde-40cd-aec3-a98f4dc6ad79	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 03:20:09.805386+00	2026-03-01 03:20:09.805386+00
6f7e45e8-fec2-4370-9544-a5b330add8ff	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 03:19:33.286312+00	2026-03-01 03:20:23.040964+00
358db9d5-4090-4bb6-94ac-72755a77692b	cc04016a-872b-40c2-b75a-acdb030b759d	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 04:02:18.895566+00	2026-03-01 04:02:18.895566+00
1a2053c8-a4d1-4b47-8e73-63670c2ce8f6	cc04016a-872b-40c2-b75a-acdb030b759d	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 04:02:44.096037+00	2026-03-01 04:02:44.096037+00
e71cd790-6140-4be0-b88d-516b23fb60d8	cc04016a-872b-40c2-b75a-acdb030b759d	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 04:02:12.911202+00	2026-03-01 04:02:44.743267+00
dfdaba12-635f-41b2-ac11-b76db7885b65	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 04:44:43.500133+00	2026-03-01 04:44:43.500133+00
afab8800-4d97-4d6d-8f8f-f5599f373f1f	391d8769-702e-4c1a-a44c-29022307c877	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 08:52:22.097737+00	2026-03-01 08:52:22.097737+00
6c360c4a-26ca-4cab-a9cc-316d5c98f2f1	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 04:44:53.485843+00	2026-03-01 04:44:53.485843+00
9b1cbad2-5223-4aa1-8d6b-5fe3427c83d9	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 04:44:30.091549+00	2026-03-01 04:44:53.903823+00
ecc26c5a-9ada-4713-b5fd-bbf97a2068d0	391d8769-702e-4c1a-a44c-29022307c877	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 08:52:02.040848+00	2026-03-01 08:52:25.940038+00
08058d8d-352c-403d-a21b-59ef64481d88	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 05:49:25.171522+00	2026-03-01 05:49:25.171522+00
26a62f1a-6d50-411f-8295-e1e1c34e691e	ca77bbd7-501b-4cea-88d8-3f62f7e46255	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 09:24:33.66422+00	2026-03-01 09:24:33.66422+00
000d534d-faf3-4bc9-9754-8c0218efc30a	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 05:49:39.110916+00	2026-03-01 05:49:39.110916+00
f4bb97ac-ce74-41e8-9770-032b7ca63cfc	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 05:49:12.157842+00	2026-03-01 05:49:39.514089+00
f4425079-965a-4304-bbdc-7fe768596cfe	e08c76f6-b5b7-4dce-b61d-450c96abedd6	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 06:27:22.732784+00	2026-03-01 06:27:22.732784+00
29dbaf40-7525-4487-9028-a31dc7c4134e	21ff734b-3c75-4574-97c9-c35cc3818bc6	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 22:03:35.248458+00	2026-03-01 22:04:10.795263+00
0e59b962-436c-4114-ae5a-63c00ed0de86	e08c76f6-b5b7-4dce-b61d-450c96abedd6	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 06:27:39.577257+00	2026-03-01 06:27:39.577257+00
5160c280-2241-433e-9f62-9ab8f90faf73	e08c76f6-b5b7-4dce-b61d-450c96abedd6	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 06:27:07.330338+00	2026-03-01 06:27:40.071412+00
d69a7a92-b44a-4661-9dd0-37b8b01487ee	2f2cd581-05ce-4f21-8352-e51f1be40de4	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 07:10:41.695901+00	2026-03-01 07:10:41.695901+00
060ab966-3826-4b54-b8bb-215fa03b49f8	2f2cd581-05ce-4f21-8352-e51f1be40de4	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 07:10:58.221429+00	2026-03-01 07:10:58.221429+00
1c2461da-06e8-4b5a-a02f-b9c2d9c9ffe6	2f2cd581-05ce-4f21-8352-e51f1be40de4	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 07:10:35.886872+00	2026-03-01 07:10:58.708523+00
f7e5b7d9-6841-43a3-867f-fb36668da7b8	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 08:22:15.581707+00	2026-03-01 08:22:15.581707+00
a474cc4c-2fd0-4fb7-995c-6148d896e80c	ca77bbd7-501b-4cea-88d8-3f62f7e46255	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 09:25:05.278898+00	2026-03-01 09:25:05.278898+00
6c7257d0-b9e4-4e8a-93cc-3e304128890f	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 08:22:41.405585+00	2026-03-01 08:22:41.405585+00
9230ec06-3e4e-4f7e-bcbb-7f83919c1388	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 08:22:09.489408+00	2026-03-01 08:22:44.987431+00
10ba1d4d-609b-4e05-994d-b1a57fd2507e	391d8769-702e-4c1a-a44c-29022307c877	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 08:52:07.756921+00	2026-03-01 08:52:07.756921+00
78facf02-8cc6-489a-80c4-d1a463e8007b	ca77bbd7-501b-4cea-88d8-3f62f7e46255	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 09:24:27.770572+00	2026-03-01 09:25:08.818985+00
f6b1cf67-e511-4b0e-bff5-6d7b108c0a0a	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 20:42:57.404976+00	2026-03-01 20:42:57.404976+00
12e6faf8-f66a-49b4-8a75-c88d8ea4f0f9	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 20:43:15.230972+00	2026-03-01 20:43:15.230972+00
53ed8dca-c521-4231-83e1-ae9ab65d2a11	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-01 20:42:51.62635+00	2026-03-01 20:43:15.856204+00
954129b1-6800-4a5c-bf2a-616e2d180073	21ff734b-3c75-4574-97c9-c35cc3818bc6	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-01 22:03:42.800753+00	2026-03-01 22:03:42.800753+00
61fcfe96-2bf8-4258-8535-e7b103c063b4	21ff734b-3c75-4574-97c9-c35cc3818bc6	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-01 22:04:09.984677+00	2026-03-01 22:04:09.984677+00
0ce77038-91c5-46ea-81a7-4408c1dc65bf	92a67500-cdac-43d1-8f4b-f27e7f1891ec	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 00:29:20.560783+00	2026-03-02 00:29:20.560783+00
e461ab95-563b-4606-a2ba-850b57924ed1	6246157a-a93d-4ef5-b943-c9a143f03e2d	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 01:23:32.817424+00	2026-03-02 01:23:32.817424+00
f98344ff-5d99-45df-83b3-dccd72b464ba	92a67500-cdac-43d1-8f4b-f27e7f1891ec	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 00:29:36.665501+00	2026-03-02 00:29:36.665501+00
359f62ed-8fc4-498a-962c-a2df71c96ce7	92a67500-cdac-43d1-8f4b-f27e7f1891ec	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 00:29:12.514696+00	2026-03-02 00:29:37.087104+00
35e4b6a5-1295-4be5-ba57-f7bb843bccf3	6246157a-a93d-4ef5-b943-c9a143f03e2d	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 01:23:16.552077+00	2026-03-02 01:23:16.552077+00
1a60049c-38fa-41de-a15b-121c9d9a6ed8	6246157a-a93d-4ef5-b943-c9a143f03e2d	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 01:23:10.800833+00	2026-03-02 01:23:33.289667+00
a078ca6b-380f-4be7-b354-ac88abc34832	56886316-0d84-4556-ba46-56b476dcfffa	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 10:18:51.862778+00	2026-03-02 10:18:51.862778+00
861902f4-8af0-4c61-b48b-bf2087dba5b1	56886316-0d84-4556-ba46-56b476dcfffa	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 10:19:08.867461+00	2026-03-02 10:19:08.867461+00
794ea3d0-299f-4488-81c1-5721d6bd66fe	56886316-0d84-4556-ba46-56b476dcfffa	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 10:18:45.905774+00	2026-03-02 10:19:09.275742+00
7826b626-2f87-4871-a77e-0e13853991eb	563da29b-6b23-4753-8dba-01fdbb6f905d	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 12:43:31.402706+00	2026-03-02 12:43:31.402706+00
c1ee4ae8-e5e5-449c-802c-95ebcaf77196	563da29b-6b23-4753-8dba-01fdbb6f905d	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 12:43:25.590094+00	2026-03-02 12:43:45.510231+00
f86dfa57-6734-4ee6-8eaa-d2515a220b1e	563da29b-6b23-4753-8dba-01fdbb6f905d	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 12:43:44.488078+00	2026-03-02 12:43:44.488078+00
3baf0f24-4717-4dfa-abea-837c69476138	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 13:17:02.800195+00	2026-03-02 13:17:02.800195+00
0b3f7a47-472a-41be-adb7-de7299728aa2	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 13:17:13.304022+00	2026-03-02 13:17:13.304022+00
3b355715-3f13-4ada-ab5a-389e635c17dc	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 13:16:56.909882+00	2026-03-02 13:17:13.767525+00
d5ea4396-7d0b-4416-b972-1cb17a10c93c	0d58e6b5-eb5a-4976-bae0-2f459280932a	Updated title	Updated body	general	text	1	0	1	f	f	2026-03-02 13:37:15.317077+00	2026-03-02 13:37:21.319489+00
e7cee905-9c36-4532-a47a-388377a9c377	24246ea0-c094-4c8c-b167-a83a72bed89b	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 14:20:50.17628+00	2026-03-02 14:20:50.17628+00
0061ea59-ccf0-48de-8f4f-9512d245f02d	24246ea0-c094-4c8c-b167-a83a72bed89b	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 14:21:08.38843+00	2026-03-02 14:21:08.38843+00
11943cac-d9c1-4067-a3d2-eb03f985fb6a	24246ea0-c094-4c8c-b167-a83a72bed89b	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 14:20:43.996617+00	2026-03-02 14:21:08.809052+00
d362008e-e841-48bd-845c-10fe19ba9bff	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 20:33:20.75319+00	2026-03-02 20:33:20.75319+00
2d5a20d0-5ba5-4b69-8155-c10f433ef19e	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 20:33:02.830581+00	2026-03-02 20:33:21.163312+00
38e69ea7-29d9-45d6-b686-3159c9739f0a	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-02 15:10:56.171799+00	2026-03-02 15:10:56.171799+00
f14cf564-246a-4e5a-a853-fac169374800	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-02 15:11:06.488391+00	2026-03-02 15:11:06.488391+00
0b5ed87d-0634-4e10-bf4d-5b71530dbc6f	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-02 15:10:50.518468+00	2026-03-02 15:11:06.892029+00
ecfaf2ce-d163-42e2-8952-85157c0583c9	436892ad-1a40-40dd-ad3e-62d59baca3bb	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-03 00:15:55.392631+00	2026-03-03 00:15:55.392631+00
def5e823-9852-4474-a129-7d0500ebd4f6	436892ad-1a40-40dd-ad3e-62d59baca3bb	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-03 00:16:05.612249+00	2026-03-03 00:16:05.612249+00
22b58c95-6c8a-4452-9085-5e51260c1242	436892ad-1a40-40dd-ad3e-62d59baca3bb	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-03 00:15:46.528375+00	2026-03-03 00:16:09.260668+00
be68e22a-b266-4c07-9fa4-aa6b68fded85	ee231bdc-5265-4443-bf4a-a66f74a3e754	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-03 00:54:43.291121+00	2026-03-03 00:54:43.291121+00
97f5a323-62a0-426f-94ab-84f01f2235e4	b282ed2d-29af-4fad-a357-02ab89c459fd	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-04 09:50:01.097726+00	2026-03-04 09:50:01.097726+00
a0130d14-1e84-4844-ae29-c02a47013c83	ee231bdc-5265-4443-bf4a-a66f74a3e754	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-03 00:55:04.483037+00	2026-03-03 00:55:04.483037+00
aba17d5a-4877-4e97-8e8f-cd1513f5ba45	ee231bdc-5265-4443-bf4a-a66f74a3e754	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-03 00:54:36.853807+00	2026-03-03 00:55:04.960041+00
ca91213d-11d9-4c96-baf7-cf64de38c826	245ed62a-4f36-4819-b992-d06509f66369	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-03 02:09:35.948928+00	2026-03-03 02:09:35.948928+00
3b990bbd-efba-4c7b-b97f-00d5a84c433b	56bdeb68-a57e-497e-95a3-c8eb0f596d61	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-03 06:17:37.978219+00	2026-03-03 06:17:37.978219+00
b319592d-0470-43e4-91f1-43e1c01da65b	245ed62a-4f36-4819-b992-d06509f66369	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-03 02:09:50.820895+00	2026-03-03 02:09:50.820895+00
22e2a3b7-c2cf-4807-a307-fe8b48495e88	245ed62a-4f36-4819-b992-d06509f66369	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-03 02:09:30.247791+00	2026-03-03 02:09:54.673172+00
31e62d45-9b0e-46ac-b86d-5ac3462f5a40	28043028-1578-4221-b470-b43484c8fc7e	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-03 05:11:02.769669+00	2026-03-03 05:11:02.769669+00
d0612acf-7be2-4794-bf90-33e024943c11	56bdeb68-a57e-497e-95a3-c8eb0f596d61	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-03 06:18:03.891865+00	2026-03-03 06:18:03.891865+00
c8d76388-1f14-4af9-b7a1-34c7ca3b0615	28043028-1578-4221-b470-b43484c8fc7e	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-03 05:11:30.426274+00	2026-03-03 05:11:30.426274+00
1d0326ae-951f-4980-a2ef-89fa671402d1	28043028-1578-4221-b470-b43484c8fc7e	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-03 05:10:49.470087+00	2026-03-03 05:11:34.313566+00
e3d32c46-ecc2-4a8c-99eb-18d09cb2c05b	56bdeb68-a57e-497e-95a3-c8eb0f596d61	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-03 06:17:26.718969+00	2026-03-03 06:18:04.71751+00
f05a2a0d-2180-4b50-8e4c-332a08935e70	b282ed2d-29af-4fad-a357-02ab89c459fd	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-04 09:50:12.127138+00	2026-03-04 09:50:12.127138+00
03e587d5-0b2d-4203-bda1-3a60abeba33d	b282ed2d-29af-4fad-a357-02ab89c459fd	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-04 09:49:55.190573+00	2026-03-04 09:50:12.59147+00
a4d6417b-ed78-47c6-8bbf-70a0bafcb629	cd859d66-dee0-4cb6-9689-bd47cae0be0f	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-03 16:12:49.429296+00	2026-03-03 16:12:49.429296+00
ee8e9bde-2033-45f7-81ef-29a3ec17fadb	cd859d66-dee0-4cb6-9689-bd47cae0be0f	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-03 16:13:35.605585+00	2026-03-03 16:13:35.605585+00
be2753a7-770c-49b8-9ee8-e2013559eefd	cd859d66-dee0-4cb6-9689-bd47cae0be0f	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-03 16:12:41.508272+00	2026-03-03 16:13:36.226585+00
cd87d376-9a81-44b7-9dfa-10c353c1ad36	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-04 16:20:25.903271+00	2026-03-04 16:20:25.903271+00
f2cd9503-6c01-47d3-a3ae-f7a09bd20684	a11c2fb2-b350-416b-9cb4-176c82eaf560	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-04 23:16:24.974271+00	2026-03-04 23:16:24.974271+00
9f8e95d6-7fb1-4081-ac6c-ba5704eb93b5	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-04 16:20:38.917724+00	2026-03-04 16:20:38.917724+00
2cc729b7-0f5e-4fe4-838a-7dc9b8ba99d9	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-04 16:20:19.912077+00	2026-03-04 16:20:39.331614+00
7b33e813-91c4-409d-858d-0f76ab58d2c9	a11c2fb2-b350-416b-9cb4-176c82eaf560	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-04 23:15:57.588614+00	2026-03-04 23:16:25.41104+00
714b047c-8024-4655-ba1c-5f09426cd265	a11c2fb2-b350-416b-9cb4-176c82eaf560	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-04 23:16:06.869346+00	2026-03-04 23:16:06.869346+00
78cb1b85-318d-4624-84e3-fa50ba32431d	b7273deb-f387-46c0-a5d4-712a9784544d	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 02:05:00.438625+00	2026-03-05 02:05:00.438625+00
184ff4db-a253-43d2-abe1-726c09832976	b7273deb-f387-46c0-a5d4-712a9784544d	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 02:04:23.033619+00	2026-03-05 02:05:01.287048+00
77ac10ee-d4d2-4005-b869-a43a5a850cf1	b7273deb-f387-46c0-a5d4-712a9784544d	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 02:04:29.580366+00	2026-03-05 02:04:29.580366+00
032eda99-aeb6-44f5-bcf5-6a3163ead7d6	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 03:22:07.67185+00	2026-03-05 03:22:07.67185+00
e5ee9e18-7d14-42da-a64c-0dc228061218	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 03:22:25.948542+00	2026-03-05 03:22:25.948542+00
77788cfa-4b4a-492f-8199-69db8a6e27f7	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 03:22:01.768947+00	2026-03-05 03:22:26.53899+00
da73a18d-b774-4e95-9439-14452454a14b	5176ab32-17b3-4f7d-8432-2d93718a0bbf	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 04:11:55.434522+00	2026-03-05 04:11:55.434522+00
70d4e52e-e032-4f97-9351-b8ad229c2faf	5176ab32-17b3-4f7d-8432-2d93718a0bbf	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 04:11:43.517072+00	2026-03-05 04:11:43.517072+00
6db217e5-0f20-4931-bd2c-3438526a7f0c	5176ab32-17b3-4f7d-8432-2d93718a0bbf	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 04:11:37.748492+00	2026-03-05 04:11:55.818705+00
eda78fcb-2f24-4b38-94e8-10b6767c78fb	aa3a21e3-ae58-40a2-946c-2c5e799d0330	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 05:21:45.666516+00	2026-03-05 05:21:45.666516+00
2092ef40-01b0-413d-ad0a-2e5b7e37a55c	aa3a21e3-ae58-40a2-946c-2c5e799d0330	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 05:22:03.834609+00	2026-03-05 05:22:03.834609+00
c681b4dc-061e-48e6-8044-14e433b3d434	aa3a21e3-ae58-40a2-946c-2c5e799d0330	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 05:21:39.88233+00	2026-03-05 05:22:04.338601+00
56172f66-5199-4127-9c37-1ba912e4b81a	cdc85298-8764-4ff7-8acf-74ace40dd1d8	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 07:31:15.760207+00	2026-03-05 07:31:15.760207+00
dd93acdf-b80c-4be8-b4cf-24b4d0c12042	cdc85298-8764-4ff7-8acf-74ace40dd1d8	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 07:31:39.711428+00	2026-03-05 07:31:39.711428+00
6160450d-c5a4-4dfc-9dd9-4b0e89def46c	cdc85298-8764-4ff7-8acf-74ace40dd1d8	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 07:31:10.091979+00	2026-03-05 07:31:40.240312+00
eb0a92d5-2e83-4e81-a54f-9cfe59dcb661	c50a2a26-686c-434a-86bb-828cb62f0ce0	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 11:41:08.546352+00	2026-03-05 11:41:08.546352+00
e8c1c09a-aec9-411f-b416-89b0451921de	d8290673-93c3-421c-8914-4c2a0f83b12b	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 07:55:58.810119+00	2026-03-05 07:55:58.810119+00
2f0e6e81-12a1-40e9-afd6-ecdcb3f5f917	d8290673-93c3-421c-8914-4c2a0f83b12b	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 07:56:19.98257+00	2026-03-05 07:56:19.98257+00
c803a568-8751-445b-a276-da1dba5fd570	d8290673-93c3-421c-8914-4c2a0f83b12b	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 07:55:52.377821+00	2026-03-05 07:56:20.725856+00
70abe994-def9-479b-8a13-4985ab196979	8701ce73-3f04-42af-8554-c72cb58a838f	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 08:32:53.534338+00	2026-03-05 08:32:53.534338+00
a559266b-7b2e-42c4-8668-a6f1b108e686	c50a2a26-686c-434a-86bb-828cb62f0ce0	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 11:41:22.008575+00	2026-03-05 11:41:22.008575+00
4a92804d-deb4-41b2-9ed1-5ade6c946595	8701ce73-3f04-42af-8554-c72cb58a838f	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 08:33:32.523898+00	2026-03-05 08:33:32.523898+00
f476e310-225e-4860-a4d2-8f109d1cc683	8701ce73-3f04-42af-8554-c72cb58a838f	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 08:32:45.658711+00	2026-03-05 08:33:33.244795+00
15db143a-27ac-48b1-831b-297df09d53e4	c50a2a26-686c-434a-86bb-828cb62f0ce0	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 11:41:02.710917+00	2026-03-05 11:41:22.404345+00
d84c52c0-5b1e-48f6-8fd7-60c82ca4a6cf	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 09:01:29.049482+00	2026-03-05 09:01:29.049482+00
6f7aaf0c-318e-4a9e-bf36-9d0c3a08afa8	3bb235ee-59d6-449b-b5a9-99e70614c7c2	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 15:28:15.1673+00	2026-03-05 15:28:15.1673+00
6561f049-351f-4f32-b7c1-8583d16e167d	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 09:01:53.193159+00	2026-03-05 09:01:53.193159+00
29695f06-74db-40a5-a12c-7fd33f869281	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 09:01:20.72309+00	2026-03-05 09:02:01.088867+00
42a5018d-4f85-41c5-9466-b4dd84397fe7	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 09:40:11.743908+00	2026-03-05 09:40:11.743908+00
085bcc9e-29fb-48b2-b369-40e78683e60c	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 09:40:22.074952+00	2026-03-05 09:40:22.074952+00
7e853104-1a64-43f4-b67e-69baa3b132e3	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 09:40:03.003679+00	2026-03-05 09:40:22.52395+00
c6692d11-79ff-4cfa-9edf-aad58b882bab	3bb235ee-59d6-449b-b5a9-99e70614c7c2	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 15:28:42.089411+00	2026-03-05 15:28:42.089411+00
cc5eeab9-8ac7-4601-999b-8832337b2fdb	3bb235ee-59d6-449b-b5a9-99e70614c7c2	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 15:28:09.078738+00	2026-03-05 15:28:49.620793+00
1f92eb1e-5a40-4ee6-826c-00aa43ee5181	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-05 22:41:47.03137+00	2026-03-05 22:41:47.03137+00
b7d7b7c5-cff8-4472-a2ff-56d40d95ee20	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-05 22:42:05.617934+00	2026-03-05 22:42:05.617934+00
870a91bc-7f2b-4505-a38f-fd5a27aa9dae	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-05 22:41:40.825005+00	2026-03-05 22:42:09.808065+00
65e9b9dd-25ba-4e5b-b3ab-73c793aae24d	74fd4160-d207-47b4-87c2-e418ccf0462e	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-06 05:23:52.193022+00	2026-03-06 05:23:52.193022+00
7e4f91f3-66db-4afb-abd7-2494f1b78029	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-06 03:03:14.231667+00	2026-03-06 03:03:14.231667+00
69151f35-3114-4ea7-9445-e707e8c3548d	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-06 03:03:33.082534+00	2026-03-06 03:03:33.082534+00
499d7de8-57a8-4d71-82a7-29114888b028	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-06 03:03:07.717957+00	2026-03-06 03:03:37.220175+00
f6e285b1-f0da-4a80-ac2f-e1edce0d2c4b	74fd4160-d207-47b4-87c2-e418ccf0462e	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-06 05:24:26.694692+00	2026-03-06 05:24:26.694692+00
a933c8c8-29b8-483f-9f0c-70d9e311edf1	74fd4160-d207-47b4-87c2-e418ccf0462e	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-06 05:23:44.878541+00	2026-03-06 05:24:27.381834+00
3d946791-33d4-4b31-904b-00c7d1cf8f9f	ae6839bd-0c8a-4f8b-8785-c1b37880e158	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-11 00:31:23.075502+00	2026-03-11 00:31:23.075502+00
c639d68c-58f3-4119-a9b8-958c9970939a	ae6839bd-0c8a-4f8b-8785-c1b37880e158	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-11 00:31:34.139913+00	2026-03-11 00:31:34.139913+00
ae9aa93d-a3c1-49bf-b2bb-939622dded53	ae6839bd-0c8a-4f8b-8785-c1b37880e158	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-11 00:31:08.041884+00	2026-03-11 00:31:34.487974+00
f6ae284f-6d48-4c42-9c83-51efe7868b52	d52c170c-8356-4666-b7b7-4d0c772ae583	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-11 03:01:45.016909+00	2026-03-11 03:01:45.016909+00
7bef1830-64f5-4e44-a1ef-59d0ced0c513	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-11 01:27:32.951573+00	2026-03-11 01:27:32.951573+00
09ec70aa-bbf3-4224-bd9a-628bd13c1570	d52c170c-8356-4666-b7b7-4d0c772ae583	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-11 03:01:22.738843+00	2026-03-11 03:01:45.35155+00
71988e31-2c9b-4e0c-aecc-b752cbaeae5c	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-11 01:27:50.642403+00	2026-03-11 01:27:50.642403+00
fadaf9e5-cdd4-448a-8412-20e33d8d1a0e	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-11 01:27:24.276751+00	2026-03-11 01:27:54.022728+00
8689fbe9-ef0c-43bb-ab1a-447e3d660b3f	d52c170c-8356-4666-b7b7-4d0c772ae583	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-11 03:01:31.154678+00	2026-03-11 03:01:31.154678+00
9a850921-518b-4888-849e-1a601aee55a7	491c69a3-3681-4da0-beac-053d9351c06a	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-11 04:53:02.541195+00	2026-03-11 04:53:02.541195+00
71c5a2c9-a338-4bc9-8643-bfc32964a677	d8f6ab86-5b6b-472c-b393-74632a4bc00a	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-11 07:24:45.200141+00	2026-03-11 07:25:04.83309+00
671c8d7c-4a5b-40e9-8dd8-2b8d1b2c8029	491c69a3-3681-4da0-beac-053d9351c06a	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-11 04:53:21.030466+00	2026-03-11 04:53:21.030466+00
036baece-222a-4403-840c-ebfa09da7d5c	491c69a3-3681-4da0-beac-053d9351c06a	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-11 04:52:57.033709+00	2026-03-11 04:53:24.450155+00
2b0cf742-0d2a-443a-b821-55cd53a43825	d8f6ab86-5b6b-472c-b393-74632a4bc00a	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-11 07:24:50.932185+00	2026-03-11 07:24:50.932185+00
da8e81ef-7f5f-4279-a7eb-976ed8a125a9	d8f6ab86-5b6b-472c-b393-74632a4bc00a	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-11 07:25:04.2162+00	2026-03-11 07:25:04.2162+00
23a1d835-10f6-4c37-9e94-80441d7d5d96	f6e8e0bd-41cb-48eb-9587-43e14005f426	Test Forum Post H3	This is a test post via HTTP/3	general	text	0	0	0	f	f	2026-03-11 09:01:14.641312+00	2026-03-11 09:01:14.641312+00
5781cd50-202a-4219-ac12-199696f758b5	f6e8e0bd-41cb-48eb-9587-43e14005f426	Test Image Post	This is a test post with upload_type=image	general	image	0	0	0	f	f	2026-03-11 09:01:25.682523+00	2026-03-11 09:01:25.682523+00
6dc18105-f0a1-4e9d-bb04-7e9a3cf3c774	f6e8e0bd-41cb-48eb-9587-43e14005f426	Test Forum Post	This is a test post via HTTP/2	general	text	1	0	2	f	f	2026-03-11 09:01:09.166907+00	2026-03-11 09:01:26.023294+00
\.


--
-- Data for Name: group_bans; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.group_bans (id, group_id, user_id, banned_by, reason, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.group_members (id, group_id, user_id, role, joined_at, left_at) FROM stdin;
0e60e094-3fbb-479a-8500-2fa8fd898366	5367cc12-2ffd-4ef2-9e60-b6bff8c49d83	3912eb1f-e62d-4f9d-a28c-3f7542e24446	owner	2026-02-27 08:39:12.415013+00	\N
45fd94c8-87b1-44fb-a12a-c7cd44f63cb2	015528ed-cdd1-4da1-87a2-c34b20ec4def	436892ad-1a40-40dd-ad3e-62d59baca3bb	owner	2026-03-03 00:16:04.281667+00	\N
973ac0c6-478b-46cb-b953-7c5c36364a02	ab6c0e09-bf2a-4a83-a405-2da4cac22c87	021b5560-5b8a-4028-94fd-83c8c102c5e2	owner	2026-02-27 09:10:21.534588+00	\N
8e196d73-81ab-48c6-96a7-1f08ebef0714	981fa4cf-9e24-4b93-9cf5-4aae50306bfa	6dc8e69c-83b7-4f09-8681-11b4b736333b	owner	2026-03-06 03:29:01.808014+00	\N
1611c4b2-4870-4239-8841-d0c9a732eaab	0e83cd72-3506-4c1c-a264-969125e80864	6ad98c87-3efa-41af-abeb-963cf0c9c96b	owner	2026-02-27 09:42:38.048376+00	\N
c64a0afd-8191-4bbd-a2b6-99f92e176ae8	4d3839ec-304c-4b99-8810-2917a0cfaac5	ee231bdc-5265-4443-bf4a-a66f74a3e754	owner	2026-03-03 00:55:03.263792+00	\N
665155d0-ce9f-48c8-b5f4-9ec423e7d1ca	d400a859-7a05-4b85-9c61-881ad0611893	3e9b0531-adbb-4989-9906-144bf69095e8	owner	2026-02-27 21:15:36.131443+00	\N
41da9b61-04ab-46b5-9774-b664c2c6a2ab	312e3683-bdbd-4613-a458-410532a3d67b	c6414dc6-8494-4962-a5a8-9032b76a6a36	owner	2026-02-28 02:02:02.6372+00	\N
d554873e-6b3a-4d2c-81d9-88f4ac9a0e5a	5e671077-f580-4397-98ca-130e5e6978fb	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	owner	2026-03-03 01:21:11.354828+00	\N
d96b5778-fe5e-449d-bfd8-812c3caaa821	ccf284fe-d0a4-4a88-bed4-fad63e747bf3	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	owner	2026-02-28 02:38:58.975023+00	\N
a559d0da-6521-446f-b9e0-95d639e2a359	38b829d4-a2a4-4385-99c6-654c9bc83339	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	owner	2026-02-28 06:02:47.492095+00	\N
eee236cd-f8da-4867-b09a-90e0eed3fc5a	6ee16cdf-db70-441e-b2c2-0a6e4b4e3c84	d9640291-3bd0-4af1-ab49-8c2867f1dd74	owner	2026-02-28 06:50:14.062732+00	\N
a0a0cd59-77ec-4233-92e4-e6d3e40e13a8	781c9953-9e6d-46c3-b47e-a3322f17aceb	74fd4160-d207-47b4-87c2-e418ccf0462e	owner	2026-03-06 05:24:20.585754+00	\N
c13074c0-f525-495b-92c5-eae26c6dfac2	72012155-d78f-408f-a923-defe6bb6d45e	445e0fc9-051f-4ab6-a6f6-12b334b24cac	owner	2026-02-28 07:57:46.780263+00	\N
f7beca13-e3a4-4de5-9b8d-de5abe4c3337	71bac6cd-f6fd-4dc1-9df5-0824701c1409	245ed62a-4f36-4819-b992-d06509f66369	owner	2026-03-03 02:09:45.725244+00	\N
0de9ee99-2f7f-4616-bd8d-adc3713b06ce	6ff43850-75ed-4b69-b735-3a1d0fc8f644	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	owner	2026-02-28 08:42:24.673896+00	\N
b5e5e7fb-af4c-4bd2-99d2-73fd8c70590d	06c91da5-f129-4621-9e59-9e66ca9630c5	a91b9539-b268-439e-b171-53a99f420ea7	owner	2026-02-28 09:12:04.015552+00	\N
a188a04f-d558-4bb9-871f-3065bdfedcd9	909f343a-571d-47c7-bd72-306aba3d6729	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	owner	2026-03-03 04:11:07.543558+00	\N
bb50418c-f940-4c19-ac2d-3805817308bf	ecce7311-eb1d-4126-8b99-c3267e10544e	38097e8b-144a-47cf-95fe-002c168192ad	owner	2026-02-28 09:33:45.658705+00	\N
215daa7b-9a2a-4c63-a343-9cfaa2985096	674f0788-079c-4fd4-9415-1e9d1e7073f7	901955ea-f274-4ab7-8f4f-62cd5a143c8e	owner	2026-03-06 05:49:17.461973+00	\N
7436c04b-2df3-4b31-81d5-136f1575a74a	1bbe1def-1495-4988-84be-538530187445	8642494b-070a-4118-9900-9de9ab1c1a15	owner	2026-02-28 10:18:12.894268+00	\N
8fca1eaf-6b2f-4d77-b5ae-a5b41a52a147	929b446a-c148-4a53-98a2-0f47a2a84f4b	0bb95722-b093-40a6-9b25-117da85f3648	owner	2026-02-28 10:58:04.751478+00	\N
1693fa58-1881-4157-a9fe-2870afeb6b17	fe1399b3-2d64-4f2a-aedb-fdeacbe679ba	28043028-1578-4221-b470-b43484c8fc7e	owner	2026-03-03 05:11:25.295641+00	\N
5d4feb93-5624-4bda-9d06-92e9c65438a5	ecb2f3a6-0cb2-4057-9576-9c3143892455	41a4377c-8f35-4d62-b76b-e5d1045c9c91	owner	2026-03-01 02:39:32.022958+00	\N
46b6b2f4-72ce-430a-b75c-9ba485f1d696	f16b12b6-8ee4-4b71-94cd-ca63ccb18c83	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	owner	2026-03-03 05:44:52.175741+00	\N
1936b41d-ef50-49c6-8ee4-4a1f808b6d95	8158c1a1-b46f-4b41-b006-366a49e445fe	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	owner	2026-03-01 03:20:08.50092+00	\N
d1facc1e-5029-4a8e-a488-9d7254b9e1b6	b5b78930-4dba-49a1-b83e-69350334a25a	cc04016a-872b-40c2-b75a-acdb030b759d	owner	2026-03-01 04:02:38.288454+00	\N
11872dd8-3d44-4215-ba2d-aeb9b2d81edf	ce8125ae-64fd-44e0-835a-86962176024b	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	owner	2026-03-01 04:44:52.379102+00	\N
3eaec83a-e230-4d81-82e4-5a6f64d7c8e0	c7d578d5-8dc3-42fd-b2f7-017def71c1bb	1ff91ffb-48bf-4604-913a-9280bd491bee	owner	2026-03-01 05:06:27.99527+00	\N
9da6f1b7-35d2-4944-89df-bf61cbaeb7e5	e5d43880-6c7e-4ae3-a804-23ec56df8b74	56bdeb68-a57e-497e-95a3-c8eb0f596d61	owner	2026-03-03 06:17:57.612695+00	\N
4bc6a934-5dff-4a65-8c44-8fbfddc1c7c4	369582b1-8a6a-4799-adbd-f45d80ed4bdf	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	owner	2026-03-01 05:49:37.873078+00	\N
35c4271a-f42c-449d-bac9-3e65b954befc	e6555055-44ef-4316-9c84-3f66545d6dd8	e08c76f6-b5b7-4dce-b61d-450c96abedd6	owner	2026-03-01 06:27:38.247224+00	\N
85d3797d-75ea-4dfa-bf23-6cba5093a2dc	f1e74255-7618-4655-98fc-99c58949b317	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	owner	2026-03-03 06:49:37.348144+00	\N
e3eee5ec-7436-42f4-9716-d032fde95497	1cf60dc8-70e7-4f6c-8421-733573cb1174	2f2cd581-05ce-4f21-8352-e51f1be40de4	owner	2026-03-01 07:10:56.379367+00	\N
e8603d39-8434-4244-a74d-b9f8849495a2	a98cf18a-67c6-4e4b-97f4-6a032771b4bb	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	owner	2026-03-01 08:22:35.177175+00	\N
73910221-be97-4460-a11e-df7343d36164	4f86d703-358c-4f78-b116-37fbac5ea970	391d8769-702e-4c1a-a44c-29022307c877	owner	2026-03-01 08:52:20.812007+00	\N
c1899209-a86a-4e33-9fbb-b26067351b56	af3a7c70-3587-435d-92da-1df311a5bcda	ca77bbd7-501b-4cea-88d8-3f62f7e46255	owner	2026-03-01 09:25:02.074536+00	\N
9e23e5fb-3a8a-4e0d-8516-9a7599f30132	8f9f832d-b658-412c-95d7-a14b05bfef98	cd859d66-dee0-4cb6-9689-bd47cae0be0f	owner	2026-03-03 16:13:30.393708+00	\N
70f25de4-ac39-424f-9f53-20c3d66d6af6	d8f16c66-e884-4427-be61-f7acba7a8867	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	owner	2026-03-01 09:55:49.035731+00	\N
c175f7c3-c2f1-480c-a010-bc4d98163e97	8b80389c-738c-468c-a3c4-91ea41e740bf	debcc6b7-cd08-43c0-8e62-f8764488d87d	owner	2026-03-03 20:38:55.73571+00	\N
32941142-c3bb-4f1a-8997-d1b0b7534df1	d0ee704b-9836-4d03-8dc2-28c20abdf1a4	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	owner	2026-03-01 20:43:10.38337+00	\N
81634066-babd-4b3c-8429-fc7f7ea7ff20	e3f5f15a-57e2-4ec9-8a0a-fdf8d818be9e	21ff734b-3c75-4574-97c9-c35cc3818bc6	owner	2026-03-01 22:04:03.555881+00	\N
8d1dcfc8-fd41-4e55-8e48-5ddc5c81b7d3	4cc8a573-89e1-4566-b67f-56bd91da189b	329c9336-72d8-4a5c-9246-629fa24930df	owner	2026-03-01 22:45:29.815447+00	\N
372c3444-90ae-44a5-b853-e4abcd365d5a	38d1cf9b-caff-4739-bfe7-a857b8286f1c	b282ed2d-29af-4fad-a357-02ab89c459fd	owner	2026-03-04 09:50:10.809066+00	\N
3d9ccad4-921a-4828-988f-191d1e2fc3b0	400f6300-1488-4db4-9f24-2c3fbe712871	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	owner	2026-03-04 16:20:37.589998+00	\N
56121374-253e-403e-b8a2-717a6f1686ea	1044a749-4a2e-477e-9cca-6d52c47e03ca	92a67500-cdac-43d1-8f4b-f27e7f1891ec	owner	2026-03-02 00:29:32.255902+00	\N
ae50cf39-b7da-43cc-b469-6c318a749be6	19b1ce6e-b5e0-4bd9-b82e-0ca6221d96c8	6246157a-a93d-4ef5-b943-c9a143f03e2d	owner	2026-03-02 01:23:28.317682+00	\N
b0486189-cc60-4a33-92a3-f59628774ebb	0036a11c-3919-400c-9fb0-102cdfbd57bb	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	owner	2026-03-04 16:41:39.255913+00	\N
b9d260f1-39b1-4a88-9f64-536f605bda05	882db819-124e-41c4-ac5c-994984a1f216	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	owner	2026-03-02 01:47:02.852811+00	\N
f0961f7b-5432-4a27-ad5d-157cedce8b95	0aec0723-56d3-4ad9-a73d-ef7abb5fa349	56886316-0d84-4556-ba46-56b476dcfffa	owner	2026-03-02 10:19:07.608947+00	\N
c43dc15d-9428-4d69-bde6-3f1108f306ca	1cdbc1e2-0e3a-41e0-b886-934a1f7953e5	a11c2fb2-b350-416b-9cb4-176c82eaf560	owner	2026-03-04 23:16:23.739583+00	\N
5d7bfaa3-5360-47a2-af10-75660ec46e12	a60dfd20-4713-4491-8ebc-ea928d9c7ec8	2830f9b0-2aec-459c-9893-8a4b993c3262	owner	2026-03-02 10:41:15.992834+00	\N
cdfb835a-4f74-434e-a9a2-953e7664a6e6	531ad1a9-2d42-41bf-b2ba-b64c58c432d8	96785040-a129-40cb-aef4-f9ae99cc8c37	owner	2026-03-04 23:38:32.648974+00	\N
1295aad9-c8da-417d-a4bc-0417598b4e85	099413c9-0bfb-4e71-bf8e-94899d705b85	563da29b-6b23-4753-8dba-01fdbb6f905d	owner	2026-03-02 12:43:41.697498+00	\N
8fa0aa84-158d-4603-a209-7cecc2848795	2e14456c-e3a1-4ec3-8ced-0c803de9763a	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	owner	2026-03-02 13:17:12.087372+00	\N
a9071bb8-fe6f-4c09-af29-1aefc7f19187	c63379b1-5bcd-4e8c-ac4b-6131cfd7097f	0d58e6b5-eb5a-4976-bae0-2f459280932a	owner	2026-03-02 13:37:27.575923+00	\N
5a977505-6f46-4074-b3eb-44a2173dbebd	e6b67cb0-e60c-4f3b-bef7-d61643d44cca	24246ea0-c094-4c8c-b167-a83a72bed89b	owner	2026-03-02 14:21:03.974181+00	\N
7b8518a4-83f3-44ff-9e9a-d96d3dc06a5c	1f5e37d4-2b16-4711-bfb2-3a4cfdbb5705	b7273deb-f387-46c0-a5d4-712a9784544d	owner	2026-03-05 02:04:57.91328+00	\N
9f35030b-3fb2-4e22-9b6d-4510463b5e74	bb8f80ef-2b12-47d9-9524-a4e7f14eb654	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	owner	2026-03-02 14:44:47.012613+00	\N
e632ee47-2018-4b83-9363-2941332ca45f	8136046b-8ff4-4048-a4a2-79dac8afd7c6	ae839a91-35eb-4008-9621-a4244b364932	owner	2026-03-05 02:36:18.499818+00	\N
17c8fc19-3658-4ed3-876d-ce082569cfbb	9a45192e-3e56-4ff3-952f-90e935df8a0c	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	owner	2026-03-02 15:11:05.270189+00	\N
e2b2d357-c8ca-423b-adad-3df90099818c	cfa7ab00-cc9a-46d7-b11d-fdcf89ccf10a	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	owner	2026-03-02 15:49:33.11554+00	\N
7ab2083e-f02c-4714-a0fa-6249e047ca2e	4a7b4e33-d768-4b26-8e46-8fb83edc62c5	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	owner	2026-03-05 03:22:24.064707+00	\N
db9ab9a7-a939-4138-a8cf-8aa8196630b2	492a00cb-eba1-4ac7-980d-1ee6a6eeecc9	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	owner	2026-03-02 20:33:19.620806+00	\N
34385d6c-6941-4e81-a805-d581972e7136	af570e93-ec77-484e-a554-88503cec7824	33492144-594d-4495-907e-3f55e5173377	owner	2026-03-05 03:41:54.91846+00	\N
24f97479-7a75-4751-b240-359fa6622e1a	71f0800f-7007-43fd-875f-8dcb456859f9	37a27965-d80a-4c0d-884b-3d6468ec7399	owner	2026-03-02 20:57:58.806683+00	\N
d6aa7d18-da32-4a7f-9c87-e4f327019537	cd4b59a3-88fb-43cc-b15e-4d6e539d87b8	5176ab32-17b3-4f7d-8432-2d93718a0bbf	owner	2026-03-05 04:11:52.617274+00	\N
56f834ea-dd0a-47cf-a94a-59ce2fc8dba2	4d0157ef-ac9c-48a1-9a7f-03229e942e7e	b7242813-979b-4dcd-a671-41214139a658	owner	2026-03-05 04:51:22.31523+00	\N
85e7f4af-2e33-4bdc-99f2-a90180b2cd95	3bb88ee9-14e6-4937-9fed-2afa19f06694	aa3a21e3-ae58-40a2-946c-2c5e799d0330	owner	2026-03-05 05:21:59.236738+00	\N
4460ce75-814b-4d41-9e7d-35072d8af17f	3d0afe59-a769-41dc-bfe0-25e0fb7af85e	bf15db20-5325-4d1d-891b-faed3c995d13	owner	2026-03-05 05:40:51.220486+00	\N
c58033ab-2c21-4296-95df-5d13bed89d6f	40847639-a797-423f-add5-e491e1dc01ae	cdc85298-8764-4ff7-8acf-74ace40dd1d8	owner	2026-03-05 07:31:34.927914+00	\N
7a81a95e-eace-4754-b1f9-15817b668d0c	32e45b20-bd33-4732-a06d-bbbd557b4786	d8290673-93c3-421c-8914-4c2a0f83b12b	owner	2026-03-05 07:56:18.135924+00	\N
c5144086-c1c2-4173-bde9-c42c8afdff6d	f3fa2742-e263-4483-a044-18ba3374d6cc	8701ce73-3f04-42af-8554-c72cb58a838f	owner	2026-03-05 08:33:26.247899+00	\N
98c0c761-fde4-4d41-96e4-5f33f1d993c5	8f290c65-1c6a-4a2d-95f6-e738e51e57b6	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	owner	2026-03-05 09:01:49.42187+00	\N
a61f384b-f68d-4b74-8538-1d8929c4f5d3	681dd38e-095d-4384-a4c9-991cf0ca0535	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	owner	2026-03-05 09:40:20.80523+00	\N
48c7c1c1-3db3-4ca3-96ad-8101959e1c75	ea6bdc12-56f8-4d9a-97a9-55efaa9d88df	1607a2cd-396c-4191-bec7-85964e49b1b1	owner	2026-03-05 10:00:12.352026+00	\N
7d4ef4e7-bff6-4ed6-a5d6-05b941cdb289	f54dfd97-9e57-4620-8b5b-3b99dacaf5d6	c50a2a26-686c-434a-86bb-828cb62f0ce0	owner	2026-03-05 11:41:20.575048+00	\N
300bb29c-2017-4da6-a566-2f63ee09d8a7	6c80e424-9326-4193-95d1-faecededa3e8	3bb235ee-59d6-449b-b5a9-99e70614c7c2	owner	2026-03-05 15:28:36.27969+00	\N
c5aa3c98-89b0-4481-9f9f-c1ef58344d0b	e73de638-7d38-4153-bb89-5d361d333357	2417489b-b5de-4777-8c7f-3e3337f21e8e	owner	2026-03-05 15:50:08.051014+00	\N
0ba4c800-75f3-4f97-bc28-d6501a21a317	e7d62c41-e474-414d-8ff0-67608454f6ec	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	owner	2026-03-05 22:41:58.626917+00	\N
f42a0bee-2061-44e0-bc90-e6a028c3738b	98d9c074-eef4-4ad4-aa28-c0756fca15a9	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	owner	2026-03-05 23:02:51.667305+00	\N
2e3180ed-e717-4229-a580-6aa0e20a6c22	7864af84-92bb-435f-afa6-8ed96bea71a7	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	owner	2026-03-06 03:03:29.005991+00	\N
1e03ccc3-65e5-490a-bba5-bcb85521cdc1	384d9c18-8de3-43f2-a23c-30e0325cf737	ae6839bd-0c8a-4f8b-8785-c1b37880e158	owner	2026-03-11 00:31:33.346106+00	\N
83a34c23-022c-4413-b7f1-9b8b45f7ecfb	df850a75-77d6-43c1-b7dc-d45c16b910de	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	owner	2026-03-11 00:59:39.203555+00	\N
f6577fce-bf97-4378-b51c-a49d1c9f8f0a	5e0131bb-4bbe-4ab6-baf4-cc18418f947c	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	owner	2026-03-11 01:27:49.849171+00	\N
d058371f-5a72-465a-8ae9-44972741c3a6	b0acf733-7621-414b-b05b-96b7c0abd7e8	4c097f4b-2253-4daf-92c2-425503b4610d	owner	2026-03-11 01:57:41.936693+00	\N
f77dc5c9-ccaf-46ef-93e1-6a4096dc24cf	f5481603-2adc-4930-a9f1-6557bfc34a4a	d52c170c-8356-4666-b7b7-4d0c772ae583	owner	2026-03-11 03:01:44.202393+00	\N
f22c707d-1518-4a58-bcad-a9835daeb9ae	8fdfc9e2-670c-44ec-9b96-191e177da5f6	dce8c08d-efcf-4098-84b1-b149bdd351f1	owner	2026-03-11 03:49:34.279518+00	\N
a50b0b1f-bd5e-4e4f-8e57-079f74552c17	7f454897-65c7-4528-bd15-00c853552122	491c69a3-3681-4da0-beac-053d9351c06a	owner	2026-03-11 04:53:20.046665+00	\N
ac218dd9-1a48-45e0-bfb7-4ea10b599ea4	9021eb7a-26ca-44a7-859b-2cb0c5dc4f3f	7ef33402-3732-4116-abbb-462876f71dc8	owner	2026-03-11 05:18:07.123743+00	\N
df622474-5526-4333-b11a-8adb5761ded3	828f01ee-2d56-411f-8e25-c0a5f70ddd61	d8f6ab86-5b6b-472c-b393-74632a4bc00a	owner	2026-03-11 07:25:01.335008+00	\N
5e7534fc-c708-4c69-9312-b69571bbfe74	64e61df8-6a79-4b46-9e03-97850dd85396	b94dcac3-58ee-4150-9ea2-1b3a0511503f	owner	2026-03-11 07:50:35.895422+00	\N
ca9cf5c0-f1fb-4772-aeb5-4837db97e136	eb14e7a4-5a22-42cb-af0d-999f0648b207	f6e8e0bd-41cb-48eb-9587-43e14005f426	owner	2026-03-11 09:01:21.638361+00	\N
c7940137-552b-4b78-bce7-592ebe527d32	8da01162-cc34-4a33-8c3d-8fff21b8db0d	d75eeb38-c50d-464e-811a-6bd92ba0cc01	owner	2026-03-11 09:28:22.903888+00	\N
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.groups (id, name, description, created_by, created_at, updated_at, archived) FROM stdin;
5367cc12-2ffd-4ef2-9e60-b6bff8c49d83	My Custom Group Name	A test group for HTTP/2/3 testing	3912eb1f-e62d-4f9d-a28c-3f7542e24446	2026-02-27 08:39:12.39475+00	2026-02-27 08:39:12.39475+00	f
ab6c0e09-bf2a-4a83-a405-2da4cac22c87	My Custom Group Name	A test group for HTTP/2/3 testing	021b5560-5b8a-4028-94fd-83c8c102c5e2	2026-02-27 09:10:21.531551+00	2026-02-27 09:10:21.531551+00	f
0e83cd72-3506-4c1c-a264-969125e80864	My Custom Group Name	A test group for HTTP/2/3 testing	6ad98c87-3efa-41af-abeb-963cf0c9c96b	2026-02-27 09:42:38.044378+00	2026-02-27 09:42:38.044378+00	f
d400a859-7a05-4b85-9c61-881ad0611893	My Custom Group Name	A test group for HTTP/2/3 testing	3e9b0531-adbb-4989-9906-144bf69095e8	2026-02-27 21:15:36.129244+00	2026-02-27 21:15:36.129244+00	f
312e3683-bdbd-4613-a458-410532a3d67b	My Custom Group Name	A test group for HTTP/2/3 testing	c6414dc6-8494-4962-a5a8-9032b76a6a36	2026-02-28 02:02:02.635221+00	2026-02-28 02:02:02.635221+00	f
ccf284fe-d0a4-4a88-bed4-fad63e747bf3	My Custom Group Name	A test group for HTTP/2/3 testing	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	2026-02-28 02:38:58.970639+00	2026-02-28 02:38:58.970639+00	f
38b829d4-a2a4-4385-99c6-654c9bc83339	My Custom Group Name	A test group for HTTP/2/3 testing	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	2026-02-28 06:02:47.486199+00	2026-02-28 06:02:47.486199+00	f
6ee16cdf-db70-441e-b2c2-0a6e4b4e3c84	My Custom Group Name	A test group for HTTP/2/3 testing	d9640291-3bd0-4af1-ab49-8c2867f1dd74	2026-02-28 06:50:14.053004+00	2026-02-28 06:50:14.053004+00	f
72012155-d78f-408f-a923-defe6bb6d45e	My Custom Group Name	A test group for HTTP/2/3 testing	445e0fc9-051f-4ab6-a6f6-12b334b24cac	2026-02-28 07:57:46.686465+00	2026-02-28 07:57:46.686465+00	f
6ff43850-75ed-4b69-b735-3a1d0fc8f644	My Custom Group Name	A test group for HTTP/2/3 testing	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	2026-02-28 08:42:24.645027+00	2026-02-28 08:42:24.645027+00	f
06c91da5-f129-4621-9e59-9e66ca9630c5	My Custom Group Name	A test group for HTTP/2/3 testing	a91b9539-b268-439e-b171-53a99f420ea7	2026-02-28 09:12:04.007388+00	2026-02-28 09:12:04.007388+00	f
ecce7311-eb1d-4126-8b99-c3267e10544e	My Custom Group Name	A test group for HTTP/2/3 testing	38097e8b-144a-47cf-95fe-002c168192ad	2026-02-28 09:33:45.651568+00	2026-02-28 09:33:45.651568+00	f
1bbe1def-1495-4988-84be-538530187445	My Custom Group Name	A test group for HTTP/2/3 testing	8642494b-070a-4118-9900-9de9ab1c1a15	2026-02-28 10:18:12.88654+00	2026-02-28 10:18:12.88654+00	f
929b446a-c148-4a53-98a2-0f47a2a84f4b	Social comp group	Created by social comprehensive test	0bb95722-b093-40a6-9b25-117da85f3648	2026-02-28 10:58:04.745625+00	2026-02-28 10:58:04.745625+00	f
ecb2f3a6-0cb2-4057-9576-9c3143892455	My Custom Group Name	A test group for HTTP/2/3 testing	41a4377c-8f35-4d62-b76b-e5d1045c9c91	2026-03-01 02:39:32.014082+00	2026-03-01 02:39:32.014082+00	f
8158c1a1-b46f-4b41-b006-366a49e445fe	My Custom Group Name	A test group for HTTP/2/3 testing	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	2026-03-01 03:20:08.484303+00	2026-03-01 03:20:08.484303+00	f
b5b78930-4dba-49a1-b83e-69350334a25a	My Custom Group Name	A test group for HTTP/2/3 testing	cc04016a-872b-40c2-b75a-acdb030b759d	2026-03-01 04:02:38.211541+00	2026-03-01 04:02:38.211541+00	f
ce8125ae-64fd-44e0-835a-86962176024b	My Custom Group Name	A test group for HTTP/2/3 testing	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	2026-03-01 04:44:52.373228+00	2026-03-01 04:44:52.373228+00	f
c7d578d5-8dc3-42fd-b2f7-017def71c1bb	Social comp group	Created by social comprehensive test	1ff91ffb-48bf-4604-913a-9280bd491bee	2026-03-01 05:06:27.98426+00	2026-03-01 05:06:27.98426+00	f
369582b1-8a6a-4799-adbd-f45d80ed4bdf	My Custom Group Name	A test group for HTTP/2/3 testing	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	2026-03-01 05:49:37.859375+00	2026-03-01 05:49:37.859375+00	f
e6555055-44ef-4316-9c84-3f66545d6dd8	My Custom Group Name	A test group for HTTP/2/3 testing	e08c76f6-b5b7-4dce-b61d-450c96abedd6	2026-03-01 06:27:38.23201+00	2026-03-01 06:27:38.23201+00	f
1cf60dc8-70e7-4f6c-8421-733573cb1174	My Custom Group Name	A test group for HTTP/2/3 testing	2f2cd581-05ce-4f21-8352-e51f1be40de4	2026-03-01 07:10:56.365559+00	2026-03-01 07:10:56.365559+00	f
a98cf18a-67c6-4e4b-97f4-6a032771b4bb	My Custom Group Name	A test group for HTTP/2/3 testing	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	2026-03-01 08:22:35.1134+00	2026-03-01 08:22:35.1134+00	f
4f86d703-358c-4f78-b116-37fbac5ea970	My Custom Group Name	A test group for HTTP/2/3 testing	391d8769-702e-4c1a-a44c-29022307c877	2026-03-01 08:52:20.800135+00	2026-03-01 08:52:20.800135+00	f
af3a7c70-3587-435d-92da-1df311a5bcda	My Custom Group Name	A test group for HTTP/2/3 testing	ca77bbd7-501b-4cea-88d8-3f62f7e46255	2026-03-01 09:25:02.02927+00	2026-03-01 09:25:02.02927+00	f
d8f16c66-e884-4427-be61-f7acba7a8867	Social comp group	Created by social comprehensive test	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	2026-03-01 09:55:49.027473+00	2026-03-01 09:55:49.027473+00	f
d0ee704b-9836-4d03-8dc2-28c20abdf1a4	My Custom Group Name	A test group for HTTP/2/3 testing	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	2026-03-01 20:43:10.369556+00	2026-03-01 20:43:10.369556+00	f
e3f5f15a-57e2-4ec9-8a0a-fdf8d818be9e	My Custom Group Name	A test group for HTTP/2/3 testing	21ff734b-3c75-4574-97c9-c35cc3818bc6	2026-03-01 22:04:03.507423+00	2026-03-01 22:04:03.507423+00	f
4cc8a573-89e1-4566-b67f-56bd91da189b	Social comp group	Created by social comprehensive test	329c9336-72d8-4a5c-9246-629fa24930df	2026-03-01 22:45:29.809125+00	2026-03-01 22:45:29.809125+00	f
1044a749-4a2e-477e-9cca-6d52c47e03ca	My Custom Group Name	A test group for HTTP/2/3 testing	92a67500-cdac-43d1-8f4b-f27e7f1891ec	2026-03-02 00:29:32.235924+00	2026-03-02 00:29:32.235924+00	f
19b1ce6e-b5e0-4bd9-b82e-0ca6221d96c8	My Custom Group Name	A test group for HTTP/2/3 testing	6246157a-a93d-4ef5-b943-c9a143f03e2d	2026-03-02 01:23:28.310822+00	2026-03-02 01:23:28.310822+00	f
882db819-124e-41c4-ac5c-994984a1f216	Social comp group	Created by social comprehensive test	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	2026-03-02 01:47:02.845604+00	2026-03-02 01:47:02.845604+00	f
0aec0723-56d3-4ad9-a73d-ef7abb5fa349	My Custom Group Name	A test group for HTTP/2/3 testing	56886316-0d84-4556-ba46-56b476dcfffa	2026-03-02 10:19:07.602757+00	2026-03-02 10:19:07.602757+00	f
a60dfd20-4713-4491-8ebc-ea928d9c7ec8	Social comp group	Created by social comprehensive test	2830f9b0-2aec-459c-9893-8a4b993c3262	2026-03-02 10:41:15.987167+00	2026-03-02 10:41:15.987167+00	f
099413c9-0bfb-4e71-bf8e-94899d705b85	My Custom Group Name	A test group for HTTP/2/3 testing	563da29b-6b23-4753-8dba-01fdbb6f905d	2026-03-02 12:43:41.687128+00	2026-03-02 12:43:41.687128+00	f
2e14456c-e3a1-4ec3-8ced-0c803de9763a	My Custom Group Name	A test group for HTTP/2/3 testing	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	2026-03-02 13:17:12.080095+00	2026-03-02 13:17:12.080095+00	f
c63379b1-5bcd-4e8c-ac4b-6131cfd7097f	Social comp group	Created by social comprehensive test	0d58e6b5-eb5a-4976-bae0-2f459280932a	2026-03-02 13:37:27.571763+00	2026-03-02 13:37:27.571763+00	f
e6b67cb0-e60c-4f3b-bef7-d61643d44cca	My Custom Group Name	A test group for HTTP/2/3 testing	24246ea0-c094-4c8c-b167-a83a72bed89b	2026-03-02 14:21:03.962396+00	2026-03-02 14:21:03.962396+00	f
bb8f80ef-2b12-47d9-9524-a4e7f14eb654	Social comp group	Created by social comprehensive test	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	2026-03-02 14:44:46.906585+00	2026-03-02 14:44:46.906585+00	f
9a45192e-3e56-4ff3-952f-90e935df8a0c	My Custom Group Name	A test group for HTTP/2/3 testing	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	2026-03-02 15:11:05.256981+00	2026-03-02 15:11:05.256981+00	f
cfa7ab00-cc9a-46d7-b11d-fdcf89ccf10a	Social comp group	Created by social comprehensive test	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	2026-03-02 15:49:33.108868+00	2026-03-02 15:49:33.108868+00	f
492a00cb-eba1-4ac7-980d-1ee6a6eeecc9	My Custom Group Name	A test group for HTTP/2/3 testing	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	2026-03-02 20:33:19.612695+00	2026-03-02 20:33:19.612695+00	f
71f0800f-7007-43fd-875f-8dcb456859f9	Social comp group	Created by social comprehensive test	37a27965-d80a-4c0d-884b-3d6468ec7399	2026-03-02 20:57:58.795825+00	2026-03-02 20:57:58.795825+00	f
015528ed-cdd1-4da1-87a2-c34b20ec4def	My Custom Group Name	A test group for HTTP/2/3 testing	436892ad-1a40-40dd-ad3e-62d59baca3bb	2026-03-03 00:16:04.267081+00	2026-03-03 00:16:04.267081+00	f
4d3839ec-304c-4b99-8810-2917a0cfaac5	My Custom Group Name	A test group for HTTP/2/3 testing	ee231bdc-5265-4443-bf4a-a66f74a3e754	2026-03-03 00:55:03.253804+00	2026-03-03 00:55:03.253804+00	f
5e671077-f580-4397-98ca-130e5e6978fb	Social comp group	Created by social comprehensive test	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	2026-03-03 01:21:11.349273+00	2026-03-03 01:21:11.349273+00	f
71bac6cd-f6fd-4dc1-9df5-0824701c1409	My Custom Group Name	A test group for HTTP/2/3 testing	245ed62a-4f36-4819-b992-d06509f66369	2026-03-03 02:09:45.70458+00	2026-03-03 02:09:45.70458+00	f
909f343a-571d-47c7-bd72-306aba3d6729	Social comp group	Created by social comprehensive test	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	2026-03-03 04:11:07.537735+00	2026-03-03 04:11:07.537735+00	f
fe1399b3-2d64-4f2a-aedb-fdeacbe679ba	My Custom Group Name	A test group for HTTP/2/3 testing	28043028-1578-4221-b470-b43484c8fc7e	2026-03-03 05:11:25.285755+00	2026-03-03 05:11:25.285755+00	f
f16b12b6-8ee4-4b71-94cd-ca63ccb18c83	Social comp group	Created by social comprehensive test	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	2026-03-03 05:44:52.168324+00	2026-03-03 05:44:52.168324+00	f
e5d43880-6c7e-4ae3-a804-23ec56df8b74	My Custom Group Name	A test group for HTTP/2/3 testing	56bdeb68-a57e-497e-95a3-c8eb0f596d61	2026-03-03 06:17:57.602685+00	2026-03-03 06:17:57.602685+00	f
f1e74255-7618-4655-98fc-99c58949b317	Social comp group	Created by social comprehensive test	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	2026-03-03 06:49:37.33943+00	2026-03-03 06:49:37.33943+00	f
8f9f832d-b658-412c-95d7-a14b05bfef98	My Custom Group Name	A test group for HTTP/2/3 testing	cd859d66-dee0-4cb6-9689-bd47cae0be0f	2026-03-03 16:13:30.355696+00	2026-03-03 16:13:30.355696+00	f
8b80389c-738c-468c-a3c4-91ea41e740bf	Social comp group	Created by social comprehensive test	debcc6b7-cd08-43c0-8e62-f8764488d87d	2026-03-03 20:38:55.727151+00	2026-03-03 20:38:55.727151+00	f
38d1cf9b-caff-4739-bfe7-a857b8286f1c	My Custom Group Name	A test group for HTTP/2/3 testing	b282ed2d-29af-4fad-a357-02ab89c459fd	2026-03-04 09:50:10.802769+00	2026-03-04 09:50:10.802769+00	f
400f6300-1488-4db4-9f24-2c3fbe712871	My Custom Group Name	A test group for HTTP/2/3 testing	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	2026-03-04 16:20:37.533079+00	2026-03-04 16:20:37.533079+00	f
0036a11c-3919-400c-9fb0-102cdfbd57bb	Social comp group	Created by social comprehensive test	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	2026-03-04 16:41:39.250501+00	2026-03-04 16:41:39.250501+00	f
1cdbc1e2-0e3a-41e0-b886-934a1f7953e5	My Custom Group Name	A test group for HTTP/2/3 testing	a11c2fb2-b350-416b-9cb4-176c82eaf560	2026-03-04 23:16:23.731846+00	2026-03-04 23:16:23.731846+00	f
531ad1a9-2d42-41bf-b2ba-b64c58c432d8	Social comp group	Created by social comprehensive test	96785040-a129-40cb-aef4-f9ae99cc8c37	2026-03-04 23:38:32.632925+00	2026-03-04 23:38:32.632925+00	f
1f5e37d4-2b16-4711-bfb2-3a4cfdbb5705	My Custom Group Name	A test group for HTTP/2/3 testing	b7273deb-f387-46c0-a5d4-712a9784544d	2026-03-05 02:04:57.891896+00	2026-03-05 02:04:57.891896+00	f
8136046b-8ff4-4048-a4a2-79dac8afd7c6	Social comp group	Created by social comprehensive test	ae839a91-35eb-4008-9621-a4244b364932	2026-03-05 02:36:18.478973+00	2026-03-05 02:36:18.478973+00	f
4a7b4e33-d768-4b26-8e46-8fb83edc62c5	My Custom Group Name	A test group for HTTP/2/3 testing	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	2026-03-05 03:22:24.046728+00	2026-03-05 03:22:24.046728+00	f
af570e93-ec77-484e-a554-88503cec7824	Social comp group	Created by social comprehensive test	33492144-594d-4495-907e-3f55e5173377	2026-03-05 03:41:54.879111+00	2026-03-05 03:41:54.879111+00	f
cd4b59a3-88fb-43cc-b15e-4d6e539d87b8	My Custom Group Name	A test group for HTTP/2/3 testing	5176ab32-17b3-4f7d-8432-2d93718a0bbf	2026-03-05 04:11:52.609148+00	2026-03-05 04:11:52.609148+00	f
4d0157ef-ac9c-48a1-9a7f-03229e942e7e	Social comp group	Created by social comprehensive test	b7242813-979b-4dcd-a671-41214139a658	2026-03-05 04:51:22.31106+00	2026-03-05 04:51:22.31106+00	f
3bb88ee9-14e6-4937-9fed-2afa19f06694	My Custom Group Name	A test group for HTTP/2/3 testing	aa3a21e3-ae58-40a2-946c-2c5e799d0330	2026-03-05 05:21:59.228676+00	2026-03-05 05:21:59.228676+00	f
3d0afe59-a769-41dc-bfe0-25e0fb7af85e	Social comp group	Created by social comprehensive test	bf15db20-5325-4d1d-891b-faed3c995d13	2026-03-05 05:40:51.211724+00	2026-03-05 05:40:51.211724+00	f
40847639-a797-423f-add5-e491e1dc01ae	My Custom Group Name	A test group for HTTP/2/3 testing	cdc85298-8764-4ff7-8acf-74ace40dd1d8	2026-03-05 07:31:34.884714+00	2026-03-05 07:31:34.884714+00	f
32e45b20-bd33-4732-a06d-bbbd557b4786	My Custom Group Name	A test group for HTTP/2/3 testing	d8290673-93c3-421c-8914-4c2a0f83b12b	2026-03-05 07:56:18.126034+00	2026-03-05 07:56:18.126034+00	f
f3fa2742-e263-4483-a044-18ba3374d6cc	My Custom Group Name	A test group for HTTP/2/3 testing	8701ce73-3f04-42af-8554-c72cb58a838f	2026-03-05 08:33:26.220494+00	2026-03-05 08:33:26.220494+00	f
8f290c65-1c6a-4a2d-95f6-e738e51e57b6	My Custom Group Name	A test group for HTTP/2/3 testing	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	2026-03-05 09:01:49.392412+00	2026-03-05 09:01:49.392412+00	f
681dd38e-095d-4384-a4c9-991cf0ca0535	My Custom Group Name	A test group for HTTP/2/3 testing	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	2026-03-05 09:40:20.79688+00	2026-03-05 09:40:20.79688+00	f
ea6bdc12-56f8-4d9a-97a9-55efaa9d88df	Social comp group	Created by social comprehensive test	1607a2cd-396c-4191-bec7-85964e49b1b1	2026-03-05 10:00:12.346046+00	2026-03-05 10:00:12.346046+00	f
f54dfd97-9e57-4620-8b5b-3b99dacaf5d6	My Custom Group Name	A test group for HTTP/2/3 testing	c50a2a26-686c-434a-86bb-828cb62f0ce0	2026-03-05 11:41:20.569144+00	2026-03-05 11:41:20.569144+00	f
6c80e424-9326-4193-95d1-faecededa3e8	My Custom Group Name	A test group for HTTP/2/3 testing	3bb235ee-59d6-449b-b5a9-99e70614c7c2	2026-03-05 15:28:36.268451+00	2026-03-05 15:28:36.268451+00	f
e73de638-7d38-4153-bb89-5d361d333357	Social comp group	Created by social comprehensive test	2417489b-b5de-4777-8c7f-3e3337f21e8e	2026-03-05 15:50:08.043732+00	2026-03-05 15:50:08.043732+00	f
e7d62c41-e474-414d-8ff0-67608454f6ec	My Custom Group Name	A test group for HTTP/2/3 testing	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	2026-03-05 22:41:58.59792+00	2026-03-05 22:41:58.59792+00	f
98d9c074-eef4-4ad4-aa28-c0756fca15a9	Social comp group	Created by social comprehensive test	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	2026-03-05 23:02:51.661823+00	2026-03-05 23:02:51.661823+00	f
7864af84-92bb-435f-afa6-8ed96bea71a7	My Custom Group Name	A test group for HTTP/2/3 testing	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	2026-03-06 03:03:28.938397+00	2026-03-06 03:03:28.938397+00	f
981fa4cf-9e24-4b93-9cf5-4aae50306bfa	Social comp group	Created by social comprehensive test	6dc8e69c-83b7-4f09-8681-11b4b736333b	2026-03-06 03:29:01.743734+00	2026-03-06 03:29:01.743734+00	f
781c9953-9e6d-46c3-b47e-a3322f17aceb	My Custom Group Name	A test group for HTTP/2/3 testing	74fd4160-d207-47b4-87c2-e418ccf0462e	2026-03-06 05:24:20.557981+00	2026-03-06 05:24:20.557981+00	f
674f0788-079c-4fd4-9415-1e9d1e7073f7	Social comp group	Created by social comprehensive test	901955ea-f274-4ab7-8f4f-62cd5a143c8e	2026-03-06 05:49:17.4516+00	2026-03-06 05:49:17.4516+00	f
384d9c18-8de3-43f2-a23c-30e0325cf737	My Custom Group Name	A test group for HTTP/2/3 testing	ae6839bd-0c8a-4f8b-8785-c1b37880e158	2026-03-11 00:31:33.342813+00	2026-03-11 00:31:33.342813+00	f
df850a75-77d6-43c1-b7dc-d45c16b910de	Social comp group	Created by social comprehensive test	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	2026-03-11 00:59:39.199984+00	2026-03-11 00:59:39.199984+00	f
5e0131bb-4bbe-4ab6-baf4-cc18418f947c	My Custom Group Name	A test group for HTTP/2/3 testing	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	2026-03-11 01:27:49.846618+00	2026-03-11 01:27:49.846618+00	f
b0acf733-7621-414b-b05b-96b7c0abd7e8	Social comp group	Created by social comprehensive test	4c097f4b-2253-4daf-92c2-425503b4610d	2026-03-11 01:57:41.933548+00	2026-03-11 01:57:41.933548+00	f
f5481603-2adc-4930-a9f1-6557bfc34a4a	My Custom Group Name	A test group for HTTP/2/3 testing	d52c170c-8356-4666-b7b7-4d0c772ae583	2026-03-11 03:01:44.198785+00	2026-03-11 03:01:44.198785+00	f
8fdfc9e2-670c-44ec-9b96-191e177da5f6	Social comp group	Created by social comprehensive test	dce8c08d-efcf-4098-84b1-b149bdd351f1	2026-03-11 03:49:34.276603+00	2026-03-11 03:49:34.276603+00	f
7f454897-65c7-4528-bd15-00c853552122	My Custom Group Name	A test group for HTTP/2/3 testing	491c69a3-3681-4da0-beac-053d9351c06a	2026-03-11 04:53:20.035746+00	2026-03-11 04:53:20.035746+00	f
9021eb7a-26ca-44a7-859b-2cb0c5dc4f3f	Social comp group	Created by social comprehensive test	7ef33402-3732-4116-abbb-462876f71dc8	2026-03-11 05:18:07.120972+00	2026-03-11 05:18:07.120972+00	f
828f01ee-2d56-411f-8e25-c0a5f70ddd61	My Custom Group Name	A test group for HTTP/2/3 testing	d8f6ab86-5b6b-472c-b393-74632a4bc00a	2026-03-11 07:25:01.33062+00	2026-03-11 07:25:01.33062+00	f
64e61df8-6a79-4b46-9e03-97850dd85396	Social comp group	Created by social comprehensive test	b94dcac3-58ee-4150-9ea2-1b3a0511503f	2026-03-11 07:50:35.890298+00	2026-03-11 07:50:35.890298+00	f
eb14e7a4-5a22-42cb-af0d-999f0648b207	My Custom Group Name	A test group for HTTP/2/3 testing	f6e8e0bd-41cb-48eb-9587-43e14005f426	2026-03-11 09:01:21.625409+00	2026-03-11 09:01:21.625409+00	f
8da01162-cc34-4a33-8c3d-8fff21b8db0d	Social comp group	Created by social comprehensive test	d75eeb38-c50d-464e-811a-6bd92ba0cc01	2026-03-11 09:28:22.896378+00	2026-03-11 09:28:22.896378+00	f
\.


--
-- Data for Name: message_attachments; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.message_attachments (id, message_id, file_url, file_path, thumbnail_url, file_name, file_size, mime_type, file_type, width, height, duration, display_order, created_at) FROM stdin;
6366dd36-c30c-4c93-b9e2-6f50cc1feff9	6c2e8608-23e4-4838-a4a6-f234fbbfc232	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-27 08:39:14.354754+00
933c658e-d58b-44bf-9b1a-0c00db4c2eb6	ecaa74b2-ece6-4b43-953f-9e9c492b20be	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-27 09:10:40.23712+00
2f557b06-20d1-4488-a0e8-3c5c160e32fe	8c2f8da7-ac5f-403d-8ce1-dd7a6eac6293	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-27 09:42:49.718309+00
89519a16-6091-4f21-830b-e46edd605c90	df4d5912-24fc-41ed-8f68-98ee972b1226	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-27 21:15:40.731225+00
f572f972-e29b-44f2-86c9-bae57e63b4dd	cfbe80e7-c91c-42d1-b2f3-a5ee78827be1	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 02:02:10.296521+00
10f22c40-3e83-4584-a46b-b01b60626bb4	7a5fdc75-4d46-4e38-9604-511967db788d	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 02:39:07.614044+00
5b2ec190-8134-4e15-a915-1e480555da9f	43aa32f7-75be-4bce-8908-bc92c9a19296	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 06:02:50.186278+00
2d00d254-4074-48c9-9e33-4dba9eb93ec6	95f97204-a6b7-4dfe-8ec0-f22b500c12af	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 06:50:16.574832+00
01a2d1ca-9bd5-4187-81b1-995d540a1d81	c58eee14-d7e4-4e1d-a9d6-6ee235f27cdd	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 07:57:53.24902+00
ade1496e-5e29-4f28-b77f-9c31365845ce	48c0de1b-e6b4-43da-b2d8-3ae8327e9466	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 08:42:26.936419+00
9eb901d0-7638-4ad9-bbc1-45202d607e41	9126cb16-cb0e-43f3-99bf-ee741fdf6cc4	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 09:12:15.580228+00
a1e8014d-395f-433b-a7b0-9b241a384905	eb9a4b2c-e562-4ca5-9250-e5e554cd58ad	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 09:33:47.778154+00
6c43a4f4-f24c-47c8-b97e-b90950bd3d25	db9ac4d0-0c6e-49fd-a227-4720b58324f8	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-02-28 10:18:14.91126+00
c6a3454d-fabf-455d-a45c-ab0874a8679d	92e3d1ff-ea5a-4ea9-9ea9-7ebee9a219f3	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 02:39:37.199948+00
70ab1317-9fc6-410d-a44f-66155a735036	5020ef5f-4eda-4b0a-bd17-e0bc7f2dcb26	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 03:20:27.043037+00
9cb69f42-caa3-4f5a-87f9-ab472ca22fcc	2edf5701-243c-4796-80ea-a90254f69f56	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 04:02:48.582484+00
7868ded9-cd35-4191-a6a7-3d9cac3e73d1	2ffad075-08fd-4043-a953-96676e01cfab	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 04:45:01.683536+00
b33ce451-611f-42aa-9b2d-b1b0559b52ea	1b284268-72ee-4672-b260-ba18ca5eacee	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 05:49:39.940121+00
c8de64d9-cb1c-47d7-be77-577cc46f9e84	27b36df7-7608-41fa-9e57-72f7ebf782c4	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 06:27:40.48617+00
7c6ed55d-8f30-4f2f-951e-6a8569a9f985	272651ad-988a-4d74-8893-d9af05d1a413	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 07:10:59.127816+00
b1cd250a-cd3c-42f3-a1eb-44eb17645d14	48af671b-fd22-4b25-953a-753bca7f6e6d	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 08:22:45.74807+00
cd237971-4063-4c35-9586-3ddd1cdc1629	f2e96b51-df1b-46d9-99bc-fd0fc788589a	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 08:52:26.724202+00
2a7ce3eb-208f-41d1-a23a-e91ec6eed8b7	3194d452-a16f-40ee-865d-13740b1ba557	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 09:25:09.344691+00
d05fca6a-6e9c-48b9-b7bd-638cf562de4f	78053cc7-db9c-4bce-a352-89b03488bb37	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 20:43:16.658329+00
56e3d4f3-e340-47b8-96a3-c869e461b57f	852f20ca-0711-410f-acfe-1a04727ed873	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-01 22:04:14.662172+00
abd03c41-7b7e-43a3-a1bd-457015c8ffaa	5ea7699b-eaab-4951-a286-6160988e9292	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 00:29:37.515937+00
b1594792-86c7-4f97-9c46-cac7ca3add3c	9173b747-47bd-45e9-ba9e-97151910ce28	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 01:23:33.708534+00
5d343f8a-822b-4408-9dd8-031e3c9a433e	711e752e-92b8-4d83-9c9a-22bb8173ffb9	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 10:19:12.883333+00
066518f5-4689-490a-8b1f-0dae55a4ec9d	5001b232-e0e0-4ad9-8ed0-e8a1866de719	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 12:43:47.274534+00
42138100-3d67-4f24-90f9-1ecc8ab39f39	44e2dd74-ba37-4917-bc8c-e2041ff41da1	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 13:17:14.197355+00
0a5c1f4f-a6ac-47dc-a0fa-51efa271c35e	904dacd3-acc5-4350-b812-f65eab6b48b3	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 14:21:09.205712+00
888b6021-0449-4d9a-b953-7ee8114afbff	6f70bb40-14d3-4117-9502-5c26e54a9b41	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 15:11:07.291536+00
21f9973a-aa70-4658-a3eb-4a2fc2d5e128	835edcd3-137c-4579-8089-37033e0e059f	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-02 20:33:21.557229+00
e4fc704e-170c-4c16-b507-8d59017d15f6	19b87608-1f35-4773-b9cf-6658c287cea8	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-03 00:16:09.990777+00
9841ff61-149c-47d0-b6d5-6a36178ab755	384a404e-0272-421e-a9b4-7e1f877df9fa	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-03 00:55:05.351112+00
bddecfdb-22c7-4eb4-a9b9-8e12e2b0b5e4	d67a7da7-6d8e-4a2a-ba7c-e50a1172e701	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-03 02:09:55.714444+00
04192d27-0fb5-4bd4-9cce-f706602547fe	43a4ba95-310e-4afc-98fd-bd54eab991e3	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-03 05:11:34.823498+00
d7b7cd44-291e-4e99-b053-1d3ea4c5a4f0	dfc6437b-5ded-4775-9b44-d45397f5f889	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-03 06:18:05.625531+00
8b400641-720a-45f0-b46d-f380cb5e64c1	76aba2dc-1de7-404e-9835-cbbfa38a6bb9	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-03 16:13:36.768943+00
630ba64d-62cb-496b-a504-0560a5399975	2bab8cbe-2161-4dc4-a1f9-b145a398e03d	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-04 09:50:13.08138+00
170d25f9-5d7a-42d7-a82b-747f2593cde7	b8ae9212-e80e-4522-b16a-851668a6b567	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-04 16:20:39.820122+00
128dcb08-f2b8-4039-bed7-03ae236a1105	a89bca91-8bd5-4f7d-a8fb-28aff69fb1b7	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-04 23:16:25.859492+00
5422f710-de64-4c6e-804f-e4c9a4563981	ca6ddbb7-0c50-4b7c-ad4f-1e408d9178f7	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 02:05:02.147319+00
d7ed8721-6903-4f31-88ce-14d478570659	0576add4-cb1b-4988-a389-7d7c84dc1241	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 03:22:27.163201+00
b13aa943-71e8-472a-9dac-e85f8cc379aa	d50a216a-2620-49bc-b616-3b69cc3dfec0	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 04:11:56.226026+00
64048a08-28b5-4f8c-a9a6-95e2d544e365	9bc8ffa4-621f-4e0b-8eea-ee9c85676a36	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 05:22:04.85381+00
b07d82f2-9f28-4942-90d3-e151351b5b0f	cb049847-30fc-4434-a193-221bc75ded10	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 07:31:40.891607+00
5d339868-4211-48b4-b85a-243b7e2a35d8	257a858c-63d3-4dad-b9e5-a153f77afa47	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 07:56:21.148038+00
b50b94d6-5ad9-47f5-97fd-9db47f4f7770	82d2301d-b426-4708-8018-e2f838f5d9c3	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 08:33:33.969544+00
48c0338a-e485-4122-879b-38f34580b184	dcf30b9b-35ed-4b4a-a053-a54be4ed94a9	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 09:02:08.857773+00
35a0f394-dda4-4b5b-b05c-7aae1ecb25cc	246080ca-1e10-4518-92a5-ada8b3631e14	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 09:40:23.092832+00
c08de0ea-ffa7-4516-98c7-35a8c3ab47dd	46cf4ed5-151c-401f-9e8a-edbaf2b0dc10	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 11:41:26.18216+00
6941da7e-a344-4576-a87b-8e81819d78ae	56e1b0d5-5b88-42b1-a0d9-e562012b3636	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 15:28:50.34921+00
fbf90e57-e433-4d47-a845-b15e67be5e1d	ba029a7c-520f-474d-9de5-ad93097e510f	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-05 22:42:13.428404+00
7d87678a-3076-44f2-9e39-a7a2b8e48ab6	d1c11b6c-f185-4135-87d6-9ea86ef3b124	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-06 03:03:37.785415+00
de0963ae-983c-4e7c-ab36-a925204b85ea	385cc11c-ba37-4114-831c-fdbd9a0edfa9	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-06 05:24:35.629633+00
d3e0390d-243a-4a3e-b451-15de1c4f74aa	5192497f-fd9f-4b51-a363-4c3ec2b396d2	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-11 00:31:34.851486+00
c385731d-2731-4d47-940e-297a9ef5335a	d32c8a9f-36bb-41f3-8c1e-1cbfad296575	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-11 01:27:57.407087+00
60f5ba9b-f16f-469f-8407-288665372453	f4a1690e-bd17-4293-90d6-a23cd558aa85	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-11 03:01:45.68395+00
6fee6705-99d7-41a6-b7b0-63b4163d31f9	a6f674ce-0b2f-438d-9d9b-d605bd7be8a9	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-11 04:53:24.925069+00
995dfaef-c3ce-400e-9cf8-fcee5833b978	8b15e1b7-343f-4fa9-a103-6a59bcdde208	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-11 07:25:05.985047+00
485fde21-f666-4b17-be0e-08bb34b656b8	3d3a31f6-acec-4320-af2e-43474f7ac2c0	https://example.com/video.mp4	\N	\N	test-video.mp4	9876543	video/mp4	video	1280	720	120	0	2026-03-11 09:01:26.371149+00
\.


--
-- Data for Name: message_reads; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.message_reads (id, message_id, user_id, read_at, read_by_sender) FROM stdin;
a4c9ddaf-6c16-4c5a-aaf6-3d87d8d74999	97bc7b46-65e9-4209-9ae1-5da2e0de3876	0bb95722-b093-40a6-9b25-117da85f3648	2026-02-28 10:58:04.663204+00	f
daedb11c-77e4-46cb-a7ea-76b2528a4676	5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	1ff91ffb-48bf-4604-913a-9280bd491bee	2026-03-01 05:06:27.877077+00	f
7223ff5e-7b79-4990-ba29-80619d9ae97e	cda32066-b0f7-4fbe-8fad-4b9d9817669e	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	2026-03-01 09:55:48.84804+00	f
e874782e-3d81-4425-9865-b8d6fe15e010	ed46adfb-e2ff-4cec-a497-0a01af0f534b	329c9336-72d8-4a5c-9246-629fa24930df	2026-03-01 22:45:29.693669+00	f
d1a1bcdf-a48a-4a75-aeb0-6ca406e1567e	735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	2026-03-02 01:47:02.712071+00	f
bc0465fc-8d59-44c5-b697-a95a6d6e0f1c	95a8ef9a-064a-4b96-b838-32a790bafeba	2830f9b0-2aec-459c-9893-8a4b993c3262	2026-03-02 10:41:15.901798+00	f
c8a0fdbd-89d8-4dce-bc46-20d876a7a8b7	86b50d98-5e38-44e9-9f0f-38fda1dc138b	0d58e6b5-eb5a-4976-bae0-2f459280932a	2026-03-02 13:37:27.481081+00	f
9c26186f-c18f-4df7-ac1e-25ae2b4b042f	46fb8c80-8f96-491d-8564-58902f7e19ee	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	2026-03-02 14:44:46.064732+00	f
9a2b02eb-7193-4e41-87f2-c6f5eea40052	10ea2568-990c-4bed-b775-ffdf5aa40878	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	2026-03-02 15:49:33.019912+00	f
e29095f2-b675-4835-98ae-5b5010cfd3bc	a736e585-0d91-411b-a9df-df8677402b71	37a27965-d80a-4c0d-884b-3d6468ec7399	2026-03-02 20:57:58.686241+00	f
361e3453-9b95-4aa3-9b97-1048f7929b3f	b8f13129-6b86-4f32-8a01-5aaf18f339d7	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	2026-03-03 01:21:11.166645+00	f
4f3047d8-bb25-4a94-9cf6-ea21ae1b631f	9d87aa39-1eb2-44da-a281-35dc0194480a	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	2026-03-03 04:11:07.445079+00	f
9e463142-7d3f-4a45-ba66-2f7b63d72ed6	09b0152d-7c6e-4d71-9473-6327a7db274f	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	2026-03-03 05:44:52.075235+00	f
8b8f1460-6781-4af9-9b60-77e03e954ed0	def8944c-966e-4df0-b0df-fe1988033609	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	2026-03-03 06:49:37.246777+00	f
47701852-7c55-4b6b-92d7-5c7cac5044ac	f6d5aeb0-08cb-4300-8d0b-8603249dac39	debcc6b7-cd08-43c0-8e62-f8764488d87d	2026-03-03 20:38:55.611771+00	f
69e8ac9a-9d97-47bd-8ecb-3327ca5af4fa	58ffa13f-91b1-4116-9e6f-10b2d868ab9e	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	2026-03-04 16:41:39.156716+00	f
8545784c-53d1-42c2-bda3-6e085aa0ba61	28bf71e9-d9fe-4e89-93a3-36a442c90ebf	96785040-a129-40cb-aef4-f9ae99cc8c37	2026-03-04 23:38:32.537491+00	f
58ea650c-99d4-4f7e-8e18-277e5a8748a4	750b2d88-6a64-42d1-9286-58b50e91f457	ae839a91-35eb-4008-9621-a4244b364932	2026-03-05 02:36:18.082429+00	f
87702af6-3510-4520-a90e-b26f7ded6979	a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	33492144-594d-4495-907e-3f55e5173377	2026-03-05 03:41:54.698856+00	f
9c25834a-56aa-4c0c-b981-3268312065b0	dd780ac0-7d23-471b-a642-0463e0852a9d	b7242813-979b-4dcd-a671-41214139a658	2026-03-05 04:51:22.174973+00	f
aaf0c4f0-d599-441d-b966-3c830c7377c4	71302627-7f3c-4f5e-b766-6deaa6f0e2e3	bf15db20-5325-4d1d-891b-faed3c995d13	2026-03-05 05:40:51.108622+00	f
fd89e57c-932d-46cb-978c-5552fb7952b7	ea82dfb7-7b7a-4977-8815-51db8687a331	1607a2cd-396c-4191-bec7-85964e49b1b1	2026-03-05 10:00:12.253853+00	f
97ba046c-be38-4e3f-8bc0-040eb4d0a8c4	a3e3078c-7062-4283-950a-761e1c30c780	2417489b-b5de-4777-8c7f-3e3337f21e8e	2026-03-05 15:50:07.933241+00	f
e08f1319-1e28-44aa-b8f9-82a094adca7b	bed250c3-2a45-4ce6-8bc4-0d8202bdb931	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	2026-03-05 23:02:51.557962+00	f
601d70f5-1482-4c53-adfa-ddf6f33c4590	361f0940-815b-4cd7-a3a9-64c49681c8fb	6dc8e69c-83b7-4f09-8681-11b4b736333b	2026-03-06 03:29:01.562982+00	f
aa2ad80a-cf1e-447a-9972-efd073ea5b5d	5f32b585-6931-477d-8052-8075bfddc587	901955ea-f274-4ab7-8f4f-62cd5a143c8e	2026-03-06 05:49:17.262815+00	f
22715d7a-fe54-4bc5-b6ab-d4fa96623726	c7dda769-dc77-438e-b78d-fb05d1ce60da	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	2026-03-11 00:59:39.145847+00	f
102467cf-2594-46a7-a0fe-fb253987453d	e497ffe0-6f96-4713-a48a-9cea9b56eafe	4c097f4b-2253-4daf-92c2-425503b4610d	2026-03-11 01:57:41.894599+00	f
0d3f0431-401f-4141-8210-bd19b0ed0be0	d280251e-ab1a-42c0-b029-5d7d471e3958	dce8c08d-efcf-4098-84b1-b149bdd351f1	2026-03-11 03:49:34.229274+00	f
b719f987-b74f-4a03-99f6-d1aa386da4e0	68a9b480-f613-468f-b27a-4a0479698964	7ef33402-3732-4116-abbb-462876f71dc8	2026-03-11 05:18:07.081062+00	f
8dd5ff87-f4d7-462d-ac46-9410ce26400d	f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	b94dcac3-58ee-4150-9ea2-1b3a0511503f	2026-03-11 07:50:35.849554+00	f
6fc6dddd-0c5e-4087-bc82-69ea43628769	2b7b9354-13f3-447a-91ff-07c3e79fce1b	d75eeb38-c50d-464e-811a-6bd92ba0cc01	2026-03-11 09:28:22.823451+00	f
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.messages (id, sender_id, recipient_id, group_id, parent_message_id, thread_id, message_type, subject, content, is_read, sender_display_name, created_at, updated_at, recalled_at, archived) FROM stdin;
ddc34c0b-6f28-4edf-b5ac-7c81ded32793	210ea469-1f0b-4e7a-9064-10bc09022f6b	75d7c735-56b5-4885-8ed0-3739224c38e9	\N	\N	ddc34c0b-6f28-4edf-b5ac-7c81ded32793	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-27 07:58:33.491873+00	2026-02-27 07:58:33.491873+00	\N	f
664d5195-8590-4635-b2a3-db9a0c270032	75d7c735-56b5-4885-8ed0-3739224c38e9	210ea469-1f0b-4e7a-9064-10bc09022f6b	\N	\N	664d5195-8590-4635-b2a3-db9a0c270032	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-27 07:58:38.936075+00	2026-02-27 07:58:38.936075+00	\N	f
6c2e8608-23e4-4838-a4a6-f234fbbfc232	3912eb1f-e62d-4f9d-a28c-3f7542e24446	f898d5aa-370c-42f8-b8d9-2073c009843e	\N	\N	6c2e8608-23e4-4838-a4a6-f234fbbfc232	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-27 08:39:06.845442+00	2026-02-27 08:39:06.845442+00	\N	f
92750a46-b692-4241-bede-74c1ff24b8f0	f898d5aa-370c-42f8-b8d9-2073c009843e	3912eb1f-e62d-4f9d-a28c-3f7542e24446	\N	\N	92750a46-b692-4241-bede-74c1ff24b8f0	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-27 08:39:12.235173+00	2026-02-27 08:39:12.235173+00	\N	f
8c4ce0b9-86ec-4dd8-9c10-c7ab063f2dd4	3912eb1f-e62d-4f9d-a28c-3f7542e24446	\N	5367cc12-2ffd-4ef2-9e60-b6bff8c49d83	\N	8c4ce0b9-86ec-4dd8-9c10-c7ab063f2dd4	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-27 08:39:13.316985+00	2026-02-27 08:39:13.316985+00	\N	f
2582d9eb-bb95-40bb-9029-96943f4a4df1	f898d5aa-370c-42f8-b8d9-2073c009843e	\N	5367cc12-2ffd-4ef2-9e60-b6bff8c49d83	8c4ce0b9-86ec-4dd8-9c10-c7ab063f2dd4	8c4ce0b9-86ec-4dd8-9c10-c7ab063f2dd4	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-27 08:39:13.622426+00	2026-02-27 08:39:13.622426+00	\N	f
ecaa74b2-ece6-4b43-953f-9e9c492b20be	021b5560-5b8a-4028-94fd-83c8c102c5e2	dfcca53c-b7c6-4c7e-b1f8-5eab18a31803	\N	\N	ecaa74b2-ece6-4b43-953f-9e9c492b20be	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-27 09:10:16.126241+00	2026-02-27 09:10:16.126241+00	\N	f
8df8d8d0-16e9-4804-bc2b-a1d881edb9eb	dfcca53c-b7c6-4c7e-b1f8-5eab18a31803	021b5560-5b8a-4028-94fd-83c8c102c5e2	\N	\N	8df8d8d0-16e9-4804-bc2b-a1d881edb9eb	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-27 09:10:21.432754+00	2026-02-27 09:10:21.432754+00	\N	f
9fc31695-17e5-41da-99a6-520c540e1896	021b5560-5b8a-4028-94fd-83c8c102c5e2	\N	ab6c0e09-bf2a-4a83-a405-2da4cac22c87	\N	9fc31695-17e5-41da-99a6-520c540e1896	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-27 09:10:25.123179+00	2026-02-27 09:10:25.123179+00	\N	f
b56e69f3-2e42-413b-aa23-0d7d9494912f	dfcca53c-b7c6-4c7e-b1f8-5eab18a31803	\N	ab6c0e09-bf2a-4a83-a405-2da4cac22c87	9fc31695-17e5-41da-99a6-520c540e1896	9fc31695-17e5-41da-99a6-520c540e1896	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-27 09:10:25.374165+00	2026-02-27 09:10:25.374165+00	\N	f
8c2f8da7-ac5f-403d-8ce1-dd7a6eac6293	6ad98c87-3efa-41af-abeb-963cf0c9c96b	f2462b92-84ec-468a-a7c0-f3137fe27079	\N	\N	8c2f8da7-ac5f-403d-8ce1-dd7a6eac6293	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-27 09:42:32.521045+00	2026-02-27 09:42:32.521045+00	\N	f
c1bb3907-d309-4ae5-b452-68d08aac2a09	f2462b92-84ec-468a-a7c0-f3137fe27079	6ad98c87-3efa-41af-abeb-963cf0c9c96b	\N	\N	c1bb3907-d309-4ae5-b452-68d08aac2a09	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-27 09:42:37.891176+00	2026-02-27 09:42:37.891176+00	\N	f
96999f9c-1209-4be1-b670-0c8c96f246a8	6ad98c87-3efa-41af-abeb-963cf0c9c96b	\N	0e83cd72-3506-4c1c-a264-969125e80864	\N	96999f9c-1209-4be1-b670-0c8c96f246a8	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-27 09:42:45.648191+00	2026-02-27 09:42:45.648191+00	\N	f
72cc78da-0a07-4e81-92d2-ac6d008a503a	f2462b92-84ec-468a-a7c0-f3137fe27079	\N	0e83cd72-3506-4c1c-a264-969125e80864	96999f9c-1209-4be1-b670-0c8c96f246a8	96999f9c-1209-4be1-b670-0c8c96f246a8	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-27 09:42:45.921799+00	2026-02-27 09:42:45.921799+00	\N	f
df4d5912-24fc-41ed-8f68-98ee972b1226	3e9b0531-adbb-4989-9906-144bf69095e8	8eb88955-4a5a-441e-980d-62032c083d4d	\N	\N	df4d5912-24fc-41ed-8f68-98ee972b1226	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-27 21:15:30.666304+00	2026-02-27 21:15:30.666304+00	\N	f
dbd25dba-3a13-423b-88ed-a38ae1c8ead8	8eb88955-4a5a-441e-980d-62032c083d4d	3e9b0531-adbb-4989-9906-144bf69095e8	\N	\N	dbd25dba-3a13-423b-88ed-a38ae1c8ead8	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-27 21:15:36.019147+00	2026-02-27 21:15:36.019147+00	\N	f
91f2eec3-1725-49ca-bb54-6dbd9c269efb	3e9b0531-adbb-4989-9906-144bf69095e8	\N	d400a859-7a05-4b85-9c61-881ad0611893	\N	91f2eec3-1725-49ca-bb54-6dbd9c269efb	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-27 21:15:36.647824+00	2026-02-27 21:15:36.647824+00	\N	f
a19da2a8-c6ad-448b-88c4-e1b23a3dc773	8eb88955-4a5a-441e-980d-62032c083d4d	\N	d400a859-7a05-4b85-9c61-881ad0611893	91f2eec3-1725-49ca-bb54-6dbd9c269efb	91f2eec3-1725-49ca-bb54-6dbd9c269efb	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-27 21:15:36.886933+00	2026-02-27 21:15:36.886933+00	\N	f
cfbe80e7-c91c-42d1-b2f3-a5ee78827be1	c6414dc6-8494-4962-a5a8-9032b76a6a36	90e9bcf9-d5cc-491d-8f61-7547398220f6	\N	\N	cfbe80e7-c91c-42d1-b2f3-a5ee78827be1	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 02:01:57.142497+00	2026-02-28 02:01:57.142497+00	\N	f
996c2b94-b651-41c4-9df0-b434994a4187	90e9bcf9-d5cc-491d-8f61-7547398220f6	c6414dc6-8494-4962-a5a8-9032b76a6a36	\N	\N	996c2b94-b651-41c4-9df0-b434994a4187	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 02:02:02.532885+00	2026-02-28 02:02:02.532885+00	\N	f
06b326ee-e38e-455e-b858-e48148972a6b	c6414dc6-8494-4962-a5a8-9032b76a6a36	\N	312e3683-bdbd-4613-a458-410532a3d67b	\N	06b326ee-e38e-455e-b858-e48148972a6b	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 02:02:06.190518+00	2026-02-28 02:02:06.190518+00	\N	f
db30c447-4fac-4d4a-89e3-94adceeca333	90e9bcf9-d5cc-491d-8f61-7547398220f6	\N	312e3683-bdbd-4613-a458-410532a3d67b	06b326ee-e38e-455e-b858-e48148972a6b	06b326ee-e38e-455e-b858-e48148972a6b	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 02:02:06.540275+00	2026-02-28 02:02:06.540275+00	\N	f
7a5fdc75-4d46-4e38-9604-511967db788d	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	7cf6ed2f-4d23-430a-bc85-37e738821801	\N	\N	7a5fdc75-4d46-4e38-9604-511967db788d	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 02:38:53.449631+00	2026-02-28 02:38:53.449631+00	\N	f
51192c4a-01a8-4459-a866-152f0d3f8405	7cf6ed2f-4d23-430a-bc85-37e738821801	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	\N	\N	51192c4a-01a8-4459-a866-152f0d3f8405	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 02:38:58.848022+00	2026-02-28 02:38:58.848022+00	\N	f
bc3f4316-d077-495c-8d33-42256580b540	e10a9f0f-6bf0-46fe-a5e1-da762b7daec1	\N	ccf284fe-d0a4-4a88-bed4-fad63e747bf3	\N	bc3f4316-d077-495c-8d33-42256580b540	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 02:39:06.58688+00	2026-02-28 02:39:06.58688+00	\N	f
e2b2fced-b41a-4ce0-b5ef-f85db9b37a9b	7cf6ed2f-4d23-430a-bc85-37e738821801	\N	ccf284fe-d0a4-4a88-bed4-fad63e747bf3	bc3f4316-d077-495c-8d33-42256580b540	bc3f4316-d077-495c-8d33-42256580b540	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 02:39:06.88022+00	2026-02-28 02:39:06.88022+00	\N	f
43aa32f7-75be-4bce-8908-bc92c9a19296	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	2d2cb136-6784-4266-a122-d1fb57c0ccf0	\N	\N	43aa32f7-75be-4bce-8908-bc92c9a19296	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 06:02:38.350429+00	2026-02-28 06:02:38.350429+00	\N	f
d311fbec-0d82-4658-8e22-a47faa997fa0	2d2cb136-6784-4266-a122-d1fb57c0ccf0	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	\N	\N	d311fbec-0d82-4658-8e22-a47faa997fa0	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 06:02:47.140394+00	2026-02-28 06:02:47.140394+00	\N	f
27dc4c9a-d8c2-45fe-9db9-647773db2d36	bfa62bb2-9fcb-4f6c-977f-0d7bfaf41cd6	\N	38b829d4-a2a4-4385-99c6-654c9bc83339	\N	27dc4c9a-d8c2-45fe-9db9-647773db2d36	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 06:02:48.61048+00	2026-02-28 06:02:48.61048+00	\N	f
92c08bd2-75e6-4a30-bac7-5cf1cb60d86e	2d2cb136-6784-4266-a122-d1fb57c0ccf0	\N	38b829d4-a2a4-4385-99c6-654c9bc83339	27dc4c9a-d8c2-45fe-9db9-647773db2d36	27dc4c9a-d8c2-45fe-9db9-647773db2d36	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 06:02:49.18785+00	2026-02-28 06:02:49.18785+00	\N	f
95f97204-a6b7-4dfe-8ec0-f22b500c12af	d9640291-3bd0-4af1-ab49-8c2867f1dd74	f0382884-80a6-47dd-9957-27e5a7d77aef	\N	\N	95f97204-a6b7-4dfe-8ec0-f22b500c12af	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 06:50:08.00319+00	2026-02-28 06:50:08.00319+00	\N	f
236a1cc1-b6e5-4a19-b655-cfa6f6055ee5	f0382884-80a6-47dd-9957-27e5a7d77aef	d9640291-3bd0-4af1-ab49-8c2867f1dd74	\N	\N	236a1cc1-b6e5-4a19-b655-cfa6f6055ee5	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 06:50:13.741298+00	2026-02-28 06:50:13.741298+00	\N	f
02722696-3e26-4036-bfe8-4422cf27bb89	d9640291-3bd0-4af1-ab49-8c2867f1dd74	\N	6ee16cdf-db70-441e-b2c2-0a6e4b4e3c84	\N	02722696-3e26-4036-bfe8-4422cf27bb89	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 06:50:14.933981+00	2026-02-28 06:50:14.933981+00	\N	f
2ffd22ce-2dd7-451f-9b6b-71523c78a396	f0382884-80a6-47dd-9957-27e5a7d77aef	\N	6ee16cdf-db70-441e-b2c2-0a6e4b4e3c84	02722696-3e26-4036-bfe8-4422cf27bb89	02722696-3e26-4036-bfe8-4422cf27bb89	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 06:50:15.527474+00	2026-02-28 06:50:15.527474+00	\N	f
c58eee14-d7e4-4e1d-a9d6-6ee235f27cdd	445e0fc9-051f-4ab6-a6f6-12b334b24cac	8f9cd0e7-20ea-4c88-849a-b68cee224dd5	\N	\N	c58eee14-d7e4-4e1d-a9d6-6ee235f27cdd	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 07:57:40.806562+00	2026-02-28 07:57:40.806562+00	\N	f
92117873-7e15-4a7d-81a2-5dc4274500fe	8f9cd0e7-20ea-4c88-849a-b68cee224dd5	445e0fc9-051f-4ab6-a6f6-12b334b24cac	\N	\N	92117873-7e15-4a7d-81a2-5dc4274500fe	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 07:57:46.321756+00	2026-02-28 07:57:46.321756+00	\N	f
4c96c249-af34-4649-bb74-4f673338e6f7	445e0fc9-051f-4ab6-a6f6-12b334b24cac	\N	72012155-d78f-408f-a923-defe6bb6d45e	\N	4c96c249-af34-4649-bb74-4f673338e6f7	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 07:57:50.629013+00	2026-02-28 07:57:50.629013+00	\N	f
a2d26567-2000-4c9b-91ed-f0c33a4b0493	8f9cd0e7-20ea-4c88-849a-b68cee224dd5	\N	72012155-d78f-408f-a923-defe6bb6d45e	4c96c249-af34-4649-bb74-4f673338e6f7	4c96c249-af34-4649-bb74-4f673338e6f7	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 07:57:52.055228+00	2026-02-28 07:57:52.055228+00	\N	f
48c0de1b-e6b4-43da-b2d8-3ae8327e9466	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	f3098473-3e59-4ce5-8a2a-b81c816bd940	\N	\N	48c0de1b-e6b4-43da-b2d8-3ae8327e9466	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 08:42:15.764261+00	2026-02-28 08:42:15.764261+00	\N	f
23e6513f-9e43-4ea9-802a-b58e42fd9147	f3098473-3e59-4ce5-8a2a-b81c816bd940	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	\N	\N	23e6513f-9e43-4ea9-802a-b58e42fd9147	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 08:42:24.354252+00	2026-02-28 08:42:24.354252+00	\N	f
d68acf0a-921c-4e85-b0ca-ad38a86705c2	cad8b18a-9c3b-45f7-83f4-78ded57bc52f	\N	6ff43850-75ed-4b69-b735-3a1d0fc8f644	\N	d68acf0a-921c-4e85-b0ca-ad38a86705c2	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 08:42:25.468386+00	2026-02-28 08:42:25.468386+00	\N	f
6b09d2b3-8688-411f-a8fb-09742466b287	f3098473-3e59-4ce5-8a2a-b81c816bd940	\N	6ff43850-75ed-4b69-b735-3a1d0fc8f644	d68acf0a-921c-4e85-b0ca-ad38a86705c2	d68acf0a-921c-4e85-b0ca-ad38a86705c2	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 08:42:25.923781+00	2026-02-28 08:42:25.923781+00	\N	f
9126cb16-cb0e-43f3-99bf-ee741fdf6cc4	a91b9539-b268-439e-b171-53a99f420ea7	5829e9e4-67f7-4102-8612-42299d0313e1	\N	\N	9126cb16-cb0e-43f3-99bf-ee741fdf6cc4	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 09:11:57.863808+00	2026-02-28 09:11:57.863808+00	\N	f
45e370d8-72e6-4bed-b9b7-b24db284a6f2	5829e9e4-67f7-4102-8612-42299d0313e1	a91b9539-b268-439e-b171-53a99f420ea7	\N	\N	45e370d8-72e6-4bed-b9b7-b24db284a6f2	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 09:12:03.800435+00	2026-02-28 09:12:03.800435+00	\N	f
e08e760f-746c-4bab-8d0c-dd25d3397bd3	a91b9539-b268-439e-b171-53a99f420ea7	\N	06c91da5-f129-4621-9e59-9e66ca9630c5	\N	e08e760f-746c-4bab-8d0c-dd25d3397bd3	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 09:12:07.853388+00	2026-02-28 09:12:07.853388+00	\N	f
8a381caf-d538-42fc-8720-27fec05404d3	5829e9e4-67f7-4102-8612-42299d0313e1	\N	06c91da5-f129-4621-9e59-9e66ca9630c5	e08e760f-746c-4bab-8d0c-dd25d3397bd3	e08e760f-746c-4bab-8d0c-dd25d3397bd3	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 09:12:08.387322+00	2026-02-28 09:12:08.387322+00	\N	f
eb9a4b2c-e562-4ca5-9250-e5e554cd58ad	38097e8b-144a-47cf-95fe-002c168192ad	c2406d5f-4d30-4032-94e8-25f4cea037a5	\N	\N	eb9a4b2c-e562-4ca5-9250-e5e554cd58ad	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 09:33:39.978693+00	2026-02-28 09:33:39.978693+00	\N	f
cdeb3828-dcae-43ce-9908-7a21608f82d5	c2406d5f-4d30-4032-94e8-25f4cea037a5	38097e8b-144a-47cf-95fe-002c168192ad	\N	\N	cdeb3828-dcae-43ce-9908-7a21608f82d5	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 09:33:45.425875+00	2026-02-28 09:33:45.425875+00	\N	f
dbbfec84-f20b-4f4f-9770-60eece99c463	38097e8b-144a-47cf-95fe-002c168192ad	\N	ecce7311-eb1d-4126-8b99-c3267e10544e	\N	dbbfec84-f20b-4f4f-9770-60eece99c463	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 09:33:46.268906+00	2026-02-28 09:33:46.268906+00	\N	f
967f0816-c31a-4cb4-b7a1-92a95e1325ce	c2406d5f-4d30-4032-94e8-25f4cea037a5	\N	ecce7311-eb1d-4126-8b99-c3267e10544e	dbbfec84-f20b-4f4f-9770-60eece99c463	dbbfec84-f20b-4f4f-9770-60eece99c463	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 09:33:46.689906+00	2026-02-28 09:33:46.689906+00	\N	f
db9ac4d0-0c6e-49fd-a227-4720b58324f8	8642494b-070a-4118-9900-9de9ab1c1a15	433f76c4-c2f8-4ad7-9a98-c4ddebac9dce	\N	\N	db9ac4d0-0c6e-49fd-a227-4720b58324f8	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-02-28 10:18:06.874454+00	2026-02-28 10:18:06.874454+00	\N	f
4aa97bb9-2d55-4992-a100-e4d63b1dc6a1	433f76c4-c2f8-4ad7-9a98-c4ddebac9dce	8642494b-070a-4118-9900-9de9ab1c1a15	\N	\N	4aa97bb9-2d55-4992-a100-e4d63b1dc6a1	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-02-28 10:18:12.549154+00	2026-02-28 10:18:12.549154+00	\N	f
a5c79e4a-b73f-4499-b744-52620ec06a27	8642494b-070a-4118-9900-9de9ab1c1a15	\N	1bbe1def-1495-4988-84be-538530187445	\N	a5c79e4a-b73f-4499-b744-52620ec06a27	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-02-28 10:18:13.550803+00	2026-02-28 10:18:13.550803+00	\N	f
7649565f-a37d-4bd6-b0a9-f927bcd78f76	433f76c4-c2f8-4ad7-9a98-c4ddebac9dce	\N	1bbe1def-1495-4988-84be-538530187445	a5c79e4a-b73f-4499-b744-52620ec06a27	a5c79e4a-b73f-4499-b744-52620ec06a27	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-02-28 10:18:13.963367+00	2026-02-28 10:18:13.963367+00	\N	f
28aaa8dc-ee71-437d-bd80-a53e1b792e16	d81fb6a4-afd5-430b-a7b3-5eab03c276e9	d81fb6a4-afd5-430b-a7b3-5eab03c276e9	\N	97bc7b46-65e9-4209-9ae1-5da2e0de3876	97bc7b46-65e9-4209-9ae1-5da2e0de3876	direct	Re: Social comp test	Reply from user2	f	\N	2026-02-28 10:58:03.95042+00	2026-02-28 10:58:03.95042+00	\N	f
97bc7b46-65e9-4209-9ae1-5da2e0de3876	0bb95722-b093-40a6-9b25-117da85f3648	d81fb6a4-afd5-430b-a7b3-5eab03c276e9	\N	\N	97bc7b46-65e9-4209-9ae1-5da2e0de3876	direct	Social comp test	[Message recalled]	f	\N	2026-02-28 10:58:03.203624+00	2026-02-28 10:58:05.693114+00	2026-02-28 10:58:05.693114+00	f
91ca8360-7746-4fb9-9e94-132ea6c80715	0bb95722-b093-40a6-9b25-117da85f3648	\N	929b446a-c148-4a53-98a2-0f47a2a84f4b	\N	91ca8360-7746-4fb9-9e94-132ea6c80715	group	Group test	Hello group	f	\N	2026-02-28 10:58:05.773675+00	2026-02-28 10:58:05.773675+00	\N	f
92e3d1ff-ea5a-4ea9-9ea9-7ebee9a219f3	41a4377c-8f35-4d62-b76b-e5d1045c9c91	341136ec-c2b1-451e-ac28-b38865090b15	\N	\N	92e3d1ff-ea5a-4ea9-9ea9-7ebee9a219f3	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 02:39:23.280832+00	2026-03-01 02:39:23.280832+00	\N	f
2223ddc9-9902-47b1-b4f4-61f7b3679c9b	341136ec-c2b1-451e-ac28-b38865090b15	41a4377c-8f35-4d62-b76b-e5d1045c9c91	\N	\N	2223ddc9-9902-47b1-b4f4-61f7b3679c9b	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 02:39:31.779118+00	2026-03-01 02:39:31.779118+00	\N	f
19f47f3f-b5ff-4f5f-94fc-999f4011a84f	41a4377c-8f35-4d62-b76b-e5d1045c9c91	\N	ecb2f3a6-0cb2-4057-9576-9c3143892455	\N	19f47f3f-b5ff-4f5f-94fc-999f4011a84f	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 02:39:32.720067+00	2026-03-01 02:39:32.720067+00	\N	f
0cb9ce10-70c7-4685-a8fc-93c5bcc5ca54	341136ec-c2b1-451e-ac28-b38865090b15	\N	ecb2f3a6-0cb2-4057-9576-9c3143892455	19f47f3f-b5ff-4f5f-94fc-999f4011a84f	19f47f3f-b5ff-4f5f-94fc-999f4011a84f	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 02:39:33.149655+00	2026-03-01 02:39:33.149655+00	\N	f
5020ef5f-4eda-4b0a-bd17-e0bc7f2dcb26	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	bc338835-6459-402b-9a49-85712076f449	\N	\N	5020ef5f-4eda-4b0a-bd17-e0bc7f2dcb26	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 03:20:02.368809+00	2026-03-01 03:20:02.368809+00	\N	f
cb7a5b00-5423-4437-bbad-c2d7bca4d0b0	bc338835-6459-402b-9a49-85712076f449	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	\N	\N	cb7a5b00-5423-4437-bbad-c2d7bca4d0b0	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 03:20:08.09451+00	2026-03-01 03:20:08.09451+00	\N	f
b2b70e1f-49c6-4e66-bbb3-6aa8ace19cfa	5ca5e80f-7b55-4e63-ac08-fb3ad0142078	\N	8158c1a1-b46f-4b41-b006-366a49e445fe	\N	b2b70e1f-49c6-4e66-bbb3-6aa8ace19cfa	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 03:20:09.277296+00	2026-03-01 03:20:09.277296+00	\N	f
cc8d7976-b539-40cb-abdf-49258efed96b	bc338835-6459-402b-9a49-85712076f449	\N	8158c1a1-b46f-4b41-b006-366a49e445fe	b2b70e1f-49c6-4e66-bbb3-6aa8ace19cfa	b2b70e1f-49c6-4e66-bbb3-6aa8ace19cfa	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 03:20:09.734526+00	2026-03-01 03:20:09.734526+00	\N	f
2edf5701-243c-4796-80ea-a90254f69f56	cc04016a-872b-40c2-b75a-acdb030b759d	56f04bfd-6f18-45f4-8946-fee3d4fd4399	\N	\N	2edf5701-243c-4796-80ea-a90254f69f56	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 04:02:32.416141+00	2026-03-01 04:02:32.416141+00	\N	f
fa5e6482-2fea-442a-953a-3db02c586938	56f04bfd-6f18-45f4-8946-fee3d4fd4399	cc04016a-872b-40c2-b75a-acdb030b759d	\N	\N	fa5e6482-2fea-442a-953a-3db02c586938	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 04:02:37.922945+00	2026-03-01 04:02:37.922945+00	\N	f
258deb61-7030-4f97-95bb-390837f501eb	cc04016a-872b-40c2-b75a-acdb030b759d	\N	b5b78930-4dba-49a1-b83e-69350334a25a	\N	258deb61-7030-4f97-95bb-390837f501eb	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 04:02:43.187221+00	2026-03-01 04:02:43.187221+00	\N	f
b7397b85-5052-46ca-b328-12f5adf9b99a	56f04bfd-6f18-45f4-8946-fee3d4fd4399	\N	b5b78930-4dba-49a1-b83e-69350334a25a	258deb61-7030-4f97-95bb-390837f501eb	258deb61-7030-4f97-95bb-390837f501eb	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 04:02:43.994422+00	2026-03-01 04:02:43.994422+00	\N	f
2ffad075-08fd-4043-a953-96676e01cfab	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	fbf0bebe-ce4a-4a11-826e-756aa0fafcb2	\N	\N	2ffad075-08fd-4043-a953-96676e01cfab	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 04:44:46.601093+00	2026-03-01 04:44:46.601093+00	\N	f
23db2a43-1c92-4f30-a25f-80de56be6a83	fbf0bebe-ce4a-4a11-826e-756aa0fafcb2	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	\N	\N	23db2a43-1c92-4f30-a25f-80de56be6a83	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 04:44:52.154994+00	2026-03-01 04:44:52.154994+00	\N	f
98dc350e-b6d6-4b82-8efe-49317bfc8645	b00c07fa-5ce1-4336-aad8-0e6905c2bda6	\N	ce8125ae-64fd-44e0-835a-86962176024b	\N	98dc350e-b6d6-4b82-8efe-49317bfc8645	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 04:44:52.992391+00	2026-03-01 04:44:52.992391+00	\N	f
ba46d39f-b16f-4707-9198-ddfdee1159af	fbf0bebe-ce4a-4a11-826e-756aa0fafcb2	\N	ce8125ae-64fd-44e0-835a-86962176024b	98dc350e-b6d6-4b82-8efe-49317bfc8645	98dc350e-b6d6-4b82-8efe-49317bfc8645	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 04:44:53.417624+00	2026-03-01 04:44:53.417624+00	\N	f
b1bdc63e-bdb5-4871-b57e-7431157e8692	73b9291b-4bb0-42be-a45c-946411aabcc3	73b9291b-4bb0-42be-a45c-946411aabcc3	\N	5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-01 05:06:27.469221+00	2026-03-01 05:06:27.469221+00	\N	f
5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	1ff91ffb-48bf-4604-913a-9280bd491bee	73b9291b-4bb0-42be-a45c-946411aabcc3	\N	\N	5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	direct	Social comp test	[Message recalled]	f	\N	2026-03-01 05:06:22.019255+00	2026-03-01 05:07:09.225373+00	2026-03-01 05:07:09.225373+00	f
c6c8e503-6f9e-4ec4-abaf-8dcd3d51fef6	1ff91ffb-48bf-4604-913a-9280bd491bee	\N	c7d578d5-8dc3-42fd-b2f7-017def71c1bb	\N	c6c8e503-6f9e-4ec4-abaf-8dcd3d51fef6	group	Group test	Hello group	f	\N	2026-03-01 05:07:09.704365+00	2026-03-01 05:07:09.704365+00	\N	f
1b284268-72ee-4672-b260-ba18ca5eacee	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	4cfdea78-eaf5-448b-91b3-6cbf2ecb0c98	\N	\N	1b284268-72ee-4672-b260-ba18ca5eacee	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 05:49:32.018707+00	2026-03-01 05:49:32.018707+00	\N	f
64cead7a-2775-4679-a18f-6da776770082	4cfdea78-eaf5-448b-91b3-6cbf2ecb0c98	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	\N	\N	64cead7a-2775-4679-a18f-6da776770082	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 05:49:37.627156+00	2026-03-01 05:49:37.627156+00	\N	f
0b863d23-86d3-4785-b055-a23191b9c9c0	fa773fa5-0b46-49ff-93d0-3b9e0cef71ca	\N	369582b1-8a6a-4799-adbd-f45d80ed4bdf	\N	0b863d23-86d3-4785-b055-a23191b9c9c0	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 05:49:38.550514+00	2026-03-01 05:49:38.550514+00	\N	f
6e5816be-8a65-449e-a11a-5b759a784344	4cfdea78-eaf5-448b-91b3-6cbf2ecb0c98	\N	369582b1-8a6a-4799-adbd-f45d80ed4bdf	0b863d23-86d3-4785-b055-a23191b9c9c0	0b863d23-86d3-4785-b055-a23191b9c9c0	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 05:49:39.019116+00	2026-03-01 05:49:39.019116+00	\N	f
2c7d1422-af42-40ae-aa51-97547927c5f3	bf15db20-5325-4d1d-891b-faed3c995d13	\N	3d0afe59-a769-41dc-bfe0-25e0fb7af85e	\N	2c7d1422-af42-40ae-aa51-97547927c5f3	group	Group test	Hello group	f	\N	2026-03-05 05:40:51.962284+00	2026-03-05 05:40:51.962284+00	\N	f
27b36df7-7608-41fa-9e57-72f7ebf782c4	e08c76f6-b5b7-4dce-b61d-450c96abedd6	0d55aa69-c8e7-417f-abb2-5eb119e59cac	\N	\N	27b36df7-7608-41fa-9e57-72f7ebf782c4	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 06:27:29.126301+00	2026-03-01 06:27:29.126301+00	\N	f
77a2977c-74fa-4b55-9b9c-8af2dc647943	0d55aa69-c8e7-417f-abb2-5eb119e59cac	e08c76f6-b5b7-4dce-b61d-450c96abedd6	\N	\N	77a2977c-74fa-4b55-9b9c-8af2dc647943	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 06:27:37.668095+00	2026-03-01 06:27:37.668095+00	\N	f
a8b07d45-1195-4284-b13a-0ccff51b5216	e08c76f6-b5b7-4dce-b61d-450c96abedd6	\N	e6555055-44ef-4316-9c84-3f66545d6dd8	\N	a8b07d45-1195-4284-b13a-0ccff51b5216	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 06:27:39.053249+00	2026-03-01 06:27:39.053249+00	\N	f
2a8183cf-abbf-42ca-85e2-1a832957f1a7	0d55aa69-c8e7-417f-abb2-5eb119e59cac	\N	e6555055-44ef-4316-9c84-3f66545d6dd8	a8b07d45-1195-4284-b13a-0ccff51b5216	a8b07d45-1195-4284-b13a-0ccff51b5216	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 06:27:39.485623+00	2026-03-01 06:27:39.485623+00	\N	f
272651ad-988a-4d74-8893-d9af05d1a413	2f2cd581-05ce-4f21-8352-e51f1be40de4	b3185860-cff6-462e-be65-cfacff59945d	\N	\N	272651ad-988a-4d74-8893-d9af05d1a413	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 07:10:47.517647+00	2026-03-01 07:10:47.517647+00	\N	f
c167bbdd-b304-4b54-91a3-8e2b71513ff0	b3185860-cff6-462e-be65-cfacff59945d	2f2cd581-05ce-4f21-8352-e51f1be40de4	\N	\N	c167bbdd-b304-4b54-91a3-8e2b71513ff0	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 07:10:56.005075+00	2026-03-01 07:10:56.005075+00	\N	f
6e3d001c-4ff6-47c2-85be-6c114cddf0f0	2f2cd581-05ce-4f21-8352-e51f1be40de4	\N	1cf60dc8-70e7-4f6c-8421-733573cb1174	\N	6e3d001c-4ff6-47c2-85be-6c114cddf0f0	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 07:10:57.102135+00	2026-03-01 07:10:57.102135+00	\N	f
ec2422d7-e3f6-4428-a3cd-64d76a090b57	b3185860-cff6-462e-be65-cfacff59945d	\N	1cf60dc8-70e7-4f6c-8421-733573cb1174	6e3d001c-4ff6-47c2-85be-6c114cddf0f0	6e3d001c-4ff6-47c2-85be-6c114cddf0f0	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 07:10:58.125117+00	2026-03-01 07:10:58.125117+00	\N	f
48af671b-fd22-4b25-953a-753bca7f6e6d	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	09a07f48-8194-4865-ad69-a1cbf10233b4	\N	\N	48af671b-fd22-4b25-953a-753bca7f6e6d	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 08:22:25.983603+00	2026-03-01 08:22:25.983603+00	\N	f
aa4e57b9-e3fa-4143-901e-c982b8a10e3c	09a07f48-8194-4865-ad69-a1cbf10233b4	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	\N	\N	aa4e57b9-e3fa-4143-901e-c982b8a10e3c	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 08:22:34.662836+00	2026-03-01 08:22:34.662836+00	\N	f
65bda7b9-22f4-4062-a51f-9fd027ce4f9d	4cbea0da-06ad-4c34-adf4-f8aa9a8acf69	\N	a98cf18a-67c6-4e4b-97f4-6a032771b4bb	\N	65bda7b9-22f4-4062-a51f-9fd027ce4f9d	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 08:22:40.687059+00	2026-03-01 08:22:40.687059+00	\N	f
4fa64837-6aaa-488c-938b-c5704af71dc9	09a07f48-8194-4865-ad69-a1cbf10233b4	\N	a98cf18a-67c6-4e4b-97f4-6a032771b4bb	65bda7b9-22f4-4062-a51f-9fd027ce4f9d	65bda7b9-22f4-4062-a51f-9fd027ce4f9d	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 08:22:41.310902+00	2026-03-01 08:22:41.310902+00	\N	f
f2e96b51-df1b-46d9-99bc-fd0fc788589a	391d8769-702e-4c1a-a44c-29022307c877	47670534-24e1-40f2-bff6-753d69b03443	\N	\N	f2e96b51-df1b-46d9-99bc-fd0fc788589a	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 08:52:14.333823+00	2026-03-01 08:52:14.333823+00	\N	f
58335ee6-b0b6-4984-b3bd-e6cfe89a301f	47670534-24e1-40f2-bff6-753d69b03443	391d8769-702e-4c1a-a44c-29022307c877	\N	\N	58335ee6-b0b6-4984-b3bd-e6cfe89a301f	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 08:52:20.19742+00	2026-03-01 08:52:20.19742+00	\N	f
c403b384-fe61-466a-93f1-b2bd57a60934	391d8769-702e-4c1a-a44c-29022307c877	\N	4f86d703-358c-4f78-b116-37fbac5ea970	\N	c403b384-fe61-466a-93f1-b2bd57a60934	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 08:52:21.543587+00	2026-03-01 08:52:21.543587+00	\N	f
fa1f635a-b27f-4201-b3a3-2455a99c0058	47670534-24e1-40f2-bff6-753d69b03443	\N	4f86d703-358c-4f78-b116-37fbac5ea970	c403b384-fe61-466a-93f1-b2bd57a60934	c403b384-fe61-466a-93f1-b2bd57a60934	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 08:52:22.025623+00	2026-03-01 08:52:22.025623+00	\N	f
3194d452-a16f-40ee-865d-13740b1ba557	ca77bbd7-501b-4cea-88d8-3f62f7e46255	07e2d78a-a5a8-416c-acb3-3de5249a0cc3	\N	\N	3194d452-a16f-40ee-865d-13740b1ba557	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 09:24:46.775219+00	2026-03-01 09:24:46.775219+00	\N	f
86b463fa-ae67-46c5-a653-9d1d8a250a55	07e2d78a-a5a8-416c-acb3-3de5249a0cc3	ca77bbd7-501b-4cea-88d8-3f62f7e46255	\N	\N	86b463fa-ae67-46c5-a653-9d1d8a250a55	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 09:25:00.790288+00	2026-03-01 09:25:00.790288+00	\N	f
1f81d072-bb1a-4d81-8d75-ddefe2f0eae4	ca77bbd7-501b-4cea-88d8-3f62f7e46255	\N	af3a7c70-3587-435d-92da-1df311a5bcda	\N	1f81d072-bb1a-4d81-8d75-ddefe2f0eae4	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 09:25:04.462625+00	2026-03-01 09:25:04.462625+00	\N	f
eef86999-f535-4d31-8df8-2645d83aff92	07e2d78a-a5a8-416c-acb3-3de5249a0cc3	\N	af3a7c70-3587-435d-92da-1df311a5bcda	1f81d072-bb1a-4d81-8d75-ddefe2f0eae4	1f81d072-bb1a-4d81-8d75-ddefe2f0eae4	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 09:25:05.2098+00	2026-03-01 09:25:05.2098+00	\N	f
57ad0abb-8cf1-4ef9-b745-6bb33851d22a	225c9e9c-1a53-483c-8185-876e47fa3fba	225c9e9c-1a53-483c-8185-876e47fa3fba	\N	cda32066-b0f7-4fbe-8fad-4b9d9817669e	cda32066-b0f7-4fbe-8fad-4b9d9817669e	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-01 09:55:47.798807+00	2026-03-01 09:55:47.798807+00	\N	f
cda32066-b0f7-4fbe-8fad-4b9d9817669e	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	225c9e9c-1a53-483c-8185-876e47fa3fba	\N	\N	cda32066-b0f7-4fbe-8fad-4b9d9817669e	direct	Social comp test	[Message recalled]	f	\N	2026-03-01 09:55:47.203256+00	2026-03-01 09:55:50.112502+00	2026-03-01 09:55:50.112502+00	f
dc3b3c75-6143-40c5-8e48-a95e5190b447	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	\N	d8f16c66-e884-4427-be61-f7acba7a8867	\N	dc3b3c75-6143-40c5-8e48-a95e5190b447	group	Group test	Hello group	f	\N	2026-03-01 09:55:50.187641+00	2026-03-01 09:55:50.187641+00	\N	f
78053cc7-db9c-4bce-a352-89b03488bb37	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	133b5917-1b22-4465-9878-313102c84d25	\N	\N	78053cc7-db9c-4bce-a352-89b03488bb37	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 20:43:04.280881+00	2026-03-01 20:43:04.280881+00	\N	f
76cd7a45-7858-4988-8901-64d00d095937	133b5917-1b22-4465-9878-313102c84d25	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	\N	\N	76cd7a45-7858-4988-8901-64d00d095937	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 20:43:09.836099+00	2026-03-01 20:43:09.836099+00	\N	f
3352dafe-af75-48c0-ab3c-c6c89e5efb44	97b950b7-ab39-4ce6-9560-e49b7b9c2db6	\N	d0ee704b-9836-4d03-8dc2-28c20abdf1a4	\N	3352dafe-af75-48c0-ab3c-c6c89e5efb44	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 20:43:14.423241+00	2026-03-01 20:43:14.423241+00	\N	f
8f70961a-f188-4127-9eca-2e6f45c6d7d7	133b5917-1b22-4465-9878-313102c84d25	\N	d0ee704b-9836-4d03-8dc2-28c20abdf1a4	3352dafe-af75-48c0-ab3c-c6c89e5efb44	3352dafe-af75-48c0-ab3c-c6c89e5efb44	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 20:43:15.133149+00	2026-03-01 20:43:15.133149+00	\N	f
852f20ca-0711-410f-acfe-1a04727ed873	21ff734b-3c75-4574-97c9-c35cc3818bc6	37d17cdf-0a49-474c-b4fb-b9095b1acb7e	\N	\N	852f20ca-0711-410f-acfe-1a04727ed873	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-01 22:03:56.579145+00	2026-03-01 22:03:56.579145+00	\N	f
4363af10-9573-46d7-8d38-e89abf54f002	37d17cdf-0a49-474c-b4fb-b9095b1acb7e	21ff734b-3c75-4574-97c9-c35cc3818bc6	\N	\N	4363af10-9573-46d7-8d38-e89abf54f002	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-01 22:04:02.459044+00	2026-03-01 22:04:02.459044+00	\N	f
5f44cf6f-2a8d-4261-a894-e7355fc6d815	21ff734b-3c75-4574-97c9-c35cc3818bc6	\N	e3f5f15a-57e2-4ec9-8a0a-fdf8d818be9e	\N	5f44cf6f-2a8d-4261-a894-e7355fc6d815	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-01 22:04:05.885123+00	2026-03-01 22:04:05.885123+00	\N	f
1c6c01e1-e5b3-42d4-82f1-b1c068da91ac	37d17cdf-0a49-474c-b4fb-b9095b1acb7e	\N	e3f5f15a-57e2-4ec9-8a0a-fdf8d818be9e	5f44cf6f-2a8d-4261-a894-e7355fc6d815	5f44cf6f-2a8d-4261-a894-e7355fc6d815	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-01 22:04:08.928949+00	2026-03-01 22:04:08.928949+00	\N	f
88700f1a-af53-42f6-8f47-4341458d218a	d34d1a82-337e-42bd-94a6-b2476d1fb261	d34d1a82-337e-42bd-94a6-b2476d1fb261	\N	ed46adfb-e2ff-4cec-a497-0a01af0f534b	ed46adfb-e2ff-4cec-a497-0a01af0f534b	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-01 22:45:29.072371+00	2026-03-01 22:45:29.072371+00	\N	f
ed46adfb-e2ff-4cec-a497-0a01af0f534b	329c9336-72d8-4a5c-9246-629fa24930df	d34d1a82-337e-42bd-94a6-b2476d1fb261	\N	\N	ed46adfb-e2ff-4cec-a497-0a01af0f534b	direct	Social comp test	[Message recalled]	f	\N	2026-03-01 22:45:23.560646+00	2026-03-01 22:45:30.808071+00	2026-03-01 22:45:30.808071+00	f
d9acf6ea-45ae-4cb8-81bc-f76bab575b23	329c9336-72d8-4a5c-9246-629fa24930df	\N	4cc8a573-89e1-4566-b67f-56bd91da189b	\N	d9acf6ea-45ae-4cb8-81bc-f76bab575b23	group	Group test	Hello group	f	\N	2026-03-01 22:45:30.874538+00	2026-03-01 22:45:30.874538+00	\N	f
5ea7699b-eaab-4951-a286-6160988e9292	92a67500-cdac-43d1-8f4b-f27e7f1891ec	f3df66bc-9014-4c35-9030-4632bf8c2cc1	\N	\N	5ea7699b-eaab-4951-a286-6160988e9292	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 00:29:23.374432+00	2026-03-02 00:29:23.374432+00	\N	f
d1093b05-17f3-4d89-809b-0e7ad64c79ba	f3df66bc-9014-4c35-9030-4632bf8c2cc1	92a67500-cdac-43d1-8f4b-f27e7f1891ec	\N	\N	d1093b05-17f3-4d89-809b-0e7ad64c79ba	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 00:29:31.968026+00	2026-03-02 00:29:31.968026+00	\N	f
c7194a1b-1305-4bdd-a3fc-0b29bf9bb9cc	92a67500-cdac-43d1-8f4b-f27e7f1891ec	\N	1044a749-4a2e-477e-9cca-6d52c47e03ca	\N	c7194a1b-1305-4bdd-a3fc-0b29bf9bb9cc	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 00:29:36.155459+00	2026-03-02 00:29:36.155459+00	\N	f
22058dce-bf13-4cb3-a4d5-00e219e2848d	f3df66bc-9014-4c35-9030-4632bf8c2cc1	\N	1044a749-4a2e-477e-9cca-6d52c47e03ca	c7194a1b-1305-4bdd-a3fc-0b29bf9bb9cc	c7194a1b-1305-4bdd-a3fc-0b29bf9bb9cc	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 00:29:36.583745+00	2026-03-02 00:29:36.583745+00	\N	f
9173b747-47bd-45e9-ba9e-97151910ce28	6246157a-a93d-4ef5-b943-c9a143f03e2d	85da0865-b48b-4ad4-a88b-883d122aa944	\N	\N	9173b747-47bd-45e9-ba9e-97151910ce28	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 01:23:22.412959+00	2026-03-02 01:23:22.412959+00	\N	f
bb1470b5-56fc-4895-9562-1807ad74b80b	85da0865-b48b-4ad4-a88b-883d122aa944	6246157a-a93d-4ef5-b943-c9a143f03e2d	\N	\N	bb1470b5-56fc-4895-9562-1807ad74b80b	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 01:23:28.004963+00	2026-03-02 01:23:28.004963+00	\N	f
faa84077-9f4a-48c1-86c1-d164d7d86867	debcc6b7-cd08-43c0-8e62-f8764488d87d	\N	8b80389c-738c-468c-a3c4-91ea41e740bf	\N	faa84077-9f4a-48c1-86c1-d164d7d86867	group	Group test	Hello group	f	\N	2026-03-03 20:38:56.562284+00	2026-03-03 20:38:56.562284+00	\N	f
16f7c2d6-eba3-4f11-9749-41a63dda0e4c	6246157a-a93d-4ef5-b943-c9a143f03e2d	\N	19b1ce6e-b5e0-4bd9-b82e-0ca6221d96c8	\N	16f7c2d6-eba3-4f11-9749-41a63dda0e4c	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 01:23:32.041156+00	2026-03-02 01:23:32.041156+00	\N	f
d5a5f2c2-161f-4431-8d8e-e1e1d67402be	85da0865-b48b-4ad4-a88b-883d122aa944	\N	19b1ce6e-b5e0-4bd9-b82e-0ca6221d96c8	16f7c2d6-eba3-4f11-9749-41a63dda0e4c	16f7c2d6-eba3-4f11-9749-41a63dda0e4c	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 01:23:32.733499+00	2026-03-02 01:23:32.733499+00	\N	f
7e96b33d-fd5a-4c12-814b-e1b5cbe13d73	0e99ed9a-8a8d-4c75-a552-1e3c3dbeaa74	0e99ed9a-8a8d-4c75-a552-1e3c3dbeaa74	\N	735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-02 01:47:02.32734+00	2026-03-02 01:47:02.32734+00	\N	f
735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	0e99ed9a-8a8d-4c75-a552-1e3c3dbeaa74	\N	\N	735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	direct	Social comp test	[Message recalled]	f	\N	2026-03-02 01:46:57.070947+00	2026-03-02 01:47:13.794493+00	2026-03-02 01:47:13.794493+00	f
3d4c1bfa-f6ad-4ee6-9210-2e1ca921c023	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	\N	882db819-124e-41c4-ac5c-994984a1f216	\N	3d4c1bfa-f6ad-4ee6-9210-2e1ca921c023	group	Group test	Hello group	f	\N	2026-03-02 01:47:13.866336+00	2026-03-02 01:47:13.866336+00	\N	f
711e752e-92b8-4d83-9c9a-22bb8173ffb9	56886316-0d84-4556-ba46-56b476dcfffa	742bcd22-7377-4911-aaf6-ea1debfe30d7	\N	\N	711e752e-92b8-4d83-9c9a-22bb8173ffb9	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 10:19:01.785105+00	2026-03-02 10:19:01.785105+00	\N	f
be9687da-6cc6-44f6-a327-b00c595c6cad	742bcd22-7377-4911-aaf6-ea1debfe30d7	56886316-0d84-4556-ba46-56b476dcfffa	\N	\N	be9687da-6cc6-44f6-a327-b00c595c6cad	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 10:19:07.261725+00	2026-03-02 10:19:07.261725+00	\N	f
bed578c6-987a-4ea6-b89a-0cbc5b92d87e	56886316-0d84-4556-ba46-56b476dcfffa	\N	0aec0723-56d3-4ad9-a73d-ef7abb5fa349	\N	bed578c6-987a-4ea6-b89a-0cbc5b92d87e	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 10:19:08.239201+00	2026-03-02 10:19:08.239201+00	\N	f
cd7a00cb-dd46-4d64-ad76-fd330048ffd3	742bcd22-7377-4911-aaf6-ea1debfe30d7	\N	0aec0723-56d3-4ad9-a73d-ef7abb5fa349	bed578c6-987a-4ea6-b89a-0cbc5b92d87e	bed578c6-987a-4ea6-b89a-0cbc5b92d87e	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 10:19:08.735005+00	2026-03-02 10:19:08.735005+00	\N	f
dc8cf593-2bd5-45fb-bf89-40247411523b	7ddd695a-4344-4466-bf54-8482baea7184	7ddd695a-4344-4466-bf54-8482baea7184	\N	95a8ef9a-064a-4b96-b838-32a790bafeba	95a8ef9a-064a-4b96-b838-32a790bafeba	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-02 10:41:15.548308+00	2026-03-02 10:41:15.548308+00	\N	f
95a8ef9a-064a-4b96-b838-32a790bafeba	2830f9b0-2aec-459c-9893-8a4b993c3262	7ddd695a-4344-4466-bf54-8482baea7184	\N	\N	95a8ef9a-064a-4b96-b838-32a790bafeba	direct	Social comp test	[Message recalled]	f	\N	2026-03-02 10:41:14.904401+00	2026-03-02 10:41:16.737837+00	2026-03-02 10:41:16.737837+00	f
a130b43e-24e6-4526-987e-8875ff046f4d	2830f9b0-2aec-459c-9893-8a4b993c3262	\N	a60dfd20-4713-4491-8ebc-ea928d9c7ec8	\N	a130b43e-24e6-4526-987e-8875ff046f4d	group	Group test	Hello group	f	\N	2026-03-02 10:41:16.952144+00	2026-03-02 10:41:16.952144+00	\N	f
5001b232-e0e0-4ad9-8ed0-e8a1866de719	563da29b-6b23-4753-8dba-01fdbb6f905d	b7c0acea-5ac9-45f5-94f1-0c4756736899	\N	\N	5001b232-e0e0-4ad9-8ed0-e8a1866de719	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 12:43:35.848674+00	2026-03-02 12:43:35.848674+00	\N	f
9dd6859b-c9d9-4420-9194-e14fa702c0cb	b7c0acea-5ac9-45f5-94f1-0c4756736899	563da29b-6b23-4753-8dba-01fdbb6f905d	\N	\N	9dd6859b-c9d9-4420-9194-e14fa702c0cb	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 12:43:41.397211+00	2026-03-02 12:43:41.397211+00	\N	f
0d2ad102-62a2-4b6b-ad66-5a38664cf6ae	563da29b-6b23-4753-8dba-01fdbb6f905d	\N	099413c9-0bfb-4e71-bf8e-94899d705b85	\N	0d2ad102-62a2-4b6b-ad66-5a38664cf6ae	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 12:43:43.338515+00	2026-03-02 12:43:43.338515+00	\N	f
e12fba9d-2dd2-4d78-925b-9b52c588d829	b7c0acea-5ac9-45f5-94f1-0c4756736899	\N	099413c9-0bfb-4e71-bf8e-94899d705b85	0d2ad102-62a2-4b6b-ad66-5a38664cf6ae	0d2ad102-62a2-4b6b-ad66-5a38664cf6ae	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 12:43:44.204599+00	2026-03-02 12:43:44.204599+00	\N	f
44e2dd74-ba37-4917-bc8c-e2041ff41da1	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	46131b88-f99b-4d7e-97ec-f2b40d70e108	\N	\N	44e2dd74-ba37-4917-bc8c-e2041ff41da1	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 13:17:06.037089+00	2026-03-02 13:17:06.037089+00	\N	f
98cd89e3-a9cd-4595-bb04-123c870e0a6f	46131b88-f99b-4d7e-97ec-f2b40d70e108	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	\N	\N	98cd89e3-a9cd-4595-bb04-123c870e0a6f	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 13:17:11.553894+00	2026-03-02 13:17:11.553894+00	\N	f
b4be75de-d678-4052-9edd-03514fc67565	23fbf174-a6cb-4d8d-b9f1-6debb8a2aa91	\N	2e14456c-e3a1-4ec3-8ced-0c803de9763a	\N	b4be75de-d678-4052-9edd-03514fc67565	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 13:17:12.842521+00	2026-03-02 13:17:12.842521+00	\N	f
3998545d-e726-45ae-adb1-38cd2f84a3ac	46131b88-f99b-4d7e-97ec-f2b40d70e108	\N	2e14456c-e3a1-4ec3-8ced-0c803de9763a	b4be75de-d678-4052-9edd-03514fc67565	b4be75de-d678-4052-9edd-03514fc67565	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 13:17:13.242583+00	2026-03-02 13:17:13.242583+00	\N	f
86b50d98-5e38-44e9-9f0f-38fda1dc138b	0d58e6b5-eb5a-4976-bae0-2f459280932a	5b3d09b9-c262-48ed-a468-1600885d50d8	\N	\N	86b50d98-5e38-44e9-9f0f-38fda1dc138b	direct	Social comp test	Hello from social suite	f	\N	2026-03-02 13:37:21.700671+00	2026-03-02 13:37:21.700671+00	\N	f
51c4a277-6fd1-4681-9b2d-38516f959695	5b3d09b9-c262-48ed-a468-1600885d50d8	5b3d09b9-c262-48ed-a468-1600885d50d8	\N	86b50d98-5e38-44e9-9f0f-38fda1dc138b	86b50d98-5e38-44e9-9f0f-38fda1dc138b	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-02 13:37:27.08093+00	2026-03-02 13:37:27.08093+00	\N	f
904dacd3-acc5-4350-b812-f65eab6b48b3	24246ea0-c094-4c8c-b167-a83a72bed89b	b386fee6-107d-475c-bac6-c29a764bbeb3	\N	\N	904dacd3-acc5-4350-b812-f65eab6b48b3	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 14:20:57.730052+00	2026-03-02 14:20:57.730052+00	\N	f
c91f5fe9-1d0b-4ab8-96e8-37a8d05a48b8	b386fee6-107d-475c-bac6-c29a764bbeb3	24246ea0-c094-4c8c-b167-a83a72bed89b	\N	\N	c91f5fe9-1d0b-4ab8-96e8-37a8d05a48b8	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 14:21:03.499192+00	2026-03-02 14:21:03.499192+00	\N	f
45f4f415-1a6e-4f51-bc07-cf7d305c759e	24246ea0-c094-4c8c-b167-a83a72bed89b	\N	e6b67cb0-e60c-4f3b-bef7-d61643d44cca	\N	45f4f415-1a6e-4f51-bc07-cf7d305c759e	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 14:21:07.785504+00	2026-03-02 14:21:07.785504+00	\N	f
9cb76dc1-6a24-4627-9e0a-7590ff864a88	b386fee6-107d-475c-bac6-c29a764bbeb3	\N	e6b67cb0-e60c-4f3b-bef7-d61643d44cca	45f4f415-1a6e-4f51-bc07-cf7d305c759e	45f4f415-1a6e-4f51-bc07-cf7d305c759e	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 14:21:08.3139+00	2026-03-02 14:21:08.3139+00	\N	f
4746b6a6-cad1-4ecb-ba3f-3521f30973bc	a27c9dd1-7830-4e77-bfdb-e9d2f343079c	a27c9dd1-7830-4e77-bfdb-e9d2f343079c	\N	46fb8c80-8f96-491d-8564-58902f7e19ee	46fb8c80-8f96-491d-8564-58902f7e19ee	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-02 14:44:38.046018+00	2026-03-02 14:44:38.046018+00	\N	f
46fb8c80-8f96-491d-8564-58902f7e19ee	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	a27c9dd1-7830-4e77-bfdb-e9d2f343079c	\N	\N	46fb8c80-8f96-491d-8564-58902f7e19ee	direct	Social comp test	[Message recalled]	f	\N	2026-03-02 14:44:28.070551+00	2026-03-02 14:44:50.909595+00	2026-03-02 14:44:50.909595+00	f
ad61d34f-fea8-4fb1-9cde-fae4e6aaf711	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	\N	bb8f80ef-2b12-47d9-9524-a4e7f14eb654	\N	ad61d34f-fea8-4fb1-9cde-fae4e6aaf711	group	Group test	Hello group	f	\N	2026-03-02 14:44:50.997794+00	2026-03-02 14:44:50.997794+00	\N	f
6f70bb40-14d3-4117-9502-5c26e54a9b41	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	f6e4c03c-c756-4eb4-911b-d1c4060a5ba0	\N	\N	6f70bb40-14d3-4117-9502-5c26e54a9b41	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 15:10:58.89626+00	2026-03-02 15:10:58.89626+00	\N	f
cdbb1ec3-a5a7-455f-80a6-34576060a557	f6e4c03c-c756-4eb4-911b-d1c4060a5ba0	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	\N	\N	cdbb1ec3-a5a7-455f-80a6-34576060a557	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 15:11:04.84829+00	2026-03-02 15:11:04.84829+00	\N	f
16ebed87-ada6-46b1-8325-84f0e0b450d8	694cba41-0bb9-45b3-bbe5-92e912bcd7a8	\N	9a45192e-3e56-4ff3-952f-90e935df8a0c	\N	16ebed87-ada6-46b1-8325-84f0e0b450d8	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 15:11:06.034167+00	2026-03-02 15:11:06.034167+00	\N	f
1627d944-373d-4792-acf2-d88468a66a17	f6e4c03c-c756-4eb4-911b-d1c4060a5ba0	\N	9a45192e-3e56-4ff3-952f-90e935df8a0c	16ebed87-ada6-46b1-8325-84f0e0b450d8	16ebed87-ada6-46b1-8325-84f0e0b450d8	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 15:11:06.409006+00	2026-03-02 15:11:06.409006+00	\N	f
af8e9c9a-e84b-4737-82b5-1b57ebddfdc7	03dab3ec-62ee-4b40-90fa-7906204db0d9	03dab3ec-62ee-4b40-90fa-7906204db0d9	\N	10ea2568-990c-4bed-b775-ffdf5aa40878	10ea2568-990c-4bed-b775-ffdf5aa40878	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-02 15:49:32.636724+00	2026-03-02 15:49:32.636724+00	\N	f
10ea2568-990c-4bed-b775-ffdf5aa40878	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	03dab3ec-62ee-4b40-90fa-7906204db0d9	\N	\N	10ea2568-990c-4bed-b775-ffdf5aa40878	direct	Social comp test	[Message recalled]	f	\N	2026-03-02 15:49:26.916554+00	2026-03-02 15:49:34.478425+00	2026-03-02 15:49:34.478425+00	f
23d2495b-0d0d-47d4-b183-d8a2ecb89002	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	\N	cfa7ab00-cc9a-46d7-b11d-fdcf89ccf10a	\N	23d2495b-0d0d-47d4-b183-d8a2ecb89002	group	Group test	Hello group	f	\N	2026-03-02 15:49:34.542081+00	2026-03-02 15:49:34.542081+00	\N	f
835edcd3-137c-4579-8089-37033e0e059f	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	c882505f-d91f-46b4-98cf-72907a7f29b3	\N	\N	835edcd3-137c-4579-8089-37033e0e059f	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-02 20:33:13.908784+00	2026-03-02 20:33:13.908784+00	\N	f
fb9d22a9-7f6c-4030-a839-203ee6caa330	c882505f-d91f-46b4-98cf-72907a7f29b3	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	\N	\N	fb9d22a9-7f6c-4030-a839-203ee6caa330	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-02 20:33:19.377908+00	2026-03-02 20:33:19.377908+00	\N	f
ddd35344-434d-4672-b898-5e39b8112e8d	70d6acf0-f43a-4ee5-a07b-d8a92da678e5	\N	492a00cb-eba1-4ac7-980d-1ee6a6eeecc9	\N	ddd35344-434d-4672-b898-5e39b8112e8d	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-02 20:33:20.275518+00	2026-03-02 20:33:20.275518+00	\N	f
62258cdb-00b6-43dc-bdac-51c8bd5ba239	c882505f-d91f-46b4-98cf-72907a7f29b3	\N	492a00cb-eba1-4ac7-980d-1ee6a6eeecc9	ddd35344-434d-4672-b898-5e39b8112e8d	ddd35344-434d-4672-b898-5e39b8112e8d	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-02 20:33:20.683667+00	2026-03-02 20:33:20.683667+00	\N	f
d957f318-198a-4615-b48f-629fedab400f	4c5385ca-07c8-4aca-ab35-b91c040bbd4b	4c5385ca-07c8-4aca-ab35-b91c040bbd4b	\N	a736e585-0d91-411b-a9df-df8677402b71	a736e585-0d91-411b-a9df-df8677402b71	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-02 20:57:57.966963+00	2026-03-02 20:57:57.966963+00	\N	f
a736e585-0d91-411b-a9df-df8677402b71	37a27965-d80a-4c0d-884b-3d6468ec7399	4c5385ca-07c8-4aca-ab35-b91c040bbd4b	\N	\N	a736e585-0d91-411b-a9df-df8677402b71	direct	Social comp test	[Message recalled]	f	\N	2026-03-02 20:57:56.887965+00	2026-03-02 20:57:59.50648+00	2026-03-02 20:57:59.50648+00	f
4c55aaad-bc45-48e6-9585-a0c4812e8888	37a27965-d80a-4c0d-884b-3d6468ec7399	\N	71f0800f-7007-43fd-875f-8dcb456859f9	\N	4c55aaad-bc45-48e6-9585-a0c4812e8888	group	Group test	Hello group	f	\N	2026-03-02 20:57:59.572564+00	2026-03-02 20:57:59.572564+00	\N	f
19b87608-1f35-4773-b9cf-6658c287cea8	436892ad-1a40-40dd-ad3e-62d59baca3bb	203dba31-03b6-4bad-8239-14a9ab706d6f	\N	\N	19b87608-1f35-4773-b9cf-6658c287cea8	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-03 00:15:58.348068+00	2026-03-03 00:15:58.348068+00	\N	f
00f33366-3902-4dd6-960d-2af3fd28b3fb	203dba31-03b6-4bad-8239-14a9ab706d6f	436892ad-1a40-40dd-ad3e-62d59baca3bb	\N	\N	00f33366-3902-4dd6-960d-2af3fd28b3fb	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-03 00:16:03.904242+00	2026-03-03 00:16:03.904242+00	\N	f
eecb6a7e-b759-4f74-89db-7c6860a0c23f	436892ad-1a40-40dd-ad3e-62d59baca3bb	\N	015528ed-cdd1-4da1-87a2-c34b20ec4def	\N	eecb6a7e-b759-4f74-89db-7c6860a0c23f	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-03 00:16:05.010573+00	2026-03-03 00:16:05.010573+00	\N	f
25e7d5b6-7e72-4425-9b38-214682fe8239	203dba31-03b6-4bad-8239-14a9ab706d6f	\N	015528ed-cdd1-4da1-87a2-c34b20ec4def	eecb6a7e-b759-4f74-89db-7c6860a0c23f	eecb6a7e-b759-4f74-89db-7c6860a0c23f	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-03 00:16:05.538367+00	2026-03-03 00:16:05.538367+00	\N	f
384a404e-0272-421e-a9b4-7e1f877df9fa	ee231bdc-5265-4443-bf4a-a66f74a3e754	7fb588e1-ea59-44c5-8402-eb8ddd5e7172	\N	\N	384a404e-0272-421e-a9b4-7e1f877df9fa	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-03 00:54:57.38167+00	2026-03-03 00:54:57.38167+00	\N	f
cc104219-fcee-4bc8-94cd-3a070cc9569f	7fb588e1-ea59-44c5-8402-eb8ddd5e7172	ee231bdc-5265-4443-bf4a-a66f74a3e754	\N	\N	cc104219-fcee-4bc8-94cd-3a070cc9569f	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-03 00:55:02.998318+00	2026-03-03 00:55:02.998318+00	\N	f
c0f6fa41-8d72-4178-b758-2e83a84571d8	ee231bdc-5265-4443-bf4a-a66f74a3e754	\N	4d3839ec-304c-4b99-8810-2917a0cfaac5	\N	c0f6fa41-8d72-4178-b758-2e83a84571d8	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-03 00:55:03.934433+00	2026-03-03 00:55:03.934433+00	\N	f
de8401b8-b9de-483d-86e1-e4d081335454	7fb588e1-ea59-44c5-8402-eb8ddd5e7172	\N	4d3839ec-304c-4b99-8810-2917a0cfaac5	c0f6fa41-8d72-4178-b758-2e83a84571d8	c0f6fa41-8d72-4178-b758-2e83a84571d8	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-03 00:55:04.390017+00	2026-03-03 00:55:04.390017+00	\N	f
3e5ddf1d-d407-4cf6-bf21-9a864592378f	c6b132b7-f7f1-453e-b4e1-bcafbbbe095f	c6b132b7-f7f1-453e-b4e1-bcafbbbe095f	\N	b8f13129-6b86-4f32-8a01-5aaf18f339d7	b8f13129-6b86-4f32-8a01-5aaf18f339d7	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-03 01:21:10.685213+00	2026-03-03 01:21:10.685213+00	\N	f
b8f13129-6b86-4f32-8a01-5aaf18f339d7	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	c6b132b7-f7f1-453e-b4e1-bcafbbbe095f	\N	\N	b8f13129-6b86-4f32-8a01-5aaf18f339d7	direct	Social comp test	[Message recalled]	f	\N	2026-03-03 01:21:05.364675+00	2026-03-03 01:21:12.008952+00	2026-03-03 01:21:12.008952+00	f
6e3ae988-4823-41b6-96d2-36c11d5a3dca	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	\N	5e671077-f580-4397-98ca-130e5e6978fb	\N	6e3ae988-4823-41b6-96d2-36c11d5a3dca	group	Group test	Hello group	f	\N	2026-03-03 01:21:12.095584+00	2026-03-03 01:21:12.095584+00	\N	f
d67a7da7-6d8e-4a2a-ba7c-e50a1172e701	245ed62a-4f36-4819-b992-d06509f66369	e2936688-4233-4586-a72e-a0a83d2e832c	\N	\N	d67a7da7-6d8e-4a2a-ba7c-e50a1172e701	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-03 02:09:39.936535+00	2026-03-03 02:09:39.936535+00	\N	f
6a9a9ddd-a763-4ed7-ae70-eae677d39ca5	e2936688-4233-4586-a72e-a0a83d2e832c	245ed62a-4f36-4819-b992-d06509f66369	\N	\N	6a9a9ddd-a763-4ed7-ae70-eae677d39ca5	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-03 02:09:45.46182+00	2026-03-03 02:09:45.46182+00	\N	f
155eaf35-46b3-4ab6-9df0-945e58dc21fb	245ed62a-4f36-4819-b992-d06509f66369	\N	71bac6cd-f6fd-4dc1-9df5-0824701c1409	\N	155eaf35-46b3-4ab6-9df0-945e58dc21fb	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-03 02:09:49.539097+00	2026-03-03 02:09:49.539097+00	\N	f
d68a596a-ba8f-4d22-a3c7-350df300f83f	e2936688-4233-4586-a72e-a0a83d2e832c	\N	71bac6cd-f6fd-4dc1-9df5-0824701c1409	155eaf35-46b3-4ab6-9df0-945e58dc21fb	155eaf35-46b3-4ab6-9df0-945e58dc21fb	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-03 02:09:50.517467+00	2026-03-03 02:09:50.517467+00	\N	f
3e3c4f86-6871-4f54-bbfa-437b22f7c66f	bcea8072-41be-4aae-84b0-1bec388975cf	bcea8072-41be-4aae-84b0-1bec388975cf	\N	9d87aa39-1eb2-44da-a281-35dc0194480a	9d87aa39-1eb2-44da-a281-35dc0194480a	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-03 04:11:07.048134+00	2026-03-03 04:11:07.048134+00	\N	f
9d87aa39-1eb2-44da-a281-35dc0194480a	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	bcea8072-41be-4aae-84b0-1bec388975cf	\N	\N	9d87aa39-1eb2-44da-a281-35dc0194480a	direct	Social comp test	[Message recalled]	f	\N	2026-03-03 04:11:06.120496+00	2026-03-03 04:11:08.253335+00	2026-03-03 04:11:08.253335+00	f
36e0220e-1ed2-492c-bbdd-2a8d4887ebee	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	\N	909f343a-571d-47c7-bd72-306aba3d6729	\N	36e0220e-1ed2-492c-bbdd-2a8d4887ebee	group	Group test	Hello group	f	\N	2026-03-03 04:11:08.327877+00	2026-03-03 04:11:08.327877+00	\N	f
43a4ba95-310e-4afc-98fd-bd54eab991e3	28043028-1578-4221-b470-b43484c8fc7e	e096959c-006c-4cdc-9944-5cedb6d64b14	\N	\N	43a4ba95-310e-4afc-98fd-bd54eab991e3	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-03 05:11:19.241527+00	2026-03-03 05:11:19.241527+00	\N	f
4ae20fcb-c4b0-4be4-b8f0-756ffb6e4d58	e096959c-006c-4cdc-9944-5cedb6d64b14	28043028-1578-4221-b470-b43484c8fc7e	\N	\N	4ae20fcb-c4b0-4be4-b8f0-756ffb6e4d58	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-03 05:11:24.844096+00	2026-03-03 05:11:24.844096+00	\N	f
eeece3af-fb68-4ff6-873b-c0d55fb6106c	28043028-1578-4221-b470-b43484c8fc7e	\N	fe1399b3-2d64-4f2a-aedb-fdeacbe679ba	\N	eeece3af-fb68-4ff6-873b-c0d55fb6106c	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-03 05:11:29.549709+00	2026-03-03 05:11:29.549709+00	\N	f
ea0212a6-de04-45d1-8861-604bdcc7e560	e096959c-006c-4cdc-9944-5cedb6d64b14	\N	fe1399b3-2d64-4f2a-aedb-fdeacbe679ba	eeece3af-fb68-4ff6-873b-c0d55fb6106c	eeece3af-fb68-4ff6-873b-c0d55fb6106c	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-03 05:11:30.200992+00	2026-03-03 05:11:30.200992+00	\N	f
98d25c6f-aba5-482d-8dd3-a68e60594585	8a8184ff-3389-4d7a-8d3e-f54152d23627	8a8184ff-3389-4d7a-8d3e-f54152d23627	\N	09b0152d-7c6e-4d71-9473-6327a7db274f	09b0152d-7c6e-4d71-9473-6327a7db274f	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-03 05:44:51.60346+00	2026-03-03 05:44:51.60346+00	\N	f
09b0152d-7c6e-4d71-9473-6327a7db274f	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	8a8184ff-3389-4d7a-8d3e-f54152d23627	\N	\N	09b0152d-7c6e-4d71-9473-6327a7db274f	direct	Social comp test	[Message recalled]	f	\N	2026-03-03 05:44:51.088993+00	2026-03-03 05:44:52.867338+00	2026-03-03 05:44:52.867338+00	f
8e06ee0f-0614-4095-9fde-cb24897b6bd8	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	\N	f16b12b6-8ee4-4b71-94cd-ca63ccb18c83	\N	8e06ee0f-0614-4095-9fde-cb24897b6bd8	group	Group test	Hello group	f	\N	2026-03-03 05:44:52.925324+00	2026-03-03 05:44:52.925324+00	\N	f
dfc6437b-5ded-4775-9b44-d45397f5f889	56bdeb68-a57e-497e-95a3-c8eb0f596d61	d323a977-0cd3-4171-a664-9d8f02929081	\N	\N	dfc6437b-5ded-4775-9b44-d45397f5f889	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-03 06:17:51.337347+00	2026-03-03 06:17:51.337347+00	\N	f
7275fcd4-bf57-42bc-be37-c5425242ce21	d323a977-0cd3-4171-a664-9d8f02929081	56bdeb68-a57e-497e-95a3-c8eb0f596d61	\N	\N	7275fcd4-bf57-42bc-be37-c5425242ce21	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-03 06:17:57.111271+00	2026-03-03 06:17:57.111271+00	\N	f
b33d3a51-c38c-481a-a745-623231b361a0	56bdeb68-a57e-497e-95a3-c8eb0f596d61	\N	e5d43880-6c7e-4ae3-a804-23ec56df8b74	\N	b33d3a51-c38c-481a-a745-623231b361a0	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-03 06:18:01.68598+00	2026-03-03 06:18:01.68598+00	\N	f
2fb87940-67f6-4fbc-b9f6-7ce6241fd5c3	d323a977-0cd3-4171-a664-9d8f02929081	\N	e5d43880-6c7e-4ae3-a804-23ec56df8b74	b33d3a51-c38c-481a-a745-623231b361a0	b33d3a51-c38c-481a-a745-623231b361a0	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-03 06:18:03.414286+00	2026-03-03 06:18:03.414286+00	\N	f
f93e55d2-1ed8-4038-a68c-0992e340316b	10e9389d-5f61-4c22-8484-4b85173ca7b5	10e9389d-5f61-4c22-8484-4b85173ca7b5	\N	def8944c-966e-4df0-b0df-fe1988033609	def8944c-966e-4df0-b0df-fe1988033609	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-03 06:49:36.807464+00	2026-03-03 06:49:36.807464+00	\N	f
def8944c-966e-4df0-b0df-fe1988033609	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	10e9389d-5f61-4c22-8484-4b85173ca7b5	\N	\N	def8944c-966e-4df0-b0df-fe1988033609	direct	Social comp test	[Message recalled]	f	\N	2026-03-03 06:49:36.335976+00	2026-03-03 06:49:38.342215+00	2026-03-03 06:49:38.342215+00	f
220bbad4-7cea-4af8-8c80-c07b24d52ad0	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	\N	f1e74255-7618-4655-98fc-99c58949b317	\N	220bbad4-7cea-4af8-8c80-c07b24d52ad0	group	Group test	Hello group	f	\N	2026-03-03 06:49:38.439176+00	2026-03-03 06:49:38.439176+00	\N	f
76aba2dc-1de7-404e-9835-cbbfa38a6bb9	cd859d66-dee0-4cb6-9689-bd47cae0be0f	54d941d6-1ea7-49e2-b7a8-e6015ae0032c	\N	\N	76aba2dc-1de7-404e-9835-cbbfa38a6bb9	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-03 16:13:22.617637+00	2026-03-03 16:13:22.617637+00	\N	f
a82a700c-509f-4663-aec5-ba3c57c5fc31	54d941d6-1ea7-49e2-b7a8-e6015ae0032c	cd859d66-dee0-4cb6-9689-bd47cae0be0f	\N	\N	a82a700c-509f-4663-aec5-ba3c57c5fc31	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-03 16:13:29.172775+00	2026-03-03 16:13:29.172775+00	\N	f
77491f13-9d81-43b2-a4f9-34a5ba0069dd	cd859d66-dee0-4cb6-9689-bd47cae0be0f	\N	8f9f832d-b658-412c-95d7-a14b05bfef98	\N	77491f13-9d81-43b2-a4f9-34a5ba0069dd	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-03 16:13:33.181757+00	2026-03-03 16:13:33.181757+00	\N	f
a1ce167f-6468-4012-a81e-9cf884f3ea38	54d941d6-1ea7-49e2-b7a8-e6015ae0032c	\N	8f9f832d-b658-412c-95d7-a14b05bfef98	77491f13-9d81-43b2-a4f9-34a5ba0069dd	77491f13-9d81-43b2-a4f9-34a5ba0069dd	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-03 16:13:35.302999+00	2026-03-03 16:13:35.302999+00	\N	f
84253df6-8d35-488a-82c0-65e412b751e4	6ed9e775-2085-4af7-a67d-b815c261886d	6ed9e775-2085-4af7-a67d-b815c261886d	\N	f6d5aeb0-08cb-4300-8d0b-8603249dac39	f6d5aeb0-08cb-4300-8d0b-8603249dac39	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-03 20:38:55.019831+00	2026-03-03 20:38:55.019831+00	\N	f
f6d5aeb0-08cb-4300-8d0b-8603249dac39	debcc6b7-cd08-43c0-8e62-f8764488d87d	6ed9e775-2085-4af7-a67d-b815c261886d	\N	\N	f6d5aeb0-08cb-4300-8d0b-8603249dac39	direct	Social comp test	[Message recalled]	f	\N	2026-03-03 20:38:54.524457+00	2026-03-03 20:38:56.487785+00	2026-03-03 20:38:56.487785+00	f
2bab8cbe-2161-4dc4-a1f9-b145a398e03d	b282ed2d-29af-4fad-a357-02ab89c459fd	a7965ef1-4594-4506-9fe0-e58f031c6172	\N	\N	2bab8cbe-2161-4dc4-a1f9-b145a398e03d	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-04 09:50:04.854447+00	2026-03-04 09:50:04.854447+00	\N	f
28c340c4-3a15-4896-a672-82b745b9f9de	a7965ef1-4594-4506-9fe0-e58f031c6172	b282ed2d-29af-4fad-a357-02ab89c459fd	\N	\N	28c340c4-3a15-4896-a672-82b745b9f9de	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-04 09:50:10.352069+00	2026-03-04 09:50:10.352069+00	\N	f
96b678fc-1ac4-462a-b073-90ddea7645d9	b282ed2d-29af-4fad-a357-02ab89c459fd	\N	38d1cf9b-caff-4739-bfe7-a857b8286f1c	\N	96b678fc-1ac4-462a-b073-90ddea7645d9	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-04 09:50:11.542668+00	2026-03-04 09:50:11.542668+00	\N	f
11b76e4e-1014-4c50-9d48-2846f56cfecd	a7965ef1-4594-4506-9fe0-e58f031c6172	\N	38d1cf9b-caff-4739-bfe7-a857b8286f1c	96b678fc-1ac4-462a-b073-90ddea7645d9	96b678fc-1ac4-462a-b073-90ddea7645d9	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-04 09:50:12.017411+00	2026-03-04 09:50:12.017411+00	\N	f
b8ae9212-e80e-4522-b16a-851668a6b567	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	93f1e2db-37ce-46ea-817e-6964a900d6a1	\N	\N	b8ae9212-e80e-4522-b16a-851668a6b567	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-04 16:20:31.779461+00	2026-03-04 16:20:31.779461+00	\N	f
664dda3d-a471-4a70-a75d-a62f7b194098	93f1e2db-37ce-46ea-817e-6964a900d6a1	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	\N	\N	664dda3d-a471-4a70-a75d-a62f7b194098	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-04 16:20:37.28013+00	2026-03-04 16:20:37.28013+00	\N	f
9f672f01-303d-42a5-b697-572419994700	493cb6a2-94f8-43e0-87aa-4b7ba7f08cd7	\N	400f6300-1488-4db4-9f24-2c3fbe712871	\N	9f672f01-303d-42a5-b697-572419994700	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-04 16:20:38.31436+00	2026-03-04 16:20:38.31436+00	\N	f
6e84789e-fe21-4219-9292-baa17bce4238	93f1e2db-37ce-46ea-817e-6964a900d6a1	\N	400f6300-1488-4db4-9f24-2c3fbe712871	9f672f01-303d-42a5-b697-572419994700	9f672f01-303d-42a5-b697-572419994700	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-04 16:20:38.848472+00	2026-03-04 16:20:38.848472+00	\N	f
542a6667-2688-4c1b-8fcb-49da45f343e9	7856d595-3115-431a-bae9-78bb774e8e32	7856d595-3115-431a-bae9-78bb774e8e32	\N	58ffa13f-91b1-4116-9e6f-10b2d868ab9e	58ffa13f-91b1-4116-9e6f-10b2d868ab9e	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-04 16:41:38.530091+00	2026-03-04 16:41:38.530091+00	\N	f
58ffa13f-91b1-4116-9e6f-10b2d868ab9e	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	7856d595-3115-431a-bae9-78bb774e8e32	\N	\N	58ffa13f-91b1-4116-9e6f-10b2d868ab9e	direct	Social comp test	[Message recalled]	f	\N	2026-03-04 16:41:37.923102+00	2026-03-04 16:41:39.933553+00	2026-03-04 16:41:39.933553+00	f
862e6332-68e2-4e1f-9883-ab308369d911	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	\N	0036a11c-3919-400c-9fb0-102cdfbd57bb	\N	862e6332-68e2-4e1f-9883-ab308369d911	group	Group test	Hello group	f	\N	2026-03-04 16:41:40.007091+00	2026-03-04 16:41:40.007091+00	\N	f
a89bca91-8bd5-4f7d-a8fb-28aff69fb1b7	a11c2fb2-b350-416b-9cb4-176c82eaf560	b9f7507a-0e78-4770-8594-0e4279f96bff	\N	\N	a89bca91-8bd5-4f7d-a8fb-28aff69fb1b7	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-04 23:16:18.025987+00	2026-03-04 23:16:18.025987+00	\N	f
c5244932-eb0e-4379-8394-d61160ef0df0	b9f7507a-0e78-4770-8594-0e4279f96bff	a11c2fb2-b350-416b-9cb4-176c82eaf560	\N	\N	c5244932-eb0e-4379-8394-d61160ef0df0	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-04 23:16:23.502153+00	2026-03-04 23:16:23.502153+00	\N	f
0d705fc4-e71b-4d29-be06-5f69d2bb72ef	a11c2fb2-b350-416b-9cb4-176c82eaf560	\N	1cdbc1e2-0e3a-41e0-b886-934a1f7953e5	\N	0d705fc4-e71b-4d29-be06-5f69d2bb72ef	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-04 23:16:24.402672+00	2026-03-04 23:16:24.402672+00	\N	f
541e00a5-bf35-4ce3-a6ab-45bcbebe4282	b9f7507a-0e78-4770-8594-0e4279f96bff	\N	1cdbc1e2-0e3a-41e0-b886-934a1f7953e5	0d705fc4-e71b-4d29-be06-5f69d2bb72ef	0d705fc4-e71b-4d29-be06-5f69d2bb72ef	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-04 23:16:24.8797+00	2026-03-04 23:16:24.8797+00	\N	f
3d0679e8-1f9a-4612-90bd-08172de43755	4ba5f20a-9378-428d-a8ea-65e877285fbe	4ba5f20a-9378-428d-a8ea-65e877285fbe	\N	28bf71e9-d9fe-4e89-93a3-36a442c90ebf	28bf71e9-d9fe-4e89-93a3-36a442c90ebf	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-04 23:38:32.129942+00	2026-03-04 23:38:32.129942+00	\N	f
28bf71e9-d9fe-4e89-93a3-36a442c90ebf	96785040-a129-40cb-aef4-f9ae99cc8c37	4ba5f20a-9378-428d-a8ea-65e877285fbe	\N	\N	28bf71e9-d9fe-4e89-93a3-36a442c90ebf	direct	Social comp test	[Message recalled]	f	\N	2026-03-04 23:38:31.419631+00	2026-03-04 23:38:33.432298+00	2026-03-04 23:38:33.432298+00	f
4f0d3bc9-1a8f-4cce-8c02-f51dcd205022	96785040-a129-40cb-aef4-f9ae99cc8c37	\N	531ad1a9-2d42-41bf-b2ba-b64c58c432d8	\N	4f0d3bc9-1a8f-4cce-8c02-f51dcd205022	group	Group test	Hello group	f	\N	2026-03-04 23:38:33.501387+00	2026-03-04 23:38:33.501387+00	\N	f
ca6ddbb7-0c50-4b7c-ad4f-1e408d9178f7	b7273deb-f387-46c0-a5d4-712a9784544d	491c0272-e244-486e-957a-36f366a3a5c6	\N	\N	ca6ddbb7-0c50-4b7c-ad4f-1e408d9178f7	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 02:04:49.018078+00	2026-03-05 02:04:49.018078+00	\N	f
db1aa47e-3e6d-4cc1-9707-250ecec7e8c6	491c0272-e244-486e-957a-36f366a3a5c6	b7273deb-f387-46c0-a5d4-712a9784544d	\N	\N	db1aa47e-3e6d-4cc1-9707-250ecec7e8c6	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 02:04:56.175314+00	2026-03-05 02:04:56.175314+00	\N	f
e4531846-3631-42b7-a512-5290e97b2080	b7273deb-f387-46c0-a5d4-712a9784544d	\N	1f5e37d4-2b16-4711-bfb2-3a4cfdbb5705	\N	e4531846-3631-42b7-a512-5290e97b2080	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 02:04:59.192043+00	2026-03-05 02:04:59.192043+00	\N	f
56d7ee4a-5b21-442f-9fda-452428a0c5c2	491c0272-e244-486e-957a-36f366a3a5c6	\N	1f5e37d4-2b16-4711-bfb2-3a4cfdbb5705	e4531846-3631-42b7-a512-5290e97b2080	e4531846-3631-42b7-a512-5290e97b2080	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 02:05:00.241689+00	2026-03-05 02:05:00.241689+00	\N	f
cf928b87-2c36-4e18-9cd8-ba7c3b971add	c2ff98d8-6135-4f44-b98c-bc8b8c216db9	c2ff98d8-6135-4f44-b98c-bc8b8c216db9	\N	750b2d88-6a64-42d1-9286-58b50e91f457	750b2d88-6a64-42d1-9286-58b50e91f457	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 02:36:17.181651+00	2026-03-05 02:36:17.181651+00	\N	f
750b2d88-6a64-42d1-9286-58b50e91f457	ae839a91-35eb-4008-9621-a4244b364932	c2ff98d8-6135-4f44-b98c-bc8b8c216db9	\N	\N	750b2d88-6a64-42d1-9286-58b50e91f457	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 02:36:16.653999+00	2026-03-05 02:36:20.274324+00	2026-03-05 02:36:20.274324+00	f
19223f2c-9f08-4841-a577-e17e68f0bd28	ae839a91-35eb-4008-9621-a4244b364932	\N	8136046b-8ff4-4048-a4a2-79dac8afd7c6	\N	19223f2c-9f08-4841-a577-e17e68f0bd28	group	Group test	Hello group	f	\N	2026-03-05 02:36:20.333172+00	2026-03-05 02:36:20.333172+00	\N	f
0576add4-cb1b-4988-a389-7d7c84dc1241	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	638535b9-f452-4817-86b3-899c56e3ba49	\N	\N	0576add4-cb1b-4988-a389-7d7c84dc1241	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 03:22:17.838229+00	2026-03-05 03:22:17.838229+00	\N	f
84bc55d3-a1b2-470d-9448-0038f9d2518d	638535b9-f452-4817-86b3-899c56e3ba49	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	\N	\N	84bc55d3-a1b2-470d-9448-0038f9d2518d	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 03:22:23.630353+00	2026-03-05 03:22:23.630353+00	\N	f
8f6253f3-aa18-4df0-86db-ec395d092484	394596ae-4bd6-4c0b-b24c-9f111cc54b5c	\N	4a7b4e33-d768-4b26-8e46-8fb83edc62c5	\N	8f6253f3-aa18-4df0-86db-ec395d092484	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 03:22:24.861264+00	2026-03-05 03:22:24.861264+00	\N	f
d881380b-bf98-4a60-ba3f-ae87eb8301ca	638535b9-f452-4817-86b3-899c56e3ba49	\N	4a7b4e33-d768-4b26-8e46-8fb83edc62c5	8f6253f3-aa18-4df0-86db-ec395d092484	8f6253f3-aa18-4df0-86db-ec395d092484	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 03:22:25.819226+00	2026-03-05 03:22:25.819226+00	\N	f
8ce296ae-151e-4543-aa2f-c4d4d16269b0	3fd185d2-959d-4ca4-aea8-a14893c4bf54	3fd185d2-959d-4ca4-aea8-a14893c4bf54	\N	a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 03:41:54.091911+00	2026-03-05 03:41:54.091911+00	\N	f
a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	33492144-594d-4495-907e-3f55e5173377	3fd185d2-959d-4ca4-aea8-a14893c4bf54	\N	\N	a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 03:41:53.081789+00	2026-03-05 03:41:55.773846+00	2026-03-05 03:41:55.773846+00	f
31f7af16-afad-4b00-ba64-27ae16f82c3b	33492144-594d-4495-907e-3f55e5173377	\N	af570e93-ec77-484e-a554-88503cec7824	\N	31f7af16-afad-4b00-ba64-27ae16f82c3b	group	Group test	Hello group	f	\N	2026-03-05 03:41:55.871782+00	2026-03-05 03:41:55.871782+00	\N	f
d50a216a-2620-49bc-b616-3b69cc3dfec0	5176ab32-17b3-4f7d-8432-2d93718a0bbf	be95d56c-09b5-4e0c-90ce-95da0726a1f0	\N	\N	d50a216a-2620-49bc-b616-3b69cc3dfec0	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 04:11:46.898961+00	2026-03-05 04:11:46.898961+00	\N	f
093535a7-7e5a-4723-b78f-c6ef9584ac7a	be95d56c-09b5-4e0c-90ce-95da0726a1f0	5176ab32-17b3-4f7d-8432-2d93718a0bbf	\N	\N	093535a7-7e5a-4723-b78f-c6ef9584ac7a	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 04:11:52.381356+00	2026-03-05 04:11:52.381356+00	\N	f
bb989259-63df-484f-b434-136a5822c30b	5176ab32-17b3-4f7d-8432-2d93718a0bbf	\N	cd4b59a3-88fb-43cc-b15e-4d6e539d87b8	\N	bb989259-63df-484f-b434-136a5822c30b	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 04:11:53.283279+00	2026-03-05 04:11:53.283279+00	\N	f
8c5770ee-0a09-4e58-8a75-7a26459f6485	be95d56c-09b5-4e0c-90ce-95da0726a1f0	\N	cd4b59a3-88fb-43cc-b15e-4d6e539d87b8	bb989259-63df-484f-b434-136a5822c30b	bb989259-63df-484f-b434-136a5822c30b	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 04:11:55.329407+00	2026-03-05 04:11:55.329407+00	\N	f
5059e4be-c78e-4197-80c7-76deedb5c912	b1425443-5811-46dc-8aa0-f3e82639a841	b1425443-5811-46dc-8aa0-f3e82639a841	\N	dd780ac0-7d23-471b-a642-0463e0852a9d	dd780ac0-7d23-471b-a642-0463e0852a9d	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 04:51:21.683055+00	2026-03-05 04:51:21.683055+00	\N	f
dd780ac0-7d23-471b-a642-0463e0852a9d	b7242813-979b-4dcd-a671-41214139a658	b1425443-5811-46dc-8aa0-f3e82639a841	\N	\N	dd780ac0-7d23-471b-a642-0463e0852a9d	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 04:51:21.125183+00	2026-03-05 04:51:22.978496+00	2026-03-05 04:51:22.978496+00	f
8b9d2d4b-be78-4a64-ad92-1bc661123087	b7242813-979b-4dcd-a671-41214139a658	\N	4d0157ef-ac9c-48a1-9a7f-03229e942e7e	\N	8b9d2d4b-be78-4a64-ad92-1bc661123087	group	Group test	Hello group	f	\N	2026-03-05 04:51:23.053348+00	2026-03-05 04:51:23.053348+00	\N	f
9bc8ffa4-621f-4e0b-8eea-ee9c85676a36	aa3a21e3-ae58-40a2-946c-2c5e799d0330	b54272d2-f5dd-46d4-9eb8-827754fe5c05	\N	\N	9bc8ffa4-621f-4e0b-8eea-ee9c85676a36	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 05:21:53.311001+00	2026-03-05 05:21:53.311001+00	\N	f
d286ebfd-7aae-4fda-b50f-8ec98c11fe2a	b54272d2-f5dd-46d4-9eb8-827754fe5c05	aa3a21e3-ae58-40a2-946c-2c5e799d0330	\N	\N	d286ebfd-7aae-4fda-b50f-8ec98c11fe2a	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 05:21:58.873676+00	2026-03-05 05:21:58.873676+00	\N	f
22cab9c1-fd20-43fc-ba06-28e80b522e05	aa3a21e3-ae58-40a2-946c-2c5e799d0330	\N	3bb88ee9-14e6-4937-9fed-2afa19f06694	\N	22cab9c1-fd20-43fc-ba06-28e80b522e05	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 05:22:03.058474+00	2026-03-05 05:22:03.058474+00	\N	f
84e6f95c-b30c-432b-8b73-9c5063a1fe68	b54272d2-f5dd-46d4-9eb8-827754fe5c05	\N	3bb88ee9-14e6-4937-9fed-2afa19f06694	22cab9c1-fd20-43fc-ba06-28e80b522e05	22cab9c1-fd20-43fc-ba06-28e80b522e05	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 05:22:03.76246+00	2026-03-05 05:22:03.76246+00	\N	f
09ac9c46-25a0-4e96-bdb6-a70cd8fc8014	97cd31e9-955d-490a-aff9-fdc556f28fb8	97cd31e9-955d-490a-aff9-fdc556f28fb8	\N	71302627-7f3c-4f5e-b766-6deaa6f0e2e3	71302627-7f3c-4f5e-b766-6deaa6f0e2e3	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 05:40:50.648538+00	2026-03-05 05:40:50.648538+00	\N	f
71302627-7f3c-4f5e-b766-6deaa6f0e2e3	bf15db20-5325-4d1d-891b-faed3c995d13	97cd31e9-955d-490a-aff9-fdc556f28fb8	\N	\N	71302627-7f3c-4f5e-b766-6deaa6f0e2e3	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 05:40:50.087965+00	2026-03-05 05:40:51.907198+00	2026-03-05 05:40:51.907198+00	f
cb049847-30fc-4434-a193-221bc75ded10	cdc85298-8764-4ff7-8acf-74ace40dd1d8	22960ac9-b138-4cbe-9083-0d90802591bb	\N	\N	cb049847-30fc-4434-a193-221bc75ded10	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 07:31:29.099078+00	2026-03-05 07:31:29.099078+00	\N	f
1b6fa25d-e778-48c9-935c-25f52ac9f114	22960ac9-b138-4cbe-9083-0d90802591bb	cdc85298-8764-4ff7-8acf-74ace40dd1d8	\N	\N	1b6fa25d-e778-48c9-935c-25f52ac9f114	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 07:31:34.599597+00	2026-03-05 07:31:34.599597+00	\N	f
3a2b0708-3734-4ff6-88b7-4dd5110aa59e	cdc85298-8764-4ff7-8acf-74ace40dd1d8	\N	40847639-a797-423f-add5-e491e1dc01ae	\N	3a2b0708-3734-4ff6-88b7-4dd5110aa59e	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 07:31:38.801012+00	2026-03-05 07:31:38.801012+00	\N	f
5bee6c1b-f918-4853-9e5c-9cbec5caea9f	22960ac9-b138-4cbe-9083-0d90802591bb	\N	40847639-a797-423f-add5-e491e1dc01ae	3a2b0708-3734-4ff6-88b7-4dd5110aa59e	3a2b0708-3734-4ff6-88b7-4dd5110aa59e	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 07:31:39.581005+00	2026-03-05 07:31:39.581005+00	\N	f
257a858c-63d3-4dad-b9e5-a153f77afa47	d8290673-93c3-421c-8914-4c2a0f83b12b	40d677cc-0352-4315-b8d8-162c66a9a00d	\N	\N	257a858c-63d3-4dad-b9e5-a153f77afa47	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 07:56:11.41772+00	2026-03-05 07:56:11.41772+00	\N	f
1cf0d837-c77a-452b-b7c7-ef71776e9ff6	40d677cc-0352-4315-b8d8-162c66a9a00d	d8290673-93c3-421c-8914-4c2a0f83b12b	\N	\N	1cf0d837-c77a-452b-b7c7-ef71776e9ff6	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 07:56:17.433212+00	2026-03-05 07:56:17.433212+00	\N	f
e202d7bc-fcae-4d77-9f0f-9c7157ff2a1f	d8290673-93c3-421c-8914-4c2a0f83b12b	\N	32e45b20-bd33-4732-a06d-bbbd557b4786	\N	e202d7bc-fcae-4d77-9f0f-9c7157ff2a1f	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 07:56:19.163284+00	2026-03-05 07:56:19.163284+00	\N	f
fe38d548-bf18-4923-aff2-d0a84b493c9c	40d677cc-0352-4315-b8d8-162c66a9a00d	\N	32e45b20-bd33-4732-a06d-bbbd557b4786	e202d7bc-fcae-4d77-9f0f-9c7157ff2a1f	e202d7bc-fcae-4d77-9f0f-9c7157ff2a1f	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 07:56:19.86758+00	2026-03-05 07:56:19.86758+00	\N	f
82d2301d-b426-4708-8018-e2f838f5d9c3	8701ce73-3f04-42af-8554-c72cb58a838f	4d16ff25-2bbd-4a06-a3fa-cee29ef9bceb	\N	\N	82d2301d-b426-4708-8018-e2f838f5d9c3	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 08:33:14.368371+00	2026-03-05 08:33:14.368371+00	\N	f
c1af941f-b0f8-438a-b4a3-8d31ecaa0ba6	4d16ff25-2bbd-4a06-a3fa-cee29ef9bceb	8701ce73-3f04-42af-8554-c72cb58a838f	\N	\N	c1af941f-b0f8-438a-b4a3-8d31ecaa0ba6	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 08:33:24.253308+00	2026-03-05 08:33:24.253308+00	\N	f
4241d033-5891-4d6e-9d37-66eb3be7b03e	8701ce73-3f04-42af-8554-c72cb58a838f	\N	f3fa2742-e263-4483-a044-18ba3374d6cc	\N	4241d033-5891-4d6e-9d37-66eb3be7b03e	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 08:33:29.289709+00	2026-03-05 08:33:29.289709+00	\N	f
d0e3a7f1-28e2-410d-83d8-21cccde68417	4d16ff25-2bbd-4a06-a3fa-cee29ef9bceb	\N	f3fa2742-e263-4483-a044-18ba3374d6cc	4241d033-5891-4d6e-9d37-66eb3be7b03e	4241d033-5891-4d6e-9d37-66eb3be7b03e	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 08:33:32.275147+00	2026-03-05 08:33:32.275147+00	\N	f
dcf30b9b-35ed-4b4a-a053-a54be4ed94a9	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	d036cfe7-b466-4a84-a850-759c5d6b1de1	\N	\N	dcf30b9b-35ed-4b4a-a053-a54be4ed94a9	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 09:01:42.706124+00	2026-03-05 09:01:42.706124+00	\N	f
c44b59f4-f6b1-4ef4-a91a-5c1f27a94c31	d036cfe7-b466-4a84-a850-759c5d6b1de1	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	\N	\N	c44b59f4-f6b1-4ef4-a91a-5c1f27a94c31	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 09:01:48.477908+00	2026-03-05 09:01:48.477908+00	\N	f
80efe739-e568-4ad5-88ae-a7ac43dc25ea	a5b28746-a9b7-4c7d-8fba-99ebdeb19a79	\N	8f290c65-1c6a-4a2d-95f6-e738e51e57b6	\N	80efe739-e568-4ad5-88ae-a7ac43dc25ea	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 09:01:51.159743+00	2026-03-05 09:01:51.159743+00	\N	f
df0db2e3-05b4-40e8-a347-2f808bc2d84f	d036cfe7-b466-4a84-a850-759c5d6b1de1	\N	8f290c65-1c6a-4a2d-95f6-e738e51e57b6	80efe739-e568-4ad5-88ae-a7ac43dc25ea	80efe739-e568-4ad5-88ae-a7ac43dc25ea	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 09:01:52.747804+00	2026-03-05 09:01:52.747804+00	\N	f
246080ca-1e10-4518-92a5-ada8b3631e14	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	3cbbf74d-0691-475e-98cc-8e3543607ac4	\N	\N	246080ca-1e10-4518-92a5-ada8b3631e14	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 09:40:15.016385+00	2026-03-05 09:40:15.016385+00	\N	f
c16061ee-156b-4adb-b06a-3a6e0f332002	3cbbf74d-0691-475e-98cc-8e3543607ac4	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	\N	\N	c16061ee-156b-4adb-b06a-3a6e0f332002	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 09:40:20.534152+00	2026-03-05 09:40:20.534152+00	\N	f
a4f809f3-1a10-46bf-ab10-0e22f9748428	c0b5e5c7-dd5e-45ca-a2c4-9681d35ec86b	\N	681dd38e-095d-4384-a4c9-991cf0ca0535	\N	a4f809f3-1a10-46bf-ab10-0e22f9748428	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 09:40:21.529921+00	2026-03-05 09:40:21.529921+00	\N	f
f9c5b324-3177-4df3-bbe6-893262729cfd	3cbbf74d-0691-475e-98cc-8e3543607ac4	\N	681dd38e-095d-4384-a4c9-991cf0ca0535	a4f809f3-1a10-46bf-ab10-0e22f9748428	a4f809f3-1a10-46bf-ab10-0e22f9748428	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 09:40:21.974967+00	2026-03-05 09:40:21.974967+00	\N	f
e94fca39-b4fb-49b1-88df-791b7a83ac28	6ea2b6ab-068a-4b40-8e5a-7d6b727abe75	6ea2b6ab-068a-4b40-8e5a-7d6b727abe75	\N	ea82dfb7-7b7a-4977-8815-51db8687a331	ea82dfb7-7b7a-4977-8815-51db8687a331	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 10:00:11.554767+00	2026-03-05 10:00:11.554767+00	\N	f
ea82dfb7-7b7a-4977-8815-51db8687a331	1607a2cd-396c-4191-bec7-85964e49b1b1	6ea2b6ab-068a-4b40-8e5a-7d6b727abe75	\N	\N	ea82dfb7-7b7a-4977-8815-51db8687a331	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 10:00:11.186057+00	2026-03-05 10:00:13.259682+00	2026-03-05 10:00:13.259682+00	f
2ba15001-8cd5-49fc-b6a3-4ec0abfff1f7	1607a2cd-396c-4191-bec7-85964e49b1b1	\N	ea6bdc12-56f8-4d9a-97a9-55efaa9d88df	\N	2ba15001-8cd5-49fc-b6a3-4ec0abfff1f7	group	Group test	Hello group	f	\N	2026-03-05 10:00:13.461311+00	2026-03-05 10:00:13.461311+00	\N	f
46cf4ed5-151c-401f-9e8a-edbaf2b0dc10	c50a2a26-686c-434a-86bb-828cb62f0ce0	da1311fc-11f8-4855-9561-9dabdbac9200	\N	\N	46cf4ed5-151c-401f-9e8a-edbaf2b0dc10	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 11:41:14.7413+00	2026-03-05 11:41:14.7413+00	\N	f
feb7718f-72e2-49e7-b00c-2d06dcbdf12d	da1311fc-11f8-4855-9561-9dabdbac9200	c50a2a26-686c-434a-86bb-828cb62f0ce0	\N	\N	feb7718f-72e2-49e7-b00c-2d06dcbdf12d	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 11:41:20.279887+00	2026-03-05 11:41:20.279887+00	\N	f
4e1c0b32-29cf-4a9f-a854-079501ab6cf9	c50a2a26-686c-434a-86bb-828cb62f0ce0	\N	f54dfd97-9e57-4620-8b5b-3b99dacaf5d6	\N	4e1c0b32-29cf-4a9f-a854-079501ab6cf9	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 11:41:21.263439+00	2026-03-05 11:41:21.263439+00	\N	f
79d1a576-5122-4306-ac74-31b1859c6100	da1311fc-11f8-4855-9561-9dabdbac9200	\N	f54dfd97-9e57-4620-8b5b-3b99dacaf5d6	4e1c0b32-29cf-4a9f-a854-079501ab6cf9	4e1c0b32-29cf-4a9f-a854-079501ab6cf9	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 11:41:21.937035+00	2026-03-05 11:41:21.937035+00	\N	f
56e1b0d5-5b88-42b1-a0d9-e562012b3636	3bb235ee-59d6-449b-b5a9-99e70614c7c2	421d247a-e0ed-469a-8d29-c77f6aad985b	\N	\N	56e1b0d5-5b88-42b1-a0d9-e562012b3636	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 15:28:30.006065+00	2026-03-05 15:28:30.006065+00	\N	f
ef1c86cb-862e-457e-b660-396f7700fb63	421d247a-e0ed-469a-8d29-c77f6aad985b	3bb235ee-59d6-449b-b5a9-99e70614c7c2	\N	\N	ef1c86cb-862e-457e-b660-396f7700fb63	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 15:28:35.841702+00	2026-03-05 15:28:35.841702+00	\N	f
154089c6-4bb2-4277-9eb7-3df1ba4e1b9b	3bb235ee-59d6-449b-b5a9-99e70614c7c2	\N	6c80e424-9326-4193-95d1-faecededa3e8	\N	154089c6-4bb2-4277-9eb7-3df1ba4e1b9b	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 15:28:40.771108+00	2026-03-05 15:28:40.771108+00	\N	f
f2753c2f-e6ce-4783-b4d0-558d987cc995	421d247a-e0ed-469a-8d29-c77f6aad985b	\N	6c80e424-9326-4193-95d1-faecededa3e8	154089c6-4bb2-4277-9eb7-3df1ba4e1b9b	154089c6-4bb2-4277-9eb7-3df1ba4e1b9b	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 15:28:42.008568+00	2026-03-05 15:28:42.008568+00	\N	f
b85865fd-b40f-424a-9eb4-0780e3236890	1710d986-f0af-4b91-97e0-e4c91a2e2f32	1710d986-f0af-4b91-97e0-e4c91a2e2f32	\N	a3e3078c-7062-4283-950a-761e1c30c780	a3e3078c-7062-4283-950a-761e1c30c780	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 15:50:07.361591+00	2026-03-05 15:50:07.361591+00	\N	f
a3e3078c-7062-4283-950a-761e1c30c780	2417489b-b5de-4777-8c7f-3e3337f21e8e	1710d986-f0af-4b91-97e0-e4c91a2e2f32	\N	\N	a3e3078c-7062-4283-950a-761e1c30c780	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 15:50:06.10334+00	2026-03-05 15:50:09.233461+00	2026-03-05 15:50:09.233461+00	f
3131d0d9-5c07-4e4e-b720-b83cb8ff2c70	2417489b-b5de-4777-8c7f-3e3337f21e8e	\N	e73de638-7d38-4153-bb89-5d361d333357	\N	3131d0d9-5c07-4e4e-b720-b83cb8ff2c70	group	Group test	Hello group	f	\N	2026-03-05 15:50:09.318482+00	2026-03-05 15:50:09.318482+00	\N	f
ba029a7c-520f-474d-9de5-ad93097e510f	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	55e16ca2-05bd-493e-acd1-462f5c03b526	\N	\N	ba029a7c-520f-474d-9de5-ad93097e510f	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-05 22:41:52.302377+00	2026-03-05 22:41:52.302377+00	\N	f
c08b2a7a-4f64-408f-80d1-e80e64b9d677	55e16ca2-05bd-493e-acd1-462f5c03b526	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	\N	\N	c08b2a7a-4f64-408f-80d1-e80e64b9d677	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-05 22:41:58.133268+00	2026-03-05 22:41:58.133268+00	\N	f
e1eb8d07-5182-4131-9fd8-802e018fc8e2	d2fbaf2f-41fd-42a9-a6e3-713fa45368c5	\N	e7d62c41-e474-414d-8ff0-67608454f6ec	\N	e1eb8d07-5182-4131-9fd8-802e018fc8e2	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-05 22:42:03.995597+00	2026-03-05 22:42:03.995597+00	\N	f
432f279d-f3a8-47bc-b418-eddc036d0029	55e16ca2-05bd-493e-acd1-462f5c03b526	\N	e7d62c41-e474-414d-8ff0-67608454f6ec	e1eb8d07-5182-4131-9fd8-802e018fc8e2	e1eb8d07-5182-4131-9fd8-802e018fc8e2	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-05 22:42:05.415424+00	2026-03-05 22:42:05.415424+00	\N	f
87d501a7-ecc9-4574-b3f0-7b56d2aea653	26bbe5d0-ec41-4b01-9a94-304ecaa89bcb	26bbe5d0-ec41-4b01-9a94-304ecaa89bcb	\N	bed250c3-2a45-4ce6-8bc4-0d8202bdb931	bed250c3-2a45-4ce6-8bc4-0d8202bdb931	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-05 23:02:51.153205+00	2026-03-05 23:02:51.153205+00	\N	f
bed250c3-2a45-4ce6-8bc4-0d8202bdb931	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	26bbe5d0-ec41-4b01-9a94-304ecaa89bcb	\N	\N	bed250c3-2a45-4ce6-8bc4-0d8202bdb931	direct	Social comp test	[Message recalled]	f	\N	2026-03-05 23:02:45.737241+00	2026-03-05 23:02:52.298971+00	2026-03-05 23:02:52.298971+00	f
588db39e-c707-47ef-9f5f-799df0f27ed0	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	\N	98d9c074-eef4-4ad4-aa28-c0756fca15a9	\N	588db39e-c707-47ef-9f5f-799df0f27ed0	group	Group test	Hello group	f	\N	2026-03-05 23:02:52.381665+00	2026-03-05 23:02:52.381665+00	\N	f
d1c11b6c-f185-4135-87d6-9ea86ef3b124	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	8ce64101-e018-4d06-badb-5b7f217509da	\N	\N	d1c11b6c-f185-4135-87d6-9ea86ef3b124	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-06 03:03:21.933572+00	2026-03-06 03:03:21.933572+00	\N	f
fe398194-bcf6-4823-89f3-3a0a34d6ba51	8ce64101-e018-4d06-badb-5b7f217509da	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	\N	\N	fe398194-bcf6-4823-89f3-3a0a34d6ba51	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-06 03:03:28.231512+00	2026-03-06 03:03:28.231512+00	\N	f
9e9dcdff-a4b0-4ec2-99c0-796e75611980	0c292f2a-c3a9-4851-a71d-c6f8dfa17b86	\N	7864af84-92bb-435f-afa6-8ed96bea71a7	\N	9e9dcdff-a4b0-4ec2-99c0-796e75611980	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-06 03:03:30.438655+00	2026-03-06 03:03:30.438655+00	\N	f
7e09532b-fbd6-4cb6-a161-ff2a71af2fd5	8ce64101-e018-4d06-badb-5b7f217509da	\N	7864af84-92bb-435f-afa6-8ed96bea71a7	9e9dcdff-a4b0-4ec2-99c0-796e75611980	9e9dcdff-a4b0-4ec2-99c0-796e75611980	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-06 03:03:32.647909+00	2026-03-06 03:03:32.647909+00	\N	f
464c9148-598b-4b43-9ba7-68ee8c192a5b	60515976-fbab-4363-86a9-74cb106440a0	60515976-fbab-4363-86a9-74cb106440a0	\N	361f0940-815b-4cd7-a3a9-64c49681c8fb	361f0940-815b-4cd7-a3a9-64c49681c8fb	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-06 03:29:01.145866+00	2026-03-06 03:29:01.145866+00	\N	f
361f0940-815b-4cd7-a3a9-64c49681c8fb	6dc8e69c-83b7-4f09-8681-11b4b736333b	60515976-fbab-4363-86a9-74cb106440a0	\N	\N	361f0940-815b-4cd7-a3a9-64c49681c8fb	direct	Social comp test	[Message recalled]	f	\N	2026-03-06 03:28:55.8519+00	2026-03-06 03:29:03.611657+00	2026-03-06 03:29:03.611657+00	f
6cf53d91-64b4-4ac8-81a9-feb33b8e7ba1	6dc8e69c-83b7-4f09-8681-11b4b736333b	\N	981fa4cf-9e24-4b93-9cf5-4aae50306bfa	\N	6cf53d91-64b4-4ac8-81a9-feb33b8e7ba1	group	Group test	Hello group	f	\N	2026-03-06 03:29:03.757416+00	2026-03-06 03:29:03.757416+00	\N	f
385cc11c-ba37-4114-831c-fdbd9a0edfa9	74fd4160-d207-47b4-87c2-e418ccf0462e	569413ba-a1c8-43fc-9f30-a0deafe7875d	\N	\N	385cc11c-ba37-4114-831c-fdbd9a0edfa9	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-06 05:24:13.823609+00	2026-03-06 05:24:13.823609+00	\N	f
fb077a6b-78b8-44f7-8afb-1abb8ecf9fef	569413ba-a1c8-43fc-9f30-a0deafe7875d	74fd4160-d207-47b4-87c2-e418ccf0462e	\N	\N	fb077a6b-78b8-44f7-8afb-1abb8ecf9fef	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-06 05:24:19.668354+00	2026-03-06 05:24:19.668354+00	\N	f
c553b7a9-9c9d-43d0-819d-3eedc4f367c3	74fd4160-d207-47b4-87c2-e418ccf0462e	\N	781c9953-9e6d-46c3-b47e-a3322f17aceb	\N	c553b7a9-9c9d-43d0-819d-3eedc4f367c3	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-06 05:24:25.156794+00	2026-03-06 05:24:25.156794+00	\N	f
f1668abe-3a9c-436a-a7d8-f73fc86aa3a6	569413ba-a1c8-43fc-9f30-a0deafe7875d	\N	781c9953-9e6d-46c3-b47e-a3322f17aceb	c553b7a9-9c9d-43d0-819d-3eedc4f367c3	c553b7a9-9c9d-43d0-819d-3eedc4f367c3	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-06 05:24:26.575006+00	2026-03-06 05:24:26.575006+00	\N	f
75e8f60f-d37f-4315-8a25-706aca93a23c	97eb7adb-663d-4565-860c-01fc0e5bd946	97eb7adb-663d-4565-860c-01fc0e5bd946	\N	5f32b585-6931-477d-8052-8075bfddc587	5f32b585-6931-477d-8052-8075bfddc587	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-06 05:49:16.538739+00	2026-03-06 05:49:16.538739+00	\N	f
5f32b585-6931-477d-8052-8075bfddc587	901955ea-f274-4ab7-8f4f-62cd5a143c8e	97eb7adb-663d-4565-860c-01fc0e5bd946	\N	\N	5f32b585-6931-477d-8052-8075bfddc587	direct	Social comp test	[Message recalled]	f	\N	2026-03-06 05:49:14.992007+00	2026-03-06 05:49:20.478654+00	2026-03-06 05:49:20.478654+00	f
e1d0a3bc-a84d-426d-8d0a-26541cbe4743	901955ea-f274-4ab7-8f4f-62cd5a143c8e	\N	674f0788-079c-4fd4-9415-1e9d1e7073f7	\N	e1d0a3bc-a84d-426d-8d0a-26541cbe4743	group	Group test	Hello group	f	\N	2026-03-06 05:49:20.68116+00	2026-03-06 05:49:20.68116+00	\N	f
5192497f-fd9f-4b51-a363-4c3ec2b396d2	ae6839bd-0c8a-4f8b-8785-c1b37880e158	3370312a-8076-4b39-b08a-d1c0815f45e8	\N	\N	5192497f-fd9f-4b51-a363-4c3ec2b396d2	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-11 00:31:27.790795+00	2026-03-11 00:31:27.790795+00	\N	f
736cf070-4a3e-4220-a1e7-43d426f23cdd	3370312a-8076-4b39-b08a-d1c0815f45e8	ae6839bd-0c8a-4f8b-8785-c1b37880e158	\N	\N	736cf070-4a3e-4220-a1e7-43d426f23cdd	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-11 00:31:33.208058+00	2026-03-11 00:31:33.208058+00	\N	f
e0643858-bad0-4dc1-993e-b7f0ce4b7f22	ae6839bd-0c8a-4f8b-8785-c1b37880e158	\N	384d9c18-8de3-43f2-a23c-30e0325cf737	\N	e0643858-bad0-4dc1-993e-b7f0ce4b7f22	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-11 00:31:33.745318+00	2026-03-11 00:31:33.745318+00	\N	f
344688a1-9d53-4564-9157-2c7fc807c082	3370312a-8076-4b39-b08a-d1c0815f45e8	\N	384d9c18-8de3-43f2-a23c-30e0325cf737	e0643858-bad0-4dc1-993e-b7f0ce4b7f22	e0643858-bad0-4dc1-993e-b7f0ce4b7f22	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-11 00:31:34.0991+00	2026-03-11 00:31:34.0991+00	\N	f
8e82a9e9-a165-456c-ae63-7454a940a22e	14376789-67ac-42f3-a841-e0bd06fc8478	14376789-67ac-42f3-a841-e0bd06fc8478	\N	e497ffe0-6f96-4713-a48a-9cea9b56eafe	e497ffe0-6f96-4713-a48a-9cea9b56eafe	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-11 01:57:41.705201+00	2026-03-11 01:57:41.705201+00	\N	f
e497ffe0-6f96-4713-a48a-9cea9b56eafe	4c097f4b-2253-4daf-92c2-425503b4610d	14376789-67ac-42f3-a841-e0bd06fc8478	\N	\N	e497ffe0-6f96-4713-a48a-9cea9b56eafe	direct	Social comp test	[Message recalled]	f	\N	2026-03-11 01:57:36.573859+00	2026-03-11 01:57:42.283581+00	2026-03-11 01:57:42.283581+00	f
69a70225-382e-43e3-811b-ed4ac8bf2f7d	4c097f4b-2253-4daf-92c2-425503b4610d	\N	b0acf733-7621-414b-b05b-96b7c0abd7e8	\N	69a70225-382e-43e3-811b-ed4ac8bf2f7d	group	Group test	Hello group	f	\N	2026-03-11 01:57:42.317728+00	2026-03-11 01:57:42.317728+00	\N	f
52016eca-5582-41f6-8a0e-e0ea0cac036c	e86ff6b9-ff9e-41f3-a60e-f1f9aa01c77c	491c69a3-3681-4da0-beac-053d9351c06a	\N	\N	52016eca-5582-41f6-8a0e-e0ea0cac036c	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-11 04:53:19.675646+00	2026-03-11 04:53:19.675646+00	\N	f
b069ea86-24e0-4ae5-b201-19f3c9f3e450	491c69a3-3681-4da0-beac-053d9351c06a	\N	7f454897-65c7-4528-bd15-00c853552122	\N	b069ea86-24e0-4ae5-b201-19f3c9f3e450	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-11 04:53:20.617306+00	2026-03-11 04:53:20.617306+00	\N	f
c4343109-6f1a-42e1-809a-26c0d3909114	e86ff6b9-ff9e-41f3-a60e-f1f9aa01c77c	\N	7f454897-65c7-4528-bd15-00c853552122	b069ea86-24e0-4ae5-b201-19f3c9f3e450	b069ea86-24e0-4ae5-b201-19f3c9f3e450	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-11 04:53:20.990014+00	2026-03-11 04:53:20.990014+00	\N	f
1251d165-612b-4793-9d48-e35935974df9	8b520915-07a2-496e-beef-ff4efe2bad9a	8b520915-07a2-496e-beef-ff4efe2bad9a	\N	f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-11 07:50:35.565834+00	2026-03-11 07:50:35.565834+00	\N	f
e90e7481-a08d-492c-8f81-84e816cbcdea	b94dcac3-58ee-4150-9ea2-1b3a0511503f	\N	64e61df8-6a79-4b46-9e03-97850dd85396	\N	e90e7481-a08d-492c-8f81-84e816cbcdea	group	Group test	Hello group	f	\N	2026-03-11 07:50:36.428126+00	2026-03-11 07:50:36.428126+00	\N	f
1e1a664a-dfb1-43d8-b7bb-2efa9d6b62cb	93771e12-8365-48bc-b031-039bc002ee02	93771e12-8365-48bc-b031-039bc002ee02	\N	c7dda769-dc77-438e-b78d-fb05d1ce60da	c7dda769-dc77-438e-b78d-fb05d1ce60da	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-11 00:59:38.890751+00	2026-03-11 00:59:38.890751+00	\N	f
c7dda769-dc77-438e-b78d-fb05d1ce60da	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	93771e12-8365-48bc-b031-039bc002ee02	\N	\N	c7dda769-dc77-438e-b78d-fb05d1ce60da	direct	Social comp test	[Message recalled]	f	\N	2026-03-11 00:59:33.649403+00	2026-03-11 00:59:39.552455+00	2026-03-11 00:59:39.552455+00	f
66d43d0e-2cab-45cb-b3b3-fad4604054bf	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	\N	df850a75-77d6-43c1-b7dc-d45c16b910de	\N	66d43d0e-2cab-45cb-b3b3-fad4604054bf	group	Group test	Hello group	f	\N	2026-03-11 00:59:39.588161+00	2026-03-11 00:59:39.588161+00	\N	f
f4a1690e-bd17-4293-90d6-a23cd558aa85	d52c170c-8356-4666-b7b7-4d0c772ae583	653ad0f3-d2b0-4a56-941e-256f958beab3	\N	\N	f4a1690e-bd17-4293-90d6-a23cd558aa85	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-11 03:01:38.594984+00	2026-03-11 03:01:38.594984+00	\N	f
d0014c58-b128-4b72-a84d-a3eb6e56648b	653ad0f3-d2b0-4a56-941e-256f958beab3	d52c170c-8356-4666-b7b7-4d0c772ae583	\N	\N	d0014c58-b128-4b72-a84d-a3eb6e56648b	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-11 03:01:44.028001+00	2026-03-11 03:01:44.028001+00	\N	f
1137fe8e-cba3-4c76-80ad-dbf64107dbc7	d52c170c-8356-4666-b7b7-4d0c772ae583	\N	f5481603-2adc-4930-a9f1-6557bfc34a4a	\N	1137fe8e-cba3-4c76-80ad-dbf64107dbc7	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-11 03:01:44.630576+00	2026-03-11 03:01:44.630576+00	\N	f
9b1c1a3d-d10b-483b-8fd2-a40d4ead3c72	653ad0f3-d2b0-4a56-941e-256f958beab3	\N	f5481603-2adc-4930-a9f1-6557bfc34a4a	1137fe8e-cba3-4c76-80ad-dbf64107dbc7	1137fe8e-cba3-4c76-80ad-dbf64107dbc7	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-11 03:01:44.9783+00	2026-03-11 03:01:44.9783+00	\N	f
46dc2750-e686-48e5-a368-f7c9335f2b39	f55f0686-e427-4a27-91fd-82c3e6e2ca2b	f55f0686-e427-4a27-91fd-82c3e6e2ca2b	\N	68a9b480-f613-468f-b27a-4a0479698964	68a9b480-f613-468f-b27a-4a0479698964	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-11 05:18:06.898639+00	2026-03-11 05:18:06.898639+00	\N	f
68a9b480-f613-468f-b27a-4a0479698964	7ef33402-3732-4116-abbb-462876f71dc8	f55f0686-e427-4a27-91fd-82c3e6e2ca2b	\N	\N	68a9b480-f613-468f-b27a-4a0479698964	direct	Social comp test	[Message recalled]	f	\N	2026-03-11 05:18:06.763355+00	2026-03-11 05:18:07.511442+00	2026-03-11 05:18:07.511442+00	f
4101a0e1-bc89-4ff5-a93c-2b9eec871cb3	7ef33402-3732-4116-abbb-462876f71dc8	\N	9021eb7a-26ca-44a7-859b-2cb0c5dc4f3f	\N	4101a0e1-bc89-4ff5-a93c-2b9eec871cb3	group	Group test	Hello group	f	\N	2026-03-11 05:18:07.547514+00	2026-03-11 05:18:07.547514+00	\N	f
3d3a31f6-acec-4320-af2e-43474f7ac2c0	f6e8e0bd-41cb-48eb-9587-43e14005f426	40ac61f7-4705-4c54-b839-ab971c2ebdaf	\N	\N	3d3a31f6-acec-4320-af2e-43474f7ac2c0	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-11 09:01:15.986647+00	2026-03-11 09:01:15.986647+00	\N	f
2698eb23-8c0f-42c2-862e-d6afb91e991f	40ac61f7-4705-4c54-b839-ab971c2ebdaf	f6e8e0bd-41cb-48eb-9587-43e14005f426	\N	\N	2698eb23-8c0f-42c2-862e-d6afb91e991f	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-11 09:01:21.468119+00	2026-03-11 09:01:21.468119+00	\N	f
f900a984-351f-4922-8d01-8bba599533e6	f6e8e0bd-41cb-48eb-9587-43e14005f426	\N	eb14e7a4-5a22-42cb-af0d-999f0648b207	\N	f900a984-351f-4922-8d01-8bba599533e6	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-11 09:01:25.156737+00	2026-03-11 09:01:25.156737+00	\N	f
bbd79905-5bb4-48fd-a678-042772286024	40ac61f7-4705-4c54-b839-ab971c2ebdaf	\N	eb14e7a4-5a22-42cb-af0d-999f0648b207	f900a984-351f-4922-8d01-8bba599533e6	f900a984-351f-4922-8d01-8bba599533e6	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-11 09:01:25.641944+00	2026-03-11 09:01:25.641944+00	\N	f
d32c8a9f-36bb-41f3-8c1e-1cbfad296575	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	cbe014df-8888-4f19-9d6a-51f3d00e146e	\N	\N	d32c8a9f-36bb-41f3-8c1e-1cbfad296575	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-11 01:27:44.362616+00	2026-03-11 01:27:44.362616+00	\N	f
ba3e8f0d-56cb-4385-9e15-ae57d425f8d0	c94af033-6227-4d49-a96a-19969e7416fc	c94af033-6227-4d49-a96a-19969e7416fc	\N	d280251e-ab1a-42c0-b029-5d7d471e3958	d280251e-ab1a-42c0-b029-5d7d471e3958	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-11 03:49:33.941314+00	2026-03-11 03:49:33.941314+00	\N	f
d280251e-ab1a-42c0-b029-5d7d471e3958	dce8c08d-efcf-4098-84b1-b149bdd351f1	c94af033-6227-4d49-a96a-19969e7416fc	\N	\N	d280251e-ab1a-42c0-b029-5d7d471e3958	direct	Social comp test	[Message recalled]	f	\N	2026-03-11 03:49:33.666136+00	2026-03-11 03:49:34.647271+00	2026-03-11 03:49:34.647271+00	f
cd8aee49-3018-4148-a809-d29dc515c1ad	dce8c08d-efcf-4098-84b1-b149bdd351f1	\N	8fdfc9e2-670c-44ec-9b96-191e177da5f6	\N	cd8aee49-3018-4148-a809-d29dc515c1ad	group	Group test	Hello group	f	\N	2026-03-11 03:49:34.682187+00	2026-03-11 03:49:34.682187+00	\N	f
8b15e1b7-343f-4fa9-a103-6a59bcdde208	d8f6ab86-5b6b-472c-b393-74632a4bc00a	1cdbfbb1-24ca-4be3-b2f0-b16ba448ab50	\N	\N	8b15e1b7-343f-4fa9-a103-6a59bcdde208	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-11 07:24:55.63073+00	2026-03-11 07:24:55.63073+00	\N	f
8ed8b50f-3d70-43d7-a136-89159d97f614	1cdbfbb1-24ca-4be3-b2f0-b16ba448ab50	d8f6ab86-5b6b-472c-b393-74632a4bc00a	\N	\N	8ed8b50f-3d70-43d7-a136-89159d97f614	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-11 07:25:01.186789+00	2026-03-11 07:25:01.186789+00	\N	f
b3d21e30-7869-47a7-a897-f147ee74a566	d8f6ab86-5b6b-472c-b393-74632a4bc00a	\N	828f01ee-2d56-411f-8e25-c0a5f70ddd61	\N	b3d21e30-7869-47a7-a897-f147ee74a566	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-11 07:25:02.110396+00	2026-03-11 07:25:02.110396+00	\N	f
7d33c946-2aa0-4d52-8445-33545363abca	1cdbfbb1-24ca-4be3-b2f0-b16ba448ab50	\N	828f01ee-2d56-411f-8e25-c0a5f70ddd61	b3d21e30-7869-47a7-a897-f147ee74a566	b3d21e30-7869-47a7-a897-f147ee74a566	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-11 07:25:04.090522+00	2026-03-11 07:25:04.090522+00	\N	f
5dda128d-84a5-45dd-9cb7-f25b6d07c184	2e3c6cfc-020e-44a3-a64b-c71f0e5f80d1	2e3c6cfc-020e-44a3-a64b-c71f0e5f80d1	\N	2b7b9354-13f3-447a-91ff-07c3e79fce1b	2b7b9354-13f3-447a-91ff-07c3e79fce1b	direct	Re: Social comp test	Reply from user2	f	\N	2026-03-11 09:28:22.565873+00	2026-03-11 09:28:22.565873+00	\N	f
2b7b9354-13f3-447a-91ff-07c3e79fce1b	d75eeb38-c50d-464e-811a-6bd92ba0cc01	2e3c6cfc-020e-44a3-a64b-c71f0e5f80d1	\N	\N	2b7b9354-13f3-447a-91ff-07c3e79fce1b	direct	Social comp test	[Message recalled]	f	\N	2026-03-11 09:28:22.39219+00	2026-03-11 09:28:23.326664+00	2026-03-11 09:28:23.326664+00	f
5865d3ea-ded4-4afa-ac57-fef243f3e2c0	d75eeb38-c50d-464e-811a-6bd92ba0cc01	\N	8da01162-cc34-4a33-8c3d-8fff21b8db0d	\N	5865d3ea-ded4-4afa-ac57-fef243f3e2c0	group	Group test	Hello group	f	\N	2026-03-11 09:28:23.361982+00	2026-03-11 09:28:23.361982+00	\N	f
9db1d46a-0a8a-495a-84d5-f4f60c2b0b27	cbe014df-8888-4f19-9d6a-51f3d00e146e	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	\N	\N	9db1d46a-0a8a-495a-84d5-f4f60c2b0b27	direct	Test P2P Reply	Hello User 1, this is a reply via HTTP/3	f	\N	2026-03-11 01:27:49.725649+00	2026-03-11 01:27:49.725649+00	\N	f
693e158c-8dc4-4b46-a57a-56e3ba3c41ea	5f8dd3e5-5a2f-4de1-97d7-f3a9da5a4a69	\N	5e0131bb-4bbe-4ab6-baf4-cc18418f947c	\N	693e158c-8dc4-4b46-a57a-56e3ba3c41ea	group	Group Chat Test	Hello group! This is a test message via HTTP/3	f	\N	2026-03-11 01:27:50.259257+00	2026-03-11 01:27:50.259257+00	\N	f
328e2f9b-0d85-4a3e-a265-e9ed47572308	cbe014df-8888-4f19-9d6a-51f3d00e146e	\N	5e0131bb-4bbe-4ab6-baf4-cc18418f947c	693e158c-8dc4-4b46-a57a-56e3ba3c41ea	693e158c-8dc4-4b46-a57a-56e3ba3c41ea	group	Re: Group Chat Test	This is a WhatsApp-style reply to the previous message!	f	\N	2026-03-11 01:27:50.603382+00	2026-03-11 01:27:50.603382+00	\N	f
a6f674ce-0b2f-438d-9d9b-d605bd7be8a9	491c69a3-3681-4da0-beac-053d9351c06a	e86ff6b9-ff9e-41f3-a60e-f1f9aa01c77c	\N	\N	a6f674ce-0b2f-438d-9d9b-d605bd7be8a9	direct	Test P2P Message	Hello User 2, this is a test message via HTTP/2	f	\N	2026-03-11 04:53:06.995748+00	2026-03-11 04:53:06.995748+00	\N	f
f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	b94dcac3-58ee-4150-9ea2-1b3a0511503f	8b520915-07a2-496e-beef-ff4efe2bad9a	\N	\N	f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	direct	Social comp test	[Message recalled]	f	\N	2026-03-11 07:50:35.164601+00	2026-03-11 07:50:36.362554+00	2026-03-11 07:50:36.362554+00	f
\.


--
-- Data for Name: user_archived_threads; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.user_archived_threads (id, user_id, thread_id, archived_at) FROM stdin;
fe1cc5b0-28c4-42f3-bd09-5943ca9b4d5c	0bb95722-b093-40a6-9b25-117da85f3648	97bc7b46-65e9-4209-9ae1-5da2e0de3876	2026-02-28 10:58:04.211015+00
3098a7f5-5da8-45ef-b739-c8201974a4cc	1ff91ffb-48bf-4604-913a-9280bd491bee	5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	2026-03-01 05:06:27.677789+00
31896012-17a7-4aae-9d7f-472019fec16c	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	cda32066-b0f7-4fbe-8fad-4b9d9817669e	2026-03-01 09:55:48.103135+00
80101367-cbad-4354-a97c-345177ff2fd4	329c9336-72d8-4a5c-9246-629fa24930df	ed46adfb-e2ff-4cec-a497-0a01af0f534b	2026-03-01 22:45:29.374734+00
419be783-9453-4c03-a534-0152f8b43d61	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	2026-03-02 01:47:02.477139+00
d125439e-cdbe-434b-9c4b-c33923a86695	2830f9b0-2aec-459c-9893-8a4b993c3262	95a8ef9a-064a-4b96-b838-32a790bafeba	2026-03-02 10:41:15.715834+00
bbaeeb4a-8eed-4eca-9ff7-e12f013f7b47	0d58e6b5-eb5a-4976-bae0-2f459280932a	86b50d98-5e38-44e9-9f0f-38fda1dc138b	2026-03-02 13:37:27.287747+00
74f8ddb1-1b55-4c8e-8a76-8cae65ec4f38	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	46fb8c80-8f96-491d-8564-58902f7e19ee	2026-03-02 14:44:43.88362+00
ed1c63fe-8cfe-40fd-8277-406c3156da8c	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	10ea2568-990c-4bed-b775-ffdf5aa40878	2026-03-02 15:49:32.798583+00
069388af-ef31-4f63-b765-1dd8d1e1b7c3	37a27965-d80a-4c0d-884b-3d6468ec7399	a736e585-0d91-411b-a9df-df8677402b71	2026-03-02 20:57:58.465221+00
4839a635-ce7d-4e56-af8c-d86091591d05	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	b8f13129-6b86-4f32-8a01-5aaf18f339d7	2026-03-03 01:21:10.884486+00
58256541-8731-4ad7-a829-aa3ad67d5831	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	9d87aa39-1eb2-44da-a281-35dc0194480a	2026-03-03 04:11:07.246124+00
45455626-9c9c-4ac0-ad2a-9680d1c7a9c1	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	09b0152d-7c6e-4d71-9473-6327a7db274f	2026-03-03 05:44:51.858129+00
d7bf651a-462d-44fb-a5d6-b7ebf707caed	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	def8944c-966e-4df0-b0df-fe1988033609	2026-03-03 06:49:37.037019+00
23f60d85-d60c-4343-a7df-5875f5b2c00c	debcc6b7-cd08-43c0-8e62-f8764488d87d	f6d5aeb0-08cb-4300-8d0b-8603249dac39	2026-03-03 20:38:55.21996+00
0ad28f48-662b-49f0-bb8a-9ed143dc361a	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	58ffa13f-91b1-4116-9e6f-10b2d868ab9e	2026-03-04 16:41:38.908303+00
1226d55c-cd2b-49ce-a2b2-94122de0e5e7	96785040-a129-40cb-aef4-f9ae99cc8c37	28bf71e9-d9fe-4e89-93a3-36a442c90ebf	2026-03-04 23:38:32.310403+00
0d759a52-e9e2-490a-a414-f6021469ef04	ae839a91-35eb-4008-9621-a4244b364932	750b2d88-6a64-42d1-9286-58b50e91f457	2026-03-05 02:36:17.501055+00
0811f127-2c07-4160-aad3-e110b1ca27a0	33492144-594d-4495-907e-3f55e5173377	a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	2026-03-05 03:41:54.371961+00
19fb03a3-4641-4599-a84d-3e8d1cdca098	b7242813-979b-4dcd-a671-41214139a658	dd780ac0-7d23-471b-a642-0463e0852a9d	2026-03-05 04:51:21.943019+00
4e772212-b7f0-43ce-b5a7-1f428ff64924	bf15db20-5325-4d1d-891b-faed3c995d13	71302627-7f3c-4f5e-b766-6deaa6f0e2e3	2026-03-05 05:40:50.837471+00
8783bd3f-09da-49f8-8c97-19dc396e223d	1607a2cd-396c-4191-bec7-85964e49b1b1	ea82dfb7-7b7a-4977-8815-51db8687a331	2026-03-05 10:00:11.81781+00
844bc83d-62c4-42cc-adbd-f9f856a56843	2417489b-b5de-4777-8c7f-3e3337f21e8e	a3e3078c-7062-4283-950a-761e1c30c780	2026-03-05 15:50:07.668863+00
194918a1-92dc-4292-aeb2-a72c86d495a7	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	bed250c3-2a45-4ce6-8bc4-0d8202bdb931	2026-03-05 23:02:51.337492+00
e9f3b767-52cd-46e2-9321-6e3660fae067	6dc8e69c-83b7-4f09-8681-11b4b736333b	361f0940-815b-4cd7-a3a9-64c49681c8fb	2026-03-06 03:29:01.32482+00
e8c74553-f991-403e-b706-2bdc797b0bbf	901955ea-f274-4ab7-8f4f-62cd5a143c8e	5f32b585-6931-477d-8052-8075bfddc587	2026-03-06 05:49:16.937136+00
98da4520-a5d3-483b-8bd4-60ebbfc152d6	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	c7dda769-dc77-438e-b78d-fb05d1ce60da	2026-03-11 00:59:38.985538+00
303f5007-2704-4f61-849b-97741bf8cf2e	4c097f4b-2253-4daf-92c2-425503b4610d	e497ffe0-6f96-4713-a48a-9cea9b56eafe	2026-03-11 01:57:41.787535+00
01d4cec5-2349-405e-a8fc-6426be64f69c	dce8c08d-efcf-4098-84b1-b149bdd351f1	d280251e-ab1a-42c0-b029-5d7d471e3958	2026-03-11 03:49:34.015204+00
69a2d897-61a1-4cc8-b719-0af5f924255c	7ef33402-3732-4116-abbb-462876f71dc8	68a9b480-f613-468f-b27a-4a0479698964	2026-03-11 05:18:06.975534+00
b11161e6-2bef-47e0-a2ac-24282120817e	b94dcac3-58ee-4150-9ea2-1b3a0511503f	f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	2026-03-11 07:50:35.678609+00
bdbb696c-5cf1-40d9-a7e1-7424b5813b4b	d75eeb38-c50d-464e-811a-6bd92ba0cc01	2b7b9354-13f3-447a-91ff-07c3e79fce1b	2026-03-11 09:28:22.673183+00
\.


--
-- Data for Name: user_deleted_threads; Type: TABLE DATA; Schema: messages; Owner: -
--

COPY messages.user_deleted_threads (id, user_id, thread_id, deleted_at) FROM stdin;
8add7638-9d4b-44b5-b400-8798d2f178a0	0bb95722-b093-40a6-9b25-117da85f3648	97bc7b46-65e9-4209-9ae1-5da2e0de3876	2026-02-28 10:58:04.601515+00
9da3fc36-1521-46f7-888a-de3a9e86c3fd	1ff91ffb-48bf-4604-913a-9280bd491bee	5899d234-d6bf-4c4e-b8ff-e55d0903c2f6	2026-03-01 05:06:27.807672+00
791d68e4-6ac4-494d-9a25-e38de71b2135	ceb551fc-8b87-4e58-8abe-9f241bc4d4bd	cda32066-b0f7-4fbe-8fad-4b9d9817669e	2026-03-01 09:55:48.588063+00
a0fd7fee-a1b6-4403-9059-1dd032b8288a	329c9336-72d8-4a5c-9246-629fa24930df	ed46adfb-e2ff-4cec-a497-0a01af0f534b	2026-03-01 22:45:29.566159+00
d6449bc6-a9fa-4c2f-9ea7-4655cea2b49c	27c4aaf6-eb00-4c5f-921e-973f52c3ed1b	735d6e9b-b6a2-4cb4-9c18-c3bf4125cba9	2026-03-02 01:47:02.620659+00
326da250-a4e9-42ab-9cca-0399ea56cab9	2830f9b0-2aec-459c-9893-8a4b993c3262	95a8ef9a-064a-4b96-b838-32a790bafeba	2026-03-02 10:41:15.839634+00
64adb94f-8267-4026-a489-fe684e796acc	0d58e6b5-eb5a-4976-bae0-2f459280932a	86b50d98-5e38-44e9-9f0f-38fda1dc138b	2026-03-02 13:37:27.410687+00
0a8e5d53-fd27-4b5a-8372-feac1903c753	6d977a32-7f8c-4e73-9d4e-7fa9f1df9eb6	46fb8c80-8f96-491d-8564-58902f7e19ee	2026-03-02 14:44:45.494404+00
a13991eb-a8f2-42ea-86da-8f22dddcdd3c	55781315-bdf1-4e5f-8dba-1f0eb8bdf712	10ea2568-990c-4bed-b775-ffdf5aa40878	2026-03-02 15:49:32.957874+00
9ff7df7c-9bff-4d96-998d-c4fd215f45fd	37a27965-d80a-4c0d-884b-3d6468ec7399	a736e585-0d91-411b-a9df-df8677402b71	2026-03-02 20:57:58.599015+00
0ceade85-7253-4037-ae08-6ebddd8613c7	2fe68c90-93a0-423f-9ed9-5f08ba8281bf	b8f13129-6b86-4f32-8a01-5aaf18f339d7	2026-03-03 01:21:11.052313+00
8ddfceb0-e053-4c4e-8dbc-c624ae60a238	e5b15617-7957-4e1e-9ad0-9bbe5c87bbe8	9d87aa39-1eb2-44da-a281-35dc0194480a	2026-03-03 04:11:07.390074+00
f3abe1af-af73-4859-ad70-30053055fe6f	0616ddbb-6dd5-4e3e-82f4-3e02e6ff0133	09b0152d-7c6e-4d71-9473-6327a7db274f	2026-03-03 05:44:51.998163+00
c8619edc-88d7-4ec5-898e-1dae3ba67213	7e8c249b-5d5f-40dd-9db4-07e3d8f5241b	def8944c-966e-4df0-b0df-fe1988033609	2026-03-03 06:49:37.18662+00
67e1a773-8a12-431e-9798-3b6da60986c3	debcc6b7-cd08-43c0-8e62-f8764488d87d	f6d5aeb0-08cb-4300-8d0b-8603249dac39	2026-03-03 20:38:55.514785+00
93e673ce-e5ad-4b04-952a-472c8b97eb82	62d1acda-d845-4137-8aaa-7b43d8a8ad1f	58ffa13f-91b1-4116-9e6f-10b2d868ab9e	2026-03-04 16:41:39.08818+00
c08b0f7b-96a9-4eb1-b8a0-508511fb802f	96785040-a129-40cb-aef4-f9ae99cc8c37	28bf71e9-d9fe-4e89-93a3-36a442c90ebf	2026-03-04 23:38:32.474779+00
17873175-87a0-45d7-be57-3617f47d54c4	ae839a91-35eb-4008-9621-a4244b364932	750b2d88-6a64-42d1-9286-58b50e91f457	2026-03-05 02:36:17.824307+00
c9a50046-bc6f-406e-ab1d-ac5d01faa0dc	33492144-594d-4495-907e-3f55e5173377	a66e9eef-597a-4a2c-bb5a-b0aa2eb14530	2026-03-05 03:41:54.57357+00
1fb03d1e-f797-47d9-b151-3f9477ce6682	b7242813-979b-4dcd-a671-41214139a658	dd780ac0-7d23-471b-a642-0463e0852a9d	2026-03-05 04:51:22.098296+00
129f4a67-1d99-4acf-ba02-00d83bd35e97	bf15db20-5325-4d1d-891b-faed3c995d13	71302627-7f3c-4f5e-b766-6deaa6f0e2e3	2026-03-05 05:40:51.007492+00
91c95ca0-774f-40f7-8eaf-d8abcac04b09	1607a2cd-396c-4191-bec7-85964e49b1b1	ea82dfb7-7b7a-4977-8815-51db8687a331	2026-03-05 10:00:12.149232+00
4aaccb38-9a4c-41b7-beed-6e2d2def2690	2417489b-b5de-4777-8c7f-3e3337f21e8e	a3e3078c-7062-4283-950a-761e1c30c780	2026-03-05 15:50:07.849209+00
761717e4-6e52-41a7-9a15-b46f8f3646a1	58f2afea-3e17-4b13-ac0b-c9e2777b11a4	bed250c3-2a45-4ce6-8bc4-0d8202bdb931	2026-03-05 23:02:51.492129+00
adbeee68-8e00-422e-a32e-09d43a8cfc19	6dc8e69c-83b7-4f09-8681-11b4b736333b	361f0940-815b-4cd7-a3a9-64c49681c8fb	2026-03-06 03:29:01.486877+00
1605c050-637f-4566-be64-647ece1f95e5	901955ea-f274-4ab7-8f4f-62cd5a143c8e	5f32b585-6931-477d-8052-8075bfddc587	2026-03-06 05:49:17.130066+00
a2669ac3-3bea-4c82-b6c2-fe6a0b288303	42e98d38-3f3b-4ddc-9951-fe1d0c664a03	c7dda769-dc77-438e-b78d-fb05d1ce60da	2026-03-11 00:59:39.111361+00
915478f6-7f83-49d8-8f5b-acc3fd00f4a0	4c097f4b-2253-4daf-92c2-425503b4610d	e497ffe0-6f96-4713-a48a-9cea9b56eafe	2026-03-11 01:57:41.862768+00
ce31f906-6ae5-4d1a-87e4-7a86e128783d	dce8c08d-efcf-4098-84b1-b149bdd351f1	d280251e-ab1a-42c0-b029-5d7d471e3958	2026-03-11 03:49:34.181894+00
acc2a779-da3a-4ec6-ad80-ce820f5ea3bb	7ef33402-3732-4116-abbb-462876f71dc8	68a9b480-f613-468f-b27a-4a0479698964	2026-03-11 05:18:07.04647+00
846868b6-34d1-4bed-9234-9b3b9e9a0d95	b94dcac3-58ee-4150-9ea2-1b3a0511503f	f6e3bd03-eaa2-4b71-81fe-73dd254ff9c2	2026-03-11 07:50:35.81269+00
e66f0b0f-a3f4-4147-9d27-b75e9b922e32	d75eeb38-c50d-464e-811a-6bd92ba0cc01	2b7b9354-13f3-447a-91ff-07c3e79fce1b	2026-03-11 09:28:22.770112+00
\.


--
-- Name: comment_attachments comment_attachments_pkey; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comment_attachments
    ADD CONSTRAINT comment_attachments_pkey PRIMARY KEY (id);


--
-- Name: comment_votes comment_votes_comment_id_user_id_key; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comment_votes
    ADD CONSTRAINT comment_votes_comment_id_user_id_key UNIQUE (comment_id, user_id);


--
-- Name: comment_votes comment_votes_pkey; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comment_votes
    ADD CONSTRAINT comment_votes_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: post_attachments post_attachments_pkey; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.post_attachments
    ADD CONSTRAINT post_attachments_pkey PRIMARY KEY (id);


--
-- Name: post_votes post_votes_pkey; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.post_votes
    ADD CONSTRAINT post_votes_pkey PRIMARY KEY (id);


--
-- Name: post_votes post_votes_post_id_user_id_key; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.post_votes
    ADD CONSTRAINT post_votes_post_id_user_id_key UNIQUE (post_id, user_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: group_bans group_bans_group_id_user_id_key; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.group_bans
    ADD CONSTRAINT group_bans_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: group_bans group_bans_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.group_bans
    ADD CONSTRAINT group_bans_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_group_id_user_id_key; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.group_members
    ADD CONSTRAINT group_members_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: message_attachments message_attachments_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.message_attachments
    ADD CONSTRAINT message_attachments_pkey PRIMARY KEY (id);


--
-- Name: message_reads message_reads_message_id_user_id_key; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.message_reads
    ADD CONSTRAINT message_reads_message_id_user_id_key UNIQUE (message_id, user_id);


--
-- Name: message_reads message_reads_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.message_reads
    ADD CONSTRAINT message_reads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: user_archived_threads user_archived_threads_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.user_archived_threads
    ADD CONSTRAINT user_archived_threads_pkey PRIMARY KEY (id);


--
-- Name: user_archived_threads user_archived_threads_user_id_thread_id_key; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.user_archived_threads
    ADD CONSTRAINT user_archived_threads_user_id_thread_id_key UNIQUE (user_id, thread_id);


--
-- Name: user_deleted_threads user_deleted_threads_pkey; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.user_deleted_threads
    ADD CONSTRAINT user_deleted_threads_pkey PRIMARY KEY (id);


--
-- Name: user_deleted_threads user_deleted_threads_user_id_thread_id_key; Type: CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.user_deleted_threads
    ADD CONSTRAINT user_deleted_threads_user_id_thread_id_key UNIQUE (user_id, thread_id);


--
-- Name: idx_comment_attachments_comment_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comment_attachments_comment_id ON forum.comment_attachments USING btree (comment_id);


--
-- Name: idx_comment_attachments_display_order; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comment_attachments_display_order ON forum.comment_attachments USING btree (comment_id, display_order);


--
-- Name: idx_comment_attachments_file_type; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comment_attachments_file_type ON forum.comment_attachments USING btree (file_type);


--
-- Name: idx_comment_votes_comment_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comment_votes_comment_id ON forum.comment_votes USING btree (comment_id);


--
-- Name: idx_comment_votes_user_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comment_votes_user_id ON forum.comment_votes USING btree (user_id);


--
-- Name: idx_comments_created_at; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comments_created_at ON forum.comments USING btree (created_at DESC);


--
-- Name: idx_comments_parent_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comments_parent_id ON forum.comments USING btree (parent_id);


--
-- Name: idx_comments_post_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comments_post_id ON forum.comments USING btree (post_id);


--
-- Name: idx_comments_user_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_comments_user_id ON forum.comments USING btree (user_id);


--
-- Name: idx_forum_posts_created; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_forum_posts_created ON forum.posts USING btree (created_at DESC, flair);


--
-- Name: idx_forum_posts_user_created; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_forum_posts_user_created ON forum.posts USING btree (user_id, created_at DESC);


--
-- Name: idx_post_attachments_display_order; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_post_attachments_display_order ON forum.post_attachments USING btree (post_id, display_order);


--
-- Name: idx_post_attachments_file_type; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_post_attachments_file_type ON forum.post_attachments USING btree (file_type);


--
-- Name: idx_post_attachments_post_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_post_attachments_post_id ON forum.post_attachments USING btree (post_id);


--
-- Name: idx_post_votes_post_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_post_votes_post_id ON forum.post_votes USING btree (post_id);


--
-- Name: idx_post_votes_user_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_post_votes_user_id ON forum.post_votes USING btree (user_id);


--
-- Name: idx_posts_content_trgm; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_content_trgm ON forum.posts USING gin (content public.gin_trgm_ops);


--
-- Name: idx_posts_created_at; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_created_at ON forum.posts USING btree (created_at DESC);


--
-- Name: idx_posts_flair; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_flair ON forum.posts USING btree (flair);


--
-- Name: idx_posts_pinned_created; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_pinned_created ON forum.posts USING btree (is_pinned DESC, created_at DESC);


--
-- Name: idx_posts_title_trgm; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_title_trgm ON forum.posts USING gin (title public.gin_trgm_ops);


--
-- Name: idx_posts_upload_type; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_upload_type ON forum.posts USING btree (upload_type);


--
-- Name: idx_posts_upvotes_created; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_upvotes_created ON forum.posts USING btree (upvotes DESC, created_at DESC);


--
-- Name: idx_posts_user_id; Type: INDEX; Schema: forum; Owner: -
--

CREATE INDEX idx_posts_user_id ON forum.posts USING btree (user_id);


--
-- Name: idx_group_bans_expires; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_group_bans_expires ON messages.group_bans USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_group_bans_group; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_group_bans_group ON messages.group_bans USING btree (group_id);


--
-- Name: idx_group_bans_user; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_group_bans_user ON messages.group_bans USING btree (user_id);


--
-- Name: idx_group_members_group_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_group_members_group_id ON messages.group_members USING btree (group_id);


--
-- Name: idx_group_members_left; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_group_members_left ON messages.group_members USING btree (group_id, left_at) WHERE (left_at IS NULL);


--
-- Name: idx_group_members_user_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_group_members_user_id ON messages.group_members USING btree (user_id);


--
-- Name: idx_groups_archived; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_groups_archived ON messages.groups USING btree (archived) WHERE (archived = true);


--
-- Name: idx_groups_created_at; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_groups_created_at ON messages.groups USING btree (created_at DESC);


--
-- Name: idx_groups_created_by; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_groups_created_by ON messages.groups USING btree (created_by);


--
-- Name: idx_message_attachments_display_order; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_attachments_display_order ON messages.message_attachments USING btree (message_id, display_order);


--
-- Name: idx_message_attachments_file_type; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_attachments_file_type ON messages.message_attachments USING btree (file_type);


--
-- Name: idx_message_attachments_message_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_attachments_message_id ON messages.message_attachments USING btree (message_id);


--
-- Name: idx_message_reads_message_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_reads_message_id ON messages.message_reads USING btree (message_id);


--
-- Name: idx_message_reads_read_at; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_reads_read_at ON messages.message_reads USING btree (read_at DESC);


--
-- Name: idx_message_reads_read_by_sender; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_reads_read_by_sender ON messages.message_reads USING btree (read_by_sender) WHERE (read_by_sender = true);


--
-- Name: idx_message_reads_user_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_reads_user_id ON messages.message_reads USING btree (user_id);


--
-- Name: idx_message_reads_user_read_at; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_message_reads_user_read_at ON messages.message_reads USING btree (user_id, read_at DESC);


--
-- Name: idx_messages_active_sender; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_active_sender ON messages.messages USING btree (sender_id, created_at DESC);


--
-- Name: idx_messages_archived; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_archived ON messages.messages USING btree (archived) WHERE (archived = true);


--
-- Name: idx_messages_content_trgm; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_content_trgm ON messages.messages USING gin (content public.gin_trgm_ops);


--
-- Name: idx_messages_created_at; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_created_at ON messages.messages USING btree (created_at DESC);


--
-- Name: idx_messages_group_created; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_group_created ON messages.messages USING btree (group_id, created_at DESC) WHERE (group_id IS NOT NULL);


--
-- Name: idx_messages_group_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_group_id ON messages.messages USING btree (group_id);


--
-- Name: idx_messages_is_read_created; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_is_read_created ON messages.messages USING btree (is_read, created_at DESC) WHERE (recipient_id IS NOT NULL);


--
-- Name: idx_messages_parent_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_parent_id ON messages.messages USING btree (parent_message_id);


--
-- Name: idx_messages_read_recipient; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_read_recipient ON messages.messages USING btree (is_read, recipient_id) WHERE (recipient_id IS NOT NULL);


--
-- Name: idx_messages_recalled; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_recalled ON messages.messages USING btree (recalled_at) WHERE (recalled_at IS NOT NULL);


--
-- Name: idx_messages_recipient_created; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_recipient_created ON messages.messages USING btree (recipient_id, created_at DESC) WHERE (recipient_id IS NOT NULL);


--
-- Name: idx_messages_recipient_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_recipient_id ON messages.messages USING btree (recipient_id);


--
-- Name: idx_messages_sender_created; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_sender_created ON messages.messages USING btree (sender_id, created_at DESC);


--
-- Name: idx_messages_sender_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_sender_id ON messages.messages USING btree (sender_id);


--
-- Name: idx_messages_subject_trgm; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_subject_trgm ON messages.messages USING gin (subject public.gin_trgm_ops);


--
-- Name: idx_messages_thread_id; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_thread_id ON messages.messages USING btree (thread_id);


--
-- Name: idx_messages_unread_inbox; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_messages_unread_inbox ON messages.messages USING btree (recipient_id, is_read, created_at DESC) WHERE ((recipient_id IS NOT NULL) AND (is_read = false));


--
-- Name: idx_user_archived_threads_thread; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_user_archived_threads_thread ON messages.user_archived_threads USING btree (thread_id);


--
-- Name: idx_user_archived_threads_user; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_user_archived_threads_user ON messages.user_archived_threads USING btree (user_id);


--
-- Name: idx_user_deleted_threads_thread; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_user_deleted_threads_thread ON messages.user_deleted_threads USING btree (thread_id);


--
-- Name: idx_user_deleted_threads_user; Type: INDEX; Schema: messages; Owner: -
--

CREATE INDEX idx_user_deleted_threads_user ON messages.user_deleted_threads USING btree (user_id);


--
-- Name: comment_votes trg_comment_votes_update; Type: TRIGGER; Schema: forum; Owner: -
--

CREATE TRIGGER trg_comment_votes_update AFTER INSERT OR DELETE OR UPDATE ON forum.comment_votes FOR EACH ROW EXECUTE FUNCTION forum.update_comment_votes();


--
-- Name: comments trg_comments_count; Type: TRIGGER; Schema: forum; Owner: -
--

CREATE TRIGGER trg_comments_count AFTER INSERT OR DELETE ON forum.comments FOR EACH ROW EXECUTE FUNCTION forum.update_comment_count();


--
-- Name: comments trg_comments_touch; Type: TRIGGER; Schema: forum; Owner: -
--

CREATE TRIGGER trg_comments_touch BEFORE UPDATE ON forum.comments FOR EACH ROW EXECUTE FUNCTION forum.touch_updated_at();


--
-- Name: post_votes trg_post_votes_update; Type: TRIGGER; Schema: forum; Owner: -
--

CREATE TRIGGER trg_post_votes_update AFTER INSERT OR DELETE OR UPDATE ON forum.post_votes FOR EACH ROW EXECUTE FUNCTION forum.update_post_votes();


--
-- Name: posts trg_posts_touch; Type: TRIGGER; Schema: forum; Owner: -
--

CREATE TRIGGER trg_posts_touch BEFORE UPDATE ON forum.posts FOR EACH ROW EXECUTE FUNCTION forum.touch_updated_at();


--
-- Name: groups trg_groups_touch; Type: TRIGGER; Schema: messages; Owner: -
--

CREATE TRIGGER trg_groups_touch BEFORE UPDATE ON messages.groups FOR EACH ROW EXECUTE FUNCTION messages.touch_updated_at();


--
-- Name: message_reads trg_message_reads_update; Type: TRIGGER; Schema: messages; Owner: -
--

CREATE TRIGGER trg_message_reads_update AFTER INSERT ON messages.message_reads FOR EACH ROW EXECUTE FUNCTION messages.update_message_read();


--
-- Name: messages trg_messages_thread_id; Type: TRIGGER; Schema: messages; Owner: -
--

CREATE TRIGGER trg_messages_thread_id BEFORE INSERT ON messages.messages FOR EACH ROW EXECUTE FUNCTION messages.set_thread_id();


--
-- Name: messages trg_messages_touch; Type: TRIGGER; Schema: messages; Owner: -
--

CREATE TRIGGER trg_messages_touch BEFORE UPDATE ON messages.messages FOR EACH ROW EXECUTE FUNCTION messages.touch_updated_at();


--
-- Name: comment_attachments comment_attachments_comment_id_fkey; Type: FK CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comment_attachments
    ADD CONSTRAINT comment_attachments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES forum.comments(id) ON DELETE CASCADE;


--
-- Name: comment_votes comment_votes_comment_id_fkey; Type: FK CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comment_votes
    ADD CONSTRAINT comment_votes_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES forum.comments(id) ON DELETE CASCADE;


--
-- Name: comments comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comments
    ADD CONSTRAINT comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES forum.comments(id) ON DELETE CASCADE;


--
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES forum.posts(id) ON DELETE CASCADE;


--
-- Name: post_attachments post_attachments_post_id_fkey; Type: FK CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.post_attachments
    ADD CONSTRAINT post_attachments_post_id_fkey FOREIGN KEY (post_id) REFERENCES forum.posts(id) ON DELETE CASCADE;


--
-- Name: post_votes post_votes_post_id_fkey; Type: FK CONSTRAINT; Schema: forum; Owner: -
--

ALTER TABLE ONLY forum.post_votes
    ADD CONSTRAINT post_votes_post_id_fkey FOREIGN KEY (post_id) REFERENCES forum.posts(id) ON DELETE CASCADE;


--
-- Name: group_bans group_bans_group_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.group_bans
    ADD CONSTRAINT group_bans_group_id_fkey FOREIGN KEY (group_id) REFERENCES messages.groups(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES messages.groups(id) ON DELETE CASCADE;


--
-- Name: message_attachments message_attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.message_attachments
    ADD CONSTRAINT message_attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES messages.messages(id) ON DELETE CASCADE;


--
-- Name: message_reads message_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.message_reads
    ADD CONSTRAINT message_reads_message_id_fkey FOREIGN KEY (message_id) REFERENCES messages.messages(id) ON DELETE CASCADE;


--
-- Name: messages messages_group_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.messages
    ADD CONSTRAINT messages_group_id_fkey FOREIGN KEY (group_id) REFERENCES messages.groups(id) ON DELETE CASCADE;


--
-- Name: messages messages_parent_message_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.messages
    ADD CONSTRAINT messages_parent_message_id_fkey FOREIGN KEY (parent_message_id) REFERENCES messages.messages(id) ON DELETE SET NULL;


--
-- Name: messages messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: messages; Owner: -
--

ALTER TABLE ONLY messages.messages
    ADD CONSTRAINT messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES messages.messages(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict r8Y9WVkpipiFDxw3MeEZqAWeSZ0PQWASrM7W7zuMFw4qwXs4wz7hpTXUmdgOjBD

