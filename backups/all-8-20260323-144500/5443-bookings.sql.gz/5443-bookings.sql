--
-- PostgreSQL database dump
--

\restrict NhLeGfv9mEElNDthB6aJZXbjZ3iAv7OPAgtjbNeye1YkOdHG2CZ3mV8y4Xc0ypH

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: booking; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA booking;


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: booking_status; Type: TYPE; Schema: booking; Owner: -
--

CREATE TYPE booking.booking_status AS ENUM (
    'created',
    'pending_confirmation',
    'confirmed',
    'rejected',
    'cancelled',
    'expired',
    'completed'
);


--
-- Name: enforce_booking_transition(); Type: FUNCTION; Schema: booking; Owner: -
--

CREATE FUNCTION booking.enforce_booking_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  -- created → pending_confirmation (submit to landlord) or cancelled
  IF OLD.status = 'created' AND NEW.status IN ('pending_confirmation', 'cancelled') THEN
    RETURN NEW;
  END IF;

  -- pending_confirmation → confirmed | rejected | cancelled | expired
  IF OLD.status = 'pending_confirmation' AND NEW.status IN ('confirmed', 'rejected', 'cancelled', 'expired') THEN
    RETURN NEW;
  END IF;

  -- confirmed → completed | cancelled
  IF OLD.status = 'confirmed' AND NEW.status IN ('completed', 'cancelled') THEN
    RETURN NEW;
  END IF;

  -- Terminal states: no transitions out
  IF OLD.status IN ('rejected', 'cancelled', 'expired', 'completed') THEN
    RAISE EXCEPTION 'Illegal booking state transition from terminal state % to %', OLD.status, NEW.status;
  END IF;

  RAISE EXCEPTION 'Illegal booking state transition from % to %', OLD.status, NEW.status;
END;
$$;


--
-- Name: FUNCTION enforce_booking_transition(); Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON FUNCTION booking.enforce_booking_transition() IS 'Enforces legal booking lifecycle transitions; terminal states (rejected, cancelled, expired, completed) allow no further changes.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: booking; Owner: -
--

CREATE FUNCTION booking.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  ELSIF TG_OP = 'INSERT' AND (NEW.version IS NULL OR NEW.version < 1) THEN
    NEW.version := 1;
  END IF;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    landlord_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status booking.booking_status DEFAULT 'created'::booking.booking_status NOT NULL,
    price_cents_snapshot integer NOT NULL,
    currency_code text DEFAULT 'USD'::text NOT NULL,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    completed_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    payment_status text DEFAULT 'unpaid'::text,
    payment_reference text
);


--
-- Name: TABLE bookings; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON TABLE booking.bookings IS 'Tenant requests on listings. tenant_id/landlord_id = auth users; listing_id = reference to listings DB (no FK).';


--
-- Name: COLUMN bookings.tenant_id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.tenant_id IS 'Auth service user id (consumer).';


--
-- Name: COLUMN bookings.landlord_id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.landlord_id IS 'Auth service user id (listing owner).';


--
-- Name: COLUMN bookings.price_cents_snapshot; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.price_cents_snapshot IS 'Price at time of booking; immutable. Never join to listing for price at payment.';


--
-- Name: outbox_events; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON TABLE booking.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.outbox_events.payload IS 'Serialized domain event (proto bytes), e.g. BookingCreatedV1; not JSON.';


--
-- Name: search_history; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.search_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    query character varying(256),
    min_price_cents integer,
    max_price_cents integer,
    max_distance_km integer,
    latitude double precision,
    longitude double precision,
    filters jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: watchlist_items; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.watchlist_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    listing_id uuid NOT NULL,
    source character varying(40),
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    removed_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.bookings (id, listing_id, tenant_id, landlord_id, start_date, end_date, status, price_cents_snapshot, currency_code, cancellation_reason, created_at, updated_at, confirmed_at, cancelled_at, completed_at, version, payment_status, payment_reference) FROM stdin;
04c74291-a6ce-4b64-87ed-c2d285a2884d	11111111-1111-1111-1111-111111111111	a3db427f-db20-4b3a-98e0-1b548e8b5529	a3db427f-db20-4b3a-98e0-1b548e8b5529	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 17:41:34.861+00	2026-03-20 17:41:34.861+00	\N	\N	\N	1	unpaid	\N
d6ca92fa-6d2d-46e2-83ea-5c6f0b43978e	11111111-1111-1111-1111-111111111111	8d5786df-a577-431b-a4a7-8dc5e67891c5	8d5786df-a577-431b-a4a7-8dc5e67891c5	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 17:51:30.05+00	2026-03-20 17:51:30.05+00	\N	\N	\N	1	unpaid	\N
afc23156-d478-4973-b534-1f35e78bf411	11111111-1111-1111-1111-111111111111	7bed0326-d09d-4672-af21-a0ad0a405772	7bed0326-d09d-4672-af21-a0ad0a405772	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 17:56:41.936+00	2026-03-20 17:56:41.936+00	\N	\N	\N	1	unpaid	\N
9fa51ea7-2c92-412b-b8d1-9d2f175e00bb	11111111-1111-1111-1111-111111111111	7b42367c-dc27-4f48-8e4b-440c7b9cbe76	7b42367c-dc27-4f48-8e4b-440c7b9cbe76	2026-04-01	2026-05-01	confirmed	0	USD	\N	2026-03-20 18:06:12.963+00	2026-03-20 18:06:15.871525+00	2026-03-20 18:06:15.866+00	\N	\N	3	unpaid	\N
bf9e9f63-6a6b-41c3-8f19-53b0e6b432d2	11111111-1111-1111-1111-111111111111	6687a92f-a32f-43ce-9232-7e924df7863f	6687a92f-a32f-43ce-9232-7e924df7863f	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:09:42.271+00	2026-03-20 18:09:42.271+00	\N	\N	\N	1	unpaid	\N
ee7464e3-6b34-4c47-a345-6dff70495144	11111111-1111-1111-1111-111111111111	e41cb5ca-9581-401c-94d3-818e49da8932	e41cb5ca-9581-401c-94d3-818e49da8932	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:18:31.248+00	2026-03-20 18:18:31.248+00	\N	\N	\N	1	unpaid	\N
f9f680c2-2b6f-4074-90b5-94140eb74a8d	11111111-1111-1111-1111-111111111111	b7bb52f4-f192-4ca4-a851-e5f974a833c5	b7bb52f4-f192-4ca4-a851-e5f974a833c5	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:29:57.752+00	2026-03-20 18:29:57.752+00	\N	\N	\N	1	unpaid	\N
8f453a0b-8421-4450-afb9-6288bff7594a	11111111-1111-1111-1111-111111111111	957c2087-edb5-4424-a4be-8e0f0954d704	957c2087-edb5-4424-a4be-8e0f0954d704	2026-04-01	2026-05-01	created	0	USD	\N	2026-03-20 18:39:22.921+00	2026-03-20 18:39:22.921+00	\N	\N	\N	1	unpaid	\N
3ff8a847-be65-4b7c-854c-ec192b0e318b	c54f9572-990d-465a-9058-e010262a104b	0460b540-17ab-4e55-98bc-9a252172697a	0460b540-17ab-4e55-98bc-9a252172697a	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:41:08.096+00	2026-03-20 18:41:10.9098+00	2026-03-20 18:41:10.904+00	\N	\N	3	unpaid	\N
f3194ce1-e9b5-4000-bef2-da40825b5636	46fc0414-c76c-45a1-91aa-084ce12699d3	6b25e7e4-e762-4be1-80b3-263a7311df0f	6b25e7e4-e762-4be1-80b3-263a7311df0f	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:43:42.883+00	2026-03-20 18:43:46.701026+00	2026-03-20 18:43:46.697+00	\N	\N	3	unpaid	\N
9027af04-ed81-43f0-96a6-fd3f3c068ead	7ef1638f-3e86-4d50-842b-afc71d6545f2	db718a84-02cb-4f2c-bb50-c157b9ab68fe	db718a84-02cb-4f2c-bb50-c157b9ab68fe	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:52:00.388+00	2026-03-20 18:52:04.176896+00	2026-03-20 18:52:04.172+00	\N	\N	3	unpaid	\N
cf772423-7409-4e9b-acea-587054c92f09	933433fa-e3dc-4301-bfc9-1270aedbde76	cad46f19-7f10-44b6-ad6c-4d4b2b29f784	cad46f19-7f10-44b6-ad6c-4d4b2b29f784	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:53:30.578+00	2026-03-20 18:53:33.56066+00	2026-03-20 18:53:33.557+00	\N	\N	3	unpaid	\N
0142b556-c031-4b8f-bff1-aad9b81cab18	b66212b0-5fb6-48b4-90b8-91abb76e0ce4	93c294e6-7d73-46cc-9f03-0a61d42f6b52	93c294e6-7d73-46cc-9f03-0a61d42f6b52	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:54:32.937+00	2026-03-20 18:54:35.658847+00	2026-03-20 18:54:35.646+00	\N	\N	3	unpaid	\N
efe1db1a-c4fa-43d1-b059-2e0b593aec1f	c59649bc-66f2-4566-ba6a-606479e1223e	1b7b7bc3-dc50-48bd-a63b-ff50052a7b14	1b7b7bc3-dc50-48bd-a63b-ff50052a7b14	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 18:56:31.062+00	2026-03-20 18:56:34.341665+00	2026-03-20 18:56:34.338+00	\N	\N	3	unpaid	\N
c2362372-8a9f-4c8c-bf6a-f2997ec6345f	069a277e-487c-475b-869f-8eca9e4bf9d5	fb50945a-decd-407c-917e-45f8384a0ad9	fb50945a-decd-407c-917e-45f8384a0ad9	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 19:07:19.139+00	2026-03-20 19:07:23.504051+00	2026-03-20 19:07:23.359+00	\N	\N	3	unpaid	\N
7d087ad3-51f0-4a97-af82-80c304451c7f	90d1876a-3a48-4598-b991-705ea74d08ac	7489d12c-7978-4988-8575-e7d6f9f6c85c	7489d12c-7978-4988-8575-e7d6f9f6c85c	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 19:16:53.593+00	2026-03-20 19:16:56.621458+00	2026-03-20 19:16:56.619+00	\N	\N	3	unpaid	\N
d5036984-c448-4ce8-a2ca-a7a0193b8217	8ecb3baa-1c93-4c5a-9602-2e1554753b59	b6b197d6-51e5-40c5-a4bc-d5c460b77cf5	b6b197d6-51e5-40c5-a4bc-d5c460b77cf5	2026-04-29	2026-05-29	confirmed	0	USD	\N	2026-03-20 19:23:26.813+00	2026-03-20 19:23:30.754671+00	2026-03-20 19:23:30.506+00	\N	\N	3	unpaid	\N
19223cf3-76c2-47ce-87e0-9b27419357a8	1f10c9c6-52e7-41c3-a3ac-5b946d19b62c	5fed5110-652d-4fe0-b1b4-c6bf678a9122	5fed5110-652d-4fe0-b1b4-c6bf678a9122	2026-04-30	2026-05-30	confirmed	0	USD	\N	2026-03-21 22:33:54.262+00	2026-03-21 22:33:57.589622+00	2026-03-21 22:33:57.583+00	\N	\N	3	unpaid	\N
ffc5b922-0ad1-4518-aa84-6c1c27ad7016	7eb5e393-bd79-46cb-bf12-34d79dc3ea38	58ef6cfb-0509-41e8-9bec-d19847738a98	58ef6cfb-0509-41e8-9bec-d19847738a98	2026-04-30	2026-05-30	confirmed	0	USD	\N	2026-03-22 00:46:26.398+00	2026-03-22 00:46:29.629907+00	2026-03-22 00:46:29.618+00	\N	\N	3	unpaid	\N
380661c8-66c9-4b3f-83ca-5a77e35cf0e0	02ab5946-55ff-4985-b0f0-8ddc54b94f5c	6b90ec84-d747-4b28-b6b1-68f8eacc30a0	6b90ec84-d747-4b28-b6b1-68f8eacc30a0	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 14:41:49.131+00	2026-03-22 14:41:52.535484+00	2026-03-22 14:41:52.529+00	\N	\N	3	unpaid	\N
fa3d48b9-42ae-4d0d-9e85-f0b095f37a4b	4f785aa2-a908-4f59-a360-e1c53c66732c	6268e2d4-73e5-42af-aca4-cd7adf744f84	6268e2d4-73e5-42af-aca4-cd7adf744f84	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 17:32:03.478+00	2026-03-22 17:32:06.668601+00	2026-03-22 17:32:06.662+00	\N	\N	3	unpaid	\N
40577f6b-f231-45a5-b9df-9b4c497147ad	7d8eb5a5-2131-42e5-bf12-8a0fb804c1a1	c2c7db13-7cb7-4c31-a10b-864cbb816dd2	c2c7db13-7cb7-4c31-a10b-864cbb816dd2	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 19:18:01.163+00	2026-03-22 19:18:04.451006+00	2026-03-22 19:18:04.416+00	\N	\N	3	unpaid	\N
15194323-137e-4ee2-ac25-8706ca3a1957	76868ccf-beb0-479d-b505-b34f7195d0e7	60a7ff4a-4e43-446c-83a4-cffefd2c3511	60a7ff4a-4e43-446c-83a4-cffefd2c3511	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 20:15:05.186+00	2026-03-22 20:15:07.765286+00	2026-03-22 20:15:07.755+00	\N	\N	3	unpaid	\N
4ac50407-e76e-40f8-b41a-72cc0cd1a42f	0447a314-b222-4184-94ce-89a644b456fc	fc5e5366-76bd-4bb2-bbd5-8c11d85bd90d	fc5e5366-76bd-4bb2-bbd5-8c11d85bd90d	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-22 23:12:06.493+00	2026-03-22 23:12:10.435116+00	2026-03-22 23:12:10.428+00	\N	\N	3	unpaid	\N
3aaf6514-90f9-4df7-90b7-c57ab14b944f	dd4b93c2-3e7d-465b-b22c-743da9be0508	b9547d08-b08e-4094-b911-c0cd78d0f44b	b9547d08-b08e-4094-b911-c0cd78d0f44b	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-23 00:27:53.965+00	2026-03-23 00:27:58.554557+00	2026-03-23 00:27:58.545+00	\N	\N	3	unpaid	\N
b26fb40d-17c1-4ece-8a16-641bcebbf230	f9c1dad1-3208-4c93-a289-da13ff85db4f	9e4a4290-4d8f-4ea3-ab8b-50dd385c1d01	9e4a4290-4d8f-4ea3-ab8b-50dd385c1d01	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-23 01:15:34.274+00	2026-03-23 01:15:38.006193+00	2026-03-23 01:15:37.979+00	\N	\N	3	unpaid	\N
e0d64686-cb98-4f8b-a9d2-8435dba3f5aa	2846dc02-a99c-406f-a12e-159ac494ab17	9040b04c-f1ee-4188-b57e-36a45166cfde	9040b04c-f1ee-4188-b57e-36a45166cfde	2026-05-01	2026-05-31	confirmed	0	USD	\N	2026-03-23 03:29:09.993+00	2026-03-23 03:29:14.225756+00	2026-03-23 03:29:14.207+00	\N	\N	3	unpaid	\N
4eee1d47-3220-4491-916a-0896789fe1c6	d3ccab1d-a2d3-43de-96b9-01fb504bd8b9	3d4dc8a7-7c4e-46e7-9af8-16efc1f43e9b	3d4dc8a7-7c4e-46e7-9af8-16efc1f43e9b	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 04:08:38.929+00	2026-03-23 04:08:42.086334+00	2026-03-23 04:08:42.073+00	\N	\N	3	unpaid	\N
30f5e9a9-6f8a-4f24-955e-2a09bc78a19f	cf179d9a-eaf6-45d5-9956-d2ccfb267933	f1d93114-c5bb-4d01-b476-2d3be75cf4d4	f1d93114-c5bb-4d01-b476-2d3be75cf4d4	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 13:25:54.602+00	2026-03-23 13:25:56.788249+00	2026-03-23 13:25:56.778+00	\N	\N	3	unpaid	\N
36589cd0-3e64-43cf-ae24-8af3f2279987	0918148b-3fe5-4361-8274-55982e8045bc	0aa3da46-f299-4032-975a-0b21dec708dc	0aa3da46-f299-4032-975a-0b21dec708dc	2026-05-02	2026-06-01	confirmed	0	USD	\N	2026-03-23 17:16:19.124+00	2026-03-23 17:16:23.028719+00	2026-03-23 17:16:23.022+00	\N	\N	3	unpaid	\N
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: search_history; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.search_history (id, user_id, query, min_price_cents, max_price_cents, max_distance_km, latitude, longitude, filters, created_at) FROM stdin;
2e01a679-4bb1-4c2d-b677-c3e14b20e7ce	c2ac34e6-ba60-4ccf-b9d5-dbb06aa31785	2 bed near campus	80000	180000	5	\N	\N	\N	2026-03-20 16:37:21.081+00
5ad40f5a-c0c2-4ac2-8065-9d6a9fd6642e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.127+00
ea835f1e-b353-44be-9ea1-b880e017bbf6	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.228+00
b50c08b8-a608-4f8a-9a7f-1a1a2e549d66	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.23+00
5a32c065-b4fb-4a1f-8530-f37abeac5a8e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.265+00
008e14ab-1ef8-4f67-8953-b2329f79de37	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.227+00
30ab6393-ed24-43cc-a075-650300058f7b	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:43.177+00
c12dbdfe-f130-41f6-8421-99831cf683fe	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.085+00
3264add7-d342-463f-8a2c-3a6b6baf1409	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.083+00
481b6351-c42c-46cd-a3f9-ad26679420a9	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.092+00
8f01747b-b13f-4036-8562-48fc05a5cfc1	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.094+00
ff676ca5-5c39-4c06-95fd-ca319841c443	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.17+00
47963c33-56cb-4793-bfca-05e2b0056b51	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.171+00
d7be51de-6c5e-46da-a4eb-e432778c5849	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.708+00
73e90ea8-f9da-4a89-8d2c-0e2c7fe37e24	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.709+00
d3f03eaf-0a61-4b16-8f71-a8dbb732c633	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.728+00
69fe4ffd-4210-4d45-8976-4768f0d93e43	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.773+00
fbc127e9-648d-4c5f-9729-c0a9815687ba	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.796+00
b95234dd-75c1-495d-8290-60a534e8ca1b	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:44.86+00
a1d101bd-b0c3-4ffa-8784-975f6ec90aa6	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.316+00
f80fda00-abbb-428b-9338-4be34837900a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.318+00
e25f5005-d504-4fa4-9d9f-2c17f18b733a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.318+00
5c1bc9ba-7881-4ac6-a00c-0201465428e5	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.402+00
38e7c898-e18f-4950-a82d-11006425361f	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.467+00
a0219abe-ee39-4052-a4ad-f5c649b9544a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.471+00
ce0b36d7-d6db-427f-81da-311cdfe40190	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.995+00
68742073-c4a2-452b-a41c-ccfd3223a32c	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.996+00
cef8a776-d0fb-4249-b43e-2de30f566085	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:45.999+00
3a55889d-bc30-44be-805e-547f087c7aa3	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.103+00
2aa124cd-7900-4c49-a934-a443e4a18d4d	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.167+00
3fa1c117-456a-4522-a174-c39c20456574	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.172+00
5e0eb046-e33a-4607-9774-b39a46215084	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.578+00
9448e522-3605-4e30-85bf-fbfc0bef5313	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.578+00
de769bd3-c811-414d-9f75-d920901f14ad	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.579+00
0bf99613-5165-4338-a816-838454b52c5a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.637+00
531351e8-2374-4c01-8239-26defd373b77	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.725+00
5b692027-59cc-4b36-a683-4514c7c2ac6a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:46.727+00
ef9e473f-c7ee-468f-aeb6-a8ea659cbdf8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.182+00
a66c5467-5452-443b-842f-b7c8313970b0	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.181+00
b537b3bf-d6bc-4bb1-97ab-0e31e5bf1e8e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.196+00
606bebe2-68e0-4bee-a8c8-0ffaddb3b191	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.259+00
473d0b61-a656-406b-ba30-9f4f9f00e013	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.276+00
6f207623-7a22-43aa-8679-288506b06c96	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.277+00
3696677f-0393-4855-9921-4bfadffc6fe6	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.786+00
fdf0f422-f643-4032-92c3-9571acb1cce7	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.787+00
a8a5712d-b388-4218-a249-a42625c98fe4	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.789+00
0602f6bd-81fe-44e6-9666-830f872ec1b5	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.823+00
47df5f5d-c00f-4569-99af-84c29c734b16	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.872+00
966b7b28-29df-4483-a25d-e8ee85f04b77	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:47.895+00
7518a29f-4aa4-41bd-aa6a-7ab08aac2ba8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.443+00
9a9373f9-552e-469c-85bf-3d60df8af45e	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.443+00
21ceb9ce-db5e-4dab-a747-69aaf8df7d02	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.444+00
823cc5d1-b9c9-4d78-af76-763a6a48df55	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.456+00
d72ee7a8-8a54-4786-a0cf-d4ce4536e6da	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.492+00
aa0be3cf-49f3-427b-bd77-c5e7ef2653f2	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:48.527+00
208fd01a-858f-4f44-8584-d608ee51b7ee	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.013+00
89533f70-f3bc-4622-be8f-27410262bd60	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.011+00
0fea9ee7-3f4a-4707-a6eb-d4c33b35c24d	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.014+00
bcf5648b-5ae7-4dc1-9a22-5fda8b04c325	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.038+00
59519d36-df6f-4dda-aa7b-02fe72de8e41	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.068+00
a180b0c6-a3fb-4c83-b092-a92f5a2bc566	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.071+00
7c22be30-532b-42aa-a369-bcd2f3b9ad5c	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.642+00
9da99ac7-6e61-4560-a971-e2b047063640	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.642+00
b0e63670-2772-422f-aa59-e762323478f8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.643+00
3b87627e-c00c-4538-aef2-1c5b7a7f2dec	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.66+00
2616698f-507f-459b-b166-e58e6149a421	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.687+00
88f4f7e4-7002-4f90-af13-f1dee29d2963	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:49.689+00
7267215b-1fac-4737-aa19-6c4bc1e462fd	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.226+00
b89d20bd-bc38-4040-91fb-a9eec49840c4	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.225+00
67308766-8274-4936-8fc9-ac836cb7c0d3	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.231+00
dd53e83b-d43e-4ebe-8be9-22656b7670cd	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.238+00
6c6654d5-bc41-4fa0-b2fe-7a0f61a7d800	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.253+00
1621779f-5cc6-4509-bd53-8d961bc6806a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:50.253+00
7448e9b3-7f9e-40f7-b5aa-7fbc17c4cead	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.075+00
1ff43693-7e1a-4643-b144-6726cd8a7c62	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
8168c8e4-9313-4303-b6d0-f9e6e1ddacde	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
ac0330ac-68ae-48ce-a131-12ec0ba27ba8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
dad45d85-af65-43c9-ac53-fc0a9814412a	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.076+00
f93c8a75-ceea-43f7-a539-6013e5dd2340	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:40:51.08+00
7647a888-68cb-44ab-b3ea-9d1c395f5e05	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:35.926+00
693737c8-f65e-49c5-afef-c745f03c500f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:35.928+00
eb8fba15-c8b5-44d6-a352-7005f8c86ebf	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:35.885+00
bbe7fa78-eccd-4067-bf44-6bbf0642fcbe	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:36.722+00
2db008ab-3a98-4dbb-9e93-fe9d8590fd06	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:36.73+00
5e73b0a8-9ecc-47f9-8067-794bead4af8f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:36.728+00
153eae74-171e-4d3c-99af-312ce8b7f7df	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:37.452+00
51251134-ef58-49b9-a1b2-556140523604	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:37.452+00
86b35679-c85b-45bb-b54d-de481538fc04	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:37.451+00
391532e4-2920-4a84-a7e5-37105f21aec6	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.094+00
a1321425-db4e-400a-9fac-afbf89dcc1bb	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.09+00
62bf344a-59ac-4d18-a71c-b7c5dbdf59ee	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.093+00
4807ffac-ebc5-491f-896c-1dbf550a9f84	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.726+00
8e2e406d-6e83-4f34-b0a1-22922463b6dc	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.726+00
607d46ee-7033-4478-a82e-c845a6e8ef46	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:38.724+00
a4d680e0-5814-4b2c-b733-bcfae36c2a7f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:39.424+00
332253db-394c-4005-8045-b7c461abe93f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:39.422+00
d3bd349a-b6e1-4548-933d-3e432894b13f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:39.588+00
128dc5d6-d55c-4e08-a720-b0224a6cc215	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:41.878+00
29fa120c-1f48-4050-9c66-1ccda298ae93	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:41.96+00
bb0d0ad2-fe5f-449f-a420-96c5440dd87e	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:41.981+00
addcb350-56fe-4224-a862-0ed7f6c86fe3	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:43.257+00
0994383f-f3f0-4fe6-82f2-0ebf44c83388	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:43.256+00
8f3a97c3-5460-417b-a5b6-f3836fdc59ca	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:43.258+00
d384d90c-fc1f-4f07-bc0c-3c1dd4901c79	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.027+00
3d0a57ed-f362-4feb-938c-5bd1bfe29589	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.034+00
fa565a48-ac60-455b-881a-57ea8c0a050f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.034+00
a1ca22f0-f091-4b57-8813-d28fee48e018	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.762+00
6e184925-dd26-4b33-888f-0be7c38d1dff	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.761+00
ad1007a8-2822-4713-979e-1ac3daec3659	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:44.758+00
33f95ae7-0374-4c81-b9b1-013b54c4ffd1	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:45.459+00
fb26f679-7215-4998-a118-281453507cc6	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:45.457+00
89baa660-d5e6-4867-b867-d69316a57e52	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:45.46+00
19a45bb1-9bfc-4873-9fb1-da6e2c1128c9	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.164+00
6a18f7c4-787f-42d2-837b-10dadbec496c	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.164+00
ebf618c2-4cf4-4474-9a2c-92282ae7444a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.162+00
e11418a1-e19e-4361-aea6-74baee3fe296	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.79+00
71e1072b-9117-4ea4-9650-438a084bebe3	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.789+00
b6e62ead-b51e-4773-9a90-7d84965439ec	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:46.79+00
50dd598b-29fd-413a-b1be-429756af59c4	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:47.46+00
0e0c1711-c07a-4b52-abdb-45aa1b291741	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:47.46+00
7b177ec4-f47b-45a0-b010-eaf87dac5404	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:47.457+00
013295cf-f46b-4519-b210-d4f5a4a9fa51	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:48.273+00
43763a9f-dcdc-467a-aa39-6f4461258309	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:48.268+00
8f2b1a99-c083-4bac-b9dc-e9ad520d89cb	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:48.274+00
a6357c6e-a88d-442b-a475-4497049059b0	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.047+00
9211637f-6eb8-420e-a7e8-c541753d0b88	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.052+00
e2ffbce4-3286-4cb7-ac2a-b9a9205ac08c	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.054+00
07efcbdc-fa0b-4093-9351-5688afe27b9d	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.692+00
23f9e38b-f274-484d-b592-d0e71b408272	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.695+00
eae37d37-df44-4c91-a5a8-ad49d1907949	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:49.696+00
afeca1ee-2a72-4e42-b0a3-c161d8d4909a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.351+00
c7550d22-6ff1-442b-9d7a-e8d4dffc4237	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.351+00
a4bc7eb1-f184-495f-a4ee-75e0de1143e9	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.35+00
3b4766ed-8756-47b6-a686-e7bacd0ce17a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.972+00
db5bfd89-a4af-459d-9f53-7a7a845c6da4	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.971+00
9e656feb-3f2a-41c3-993d-339a90986894	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:50.974+00
eec82d10-6321-4274-8085-e564effaa25e	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:51.614+00
e3decacc-874c-4af4-a09a-dbe4600655ec	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:51.613+00
85f32142-2e3b-42e4-8af2-4899ef679c33	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:51.614+00
e4684d4a-27b7-4a78-9680-0bf8d57b3e5d	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.19+00
bc4697bf-40f0-45b2-9695-a1bcd9e32dd6	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.191+00
0c8a2153-62bb-47d2-a502-62feb6e4980f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.191+00
2b86cadf-97cc-408e-a0e6-14a151e0adfe	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.744+00
b14b7fa9-4cc5-48bc-af86-f51c9867da8b	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.744+00
c95bfc84-5ae9-4141-9d3b-02ace68f413f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:52.744+00
1875f2b1-faa4-4c2d-8c00-2835db4f2d5f	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.293+00
674c9742-7ac3-49ff-ac51-24413b9d7672	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.294+00
e4456999-0426-49c3-8d2e-178ab5043126	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.294+00
9de671e7-912b-436e-862f-197a38f6795a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.848+00
4729aa10-70a2-4d18-ac36-3664cb015db4	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.849+00
88914cef-54bc-4e79-b146-68466aaf820a	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:53.849+00
768b71a1-0be7-44e4-bff5-cfca769e5fe0	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:54.407+00
4a3e8ed6-cb1d-42f0-ab73-aefb2dbc4290	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:54.408+00
daf0abd4-6bc2-43bb-972c-deb069686914	893699ca-346f-4aab-bf83-f51809169543	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-20 16:42:54.408+00
0cfe5959-984f-4c61-b0ab-2a18a89541c4	f872a417-3409-4bd0-bf41-c7129108554e	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-22 19:25:11.16+00
696a9825-05db-42d2-af6b-e2ff3d64e39d	958e471b-aa70-4374-a38d-8544ee85b5fc	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-22 20:20:56.49+00
556e9a92-6800-4b2a-b603-e1b459ee3089	a4a667b1-c43a-4092-a0d1-a437172faa7a	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-22 23:18:09.161+00
28dce675-a75e-4080-a93b-690d5a3da1f3	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 d3fqv97o	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.287+00
1ca4ced9-db5e-4237-a3da-91d532f7a450	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 oa8g6ftj	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.429+00
d0c5b17d-09f1-4ed3-8178-5d85b121a806	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 7ixsaye5	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.43+00
018b504b-4701-4bfa-8ee4-518184416c64	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 z63isngy	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.43+00
0f9d3b41-8310-48f4-a304-484f939d4ea2	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 ujrnetbw	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.458+00
f9586ece-22fe-4df7-acdc-cef9a4cb3e89	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 0 nj78shfz	80000	250000	3	\N	\N	\N	2026-03-23 00:33:09.463+00
d6764189-834f-4b0a-b85a-a1f33e137ed8	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 wacs91hb	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.156+00
b2b86f65-000b-4b42-b269-82018b158e70	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 d5p9s91o	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.162+00
489e4958-dbc8-4fbb-a003-ef9841bf2897	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 l3oxjbzw	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.165+00
f9484a58-8ec6-4bcf-a13f-f4858f0d2f1f	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 6223rgs0	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.227+00
b69ddf6b-7546-4dca-8761-493bbc58b6c7	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 8wt3zq4r	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.363+00
2b817540-864c-435c-bb2b-2e8090525dcc	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 1 xdwbur7j	81000	250000	4	\N	\N	\N	2026-03-23 00:33:11.26+00
21609c8c-0116-4516-a694-71d0ffdd8d9a	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 f73x0mql	82000	250000	5	\N	\N	\N	2026-03-23 00:33:12.987+00
163cc0c9-cbf2-4669-9e11-b66f6c8c330b	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 9i3vmmry	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.209+00
53872dc7-3157-41bf-bc07-ad158ecbacf4	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 3u2mpz9y	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.215+00
021d2187-6e8b-4cb5-86e3-ac9b6071e48d	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 lj1bsh6t	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.22+00
5cb76f5c-ad13-4c51-b27b-ae695edd2e46	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 zkxezp5t	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.223+00
3afd6b9b-0a2e-4730-a455-190218e49d4f	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 2 53yrjc3z	82000	250000	5	\N	\N	\N	2026-03-23 00:33:13.227+00
8f034492-df73-4f95-a048-dffef8ef0ef0	1e25e645-6ec0-4975-b099-de6b5d40e7d4	k6 search 3 8otn1067	83000	250000	6	\N	\N	\N	2026-03-23 00:33:13.629+00
cea85453-d1ac-4fa2-98c6-475b508df9ea	d9c4b3a1-4517-459b-8e71-416b6f3a0df7	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 00:34:07.958+00
eab8e68a-e228-4d73-b1ec-9574c1a4afb1	f9b62a55-8b9d-4486-b719-129c4dca6d66	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 01:21:50.969+00
2389c5a1-c314-40f2-b3c0-c45b30095b61	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 aakekldu	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.561+00
41463d32-c367-414f-9e39-8deb3d7ded78	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 w96wd96o	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.562+00
aee5c23e-c0b4-4a99-8800-e11edc5501e9	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 7rx54kre	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.561+00
d911abe8-aec5-4fc9-bb32-b4d485d9b94c	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 rk4cw74z	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.563+00
7c025207-be84-4998-9f4c-64b11f9e788f	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 kdzuud02	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.638+00
d458baa9-f02d-45f6-9b7e-54e45d61206a	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 0 2uc9x2ad	80000	250000	3	\N	\N	\N	2026-03-23 03:34:51.638+00
18a0198f-0bae-4c0b-926d-91e582def4b8	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 othrlojn	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.845+00
9172c45c-3951-4be0-aca2-94917391306a	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 j8ujo3jm	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.896+00
01d37a76-f24e-4c6d-8dfe-8429ea9b109c	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 3sf5myg5	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.96+00
5e8d2a61-8f25-4391-82a3-c3f7fe8f8c32	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 c9ko6fd8	81000	250000	4	\N	\N	\N	2026-03-23 03:34:52.968+00
5126508e-7d5d-4e8b-a880-1e195d3053e0	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 z9rnwms5	81000	250000	4	\N	\N	\N	2026-03-23 03:34:53.038+00
c68264e7-d15f-4b16-bee2-4d1472e0c45c	322c881d-0e5b-4c58-a8d9-131b5358b8fb	k6 search 1 aok74r8g	81000	250000	4	\N	\N	\N	2026-03-23 03:34:53.063+00
8242182d-2892-4c87-9806-8aa0bce2093e	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:02.439+00
a0ba847b-1151-4f90-8c7f-afbfedc5e40f	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:02.485+00
75a90fd4-e2bc-4d15-8d7a-102448b8ac23	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:02.519+00
a3ddbf0c-6b77-4ccf-bdc7-24e34742d4ad	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:03.578+00
27a0e510-797f-4537-823f-10da26751088	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:03.584+00
5cf6e456-5516-46c5-9ced-ae7cf5e1d5d1	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:03.591+00
1f94589d-faa0-4379-a28a-d8bc9f6c6394	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:04.704+00
4fcd365d-3ac9-4d01-9ffe-08558ba98745	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:04.725+00
557bba87-a34f-41d3-b12c-d6caa3ae715d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:04.813+00
5728ecf3-7768-476e-8f11-69c351767afb	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:06.551+00
db4c1a87-57f4-44aa-8c1d-92850f29d20c	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:06.863+00
e325ba6e-662e-472c-bdee-dd848978e9f2	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:06.87+00
f9d0bc20-67d5-42aa-9018-e2f63b52db18	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:07.296+00
c28a35f8-70c4-44a6-92ec-2019de3721d6	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:07.601+00
db3a5863-ed09-4145-aef3-95b484b0d65e	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:07.603+00
f9e45762-0e69-48c7-8851-852af84791dc	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:08.202+00
98ccd5a6-471e-4448-b7de-ca79d59d151c	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:08.71+00
3349e0b2-5418-4841-80bb-6ba02c38eaf7	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:08.793+00
215830af-5efb-4f36-9e17-88006d262283	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.228+00
8d674500-b8d0-4ca6-9395-5b47325ad556	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.697+00
3c6f548d-ef5a-4686-8d1f-5c5df482a5ea	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.701+00
ac13b8d7-20ee-4319-9752-e340005c637a	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:09.872+00
5d941fb1-8923-4908-9af8-b795e2817907	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:10.362+00
ecb91dd8-13bc-41bc-ac85-749b104e879e	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:10.366+00
d2e5b70c-6348-4947-95e5-0a4b78e89a43	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:10.589+00
184eb7ca-26be-407b-9433-d562e945db9d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.045+00
6227117d-79ca-4160-b7bf-8672d3c3e472	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.047+00
fb974df6-8ddd-409b-b7dc-50121f208d55	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.245+00
46fc2e02-0f80-4097-a36c-22bcd348e458	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.724+00
83345794-e45c-4983-9e0e-8824caab77a1	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.728+00
ef24d56e-d0b3-434c-b96e-e8253fd5286b	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:11.906+00
1d6e4bf9-cd75-4d7a-93e5-e4c4d1b95356	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:12.39+00
6fc97707-8255-4c8c-b8a6-e88d89db6034	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:12.392+00
d97c9a5a-e8b5-4629-bdd4-354730d5e482	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:12.553+00
f5f6f1d6-196c-4093-a7f6-01a263792e9f	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.026+00
2a1937d3-cb6b-44b1-bb23-b3524c319fa4	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.045+00
e2412593-38dc-4630-bc9e-cc8cdfe67b6b	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.161+00
1ab9e06e-7068-46df-a118-fd5d4467b678	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.686+00
c68bba76-48be-4be3-9009-cd5437494c73	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.803+00
5274b74e-4e8d-4df8-815f-595bd37eb8b3	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.097+00
d7ddfd62-000c-46bf-86e6-0bc17446cbe5	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.257+00
e1714111-6201-4e63-8914-cd14cda1ed32	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.27+00
fcd2a483-b236-425d-b2a4-3cd60a8e9d29	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.707+00
ca8498a7-5219-4c5c-9d72-a6b1a7b5523b	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.871+00
06855dae-10b5-4142-b550-bea6aa383dc3	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:15.925+00
dbfe76bd-4639-49f1-819e-842c496db424	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:16.616+00
b0108857-1458-4997-8758-4cf53fc8d688	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.39+00
d182cdcb-5d2a-4082-bd23-9622cedf6b73	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.79+00
6a9638cf-8e70-4d3a-bbe9-aa3abdd4fef3	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:18.387+00
19058681-e4ad-4b05-bfb1-ee73f97abf74	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:19.392+00
fca6e87d-5c9a-45a7-9c5d-d97ffe2757dd	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:19.992+00
14008c91-740a-44b7-b641-126e54b19e78	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:20.09+00
92e6a5d4-8582-4d8a-9d8e-8fc6dbb0612d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:13.689+00
15acdfbf-979c-42f8-861d-1a6bf1ed6421	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:14.454+00
4ad621d9-9cb4-4957-b299-00d1f9f3dc91	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:14.527+00
01be74e9-4cb9-42e8-96b9-165b8e1d2261	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:14.604+00
2f7e989d-f88f-4e56-b517-3574c818872d	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:16.363+00
efde0fb7-db57-48d6-bf27-1f03fab7b9af	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:16.557+00
cbff0a0c-7f66-4e21-a3f5-a89cdd670b44	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.027+00
080ac91c-1e06-4f0d-961b-62a831105beb	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:17.292+00
86bf0494-5120-4284-9097-ab5a658aeca1	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:18.785+00
086134dc-88c8-4841-917b-c4f6e2066951	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:18.994+00
a8e873e0-964c-4032-b7cf-bd0a457a9a83	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:20.392+00
6453ad95-ad7a-4c76-a867-33f0d730db02	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:20.914+00
49b2b199-ef41-42fd-a625-b607af12f996	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:21.012+00
40c060c9-b8bb-46b4-ad72-c30956840aa0	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:21.134+00
76bcfc2b-f3a8-4dfb-a76b-e807de65e134	09635deb-f21d-4d0a-a4af-bb41cd10b405	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 13:31:21.559+00
da8bff4c-469b-4c97-b78c-0865c40259fd	ed711d1f-2108-4fbc-bf9c-f915dc2d4c36	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 15:12:40.917+00
69bbe2f5-7b9e-4147-94f8-540d51e600e2	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:29.915+00
3de6f47a-242b-4a08-a58f-c2f2bfab220f	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:29.852+00
5f376e14-7fcb-4381-9414-47a8d197e951	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:29.913+00
382028c8-d37e-4104-8a11-d33a5fb11f77	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:31.842+00
f55eac3d-1c1a-46f5-8b6b-3f5199660beb	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:31.919+00
3d0be33b-d4c9-408b-8ccb-ac6efbb649a8	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:31.928+00
111f1c18-c56c-490d-bbc8-9fba18fc071e	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:34.647+00
0a0c5a42-2cf1-4fdb-ad20-47326a95d8a9	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:34.699+00
1263acfe-6128-4e96-ba7b-9acd3cbedc31	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:34.702+00
0952329d-aac2-48dc-9688-e40ce9c9a8a9	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:35.343+00
0c954591-38b5-4471-b8d3-250b4a059360	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:35.366+00
5f64b93f-c0f1-482f-bc5b-83fa75828ab7	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:35.37+00
5eb06824-b242-410f-8ab4-9a532356c5a3	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:36.272+00
8a528b60-c397-4bd5-b31c-fb615b2adc26	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:36.276+00
cd9c38c2-fd44-45b6-ae9b-3e8b1d4d5215	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:36.279+00
e8da43f0-478e-4600-accd-011bcea92f8c	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:37.336+00
7fba9a6d-67ad-4a3a-868b-5518af9fe97c	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:37.321+00
f1cd8442-ab33-4d12-803d-afae720d7977	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:37.328+00
1beecb68-1b4b-4769-b461-285ea3e097d1	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:39.316+00
554e1951-e348-46d0-b25a-fca4524e6d2a	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:39.321+00
1079a768-a455-4f57-b70f-032ffac4eb97	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:39.323+00
6c959953-011c-4909-85fd-c07a7c5e4245	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:40.323+00
f888bbd4-7e04-4eb9-9478-27bfe0797346	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:40.398+00
a7fb9991-b7ab-4589-9c64-4adf70baac1d	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:40.415+00
40a76ab4-fcfa-4fce-80e8-007b7c60b48a	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:41.616+00
f61658c6-5732-495e-84e2-e41903766e4e	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:41.705+00
954b99c1-cf49-4d3e-9e20-1eaeb5887447	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:41.718+00
f3d322a8-8f35-41d2-9f97-4c2ebb21b831	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:43.096+00
ce3ce617-eb41-4731-8cbd-08838c17d7f0	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:43.201+00
1249b16f-a566-428f-9e4e-61a78e6ecb99	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:43.215+00
e9b1589f-e78c-48e0-9caf-027af9d5efee	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.041+00
247d979c-e459-4e4b-b367-9a6597fd5979	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.133+00
b7dfede5-53f7-4937-b6a9-d3b9c5c27279	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.136+00
1afa5cdc-4918-41ca-a906-1cf1f6dc0c06	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.865+00
b7a62606-f5ba-41a5-ba07-e5c94342ea28	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.917+00
2a22f52e-59b6-41bd-98a9-d6092f00d860	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:44.922+00
7726a3c2-7f2a-4d0e-9d7d-0e998f909246	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:45.685+00
1d3e837a-dfe0-4705-ae27-5034fe682ae1	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:45.695+00
8b55d781-aab4-43ef-a92c-ba5d2acc01a8	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:45.703+00
4e91b3ac-35f9-4820-9f46-ef3720f138a1	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:46.423+00
c3959d01-103b-4844-a8f7-f4872b00ac90	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:46.425+00
09be8578-76fa-403a-9244-d6fa0a6847d0	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:46.428+00
3bd23656-7e61-422f-a1c8-fc41499d7017	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:47.502+00
f8db5f0c-e253-4315-9651-b7fe4aed8b42	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:47.517+00
92359d49-70cc-46a7-a0b1-bccb76c5a205	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:47.52+00
34e26bed-f992-4f75-9d5c-2b9d76d2efc3	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:48.31+00
c52a862d-d7b1-4d42-abfe-2c43dc15e914	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:48.314+00
b669c080-c359-4134-83bd-96f3b92db6bc	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:48.317+00
62b8549c-f85c-4bb0-bbaa-d5fe70cbddb2	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.162+00
dd522a68-eb6e-4d81-be1b-8eba23f7a958	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.166+00
fee1aea7-5cd9-42a5-a553-1ac7885dda04	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.17+00
2d7be938-4734-42a5-9678-eb9bb9f9631f	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.936+00
ec2eb833-3a62-4dfd-85a5-862965225537	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.939+00
835e4f98-5689-4f33-8ad7-d59d5ab96211	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:49.948+00
31a6ede3-705f-42ba-8002-9eb0b41e1d96	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:51.036+00
b77a6f34-c560-4409-a72c-b7b3c6d09824	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:51.12+00
dd3876e5-c9e4-48a7-8b04-2dbcf20cf6f4	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:51.123+00
f919a017-b73f-491e-9233-78e834c4f544	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:52.203+00
fc6e5206-0523-4d9a-8bbd-0f3732a87cf3	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:52.224+00
3dc97fb1-8382-4050-aae7-740c5bb0464f	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:52.288+00
73bd5a3c-0e9b-40fa-9c9c-6ea567ac1abd	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:53.621+00
4258ddf6-d2a8-44a0-84ed-3f24ff72e0ba	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:54.465+00
b734f0ed-55bd-4321-a7e6-4de985f220b5	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:54.471+00
3e0bf8bb-b99e-45a1-8e5b-f2b489e0e7ba	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 j1g82etk	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.025+00
18972edf-ef7d-4368-9cf7-d63c88320d9a	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 mukt6z30	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.143+00
e1db18af-959a-4838-8080-e3825a533ed1	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 ccvyti5r	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.162+00
c015c6ff-540f-4645-809f-eb89d62e7704	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 9zyrnu0h	86000	250000	4	\N	\N	\N	2026-03-23 17:22:22.817+00
490215af-9737-44e3-b788-73861a835cee	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 o0lkelqz	86000	250000	4	\N	\N	\N	2026-03-23 17:22:23.016+00
37a672df-d524-4029-be96-8ed046fc884b	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 2indx9b9	86000	250000	4	\N	\N	\N	2026-03-23 17:22:23.116+00
10969ed3-6430-40d0-8836-e93f5f8e4920	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:53.531+00
255406e7-3609-4dd1-84f9-ed925d67dc87	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:53.619+00
d0bd076a-fa01-4e5a-8bdd-27d90c3576d6	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 4dsmq797	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.018+00
6c104cbb-d7a5-4101-957f-38828ae8ec9d	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 xonirtaw	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.222+00
5448d77d-3268-4f8e-a46a-f6aa827975a5	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	k6 near campus	90000	200000	8	\N	\N	\N	2026-03-23 17:21:54.468+00
e13b67d5-1f51-4ce1-a9e5-e80e66232c96	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 0 2px5larw	80000	250000	3	\N	\N	\N	2026-03-23 17:21:56.001+00
392cb83b-570a-43ea-8ac1-bcbaa5095fa1	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 g6htwdc1	86000	250000	4	\N	\N	\N	2026-03-23 17:22:22.72+00
464821bb-0ff3-4f80-966a-144ceeec3886	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 76 orm6gm15	86000	250000	4	\N	\N	\N	2026-03-23 17:22:22.814+00
1d7705ef-21fa-49d7-8504-6c59a7d86b70	74f8a205-4f43-4666-b5de-9d6c5da4edac	k6 search 77 pk0f9kzk	87000	250000	5	\N	\N	\N	2026-03-23 17:22:23.796+00
7c5712e2-e4c2-4d16-bf87-3b69a3683d95	9e72c822-2ee5-46aa-89cc-3f982efa2929	studio near campus e2e	\N	\N	4	\N	\N	\N	2026-03-23 17:22:47.338+00
\.


--
-- Data for Name: watchlist_items; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.watchlist_items (id, user_id, listing_id, source, added_at, removed_at, is_active) FROM stdin;
36eb6068-3772-46f1-a908-ec974297f668	c2ac34e6-ba60-4ccf-b9d5-dbb06aa31785	11111111-1111-1111-1111-111111111111	search	2026-03-20 16:37:21.244+00	\N	t
1c83378d-43d7-47e2-ba91-35d143b18d4d	f872a417-3409-4bd0-bf41-c7129108554e	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-22 19:25:11.572+00	2026-03-22 19:25:12.127+00	f
6a5e9566-7a76-4508-b7ba-f3c49ec9923b	ed711d1f-2108-4fbc-bf9c-f915dc2d4c36	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 15:12:41.331+00	2026-03-23 15:12:41.548+00	f
cf927202-145e-4f1a-8194-6c9558f02885	958e471b-aa70-4374-a38d-8544ee85b5fc	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-22 20:20:57.263+00	2026-03-22 20:20:58.182+00	f
44233e3d-9808-4cce-b163-04ee8705c317	a4a667b1-c43a-4092-a0d1-a437172faa7a	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-22 23:18:12.469+00	\N	t
f0d04c62-be38-4576-bcb7-0ac63872d93a	9e72c822-2ee5-46aa-89cc-3f982efa2929	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 17:22:48.23+00	2026-03-23 17:22:48.556+00	f
ceef0f6f-8d3b-4025-886d-4342ed8859a6	1e25e645-6ec0-4975-b099-de6b5d40e7d4	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 00:33:09.926+00	2026-03-23 00:33:10.266+00	f
c5ab23c3-b3dd-4913-bd2d-42d3cd405949	1e25e645-6ec0-4975-b099-de6b5d40e7d4	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-23 00:33:11.86+00	2026-03-23 00:33:12.46+00	f
82e54085-f1c0-4efe-a309-fffe322151ce	1e25e645-6ec0-4975-b099-de6b5d40e7d4	11111111-1111-1111-1111-100000000002	k6-search-watchlist	2026-03-23 00:33:13.057+00	\N	t
7ea2f755-c85f-4787-91ad-8b5a7a13dcba	d9c4b3a1-4517-459b-8e71-416b6f3a0df7	aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee	webapp	2026-03-23 00:34:09.131+00	2026-03-23 00:34:09.717+00	f
f150b19c-c7ad-4d5b-93a3-10961b6e7088	322c881d-0e5b-4c58-a8d9-131b5358b8fb	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 03:34:51.986+00	2026-03-23 03:34:52.357+00	f
b95a1142-fdcd-421e-843f-7927553f2a72	322c881d-0e5b-4c58-a8d9-131b5358b8fb	11111111-1111-1111-1111-100000000001	k6-search-watchlist	2026-03-23 03:34:53.058+00	\N	t
739e1162-6e74-4a6a-96e7-136d0bf49c31	893699ca-346f-4aab-bf83-f51809169543	11111111-1111-1111-1111-111111111111	k6	2026-03-20 16:42:36.072+00	2026-03-20 16:42:54.468+00	f
87bf34e5-81f0-405e-86cf-2a29b86e7f06	a1ad9c8b-1335-4f45-863d-a12a1b2b3cda	11111111-1111-1111-1111-111111111111	k6	2026-03-23 17:21:30.623+00	2026-03-23 17:21:54.619+00	f
169d1ded-fbd6-42ae-8b51-60cfc47ac3ed	74f8a205-4f43-4666-b5de-9d6c5da4edac	11111111-1111-1111-1111-100000000000	k6-search-watchlist	2026-03-23 17:21:56.412+00	\N	t
8923c06b-4da2-438b-8e30-41c65f7d8cd8	3383f8b4-4048-4a47-a92d-a4bc3c8c0722	11111111-1111-1111-1111-111111111111	k6	2026-03-20 16:40:43.448+00	2026-03-20 16:40:50.29+00	f
7f2d217f-2c0f-4a75-aa3a-ad56d4fb91b0	74f8a205-4f43-4666-b5de-9d6c5da4edac	11111111-1111-1111-1111-100000000076	k6-search-watchlist	2026-03-23 17:22:23.414+00	2026-03-23 17:22:24.128+00	f
7e0338e3-738d-4d7c-90d1-a004f88d6975	74f8a205-4f43-4666-b5de-9d6c5da4edac	11111111-1111-1111-1111-100000000077	k6-search-watchlist	2026-03-23 17:22:24.397+00	2026-03-23 17:22:24.796+00	f
00e13823-de48-4091-a385-bb5a49ea22bb	09635deb-f21d-4d0a-a4af-bb41cd10b405	11111111-1111-1111-1111-111111111111	k6	2026-03-23 13:31:02.812+00	2026-03-23 13:31:21.626+00	f
\.


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: bookings no_overlapping_bookings; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.bookings
    ADD CONSTRAINT no_overlapping_bookings EXCLUDE USING gist (listing_id WITH =, daterange(start_date, end_date, '[]'::text) WITH &&) WHERE ((status = ANY (ARRAY['confirmed'::booking.booking_status, 'pending_confirmation'::booking.booking_status])));


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- Name: watchlist_items watchlist_items_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.watchlist_items
    ADD CONSTRAINT watchlist_items_pkey PRIMARY KEY (id);


--
-- Name: idx_booking_landlord; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_landlord ON booking.bookings USING btree (landlord_id, created_at DESC);


--
-- Name: idx_booking_listing_status; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_listing_status ON booking.bookings USING btree (listing_id, status);


--
-- Name: idx_booking_outbox_unpublished; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_outbox_unpublished ON booking.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_booking_status_dates; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_status_dates ON booking.bookings USING btree (status, start_date);


--
-- Name: idx_booking_tenant; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_tenant ON booking.bookings USING btree (tenant_id, created_at DESC);


--
-- Name: idx_bookings_listing_id; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_bookings_listing_id ON booking.bookings USING btree (listing_id);


--
-- Name: idx_bookings_status; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_bookings_status ON booking.bookings USING btree (status);


--
-- Name: idx_bookings_tenant_id; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_bookings_tenant_id ON booking.bookings USING btree (tenant_id);


--
-- Name: idx_search_history_user_created; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_search_history_user_created ON booking.search_history USING btree (user_id, created_at DESC);


--
-- Name: idx_watchlist_user_active_added; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_watchlist_user_active_added ON booking.watchlist_items USING btree (user_id, is_active, added_at DESC);


--
-- Name: ux_watchlist_user_listing; Type: INDEX; Schema: booking; Owner: -
--

CREATE UNIQUE INDEX ux_watchlist_user_listing ON booking.watchlist_items USING btree (user_id, listing_id);


--
-- Name: bookings tr_booking_state_transition; Type: TRIGGER; Schema: booking; Owner: -
--

CREATE TRIGGER tr_booking_state_transition BEFORE UPDATE ON booking.bookings FOR EACH ROW EXECUTE FUNCTION booking.enforce_booking_transition();


--
-- Name: bookings tr_booking_updated_at; Type: TRIGGER; Schema: booking; Owner: -
--

CREATE TRIGGER tr_booking_updated_at BEFORE UPDATE ON booking.bookings FOR EACH ROW EXECUTE FUNCTION booking.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict NhLeGfv9mEElNDthB6aJZXbjZ3iAv7OPAgtjbNeye1YkOdHG2CZ3mV8y4Xc0ypH

