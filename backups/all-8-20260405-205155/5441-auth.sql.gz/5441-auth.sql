--
-- PostgreSQL database dump
--

\restrict DZmZTCk0g4dQDbvWb8wJgIsPtGEiaetNxMVTeFbe7E5fqNc7sJJsDYsAOM0JVnW

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: outbox_events; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: idx_auth_outbox_unpublished; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_outbox_unpublished ON auth.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- PostgreSQL database dump complete
--

\unrestrict DZmZTCk0g4dQDbvWb8wJgIsPtGEiaetNxMVTeFbe7E5fqNc7sJJsDYsAOM0JVnW

