--
-- PostgreSQL database dump
--

\restrict ArJOoSGSGSWr81gvzpQPCw0RTkPcD3g81lkO59zFekznfx1nxdJWKxA68l992KN

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: booking; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA booking;


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: booking_status; Type: TYPE; Schema: booking; Owner: -
--

CREATE TYPE booking.booking_status AS ENUM (
    'created',
    'pending_confirmation',
    'confirmed',
    'rejected',
    'cancelled',
    'expired',
    'completed'
);


--
-- Name: enforce_booking_transition(); Type: FUNCTION; Schema: booking; Owner: -
--

CREATE FUNCTION booking.enforce_booking_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  -- created → pending_confirmation (submit to landlord) or cancelled
  IF OLD.status = 'created' AND NEW.status IN ('pending_confirmation', 'cancelled') THEN
    RETURN NEW;
  END IF;

  -- pending_confirmation → confirmed | rejected | cancelled | expired
  IF OLD.status = 'pending_confirmation' AND NEW.status IN ('confirmed', 'rejected', 'cancelled', 'expired') THEN
    RETURN NEW;
  END IF;

  -- confirmed → completed | cancelled
  IF OLD.status = 'confirmed' AND NEW.status IN ('completed', 'cancelled') THEN
    RETURN NEW;
  END IF;

  -- Terminal states: no transitions out
  IF OLD.status IN ('rejected', 'cancelled', 'expired', 'completed') THEN
    RAISE EXCEPTION 'Illegal booking state transition from terminal state % to %', OLD.status, NEW.status;
  END IF;

  RAISE EXCEPTION 'Illegal booking state transition from % to %', OLD.status, NEW.status;
END;
$$;


--
-- Name: FUNCTION enforce_booking_transition(); Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON FUNCTION booking.enforce_booking_transition() IS 'Enforces legal booking lifecycle transitions; terminal states (rejected, cancelled, expired, completed) allow no further changes.';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: booking; Owner: -
--

CREATE FUNCTION booking.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  ELSIF TG_OP = 'INSERT' AND (NEW.version IS NULL OR NEW.version < 1) THEN
    NEW.version := 1;
  END IF;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookings; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    landlord_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status booking.booking_status DEFAULT 'created'::booking.booking_status NOT NULL,
    price_cents_snapshot integer NOT NULL,
    currency_code text DEFAULT 'USD'::text NOT NULL,
    cancellation_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confirmed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    completed_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    payment_status text DEFAULT 'unpaid'::text,
    payment_reference text
);


--
-- Name: TABLE bookings; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON TABLE booking.bookings IS 'Tenant requests on listings. tenant_id/landlord_id = auth users; listing_id = reference to listings DB (no FK).';


--
-- Name: COLUMN bookings.tenant_id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.tenant_id IS 'Auth service user id (consumer).';


--
-- Name: COLUMN bookings.landlord_id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.landlord_id IS 'Auth service user id (listing owner).';


--
-- Name: COLUMN bookings.price_cents_snapshot; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.bookings.price_cents_snapshot IS 'Price at time of booking; immutable. Never join to listing for price at payment.';


--
-- Name: outbox_events; Type: TABLE; Schema: booking; Owner: -
--

CREATE TABLE booking.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON TABLE booking.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: booking; Owner: -
--

COMMENT ON COLUMN booking.outbox_events.payload IS 'Serialized domain event (proto bytes), e.g. BookingCreatedV1; not JSON.';


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.bookings (id, listing_id, tenant_id, landlord_id, start_date, end_date, status, price_cents_snapshot, currency_code, cancellation_reason, created_at, updated_at, confirmed_at, cancelled_at, completed_at, version, payment_status, payment_reference) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: booking; Owner: -
--

COPY booking.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: bookings no_overlapping_bookings; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.bookings
    ADD CONSTRAINT no_overlapping_bookings EXCLUDE USING gist (listing_id WITH =, daterange(start_date, end_date, '[]'::text) WITH &&) WHERE ((status = ANY (ARRAY['confirmed'::booking.booking_status, 'pending_confirmation'::booking.booking_status])));


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: booking; Owner: -
--

ALTER TABLE ONLY booking.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: idx_booking_landlord; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_landlord ON booking.bookings USING btree (landlord_id, created_at DESC);


--
-- Name: idx_booking_listing_status; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_listing_status ON booking.bookings USING btree (listing_id, status);


--
-- Name: idx_booking_outbox_unpublished; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_outbox_unpublished ON booking.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_booking_status_dates; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_status_dates ON booking.bookings USING btree (status, start_date);


--
-- Name: idx_booking_tenant; Type: INDEX; Schema: booking; Owner: -
--

CREATE INDEX idx_booking_tenant ON booking.bookings USING btree (tenant_id, created_at DESC);


--
-- Name: bookings tr_booking_state_transition; Type: TRIGGER; Schema: booking; Owner: -
--

CREATE TRIGGER tr_booking_state_transition BEFORE UPDATE ON booking.bookings FOR EACH ROW EXECUTE FUNCTION booking.enforce_booking_transition();


--
-- Name: bookings tr_booking_updated_at; Type: TRIGGER; Schema: booking; Owner: -
--

CREATE TRIGGER tr_booking_updated_at BEFORE UPDATE ON booking.bookings FOR EACH ROW EXECUTE FUNCTION booking.set_updated_at();


--
-- PostgreSQL database dump complete
--

\unrestrict ArJOoSGSGSWr81gvzpQPCw0RTkPcD3g81lkO59zFekznfx1nxdJWKxA68l992KN

