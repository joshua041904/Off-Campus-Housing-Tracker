--
-- PostgreSQL database dump
--

\restrict aqBhqswRdfXaal0VNJNJrnuMHPA5kDTa9ARfcSd4QD2dknoCx43ZZe8kL3HX4rY

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: messaging; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA messaging;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_message_edited(); Type: FUNCTION; Schema: messaging; Owner: -
--

CREATE FUNCTION messaging.set_message_edited() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.body IS DISTINCT FROM NEW.body OR OLD.deleted_at IS DISTINCT FROM NEW.deleted_at THEN
    NEW.edited_at = now();
    NEW.version = OLD.version + 1;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: messaging; Owner: -
--

CREATE FUNCTION messaging.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: conversation_participants; Type: TABLE; Schema: messaging; Owner: -
--

CREATE TABLE messaging.conversation_participants (
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    last_read_at timestamp with time zone
);


--
-- Name: TABLE conversation_participants; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON TABLE messaging.conversation_participants IS 'Per-user conversation state. last_read_at drives read receipts; MarkAsRead RPC updates it (optionally up to a given message_id). Archive/delete are per-user; never delete conversation globally.';


--
-- Name: conversations; Type: TABLE; Schema: messaging; Owner: -
--

CREATE TABLE messaging.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    conversation_key text
);


--
-- Name: TABLE conversations; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON TABLE messaging.conversations IS 'Conversation container. Optionally scoped by listing_id. Duplicate prevention via app-layer or conversation_key.';


--
-- Name: message_rate_limit; Type: TABLE; Schema: messaging; Owner: -
--

CREATE TABLE messaging.message_rate_limit (
    user_id uuid NOT NULL,
    window_start timestamp with time zone NOT NULL,
    count integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE message_rate_limit; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON TABLE messaging.message_rate_limit IS 'Optional sliding-window rate limit. Prefer Redis (rate:msg:{user_id}). Rule: max 30 messages per minute, 500 per day per user. Cleanup old windows periodically.';


--
-- Name: messages; Type: TABLE; Schema: messaging; Owner: -
--

CREATE TABLE messaging.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    body text,
    message_type text DEFAULT 'text'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    edited_at timestamp with time zone,
    deleted_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    media_id text
);


--
-- Name: TABLE messages; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON TABLE messaging.messages IS 'Messages are soft-deleted (deleted_at). Never hard delete unless admin purge. Unread = count where created_at > participant.last_read_at AND sender_id != current user AND deleted_at IS NULL.';


--
-- Name: COLUMN messages.media_id; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON COLUMN messaging.messages.media_id IS 'Optional reference to media service object; media bytes stored in object storage (MinIO/S3), not here.';


--
-- Name: outbox_events; Type: TABLE; Schema: messaging; Owner: -
--

CREATE TABLE messaging.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON TABLE messaging.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON COLUMN messaging.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: messaging; Owner: -
--

COMMENT ON COLUMN messaging.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Data for Name: conversation_participants; Type: TABLE DATA; Schema: messaging; Owner: -
--

COPY messaging.conversation_participants (conversation_id, user_id, joined_at, archived, deleted, last_read_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: messaging; Owner: -
--

COPY messaging.conversations (id, listing_id, created_at, updated_at, conversation_key) FROM stdin;
\.


--
-- Data for Name: message_rate_limit; Type: TABLE DATA; Schema: messaging; Owner: -
--

COPY messaging.message_rate_limit (user_id, window_start, count) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: messaging; Owner: -
--

COPY messaging.messages (id, conversation_id, sender_id, body, message_type, created_at, edited_at, deleted_at, version, media_id) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: messaging; Owner: -
--

COPY messaging.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Name: conversation_participants conversation_participants_pkey; Type: CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.conversation_participants
    ADD CONSTRAINT conversation_participants_pkey PRIMARY KEY (conversation_id, user_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: message_rate_limit message_rate_limit_pkey; Type: CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.message_rate_limit
    ADD CONSTRAINT message_rate_limit_pkey PRIMARY KEY (user_id, window_start);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: idx_conversation_key_unique; Type: INDEX; Schema: messaging; Owner: -
--

CREATE UNIQUE INDEX idx_conversation_key_unique ON messaging.conversations USING btree (conversation_key) WHERE (conversation_key IS NOT NULL);


--
-- Name: idx_conversation_participants_user; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_conversation_participants_user ON messaging.conversation_participants USING btree (user_id);


--
-- Name: idx_conversation_participants_user_archived_deleted; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_conversation_participants_user_archived_deleted ON messaging.conversation_participants USING btree (user_id, archived, deleted) WHERE (deleted = false);


--
-- Name: idx_conversations_listing; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_conversations_listing ON messaging.conversations USING btree (listing_id);


--
-- Name: idx_message_rate_limit_window; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_message_rate_limit_window ON messaging.message_rate_limit USING btree (window_start);


--
-- Name: idx_messages_conversation_created; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_messages_conversation_created ON messaging.messages USING btree (conversation_id, created_at DESC);


--
-- Name: idx_messages_sender; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_messages_sender ON messaging.messages USING btree (sender_id, created_at DESC);


--
-- Name: idx_messaging_outbox_unpublished; Type: INDEX; Schema: messaging; Owner: -
--

CREATE INDEX idx_messaging_outbox_unpublished ON messaging.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: conversations tr_conversations_updated; Type: TRIGGER; Schema: messaging; Owner: -
--

CREATE TRIGGER tr_conversations_updated BEFORE UPDATE ON messaging.conversations FOR EACH ROW EXECUTE FUNCTION messaging.set_updated_at();


--
-- Name: messages tr_messages_edited; Type: TRIGGER; Schema: messaging; Owner: -
--

CREATE TRIGGER tr_messages_edited BEFORE UPDATE ON messaging.messages FOR EACH ROW EXECUTE FUNCTION messaging.set_message_edited();


--
-- Name: conversation_participants conversation_participants_conversation_id_fkey; Type: FK CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.conversation_participants
    ADD CONSTRAINT conversation_participants_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES messaging.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: messaging; Owner: -
--

ALTER TABLE ONLY messaging.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES messaging.conversations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict aqBhqswRdfXaal0VNJNJrnuMHPA5kDTa9ARfcSd4QD2dknoCx43ZZe8kL3HX4rY

