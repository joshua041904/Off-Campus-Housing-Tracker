--
-- PostgreSQL database dump
--

\restrict agaazJnx4XAKYK3Dih9ew5PcHfmWgihXaVWJfvP0QSsv5recvaaiy1S3V0LO2uk

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: listings; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA listings;


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: listing_status; Type: TYPE; Schema: listings; Owner: -
--

CREATE TYPE listings.listing_status AS ENUM (
    'active',
    'paused',
    'closed',
    'flagged'
);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  ELSIF TG_OP = 'INSERT' AND (NEW.version IS NULL OR NEW.version < 1) THEN
    NEW.version := 1;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: sync_search_norm(); Type: FUNCTION; Schema: listings; Owner: -
--

CREATE FUNCTION listings.sync_search_norm() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.search_norm := lower(trim(coalesce(NEW.title, '') || ' ' || coalesce(NEW.description, '')));
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: listing_media; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.listing_media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid NOT NULL,
    media_type text NOT NULL,
    url_or_path text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT listing_media_media_type_check CHECK ((media_type = ANY (ARRAY['image'::text, 'video'::text])))
);


--
-- Name: listings; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.listings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    username_display text,
    title text,
    listed_at date NOT NULL,
    price_cents integer NOT NULL,
    lease_length_months integer,
    size_sqft integer,
    description text,
    amenities jsonb DEFAULT '[]'::jsonb,
    smoke_free boolean DEFAULT true NOT NULL,
    pet_friendly boolean DEFAULT false NOT NULL,
    furnished boolean,
    effective_from date NOT NULL,
    effective_until date,
    status listings.listing_status DEFAULT 'active'::listings.listing_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    latitude double precision,
    longitude double precision,
    version integer DEFAULT 1 NOT NULL,
    search_norm text,
    listing_code text
);


--
-- Name: TABLE listings; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.listings IS 'Housing listings; user_id references auth.users.id on auth DB (5441). Trust: listing service consumes listing.flagged Kafka event and sets status=flagged (no cross-DB write).';


--
-- Name: COLUMN listings.listed_at; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.listed_at IS 'Listing date (mm-dd-yyyy).';


--
-- Name: COLUMN listings.price_cents; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.price_cents IS 'Rent in cents to avoid float.';


--
-- Name: COLUMN listings.lease_length_months; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.lease_length_months IS 'Lease length in months if fixed.';


--
-- Name: COLUMN listings.effective_from; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.effective_from IS 'When the listing becomes active.';


--
-- Name: COLUMN listings.effective_until; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.effective_until IS 'When the listing stops being effective (NULL = no end).';


--
-- Name: COLUMN listings.deleted_at; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.deleted_at IS 'Soft delete; preserve for analytics. All reads filter deleted_at IS NULL.';


--
-- Name: COLUMN listings.latitude; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.latitude IS 'Location: latitude (distance-from-campus, map).';


--
-- Name: COLUMN listings.longitude; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.longitude IS 'Location: longitude.';


--
-- Name: COLUMN listings.version; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.listings.version IS 'Optimistic lock; increment on update.';


--
-- Name: outbox_events; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_id text NOT NULL,
    type text NOT NULL,
    version integer NOT NULL,
    payload bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    published boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE outbox_events; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.outbox_events IS 'Transactional outbox: same transaction as domain write; background publisher sends EventEnvelope; Kafka key = aggregate_id.';


--
-- Name: COLUMN outbox_events.id; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.outbox_events.id IS 'UUID = envelope.event_id; publisher must set envelope.event_id = this id (no new UUID on publish).';


--
-- Name: COLUMN outbox_events.payload; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON COLUMN listings.outbox_events.payload IS 'Serialized domain event (proto bytes); not JSON.';


--
-- Name: processed_events; Type: TABLE; Schema: listings; Owner: -
--

CREATE TABLE listings.processed_events (
    event_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE processed_events; Type: COMMENT; Schema: listings; Owner: -
--

COMMENT ON TABLE listings.processed_events IS 'Idempotent consumer: before handling event, INSERT event_id; ON CONFLICT DO NOTHING skip; else process then commit offset. Kafka is at-least-once.';


--
-- Data for Name: listing_media; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.listing_media (id, listing_id, media_type, url_or_path, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: listings; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.listings (id, user_id, username_display, title, listed_at, price_cents, lease_length_months, size_sqft, description, amenities, smoke_free, pet_friendly, furnished, effective_from, effective_until, status, created_at, updated_at, deleted_at, latitude, longitude, version, search_norm, listing_code) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.outbox_events (id, aggregate_id, type, version, payload, created_at, published) FROM stdin;
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: listings; Owner: -
--

COPY listings.processed_events (event_id, processed_at) FROM stdin;
\.


--
-- Name: listing_media listing_media_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listing_media
    ADD CONSTRAINT listing_media_pkey PRIMARY KEY (id);


--
-- Name: listings listings_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listings
    ADD CONSTRAINT listings_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: idx_listing_media_listing_id; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listing_media_listing_id ON listings.listing_media USING btree (listing_id);


--
-- Name: idx_listings_active_effective; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_active_effective ON listings.listings USING btree (effective_from, effective_until, price_cents) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_amenities_gin; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_amenities_gin ON listings.listings USING gin (amenities);


--
-- Name: idx_listings_effective_dates; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_effective_dates ON listings.listings USING btree (effective_from, effective_until);


--
-- Name: idx_listings_lat_lon; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_lat_lon ON listings.listings USING btree (latitude, longitude) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_listing_code; Type: INDEX; Schema: listings; Owner: -
--

CREATE UNIQUE INDEX idx_listings_listing_code ON listings.listings USING btree (listing_code) WHERE (listing_code IS NOT NULL);


--
-- Name: idx_listings_listing_code_hash; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_listing_code_hash ON listings.listings USING hash (listing_code) WHERE (listing_code IS NOT NULL);


--
-- Name: idx_listings_outbox_unpublished; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_outbox_unpublished ON listings.outbox_events USING btree (published, created_at) WHERE (published = false);


--
-- Name: idx_listings_price_effective; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_price_effective ON listings.listings USING btree (price_cents, effective_from);


--
-- Name: idx_listings_search_norm_gin; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_search_norm_gin ON listings.listings USING gin (search_norm public.gin_trgm_ops);


--
-- Name: idx_listings_smoke_pet; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_smoke_pet ON listings.listings USING btree (smoke_free, pet_friendly) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_status_effective_until; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_status_effective_until ON listings.listings USING btree (status, effective_until) WHERE ((status = 'active'::listings.listing_status) AND (deleted_at IS NULL));


--
-- Name: idx_listings_user_created; Type: INDEX; Schema: listings; Owner: -
--

CREATE INDEX idx_listings_user_created ON listings.listings USING btree (user_id, created_at DESC);


--
-- Name: listings tr_listings_sync_search_norm; Type: TRIGGER; Schema: listings; Owner: -
--

CREATE TRIGGER tr_listings_sync_search_norm BEFORE INSERT OR UPDATE OF title, description ON listings.listings FOR EACH ROW EXECUTE FUNCTION listings.sync_search_norm();


--
-- Name: listings tr_listings_updated_at; Type: TRIGGER; Schema: listings; Owner: -
--

CREATE TRIGGER tr_listings_updated_at BEFORE UPDATE ON listings.listings FOR EACH ROW EXECUTE FUNCTION listings.set_updated_at();


--
-- Name: listing_media listing_media_listing_id_fkey; Type: FK CONSTRAINT; Schema: listings; Owner: -
--

ALTER TABLE ONLY listings.listing_media
    ADD CONSTRAINT listing_media_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES listings.listings(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict agaazJnx4XAKYK3Dih9ew5PcHfmWgihXaVWJfvP0QSsv5recvaaiy1S3V0LO2uk

