# External DB schema report — 20260324-210748

Generated: 2026-03-24T21:07:48-04:00

Host: `127.0.0.1` (user: postgres).

Inspected DB targets:

| Port | DB | Label |
|------|----|-------|
| `5441` | `auth` | `auth` |
| `5442` | `listings` | `listings` |
| `5443` | `bookings` | `bookings` |
| `5444` | `messaging` | `messaging` |
| `5445` | `notification` | `notification` |
| `5446` | `trust` | `trust` |
| `5447` | `analytics` | `analytics` |
| `5448` | `media` | `media` |

---

## Port 5441 — auth (`auth`)

### Actual tables (from DB)

 schema |     table_name     |  size  
--------+--------------------+--------
 auth   | mfa_settings       | 136 kB
 auth   | oauth_providers    | 40 kB
 auth   | passkey_challenges | 40 kB
 auth   | passkeys           | 56 kB
 auth   | sessions           | 24 kB
 auth   | user_addresses     | 40 kB
 auth   | users              | 344 kB
 auth   | verification_codes | 120 kB
(8 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `auth.users` |
| `auth.sessions` |
| `auth.mfa_settings` |
| `auth.oauth_providers` |
| `auth.passkeys` |
| `auth.passkey_challenges` |
| `auth.verification_codes` |
| `auth.user_addresses` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5442 — listings (`listings`)

### Actual tables (from DB)

  schema  |    table_name    |    size    
----------+------------------+------------
 listings | listing_media    | 24 kB
 listings | listings         | 240 kB
 listings | outbox_events    | 24 kB
 listings | processed_events | 8192 bytes
(4 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `listings.listings` |
| `listings.outbox_events` |
| `listings.processed_events` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5443 — bookings (`bookings`)

### Actual tables (from DB)

 schema  |   table_name    |  size  
---------+-----------------+--------
 booking | bookings        | 152 kB
 booking | outbox_events   | 24 kB
 booking | search_history  | 664 kB
 booking | watchlist_items | 192 kB
(4 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `booking.bookings` |
| `booking.outbox_events` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5444 — messaging (`messaging`)

### Actual tables (from DB)

  schema   |        table_name         |  size  
-----------+---------------------------+--------
 forum     | comment_attachments       | 112 kB
 forum     | comment_votes             | 112 kB
 forum     | comments                  | 144 kB
 forum     | post_attachments          | 112 kB
 forum     | post_votes                | 72 kB
 forum     | posts                     | 408 kB
 messages  | group_bans                | 88 kB
 messages  | group_members             | 120 kB
 messages  | groups                    | 120 kB
 messages  | message_attachments       | 112 kB
 messages  | message_reads             | 112 kB
 messages  | messages                  | 856 kB
 messages  | user_archived_threads     | 72 kB
 messages  | user_deleted_threads      | 72 kB
 messaging | conversation_participants | 24 kB
 messaging | conversations             | 56 kB
 messaging | messages                  | 96 kB
 messaging | outbox_events             | 88 kB
(18 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `messaging.conversations` |
| `messaging.messages` |
| `messaging.outbox_events` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5445 — notification (`notification`)

### Actual tables (from DB)

    schema    |    table_name    |    size    
--------------+------------------+------------
 notification | notifications    | 40 kB
 notification | outbox_events    | 24 kB
 notification | processed_events | 8192 bytes
 notification | user_preferences | 8192 bytes
(4 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `notification.user_preferences` |
| `notification.outbox_events` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5446 — trust (`trust`)

### Actual tables (from DB)

 schema |    table_name    |    size    
--------+------------------+------------
 trust  | listing_flags    | 40 kB
 trust  | outbox_events    | 24 kB
 trust  | processed_events | 8192 bytes
 trust  | reputation       | 8192 bytes
 trust  | reviews          | 40 kB
 trust  | user_flags       | 40 kB
 trust  | user_spam_score  | 40 kB
 trust  | user_suspensions | 32 kB
(8 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `trust.outbox_events` |
| `trust.processed_events` |
| `trust.reputation` |
| `trust.user_spam_score` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5447 — analytics (`analytics`)

### Actual tables (from DB)

  schema   |         table_name         |    size    
-----------+----------------------------+------------
 analytics | daily_metrics              | 8192 bytes
 analytics | events                     | 40 kB
 analytics | listing_feel_cache         | 24 kB
 analytics | processed_events           | 8192 bytes
 analytics | projection_state           | 16 kB
 analytics | projection_versions        | 16 kB
 analytics | recommendation_experiments | 16 kB
 analytics | recommendation_models      | 24 kB
 analytics | recommendation_weights     | 16 kB
 analytics | user_activity              | 8192 bytes
 analytics | user_listing_engagement    | 16 kB
 analytics | user_watchlist_daily       | 8192 bytes
(12 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `analytics.events` |
| `analytics.processed_events` |
| `analytics.daily_metrics` |

### Integrity check

✅ **Match** — All expected tables present.

## Port 5448 — media (`media`)

### Actual tables (from DB)

 schema |  table_name   | size  
--------+---------------+-------
 media  | media_files   | 96 kB
 media  | outbox_events | 80 kB
(2 rows)


### Expected tables (from infra/db and auth dump)

| schema.table |
|--------------|
| `media.media_files` |
| `media.outbox_events` |

### Integrity check

✅ **Match** — All expected tables present.

---

## Data integrity summary

✅ All DBs match expected schema (from infra/db and auth dump). Safe to run tests.

